/*! Copyright (c) 2021 WhatsApp Inc. All Rights Reserved. */
(() => {
    "use strict";
    var e = {
            612: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.MMS_URL_MEDIA_TYPE_SEARCH_PARAM = t.IS_MMS_URL_SEARCH_PARAM = void 0;
                t.IS_MMS_URL_SEARCH_PARAM = "__wa-mms";
                t.MMS_URL_MEDIA_TYPE_SEARCH_PARAM = "mms-type"
            },
            541: (e, t, r) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var a = s(r(303)),
                    n = s(r(135));

                function s(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                class c extends n.default {
                    constructor(...e) {
                        super(...e), this.matchFetch = e => {
                            var {
                                request: t
                            } = e, r = n.default.parseUrl(t.url);
                            return t.method === n.default.RequestType.GET && !!r && r.base === self.registration.scope && !!r.relativePath.match("^img/")
                        }, this.onFetch = e => {
                            var {
                                request: t
                            } = e;
                            return this.cache.matchOrFetch(t).then((e => e.ok ? e : this.cache.fetchAndPut(t)))
                        }, this.matchAction = e => a.default.CLEAN_ASSETS === e, this.onAction = (e, t) => {
                            var r = new Set(t);
                            return this.cache.keys().then((e => {
                                if (e) {
                                    var t = [];
                                    return e.forEach((e => {
                                        var a = e.url.lastIndexOf("/") + 1,
                                            n = e.url.slice(a);
                                        r.has(n) || t.push(e)
                                    })), Promise.all(t.map((e => this.cache.delete(e))))
                                }
                            })).then((() => {}))
                        }
                    }
                }
                t.default = c
            },
            286: (e, t, r) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var a = o(r(303)),
                    n = o(r(492)),
                    s = o(r(135)),
                    c = o(r(621));

                function o(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                class i extends s.default {
                    constructor(e, t) {
                        super(e, t), this.matchInstall = () => !0, this.onInstall = () => this.store.get("l10n").then((e => (this.cacheObject.hashedResources.push(...this.cachedL10nHashes(this.cacheObject, e)), this.cache.update(this.cacheObject.hashedResources, this.cacheObject.unhashedResources)))), this.matchActivate = () => !0, this.onActivate = () => this.cache.cleanup(), this.matchFetch = e => {
                            var {
                                request: t
                            } = e, r = s.default.parseUrl(t.url);
                            return t.method === s.default.RequestType.GET && !this.isCacheStale() && !!r && r.base === self.registration.scope && this.cacheList.has(r.relativePath)
                        }, this.onFetch = e => {
                            var {
                                request: t
                            } = e, r = s.default.parseUrl(t.url);
                            return r ? this.cache.matchOrFetch(t, "".concat(r.base).concat(r.relativePath)) : self.fetch(t)
                        }, this.matchAction = e => e === a.default.SET_L10N, this.onAction = (e, t) => this.store.get("l10n").then((e => {
                            if (!e || t.locale !== e.locale) {
                                var [r] = this.cachedL10nHashes(this.cacheObject, t);
                                if (!r) return this.store.delete("l10n");
                                var a = "".concat(self.registration.scope).concat(c.default.getIndexPath(t));
                                return Promise.all([this.cache.fetchAndPut(a, self.registration.scope), this.store.put("l10n", {
                                    locale: t.locale,
                                    isRTL: t.isRTL
                                })])
                            }
                        })).then((() => {})), this.cacheObject = n.default, this.cacheList = new Set([...this.cacheObject.hashedResources, ...this.cacheObject.unhashedResources, ...Object.keys(this.cacheObject.l10n.locales).map((e => this.cacheObject.l10n.locales[e]))])
                    }
                    cachedL10nHashes(e, t = {}) {
                        var {
                            locale: r
                        } = t, a = e.l10n.locales[r];
                        return a ? [a] : []
                    }
                    isCacheStale() {
                        return (new Date).getTime() - this.cacheObject.releaseDate >= 2592e6
                    }
                }
                t.default = i
            },
            580: (e, t, r) => {
                var a = r(329).log;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var n = s(r(621));

                function s(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }

                function c() {
                    var e = m(["Could not find previous cache, current cache:", ", error: ", ""]);
                    return c = function() {
                        return e
                    }, e
                }

                function o() {
                    var e = m(["Unable to match request: ", ", in cache: ", ", error: ", ""]);
                    return o = function() {
                        return e
                    }, e
                }

                function i() {
                    var e = m(["Unable to delete request: ", ", in cache: ", ", error: ", ""]);
                    return i = function() {
                        return e
                    }, e
                }

                function l() {
                    var e = m(["Unable to put in cache: ", ", request: ", ", response status: ", ", err: ", ""]);
                    return l = function() {
                        return e
                    }, e
                }

                function u() {
                    var e = m(["Unable to match request: ", ", in cache: ", ", error: ", ""]);
                    return u = function() {
                        return e
                    }, e
                }

                function d() {
                    var e = m(["Unable to fetch request: ", ", error: ", ""]);
                    return d = function() {
                        return e
                    }, e
                }

                function f() {
                    var e = m(["Received invalid response, url: ", ", status: ", ", type: ", ""]);
                    return f = function() {
                        return e
                    }, e
                }

                function h() {
                    var e = m(["Unable to delete cache: ", ", current cache: ", ", error: ", ""]);
                    return h = function() {
                        return e
                    }, e
                }

                function b() {
                    var e = m(["Unable to match prev. cache, cache name: ", ", request: ", ", error: ", ""]);
                    return b = function() {
                        return e
                    }, e
                }

                function p() {
                    var e = m(["Error occured while updating cache:", ", error: ", ""]);
                    return p = function() {
                        return e
                    }, e
                }

                function v() {
                    var e = m(["Updating cache: ", ""]);
                    return v = function() {
                        return e
                    }, e
                }

                function m(e, t) {
                    return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(t)
                        }
                    }))
                }
                var _ = s(r(274)).default.prefs,
                    g = self.caches.keys(),
                    j = /wa\d+\.\d+\.\d+(\.[id])?(\.canary)?$/,
                    y = ["wa-pp", "wa-assets", "wa-stickers"];

                function w(e) {
                    this.cacheName = e, this.openCachePromise = self.caches.open(this.cacheName)
                }
                w.prototype = {
                    update(e, t) {
                        return function(e) {
                            return g.then((t => {
                                var r = t.find((t => t !== e && j.test(t)));
                                if (r) return new w(r)
                            })).catch((e => {
                                a(3)(c(), this.cacheName, e)
                            }))
                        }(this.cacheName).then((r => {
                            if (r) return a(2)(v(), this.cacheName), _.get("l10n").then((a => Promise.all(this.prefetchHashedResources(e, r).concat(this.prefetchUnhashedResources(t, a)))))
                        })).catch((e => {
                            a(3)(p(), this.cacheName, e)
                        }))
                    },
                    prefetchHashedResources(e, t) {
                        return e.map((e => {
                            var r = self.registration.scope + e;
                            return t.match(r).catch((e => {
                                a(3)(b(), t.cacheName, r, e)
                            })).then((e => e ? this.put(r, e) : this.fetchAndPut(r)))
                        }))
                    },
                    prefetchUnhashedResources(e, t) {
                        return e.map((e => "" === e ? this.fetchAndPut(self.registration.scope + n.default.getIndexPath(t), self.registration.scope, {
                            cache: "reload"
                        }) : this.fetchAndPut(self.registration.scope + e)))
                    },
                    cleanup() {
                        return g.then((e => Promise.all(e.map((e => {
                            if (e !== this.cacheName && !y.includes(e)) return self.caches.delete(e).catch((t => {
                                a(3)(h(), e, this.cacheName, t)
                            }))
                        })))))
                    },
                    matchOrFetch(e, t, r) {
                        var a = t || R(e);
                        return this.match(a).then((t => t || this.fetchAndPut(e, a, r)))
                    },
                    fetchAndPut(e, t, r) {
                        var s = n.default.manuallyCloneRequest(e, void 0, {
                            redirect: "manual",
                            mode: "cors"
                        });
                        return self.fetch(s, r).then((r => {
                            if (r.ok) {
                                var n = t || R(e);
                                this.put(n, r.clone())
                            } else "opaqueredirect" !== r.type && a(3)(f(), r.url, r.status, r.type);
                            return r
                        })).catch((t => {
                            throw a(3)(d(), R(e), t), t
                        }))
                    },
                    reset() {
                        return this.openCachePromise = self.caches.delete(this.cacheName).then((() => self.caches.open(this.cacheName)))
                    },
                    match(e, t) {
                        return this.openCachePromise.then((r => r.match(e, t))).catch((t => {
                            a(3)(u(), R(e), this.cacheName, t)
                        }))
                    },
                    put(e, t) {
                        return this.openCachePromise.then((r => r.put(e, t))).catch((r => {
                            a(3)(l(), this.cacheName, R(e), t.status, r)
                        }))
                    },
                    delete(e, t) {
                        return this.openCachePromise.then((r => r.delete(e, t))).catch((t => {
                            a(3)(i(), R(e), this.cacheName, t)
                        }))
                    },
                    keys(e, t) {
                        return this.openCachePromise.then((r => r.keys(e, t))).catch((t => {
                            a(3)(o(), R(e), this.cacheName, t)
                        }))
                    }
                };
                var P = w;

                function R(e) {
                    return e instanceof Request ? e.url : e
                }
                t.default = P
            },
            329: (e, t, r) => {
                var a = r(329).log;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.upload = P, t.log = void 0;
                var n = i(r(303)),
                    s = i(r(72)),
                    c = i(r(301)),
                    o = i(r(583));

                function i(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }

                function l() {
                    var e = function(e, t) {
                        t || (t = e.slice(0));
                        return Object.freeze(Object.defineProperties(e, {
                            raw: {
                                value: Object.freeze(t)
                            }
                        }))
                    }(["Unable to send upload request, error: ", ""]);
                    return l = function() {
                        return e
                    }, e
                }
                var u, d = "log",
                    f = "info",
                    h = "warn",
                    b = "error",
                    p = "errorVerbose",
                    v = [],
                    m = Promise.resolve();
                var _, g, j, y, w = (_ = function() {
                    return 0 === v.length ? Promise.resolve() : o.default.broadcast(n.default.LOG, {
                        buffer: v
                    }).then((e => {
                        v = []
                    })).catch((() => {}))
                }, g = 500, function e() {
                    if (j) return y = !0, j;
                    var t = Array.prototype.slice.call(arguments);
                    return j = new Promise((function(r) {
                        self.setTimeout((function() {
                            j = null, y && (r(e.apply(null, t)), y = !1), r()
                        }), g)
                    })), Promise.resolve(_.apply(null, t))
                });

                function P(...e) {
                    return e.length && v.push({
                        level: p,
                        message: e
                    }), u = u || R()
                }

                function R(e = 0) {
                    return m.then((() => o.default.broadcast(n.default.UPLOAD_LOGS, {
                        buffer: v
                    }))).catch((() => e < 3 ? function(e) {
                        return new Promise((t => {
                            setTimeout(t, e)
                        }))
                    }(1e3).then((() => R(e + 1))) : Promise.reject("Max generation reached. Failed to upload."))).then((e => (u = void 0, e))).catch((e => {
                        a(3)(l(), e), u = void 0
                    }))
                }
                var S = (0, c.default)(((e, t = !1, r, a, n) => (c, ...o) => {
                    var i, l = (0, s.default)(c, o, !t);
                    return r && (i = {
                            name: r.name,
                            stack: r.stack
                        }),
                        function(e, t, r, a, n) {
                            if (0 === t.length) return;
                            v.push({
                                level: e,
                                message: t,
                                error: r,
                                attachedToSendLogs: a,
                                extraTags: n
                            }), m = w()
                        }(function(e, t) {
                            switch (e) {
                                case 1:
                                    return f;
                                case 2:
                                    return d;
                                case 3:
                                    return h;
                                case 4:
                                    return t ? p : b
                            }
                            throw new Error("Invalid numeric level ".concat(e).concat(t ? ", verbose" : ""))
                        }(e, t), [l], i, a, n), l
                }), ((e, t, r, a, n) => r || n ? null : String(e) + String(Boolean(t)) + String(Boolean(a))));
                t.log = S, self.addEventListener("error", (e => {
                    P("Global Scope error: ".concat(String(e.error), ", stack: ").concat(e.error ? e.error.stack : ""))
                }))
            },
            303: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = {
                    REQUEST_STREAMING_INFO: "GET_STREAMING_INFO",
                    REQUEST_RMR: "REQUEST_RMR",
                    SEND_STREAMING_CHUNK: "SEND_STREAMING_CHUNK",
                    EXP_BACKOFF: "EXP_BACKOFF",
                    LOG: "LOG",
                    UPLOAD_LOGS: "UPLOAD_LOGS",
                    REQUEST_DOCUMENT_DOWNLOAD: "REQUEST_DOCUMENT_DOWNLOAD",
                    SET_L10N: "SET_L10N",
                    STREAMING_SUPPORTED: "STREAMING_SUPPORTED",
                    REMOVE_PP: "REMOVE_PP",
                    LOGOUT: "LOGOUT",
                    CLEAN_ASSETS: "CLEAN_ASSETS",
                    PRELOAD_LAZY_LOADED_BUNDLES: "PRELOAD_LAZY_LOADED_BUNDLES"
                };
                t.default = r
            },
            583: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                class r {
                    constructor(e) {
                        this.onMessage = e => {
                            if (e.data && e.data.action) {
                                var t = e.data;
                                if (e.ports && 0 !== e.ports.length) {
                                    var a = e.ports;
                                    if (r.isSW() || !window.navigator.serviceWorker || e.source === window.navigator.serviceWorker.controller)("function" == typeof e.waitUntil ? t => e.waitUntil(t) : () => {})(Promise.resolve(this.requestHandler(t)).then((e => {
                                        a[0].postMessage(e)
                                    })).catch((e => {
                                        a[0].postMessage({
                                            error: e && e.toString()
                                        })
                                    })))
                                }
                            }
                        }, this.requestHandler = e
                    }
                    init() {
                        var e = r.isSW() ? self : window.navigator.serviceWorker;
                        try {
                            if (!e) return;
                            e.addEventListener("message", this.onMessage)
                        } catch (e) {}
                    }
                    static isSW() {
                        return "undefined" == typeof window
                    }
                    static getRequestor(e) {
                        return r.isSW() ? "string" == typeof e ? self.clients.get(e) : Promise.resolve(e) : window.navigator.serviceWorker ? window.navigator.serviceWorker.ready.then((() => window.navigator.serviceWorker ? window.navigator.serviceWorker.controller : null)) : Promise.resolve(null)
                    }
                    static broadcast(e, t) {
                        return r.isSW() ? self.clients.matchAll().then((a => 0 === a.length ? Promise.reject("No clients available.") : Promise.all(a.map((a => r.request(a, e, t)))))) : Promise.reject(new Error("Broadcast called from non-serviceworker."))
                    }
                    static request(e, t, a) {
                        var n = new MessageChannel;
                        return new Promise(((s, c) => (n.port1.onmessage = e => {
                            e.data && e.data.error ? c(e.data.error) : s(e.data)
                        }, r.getRequestor(e).then((e => {
                            if (!e) return c("No ServiceWorker controlling this client.");
                            e.postMessage({
                                action: t,
                                message: a,
                                version: "2.2112.10"
                            }, [n.port2])
                        })))))
                    }
                }
                t.default = r
            },
            274: (e, t, r) => {
                var a;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var n = ((a = r(402)) && a.__esModule ? a : {
                    default: a
                }).default;
                t.default = n
            },
            402: (e, t, r) => {
                var a = r(329).log;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var n = c(r(98)),
                    s = c(r(315));

                function c(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }

                function o() {
                    var e = h(["Unable to clear object store: ", ", error: ", ""]);
                    return o = function() {
                        return e
                    }, e
                }

                function i() {
                    var e = h(["Unable to delete in db, object store: ", ", key: ", ", error: ", ""]);
                    return i = function() {
                        return e
                    }, e
                }

                function l() {
                    var e = h(["Unable to put to db, object store: ", ", key: ", ", value: ", ", error: ", ""]);
                    return l = function() {
                        return e
                    }, e
                }

                function u() {
                    var e = h(["Unable to fetch from db, object store: ", ", key: ", ", error: ", ""]);
                    return u = function() {
                        return e
                    }, e
                }

                function d() {
                    var e = h(["Unable to open sw database, error: ", ""]);
                    return d = function() {
                        return e
                    }, e
                }

                function f() {
                    var e = h(["Unable to upgrade database, error: ", ""]);
                    return f = function() {
                        return e
                    }, e
                }

                function h(e, t) {
                    return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(t)
                        }
                    }))
                }
                var b, p = {
                    prefs: {},
                    pp: {},
                    stickers: {}
                };
                class v {
                    constructor(e) {
                        this.storeName = e, this.storeCache = {}
                    }
                    _callAction(e, t) {
                        return (b || (b = new Promise(((e, t) => {
                            var r = (0, s.default)(n.default).open("sw", 2);
                            r.onupgradeneeded = e => {
                                var t = e.target.result;
                                for (var r in e.target.transaction.onerror = e => {
                                        a(3)(f(), e.target.error)
                                    }, p) t.objectStoreNames.contains(r) && t.deleteObjectStore(r), t.createObjectStore(r, p[r])
                            }, r.onsuccess = t => {
                                e(t.target.result)
                            }, r.onerror = e => {
                                t(e.target.error)
                            }
                        })).catch((e => {
                            throw a(3)(d(), e), b = void 0, e
                        })))).then((r => {
                            var a = r.transaction([this.storeName], "readwrite").objectStore(this.storeName),
                                n = a[e].apply(a, t);
                            return new Promise(((e, t) => {
                                n.onsuccess = t => {
                                    e(t.target.result)
                                }, n.onerror = e => {
                                    t(e.target.error)
                                }
                            }))
                        }))
                    }
                    get(e) {
                        return void 0 !== this.storeCache[e] ? this.storeCache[e] : this.storeCache[e] = this._callAction("get", [e]).catch((t => {
                            a(3)(u(), this.storeName, e, t), this.storeCache[e] = void 0
                        }))
                    }
                    put(e, t) {
                        return this.storeCache[e] = Promise.resolve(t), this._callAction("put", [t, e]).catch((r => {
                            a(3)(l(), this.storeName, e, t, r)
                        }))
                    }
                    delete(e) {
                        return this.storeCache[e] = Promise.resolve(void 0), this._callAction("delete", [e]).catch((t => {
                            a(3)(i(), this.storeName, e, t)
                        }))
                    }
                    clear() {
                        return this.storeCache = {}, this._callAction("clear").catch((e => {
                            a(3)(o(), this.storeName, e)
                        }))
                    }
                }
                var m = {
                    ObjectStore: v
                };
                for (var _ in p) m[_] = new v(_);
                var g = m;
                t.default = g
            },
            496: (e, t, r) => {
                var a = r(329).log;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var n = c(r(303)),
                    s = c(r(135));

                function c(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }

                function o() {
                    var e = function(e, t) {
                        t || (t = e.slice(0));
                        return Object.freeze(Object.defineProperties(e, {
                            raw: {
                                value: Object.freeze(t)
                            }
                        }))
                    }(["Unexpected pp url ", ""]);
                    return o = function() {
                        return e
                    }, e
                }
                class i extends s.default {
                    constructor(...e) {
                        super(...e), this.matchFetch = e => {
                            var {
                                request: t
                            } = e, r = s.default.parseUrl(t.url);
                            return t.method === s.default.RequestType.GET && !!r && ("https://web.whatsapp.com/" === r.base || "https://dyn.web.whatsapp.com/" === r.base) && "pp" === r.relativePath
                        }, this.onFetch = e => {
                            var {
                                request: t
                            } = e, r = s.default.parseUrl(t.url);
                            if (!r || !r.queryParams) return self.fetch(t);
                            var {
                                e: a,
                                t: n,
                                u: c,
                                i: o,
                                n: i
                            } = r.queryParams, u = "".concat(r.base).concat(r.relativePath, "?t=").concat(n, "&u=").concat(c, "&i=").concat(o, "&n=").concat(i), d = a ? self.decodeURIComponent(a) : t;
                            return l(a ? self.decodeURIComponent(a) : t.url), this.cache.matchOrFetch(d, u).then((e => (e.ok && this.store.get(c).then((e => {
                                if (e !== o) return Promise.all([this.removePPFromCache(c, o), this.store.put(c, o)])
                            })), l(e.url), e)))
                        }, this.matchAction = e => n.default.REMOVE_PP === e || n.default.LOGOUT === e, this.onAction = (e, t) => {
                            switch (e) {
                                case n.default.REMOVE_PP:
                                    var r = self.encodeURIComponent(t);
                                    return this.store.get(r).then((e => {
                                        if (e) return Promise.all([this.removePPFromCache(r, e), this.store.delete(r)])
                                    })).then((() => {}));
                                default:
                                    return Promise.all([this.cache.reset(), this.store.clear()]).then((() => {}))
                            }
                        }
                    }
                    removePPFromCache(e, t) {
                        return Promise.all([this.cache.delete("https://web.whatsapp.com/pp?t=s&u=".concat(e, "&i=").concat(t)), this.cache.delete("https://web.whatsapp.com/pp?t=l&u=".concat(e, "&i=").concat(t)), this.cache.delete("https://dyn.web.whatsapp.com/pp?t=s&u=".concat(e, "&i=").concat(t)), this.cache.delete("https://dyn.web.whatsapp.com/pp?t=l&u=".concat(e, "&i=").concat(t))])
                    }
                }

                function l(e) {
                    var t = new URL(e),
                        r = t.host;
                    if ("https:" !== t.protocol || !/\.whatsapp\.(net|com)(:\d+)?$/.test(r)) throw a(4, void 0, new Error)(o(), e), new Error("Profile picture URL is not of allowed host or protocol")
                }
                t.default = i
            },
            14: (e, t, r) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var a, n = r(612),
                    s = (a = r(135)) && a.__esModule ? a : {
                        default: a
                    };
                class c extends s.default {
                    constructor(...e) {
                        super(...e), this.matchFetch = e => {
                            var {
                                request: t
                            } = e, r = new URL(t.url), a = new URLSearchParams(r.search);
                            return t.method === s.default.RequestType.GET && a.has(n.IS_MMS_URL_SEARCH_PARAM) && (0 === r.pathname.indexOf("/mms/sticker/") || "sticker" === a.get(n.MMS_URL_MEDIA_TYPE_SEARCH_PARAM))
                        }, this.onFetch = e => this.cache.matchOrFetch(e.request)
                    }
                }
                t.default = c
            },
            907: (e, t, r) => {
                var a = r(329).log;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var n, s = (n = r(583)) && n.__esModule ? n : {
                    default: n
                };

                function c() {
                    var e = u(["onActivate error: ", "."]);
                    return c = function() {
                        return e
                    }, e
                }

                function o() {
                    var e = u(["Activating..."]);
                    return o = function() {
                        return e
                    }, e
                }

                function i() {
                    var e = u(["onInstall error: ", ""]);
                    return i = function() {
                        return e
                    }, e
                }

                function l() {
                    var e = u(["Installing..."]);
                    return l = function() {
                        return e
                    }, e
                }

                function u(e, t) {
                    return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(t)
                        }
                    }))
                }
                t.default = e => {
                    self.addEventListener("install", (function(t) {
                        a(2)(l());
                        var r = e.filter((e => e.matchInstall(t))).map((e => Promise.resolve(e.onInstall(t))));
                        t.waitUntil(Promise.all(r).then((() => self.skipWaiting())).catch((e => {
                            a(3)(i(), String(e))
                        })))
                    })), self.addEventListener("activate", (function(t) {
                        a(2)(o());
                        var r = e.filter((e => e.matchActivate(t))).map((e => e.onActivate(t)));
                        t.waitUntil(self.clients.claim().then((() => Promise.all(r))).catch((e => {
                            a(3)(c(), e)
                        })))
                    })), self.addEventListener("fetch", (function(t) {
                        var r = e.find((e => e.matchFetch(t)));
                        if (r) return t.respondWith(r.onFetch(t))
                    })), new s.default((({
                        action: t,
                        message: r
                    }) => {
                        var a = e.find((e => e.matchAction(t)));
                        return a ? a.onAction(t, r) : Promise.reject("Invalid Action: ".concat(t))
                    })).init()
                }
            },
            492: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                t.default = {
                    version: "2.2112.10",
                    hashedResources: ["bootstrap_main.5740c4197306d09aaad9.js", "bootstrap_qr.2f82ee7dd80cf0cef06e.js", "early_error_handling.4fd403f4a7e8b07dbe3e.js", "lazy_loaded_high_priority_components.afdfc7fd7491545984ae.js", "lazy_loaded_high_priority_components~lazy_loaded_low_priority_components.44a7a4447c63538039be.js", "lazy_loaded_low_priority_components.7a7efefeaa3e55cba403.js", "libsignal-protocol-4a88682.min.js", "pdf.worker.96d1bc1f3d0105cd5a81bae7a9dad228.js", "svg.4d3a5cc47232a6862b80.js", "vendor1~bootstrap_qr.69e960b196d7d6aa3d46.js", "vendors~bootstrap_main.c1b7995b54edd057ce1f.js", "vendors~lazy_loaded_high_priority_components~lazy_loaded_low_priority_components.0d95f3cee944da5fc9ac.js", "vendors~lazy_loaded_low_priority_components.8ae1e37355137d9e440b.js", "vendors~pdf.8190509a7c5c75ae57d7.js", "vendors~unorm.fda875c14206939717ad.js", "bootstrap_main.dd24c69b26ac7574401a.css", "bootstrap_qr-165277ab61dff9c7534e.css", "browsers_3345ebb0e6be6007db1a.css", "lazy_loaded_high_priority_components.22745edfeaa6219de64f.css", "lazy_loaded_high_priority_components~lazy_loaded_low_priority_components.01f2b9c4f6ebc5d7294a.css", "lazy_loaded_low_priority_components.08f7c3ad5375f4212881.css"],
                    unhashedResources: ["apple-touch-icon.png", "bryndan_write_20e48b2ec8c64b2a1ceb5b28d9bcc9d0.ttf", "crossdomain.xml", "favicon-48x48.ico", "favicon-64x64.ico", "favicon.ico", "notification_2a485d84012c106acef03b527bb54635.mp3", "robots.txt", "sequential-ptt-end_62ed28be622237546fd39f9468a76a49.mp3", "sequential-ptt-middle_7fa161964e93db72b8d00ae22189d75f.mp3", "whatsapp-webclient-login_a0f99e8cbba9eaa747ec23ffb30d63fe.mp4", "whatsapp-webclient-login-hq_10ce945f706bbd216466cd05f672164d.mp4"],
                    l10n: {
                        locales: {
                            "af.edb608fe682d7c8319c8.js": "locales/af.edb608fe682d7c8319c8.js",
                            "ar.7bc4b2d01ab368be751d.js": "locales/ar.7bc4b2d01ab368be751d.js",
                            "az.ecd4595b73602af25512.js": "locales/az.ecd4595b73602af25512.js",
                            "bg.963e63340c02944bda24.js": "locales/bg.963e63340c02944bda24.js",
                            "bn.1f166a4394bda86ebd96.js": "locales/bn.1f166a4394bda86ebd96.js",
                            "ca.1fc6afc3c9881330fe5d.js": "locales/ca.1fc6afc3c9881330fe5d.js",
                            "cs.05274bea98e0cc62cb24.js": "locales/cs.05274bea98e0cc62cb24.js",
                            "da.bee48408a34207f87320.js": "locales/da.bee48408a34207f87320.js",
                            "de.faf8fbe81bbc91316f7b.js": "locales/de.faf8fbe81bbc91316f7b.js",
                            "el.25c2eba5a8a758121fd4.js": "locales/el.25c2eba5a8a758121fd4.js",
                            "en.fbb2b50f3de094b1ed93.js": "locales/en.fbb2b50f3de094b1ed93.js",
                            "es.c0665ba6a23e66c8068b.js": "locales/es.c0665ba6a23e66c8068b.js",
                            "et.08c46fc7e90dcb6dab07.js": "locales/et.08c46fc7e90dcb6dab07.js",
                            "fa.e69e93238117e7937443.js": "locales/fa.e69e93238117e7937443.js",
                            "fi.f190c9a0a2d42d69431e.js": "locales/fi.f190c9a0a2d42d69431e.js",
                            "fil.e3b0cd085d7d535675ae.js": "locales/fil.e3b0cd085d7d535675ae.js",
                            "fr.14b84afb28b831a4fbf9.js": "locales/fr.14b84afb28b831a4fbf9.js",
                            "gu.d7f987927749d24f15f7.js": "locales/gu.d7f987927749d24f15f7.js",
                            "he.317d2ee4ca8fa75f29fa.js": "locales/he.317d2ee4ca8fa75f29fa.js",
                            "hi.ad71fac989e93fa3f0bf.js": "locales/hi.ad71fac989e93fa3f0bf.js",
                            "hr.91a2c734b5a6737ccc82.js": "locales/hr.91a2c734b5a6737ccc82.js",
                            "hu.6587166afcb4112532ee.js": "locales/hu.6587166afcb4112532ee.js",
                            "id.ee35b3692559c9b18b8f.js": "locales/id.ee35b3692559c9b18b8f.js",
                            "it.96e36c6b1d79ad19f792.js": "locales/it.96e36c6b1d79ad19f792.js",
                            "ja.ca0841905a58b14446ca.js": "locales/ja.ca0841905a58b14446ca.js",
                            "kk.f4a27ac2f5cd13477bba.js": "locales/kk.f4a27ac2f5cd13477bba.js",
                            "kn.c80c5948dbc522681471.js": "locales/kn.c80c5948dbc522681471.js",
                            "ko.828a52019015493f1c0d.js": "locales/ko.828a52019015493f1c0d.js",
                            "lt.0bc29d90b750083490b6.js": "locales/lt.0bc29d90b750083490b6.js",
                            "lv.07da6e657f69d1960115.js": "locales/lv.07da6e657f69d1960115.js",
                            "mk.6ab8e85a7a98d111eef8.js": "locales/mk.6ab8e85a7a98d111eef8.js",
                            "ml.b3afdf1bc574e1a3f69f.js": "locales/ml.b3afdf1bc574e1a3f69f.js",
                            "mr.f56242f53af7b44d1173.js": "locales/mr.f56242f53af7b44d1173.js",
                            "ms.2c388336516075816fc3.js": "locales/ms.2c388336516075816fc3.js",
                            "nb.b91ea38a95a8c3294e73.js": "locales/nb.b91ea38a95a8c3294e73.js",
                            "nl.00d39f31fdead2a401d4.js": "locales/nl.00d39f31fdead2a401d4.js",
                            "pa.12f6e172a99e49775444.js": "locales/pa.12f6e172a99e49775444.js",
                            "pl.4a84d1e476291c574f4b.js": "locales/pl.4a84d1e476291c574f4b.js",
                            "pt-BR.584d1d12332f6baf2875.js": "locales/pt-BR.584d1d12332f6baf2875.js",
                            "pt.c344195769387871df5b.js": "locales/pt.c344195769387871df5b.js",
                            "ro.d8be71dada9f2d83ea97.js": "locales/ro.d8be71dada9f2d83ea97.js",
                            "ru.425be58ace786fad4572.js": "locales/ru.425be58ace786fad4572.js",
                            "sk.06a0bcb2e9435ede2042.js": "locales/sk.06a0bcb2e9435ede2042.js",
                            "sl.f63ee77bd05fb32bf86a.js": "locales/sl.f63ee77bd05fb32bf86a.js",
                            "sq.38485ea6c7b25c0792bc.js": "locales/sq.38485ea6c7b25c0792bc.js",
                            "sr.d690b98992145b2e3568.js": "locales/sr.d690b98992145b2e3568.js",
                            "sv.fb73eb973e52a8c0baf5.js": "locales/sv.fb73eb973e52a8c0baf5.js",
                            "sw.f62ff4f0bd4d789716c6.js": "locales/sw.f62ff4f0bd4d789716c6.js",
                            "ta.9a17fd0f29a66b405a4d.js": "locales/ta.9a17fd0f29a66b405a4d.js",
                            "te.be8f1cbeee6e93350070.js": "locales/te.be8f1cbeee6e93350070.js",
                            "th.3f26cc6d1af862ec5b8f.js": "locales/th.3f26cc6d1af862ec5b8f.js",
                            "tr.ebe9a4b02baf2f0f85ba.js": "locales/tr.ebe9a4b02baf2f0f85ba.js",
                            "uk.eb5ddf856baed79719b5.js": "locales/uk.eb5ddf856baed79719b5.js",
                            "ur.0fcd787232d407852950.js": "locales/ur.0fcd787232d407852950.js",
                            "uz.8fb584950fecf693935d.js": "locales/uz.8fb584950fecf693935d.js",
                            "vi.ebd0ea1f8a4162ce9831.js": "locales/vi.ebd0ea1f8a4162ce9831.js",
                            "zh-CN.93adf19242a134e076d6.js": "locales/zh-CN.93adf19242a134e076d6.js",
                            "zh-HK.a03dbd1768603ecee17f.js": "locales/zh-HK.a03dbd1768603ecee17f.js",
                            "zh-TW.e637a68b0d1d169fe957.js": "locales/zh-TW.e637a68b0d1d169fe957.js"
                        },
                        styles: {}
                    },
                    releaseDate: 1617832437958
                }
            },
            135: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = new RegExp("(".concat(self.registration.scope, "|https://web.whatsapp.com/|https://dyn.web.whatsapp.com/)([^?]*)(?:\\?(.*))?"));
                class a {
                    static parseUrl(e) {
                        var t = e.match(r);
                        if (t) {
                            var a;
                            if (t[3]) {
                                var n = {};
                                t[3].split("&").forEach((e => {
                                    var t = e.split("=");
                                    n[t[0]] = t[1]
                                })), a = n
                            }
                            return {
                                base: t[1],
                                relativePath: t[2],
                                queryParams: a
                            }
                        }
                    }
                    static convertToUrl(e, t) {
                        var r = Object.keys(t).map((e => [e, t[e]].map(encodeURIComponent).join("="))).join("&");
                        return r.length ? e.endsWith("/") ? "".concat(e, "?").concat(r) : "".concat(e, "/?").concat(r) : e
                    }
                    constructor(e, t) {
                        this.matchFetch = () => !1, this.matchAction = () => !1, this.matchInstall = () => !1, this.matchActivate = () => !1, this.cache = e, this.store = t
                    }
                }
                t.default = a, a.RequestType = {
                    GET: "GET"
                }
            },
            621: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = {
                    manuallyCloneRequest: function(e, t, r) {
                        var a = r;
                        return "string" == typeof e ? ((a = a || {}).credentials = "same-origin", new Request(t || e, a)) : new Request(t || e.url, {
                            method: void 0 === a.method ? e.method : a.method,
                            headers: void 0 === a.headers ? e.headers : a.headers,
                            mode: void 0 === a.mode ? e.mode : a.mode,
                            credentials: "same-origin",
                            cache: void 0 === a.cache ? e.cache : a.cache,
                            redirect: void 0 === a.redirect ? e.redirect : a.redirect,
                            integrity: void 0 === a.integrity ? e.integrity : a.integrity
                        })
                    },
                    getIndexPath: function(e) {
                        return e && e.locale ? "%F0%9F%8C%90/".concat(e.locale) : ""
                    }
                };
                t.default = r
            },
            871: (e, t, r) => {
                var a = r(329).log;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.parseClientRange = j, t.default = void 0;
                var n = u(r(303)),
                    s = u(r(340)),
                    c = r(125),
                    o = u(r(113)),
                    i = u(r(583)),
                    l = u(r(621));

                function u(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }

                function d() {
                    var e = m(["sw:videoStreaming:getEncryptedPadding encrypt error: ", ""]);
                    return d = function() {
                        return e
                    }, e
                }

                function f() {
                    var e = m(["sw:videoStreaming:getEncryptedPadding importKey error: ", ""]);
                    return f = function() {
                        return e
                    }, e
                }

                function h() {
                    var e = m(["sw:videoStreaming:decrypt decrypt error: ", ""]);
                    return h = function() {
                        return e
                    }, e
                }

                function b() {
                    var e = m(["sw:videoStreaming:decrypt importKey error: ", ""]);
                    return b = function() {
                        return e
                    }, e
                }

                function p() {
                    var e = m(["sw:videoStreaming:processRequest ciphertext is too short - ", " bytes"]);
                    return p = function() {
                        return e
                    }, e
                }

                function v() {
                    var e = m(["sw:videoStreaming:processRequest server returns ", " error"]);
                    return v = function() {
                        return e
                    }, e
                }

                function m(e, t) {
                    return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(t)
                        }
                    }))
                }
                var _ = 16,
                    g = 65536;

                function j(e) {
                    var {
                        clientRangeStartString: t,
                        clientRangeEndString: r
                    } = function(e) {
                        var t = e.headers.get("Range");
                        if (t) {
                            var [r, a] = t.replace("bytes=", "").split("-");
                            return {
                                clientRangeStartString: r,
                                clientRangeEndString: a
                            }
                        }
                        var n = new URL(e.url);
                        return {
                            clientRangeStartString: n.searchParams.get("bytesstart"),
                            clientRangeEndString: n.searchParams.get("bytesend")
                        }
                    }(e), a = parseInt(t, 10), n = parseInt(r, 10);
                    return {
                        clientRangeStart: isNaN(a) ? 0 : a,
                        clientRangeEnd: isNaN(n) ? null : n
                    }
                }
                t.default = class {
                    constructor(e, t, r) {
                        this.generation = 0;
                        for (var {
                                sidecar: a
                            } = t, n = [], s = 0; s < a.byteLength; s += 10) n.push(a.slice(s, s + 10));
                        this.cryptoKeys = {
                            iv: t.iv,
                            sidecar: n,
                            encKey: t.encKey,
                            macKey: t.macKey
                        }, this.streamData = r, this.clientId = e
                    }
                    fetchAndDecrypt(e) {
                        var {
                            clientUrl: t,
                            msgKey: r
                        } = this.streamData, {
                            clientRangeStart: s,
                            clientRangeEnd: c
                        } = j(e), {
                            serverRangeStart: o,
                            serverRangeEnd: l
                        } = this.computeServerRange(s, c), u = this.createServerRequest(e, o, l, t);
                        return fetch(u).then((t => 404 === t.status ? this.handleRMR(e, r) : t.status >= 400 ? (a(2)(v(), t.status), this.generation++, i.default.request(this.clientId, n.default.EXP_BACKOFF, {
                            generation: this.generation
                        }).then((() => this.fetchAndDecrypt(e)))) : (this.generation = 0, t.arrayBuffer().then((e => {
                            var r = e.byteLength;
                            return !e || r < _ ? (a(2)(p(), r), new Response("Ciphertext is too short - ".concat(r, " bytes"), {
                                status: 500
                            })) : this.validateSidecar(o, e).then((() => this.cleanupCiphertextAndIv(o, e))).then((({
                                ciphertext: e,
                                iv: t
                            }) => this.decrypt(e, t))).then((e => {
                                var r = this.cleanupPlaintext(e, {
                                        clientRangeStart: s,
                                        clientRangeEnd: c
                                    }, {
                                        serverRangeStart: o,
                                        serverRangeEnd: l
                                    }),
                                    a = this.createClientResponse(t, r, s);
                                return this.sendBackArrayBuffer(s, r), a
                            }))
                        })))))
                    }
                    decrypt(e, t) {
                        var {
                            encKey: r
                        } = this.cryptoKeys, n = {
                            name: "AES-CBC",
                            iv: new Uint8Array(t)
                        };
                        return (0, c.getCrypto)().importKey("raw", new Uint8Array(r), "AES-CBC", !1, ["decrypt"]).catch((e => {
                            throw a(2)(b(), String(e)), e
                        })).then((t => (0, c.getCrypto)().decrypt(n, t, e))).catch((e => {
                            throw a(2)(h(), String(e)), e
                        }))
                    }
                    handleRMR(e, t) {
                        return i.default.request(this.clientId, n.default.REQUEST_RMR, {
                            key: t
                        }).then((t => (this.cryptoKeys.encKey = t.encKey, this.cryptoKeys.iv = t.iv, this.streamData.clientUrl = t.clientUrl, this.streamData.size = t.size, this.fetchAndDecrypt(e))))
                    }
                    cleanupCiphertextAndIv(e, t) {
                        var r, a = t instanceof Uint8Array ? t : new Uint8Array(t),
                            n = a.byteLength % _ == 0;
                        return 0 === e ? r = new Uint8Array(this.cryptoKeys.iv) : (r = a.slice(0, _), a = a.slice(_)), n || (a = a.slice(0, a.byteLength - 10)), n ? this.getEncryptedPadding(a).then((e => ({
                            ciphertext: a = (0, s.default)(Uint8Array, [a, new Uint8Array(e)]),
                            iv: r
                        }))) : Promise.resolve({
                            ciphertext: a,
                            iv: r
                        })
                    }
                    cleanupPlaintext(e, {
                        clientRangeStart: t,
                        clientRangeEnd: r
                    }, {
                        serverRangeStart: a,
                        serverRangeEnd: n
                    }) {
                        var s = 0 === a ? 0 : t - (a + _),
                            c = null != r ? n - r : 0;
                        return e.slice(s, e.byteLength - c)
                    }
                    getEncryptedPadding(e) {
                        var {
                            encKey: t
                        } = this.cryptoKeys, r = {
                            name: "AES-CBC",
                            iv: (e instanceof Uint8Array ? e : new Uint8Array(e)).slice(-16)
                        };
                        return (0, c.getCrypto)().importKey("raw", new Uint8Array(t), "AES-CBC", !1, ["encrypt"]).catch((e => {
                            a(2)(f(), String(e))
                        })).then((e => {
                            var t = new Uint8Array([]);
                            return (0, c.getCrypto)().encrypt(r, e, t)
                        })).catch((e => {
                            a(2)(d(), String(e))
                        }))
                    }
                    validateSidecar(e, t) {
                        var r, a, n = t,
                            {
                                macKey: o,
                                iv: i,
                                sidecar: l
                            } = this.cryptoKeys;
                        0 === e ? (r = 0, a = i) : (r = (e + _) / g, a = n.slice(0, _), n = n.slice(_));
                        var u = n.byteLength / g;
                        return (0, c.getCrypto)().importKey("raw", new Uint8Array(o), {
                            name: "HMAC",
                            hash: {
                                name: "SHA-256"
                            }
                        }, !1, ["sign"]).then((e => {
                            for (var t = [], c = 0; c < u; c++) {
                                var o = l[r + c],
                                    i = c * g,
                                    d = n.slice(i, i + g),
                                    f = a;
                                a = d.slice(65520, 65536);
                                var h = (0, s.default)(Uint8Array, [new Uint8Array(f), new Uint8Array(d)]);
                                t.push(this.validateChunk(h, e, o))
                            }
                            return Promise.all(t)
                        }))
                    }
                    validateChunk(e, t, r) {
                        return (0, c.getCrypto)().sign({
                            name: "HMAC"
                        }, t, e).then((e => {
                            var t = e.slice(0, 10);
                            if (!(0, o.default)(t, r)) return Promise.reject("Invalid Chunk: Does not match sidecar.")
                        }))
                    }
                    createClientResponse(e, t, r) {
                        var {
                            size: a
                        } = this.streamData, {
                            contentRangeStart: n,
                            contentRangeEnd: s
                        } = this.getContentRange(r, t), c = "bytes ".concat(n, "-").concat(s, "/").concat(a), o = new Headers(e.headers);
                        return o.set("Content-Range", c), o.set("Content-Length", "".concat(t.byteLength)), new Response(t, {
                            status: 200 === e.status ? 206 : e.status,
                            statusText: e.statusText,
                            headers: o
                        })
                    }
                    getContentRange(e, t) {
                        return {
                            contentRangeStart: e,
                            contentRangeEnd: e + t.byteLength - 1
                        }
                    }
                    sendBackArrayBuffer(e, t) {
                        var {
                            contentRangeStart: r,
                            contentRangeEnd: a
                        } = this.getContentRange(e, t);
                        i.default.request(this.clientId, n.default.SEND_STREAMING_CHUNK, {
                            msgKey: this.streamData.msgKey,
                            data: {
                                start: r,
                                end: a,
                                buffer: t
                            }
                        })
                    }
                    createServerRequest(e, t, r, a) {
                        var n = new URL(a);
                        return n.searchParams.set("bytestart", t.toString()), n.searchParams.set("byteend", r.toString()), l.default.manuallyCloneRequest(e, n.toString(), {
                            credentials: "omit",
                            headers: new Headers({}),
                            mode: "cors",
                            referrer: e.referrer
                        })
                    }
                    computeServerRange(e, t) {
                        var r = e,
                            a = t;
                        return r = e ? this.roundDown(e, g) : 0, a = null != t && 0 !== t ? this.roundUp(t, g) - 1 : r + 1572864 - 1, r > 0 && (r -= _), {
                            serverRangeStart: r,
                            serverRangeEnd: a
                        }
                    }
                    roundUp(e, t) {
                        return Math.ceil(e / t) * t
                    }
                    roundDown(e, t) {
                        return Math.floor(e / t) * t
                    }
                }
            },
            715: (e, t, r) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var a = o(r(303)),
                    n = o(r(583)),
                    s = o(r(135)),
                    c = o(r(871));

                function o(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                class i extends s.default {
                    constructor(...e) {
                        super(...e), this.matchFetch = e => {
                            var {
                                request: t
                            } = e, r = s.default.parseUrl(t.url);
                            return !!(t.method === s.default.RequestType.GET && r && r.queryParams && r.queryParams.key && t.url.match("/stream/video"))
                        }, this.onFetch = e => {
                            var {
                                request: t,
                                client: r,
                                clientId: o
                            } = e, i = s.default.parseUrl(t.url), l = o || r && r.id;
                            return l ? n.default.request(l, a.default.REQUEST_STREAMING_INFO, {
                                key: i.queryParams.key
                            }).then((({
                                cryptoKeys: e,
                                streamData: r
                            }) => new c.default(l, e, r).fetchAndDecrypt(t))) : Promise.reject("No client id found.")
                        }, this.matchAction = e => e === a.default.STREAMING_SUPPORTED, this.onAction = () => !(!self.crypto || !self.crypto.subtle && !self.crypto.webkitSubtle)
                    }
                }
                t.default = i
            },
            113: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t) {
                    if (e.byteLength !== t.byteLength) return !1;
                    for (var r = new DataView(e), a = new DataView(t), n = 0; n < r.byteLength; n++)
                        if (r.getUint8(n) !== a.getUint8(n)) return !1;
                    return !0
                }
            },
            287: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t) {
                    for (var r = [], a = e.length, n = t.length, s = Math.max(a, n), c = 0; c < s; c++) c < a && r.push(e[c]), c < n && r.push(t[c]);
                    return r
                }
            },
            72: (e, t, r) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t, r, a = String) {
                    var s = (0, n.default)(e, t.map(a)).join(""),
                        c = r ? 4e3 : Number.POSITIVE_INFINITY;
                    s.length > c && (s = s.slice(0, c).replace(/\s+$/, " [truncated]"));
                    return s
                };
                var a, n = (a = r(287)) && a.__esModule ? a : {
                    default: a
                }
            },
            98: (e, t) => {
                var r;
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                try {
                    r = self.indexedDB
                } catch (e) {}
                var a = r;
                t.default = a
            },
            301: (e, t) => {
                function r(e, t) {
                    var a = function(...r) {
                        var n = t ? t.apply(this, r) : r[0];
                        if (!n) return e.apply(this, r);
                        var s = a.cache;
                        if (s.has(n)) return s.get(n);
                        var c = e.apply(this, r);
                        return a.cache = s.set(n, c) || s, c
                    };
                    return a.cache = new(r.Cache || Map), a
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0, r.Cache = Map;
                var a = r;
                t.default = a
            },
            315: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t = "?") {
                    if (null == e) throw new Error("Unexpected null or undefined: ".concat(t));
                    return e
                }
            },
            125: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.getCrypto = function() {
                    return self.crypto.subtle || self.crypto.webkitSubtle
                }
            },
            340: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t) {
                    var r = t.reduce(((e, t) => e + t.length), 0),
                        a = new e(r),
                        n = 0;
                    return t.forEach((e => {
                        a.set(e, n), n += e.length
                    })), a
                }
            }
        },
        t = {};

    function r(a) {
        if (t[a]) return t[a].exports;
        var n = t[a] = {
            exports: {}
        };
        return e[a](n, n.exports, r), n.exports
    }(() => {
        var e = l(r(541)),
            t = l(r(286)),
            a = l(r(580)),
            n = l(r(274)),
            s = l(r(496)),
            c = l(r(14)),
            o = l(r(907)),
            i = l(r(715));

        function l(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var u = new a.default("wa-stickers"),
            d = [new s.default(new a.default("wa-pp"), n.default.pp), new i.default, new t.default(new a.default("wa2.2112.10"), n.default.prefs), new e.default(new a.default("wa-assets")), new c.default(u, n.default.stickers)];
        (0, o.default)(d)
    })()
})();