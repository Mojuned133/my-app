/*! Copyright (c) 2021 WhatsApp Inc. All Rights Reserved. */
(() => {
    var e = {
            8103: e => {
                "use strict";
                var t = Object.prototype.hasOwnProperty,
                    n = "function" == typeof WeakMap ? new WeakMap : new Map;

                function r(e) {
                    var t = n.get(e);
                    if (void 0 !== t) return t;
                    var r = Object.getOwnPropertyNames(e),
                        i = new Set(r.map((t => e[t])));
                    return n.set(e, i), i
                }
                var i = Object.freeze(Object.defineProperties(Object.create(null), {
                    isValid: {
                        value: function(e) {
                            return r(this).has(e)
                        }
                    },
                    cast: {
                        value: function(e) {
                            return this.isValid(e) ? e : void 0
                        }
                    },
                    members: {
                        value: function() {
                            return r(this).values()
                        }
                    }
                }));

                function o(e) {
                    var n = Object.create(i);
                    for (var r in e) t.call(e, r) && Object.defineProperty(n, r, {
                        value: e[r]
                    });
                    return Object.freeze(n)
                }
                var a = Object.freeze(Object.defineProperties(Object.create(null), {
                    isValid: {
                        value: function(e) {
                            return "string" == typeof e && t.call(this, e)
                        }
                    },
                    cast: {
                        value: i.cast
                    },
                    members: {
                        value: function() {
                            return Object.getOwnPropertyNames(this)
                        }
                    }
                }));
                o.Mirrored = function(e) {
                    for (var t = Object.create(a), n = 0, r = e.length; n < r; ++n) Object.defineProperty(t, e[n], {
                        value: e[n]
                    });
                    return Object.freeze(t)
                }, Object.freeze(o.Mirrored), e.exports = Object.freeze(o)
            },
            2954: e => {
                function t(e, t, n, r, i, o, a) {
                    try {
                        var s = e[o](a),
                            u = s.value
                    } catch (e) {
                        return void n(e)
                    }
                    s.done ? t(u) : Promise.resolve(u).then(r, i)
                }
                e.exports = function(e) {
                    return function() {
                        var n = this,
                            r = arguments;
                        return new Promise((function(i, o) {
                            var a = e.apply(n, r);

                            function s(e) {
                                t(a, i, o, s, u, "next", e)
                            }

                            function u(e) {
                                t(a, i, o, s, u, "throw", e)
                            }
                            s(void 0)
                        }))
                    }
                }
            },
            1260: e => {
                e.exports = function(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
            },
            4859: e => {
                e.exports = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
            },
            3291: (e, t, n) => {
                var r = n(8921);

                function i() {
                    if ("function" != typeof WeakMap) return null;
                    var e = new WeakMap;
                    return i = function() {
                        return e
                    }, e
                }
                e.exports = function(e) {
                    if (e && e.__esModule) return e;
                    if (null === e || "object" !== r(e) && "function" != typeof e) return {
                        default: e
                    };
                    var t = i();
                    if (t && t.has(e)) return t.get(e);
                    var n = {},
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var a in e)
                        if (Object.prototype.hasOwnProperty.call(e, a)) {
                            var s = o ? Object.getOwnPropertyDescriptor(e, a) : null;
                            s && (s.get || s.set) ? Object.defineProperty(n, a, s) : n[a] = e[a]
                        }
                    return n.default = e, t && t.set(e, n), n
                }
            },
            417: (e, t, n) => {
                var r = n(1260);

                function i(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }
                e.exports = function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? i(Object(n), !0).forEach((function(t) {
                            r(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }
            },
            9976: e => {
                e.exports = function(e, t) {
                    return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                        raw: {
                            value: Object.freeze(t)
                        }
                    }))
                }
            },
            8921: e => {
                function t(n) {
                    return "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? e.exports = t = function(e) {
                        return typeof e
                    } : e.exports = t = function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    }, t(n)
                }
                e.exports = t
            },
            7715: (e, t, n) => {
                "use strict";
                n.r(t);
                var r = Object.keys,
                    i = Array.isArray,
                    o = "undefined" != typeof self ? self : "undefined" != typeof window ? window : n.g;

                function a(e, t) {
                    return "object" != typeof t || r(t).forEach((function(n) {
                        e[n] = t[n]
                    })), e
                }
                var s = Object.getPrototypeOf,
                    u = {}.hasOwnProperty;

                function c(e, t) {
                    return u.call(e, t)
                }

                function l(e, t) {
                    "function" == typeof t && (t = t(s(e))), r(t).forEach((function(n) {
                        d(e, n, t[n])
                    }))
                }
                var f = Object.defineProperty;

                function d(e, t, n, r) {
                    f(e, t, a(n && c(n, "get") && "function" == typeof n.get ? {
                        get: n.get,
                        set: n.set,
                        configurable: !0
                    } : {
                        value: n,
                        configurable: !0,
                        writable: !0
                    }, r))
                }

                function h(e) {
                    return {
                        from: function(t) {
                            return e.prototype = Object.create(t.prototype), d(e.prototype, "constructor", e), {
                                extend: l.bind(null, e.prototype)
                            }
                        }
                    }
                }
                var v = Object.getOwnPropertyDescriptor;

                function p(e, t) {
                    var n;
                    return v(e, t) || (n = s(e)) && p(n, t)
                }
                var m = [].slice;

                function y(e, t, n) {
                    return m.call(e, t, n)
                }

                function g(e, t) {
                    return t(e)
                }

                function _(e) {
                    if (!e) throw new Error("Assertion Failed")
                }

                function b(e) {
                    o.setImmediate ? setImmediate(e) : setTimeout(e, 0)
                }

                function w(e, t) {
                    return e.reduce((function(e, n, r) {
                        var i = t(n, r);
                        return i && (e[i[0]] = i[1]), e
                    }), {})
                }

                function E(e, t) {
                    return function() {
                        try {
                            e.apply(this, arguments)
                        } catch (e) {
                            t(e)
                        }
                    }
                }

                function O(e, t, n) {
                    try {
                        e.apply(null, n)
                    } catch (e) {
                        t && t(e)
                    }
                }

                function A(e, t) {
                    if (c(e, t)) return e[t];
                    if (!t) return e;
                    if ("string" != typeof t) {
                        for (var n = [], r = 0, i = t.length; r < i; ++r) {
                            var o = A(e, t[r]);
                            n.push(o)
                        }
                        return n
                    }
                    var a = t.indexOf(".");
                    if (-1 !== a) {
                        var s = e[t.substr(0, a)];
                        return void 0 === s ? void 0 : A(s, t.substr(a + 1))
                    }
                }

                function S(e, t, n) {
                    if (e && void 0 !== t && (!("isFrozen" in Object) || !Object.isFrozen(e)))
                        if ("string" != typeof t && "length" in t) {
                            _("string" != typeof n && "length" in n);
                            for (var r = 0, i = t.length; r < i; ++r) S(e, t[r], n[r])
                        } else {
                            var o = t.indexOf(".");
                            if (-1 !== o) {
                                var a = t.substr(0, o),
                                    s = t.substr(o + 1);
                                if ("" === s) void 0 === n ? delete e[a] : e[a] = n;
                                else {
                                    var u = e[a];
                                    u || (u = e[a] = {}), S(u, s, n)
                                }
                            } else void 0 === n ? delete e[t] : e[t] = n
                        }
                }

                function P(e) {
                    var t = {};
                    for (var n in e) c(e, n) && (t[n] = e[n]);
                    return t
                }
                var x = [].concat;

                function I(e) {
                    return x.apply([], e)
                }
                var M = "Boolean,String,Date,RegExp,Blob,File,FileList,ArrayBuffer,DataView,Uint8ClampedArray,ImageData,Map,Set".split(",").concat(I([8, 16, 32, 64].map((function(e) {
                    return ["Int", "Uint", "Float"].map((function(t) {
                        return t + e + "Array"
                    }))
                })))).filter((function(e) {
                    return o[e]
                })).map((function(e) {
                    return o[e]
                }));

                function C(e) {
                    if (!e || "object" != typeof e) return e;
                    var t;
                    if (i(e)) {
                        t = [];
                        for (var n = 0, r = e.length; n < r; ++n) t.push(C(e[n]))
                    } else if (M.indexOf(e.constructor) >= 0) t = e;
                    else
                        for (var o in t = e.constructor ? Object.create(e.constructor.prototype) : {}, e) c(e, o) && (t[o] = C(e[o]));
                    return t
                }

                function k(e, t, n, i) {
                    return n = n || {}, i = i || "", r(e).forEach((function(r) {
                        if (c(t, r)) {
                            var o = e[r],
                                a = t[r];
                            "object" == typeof o && "object" == typeof a && o && a && "" + o.constructor == "" + a.constructor ? k(o, a, n, i + r + ".") : o !== a && (n[i + r] = t[r])
                        } else n[i + r] = void 0
                    })), r(t).forEach((function(r) {
                        c(e, r) || (n[i + r] = t[r])
                    })), n
                }
                var T = "undefined" != typeof Symbol && Symbol.iterator,
                    j = T ? function(e) {
                        var t;
                        return null != e && (t = e[T]) && t.apply(e)
                    } : function() {
                        return null
                    },
                    R = {};

                function N(e) {
                    var t, n, r, o;
                    if (1 === arguments.length) {
                        if (i(e)) return e.slice();
                        if (this === R && "string" == typeof e) return [e];
                        if (o = j(e)) {
                            for (n = []; !(r = o.next()).done;) n.push(r.value);
                            return n
                        }
                        if (null == e) return [e];
                        if ("number" == typeof(t = e.length)) {
                            for (n = new Array(t); t--;) n[t] = e[t];
                            return n
                        }
                        return [e]
                    }
                    for (t = arguments.length, n = new Array(t); t--;) n[t] = arguments[t];
                    return n
                }
                var D = "undefined" != typeof location && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);

                function K(e, t) {
                    D = e, F = t
                }
                var F = function() {
                        return !0
                    },
                    U = !new Error("").stack;

                function L() {
                    if (U) try {
                        throw L.arguments, new Error
                    } catch (e) {
                        return e
                    }
                    return new Error
                }

                function B(e, t) {
                    var n = e.stack;
                    return n ? (t = t || 0, 0 === n.indexOf(e.name) && (t += (e.name + e.message).split("\n").length), n.split("\n").slice(t).filter(F).map((function(e) {
                        return "\n" + e
                    })).join("")) : ""
                }
                var Y = ["Unknown", "Constraint", "Data", "TransactionInactive", "ReadOnly", "Version", "NotFound", "InvalidState", "InvalidAccess", "Abort", "Timeout", "QuotaExceeded", "Syntax", "DataClone"],
                    V = ["Modify", "Bulk", "OpenFailed", "VersionChange", "Schema", "Upgrade", "InvalidTable", "MissingAPI", "NoSuchDatabase", "InvalidArgument", "SubTransaction", "Unsupported", "Internal", "DatabaseClosed", "PrematureCommit", "ForeignAwait"].concat(Y),
                    z = {
                        VersionChanged: "Database version changed by other database connection",
                        DatabaseClosed: "Database has been closed",
                        Abort: "Transaction aborted",
                        TransactionInactive: "Transaction has already completed or failed"
                    };

                function q(e, t) {
                    this._e = L(), this.name = e, this.message = t
                }

                function H(e, t, n, r) {
                    this._e = L(), this.failures = t, this.failedKeys = r, this.successCount = n
                }

                function W(e, t) {
                    this._e = L(), this.name = "BulkError", this.failures = t, this.message = function(e, t) {
                        return e + ". Errors: " + t.map((function(e) {
                            return e.toString()
                        })).filter((function(e, t, n) {
                            return n.indexOf(e) === t
                        })).join("\n")
                    }(e, t)
                }
                h(q).from(Error).extend({
                    stack: {
                        get: function() {
                            return this._stack || (this._stack = this.name + ": " + this.message + B(this._e, 2))
                        }
                    },
                    toString: function() {
                        return this.name + ": " + this.message
                    }
                }), h(H).from(q), h(W).from(q);
                var G = V.reduce((function(e, t) {
                        return e[t] = t + "Error", e
                    }), {}),
                    X = q,
                    Q = V.reduce((function(e, t) {
                        var n = t + "Error";

                        function r(e, r) {
                            this._e = L(), this.name = n, e ? "string" == typeof e ? (this.message = e, this.inner = r || null) : "object" == typeof e && (this.message = e.name + " " + e.message, this.inner = e) : (this.message = z[t] || n, this.inner = null)
                        }
                        return h(r).from(X), e[t] = r, e
                    }), {});
                Q.Syntax = SyntaxError, Q.Type = TypeError, Q.Range = RangeError;
                var J = Y.reduce((function(e, t) {
                    return e[t + "Error"] = Q[t], e
                }), {});
                var Z = V.reduce((function(e, t) {
                    return -1 === ["Syntax", "Type", "Range"].indexOf(t) && (e[t + "Error"] = Q[t]), e
                }), {});

                function $() {}

                function ee(e) {
                    return e
                }

                function te(e, t) {
                    return null == e || e === ee ? t : function(n) {
                        return t(e(n))
                    }
                }

                function ne(e, t) {
                    return function() {
                        e.apply(this, arguments), t.apply(this, arguments)
                    }
                }

                function re(e, t) {
                    return e === $ ? t : function() {
                        var n = e.apply(this, arguments);
                        void 0 !== n && (arguments[0] = n);
                        var r = this.onsuccess,
                            i = this.onerror;
                        this.onsuccess = null, this.onerror = null;
                        var o = t.apply(this, arguments);
                        return r && (this.onsuccess = this.onsuccess ? ne(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? ne(i, this.onerror) : i), void 0 !== o ? o : n
                    }
                }

                function ie(e, t) {
                    return e === $ ? t : function() {
                        e.apply(this, arguments);
                        var n = this.onsuccess,
                            r = this.onerror;
                        this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? ne(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? ne(r, this.onerror) : r)
                    }
                }

                function oe(e, t) {
                    return e === $ ? t : function(n) {
                        var r = e.apply(this, arguments);
                        a(n, r);
                        var i = this.onsuccess,
                            o = this.onerror;
                        this.onsuccess = null, this.onerror = null;
                        var s = t.apply(this, arguments);
                        return i && (this.onsuccess = this.onsuccess ? ne(i, this.onsuccess) : i), o && (this.onerror = this.onerror ? ne(o, this.onerror) : o), void 0 === r ? void 0 === s ? void 0 : s : a(r, s)
                    }
                }

                function ae(e, t) {
                    return e === $ ? t : function() {
                        return !1 !== t.apply(this, arguments) && e.apply(this, arguments)
                    }
                }

                function se(e, t) {
                    return e === $ ? t : function() {
                        var n = e.apply(this, arguments);
                        if (n && "function" == typeof n.then) {
                            for (var r = this, i = arguments.length, o = new Array(i); i--;) o[i] = arguments[i];
                            return n.then((function() {
                                return t.apply(r, o)
                            }))
                        }
                        return t.apply(this, arguments)
                    }
                }
                Z.ModifyError = H, Z.DexieError = q, Z.BulkError = W;
                var ue = {},
                    ce = function() {
                        try {
                            return new Function("let F=async ()=>{},p=F();return [p,Object.getPrototypeOf(p),Promise.resolve(),F.constructor];")()
                        } catch (t) {
                            var e = o.Promise;
                            return e ? [e.resolve(), e.prototype, e.resolve()] : []
                        }
                    }(),
                    le = ce[0],
                    fe = ce[1],
                    de = ce[2],
                    he = fe && fe.then,
                    ve = le && le.constructor,
                    pe = ce[3],
                    me = !!de,
                    ye = !1,
                    ge = de ? function() {
                        de.then(Be)
                    } : o.setImmediate ? setImmediate.bind(null, Be) : o.MutationObserver ? function() {
                        var e = document.createElement("div");
                        new MutationObserver((function() {
                            Be(), e = null
                        })).observe(e, {
                            attributes: !0
                        }), e.setAttribute("i", "1")
                    } : function() {
                        setTimeout(Be, 0)
                    },
                    _e = function(e, t) {
                        Ie.push([e, t]), we && (ge(), we = !1)
                    },
                    be = !0,
                    we = !0,
                    Ee = [],
                    Oe = [],
                    Ae = null,
                    Se = ee,
                    Pe = {
                        id: "global",
                        global: !0,
                        ref: 0,
                        unhandleds: [],
                        onunhandled: ft,
                        pgp: !1,
                        env: {},
                        finalize: function() {
                            this.unhandleds.forEach((function(e) {
                                try {
                                    ft(e[0], e[1])
                                } catch (e) {}
                            }))
                        }
                    },
                    xe = Pe,
                    Ie = [],
                    Me = 0,
                    Ce = [];

                function ke(e) {
                    if ("object" != typeof this) throw new TypeError("Promises must be constructed via new");
                    this._listeners = [], this.onuncatched = $, this._lib = !1;
                    var t = this._PSD = xe;
                    if (D && (this._stackHolder = L(), this._prev = null, this._numPrev = 0), "function" != typeof e) {
                        if (e !== ue) throw new TypeError("Not a function");
                        return this._state = arguments[1], this._value = arguments[2], void(!1 === this._state && Ne(this, this._value))
                    }
                    this._state = null, this._value = null, ++t.ref, Re(this, e)
                }
                var Te = {
                    get: function() {
                        var e = xe,
                            t = Je;

                        function n(n, r) {
                            var i = this,
                                o = !e.global && (e !== xe || t !== Je);
                            o && tt();
                            var a = new ke((function(t, a) {
                                Ke(i, new je(ut(n, e, o), ut(r, e, o), t, a, e))
                            }));
                            return D && Le(a, this), a
                        }
                        return n.prototype = ue, n
                    },
                    set: function(e) {
                        d(this, "then", e && e.prototype === ue ? Te : {
                            get: function() {
                                return e
                            },
                            set: Te.set
                        })
                    }
                };

                function je(e, t, n, r, i) {
                    this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.resolve = n, this.reject = r, this.psd = i
                }

                function Re(e, t) {
                    try {
                        t((function(t) {
                            if (null === e._state) {
                                if (t === e) throw new TypeError("A promise cannot be resolved with itself.");
                                var n = e._lib && Ye();
                                t && "function" == typeof t.then ? Re(e, (function(e, n) {
                                    t instanceof ke ? t._then(e, n) : t.then(e, n)
                                })) : (e._state = !0, e._value = t, De(e)), n && Ve()
                            }
                        }), Ne.bind(null, e))
                    } catch (t) {
                        Ne(e, t)
                    }
                }

                function Ne(e, t) {
                    if (Oe.push(t), null === e._state) {
                        var n = e._lib && Ye();
                        t = Se(t), e._state = !1, e._value = t, D && null !== t && "object" == typeof t && !t._promise && O((function() {
                                var n = p(t, "stack");
                                t._promise = e, d(t, "stack", {
                                    get: function() {
                                        return ye ? n && (n.get ? n.get.apply(t) : n.value) : e.stack
                                    }
                                })
                            })),
                            function(e) {
                                Ee.some((function(t) {
                                    return t._value === e._value
                                })) || Ee.push(e)
                            }(e), De(e), n && Ve()
                    }
                }

                function De(e) {
                    var t = e._listeners;
                    e._listeners = [];
                    for (var n = 0, r = t.length; n < r; ++n) Ke(e, t[n]);
                    var i = e._PSD;
                    --i.ref || i.finalize(), 0 === Me && (++Me, _e((function() {
                        0 == --Me && ze()
                    }), []))
                }

                function Ke(e, t) {
                    if (null !== e._state) {
                        var n = e._state ? t.onFulfilled : t.onRejected;
                        if (null === n) return (e._state ? t.resolve : t.reject)(e._value);
                        ++t.psd.ref, ++Me, _e(Fe, [n, e, t])
                    } else e._listeners.push(t)
                }

                function Fe(e, t, n) {
                    try {
                        Ae = t;
                        var r, i = t._value;
                        t._state ? r = e(i) : (Oe.length && (Oe = []), r = e(i), -1 === Oe.indexOf(i) && function(e) {
                            var t = Ee.length;
                            for (; t;)
                                if (Ee[--t]._value === e._value) return void Ee.splice(t, 1)
                        }(t)), n.resolve(r)
                    } catch (e) {
                        n.reject(e)
                    } finally {
                        Ae = null, 0 == --Me && ze(), --n.psd.ref || n.psd.finalize()
                    }
                }

                function Ue(e, t, n) {
                    if (t.length === n) return t;
                    var r = "";
                    if (!1 === e._state) {
                        var i, o, a = e._value;
                        null != a ? (i = a.name || "Error", o = a.message || a, r = B(a, 0)) : (i = a, o = ""), t.push(i + (o ? ": " + o : "") + r)
                    }
                    return D && ((r = B(e._stackHolder, 2)) && -1 === t.indexOf(r) && t.push(r), e._prev && Ue(e._prev, t, n)), t
                }

                function Le(e, t) {
                    var n = t ? t._numPrev + 1 : 0;
                    n < 100 && (e._prev = t, e._numPrev = n)
                }

                function Be() {
                    Ye() && Ve()
                }

                function Ye() {
                    var e = be;
                    return be = !1, we = !1, e
                }

                function Ve() {
                    var e, t, n;
                    do {
                        for (; Ie.length > 0;)
                            for (e = Ie, Ie = [], n = e.length, t = 0; t < n; ++t) {
                                var r = e[t];
                                r[0].apply(null, r[1])
                            }
                    } while (Ie.length > 0);
                    be = !0, we = !0
                }

                function ze() {
                    var e = Ee;
                    Ee = [], e.forEach((function(e) {
                        e._PSD.onunhandled.call(null, e._value, e)
                    }));
                    for (var t = Ce.slice(0), n = t.length; n;) t[--n]()
                }

                function qe(e) {
                    return new ke(ue, !1, e)
                }

                function He(e, t) {
                    var n = xe;
                    return function() {
                        var r = Ye(),
                            i = xe;
                        try {
                            return ot(n, !0), e.apply(this, arguments)
                        } catch (e) {
                            t && t(e)
                        } finally {
                            ot(i, !1), r && Ve()
                        }
                    }
                }
                l(ke.prototype, {
                    then: Te,
                    _then: function(e, t) {
                        Ke(this, new je(null, null, e, t, xe))
                    },
                    catch: function(e) {
                        if (1 === arguments.length) return this.then(null, e);
                        var t = arguments[0],
                            n = arguments[1];
                        return "function" == typeof t ? this.then(null, (function(e) {
                            return e instanceof t ? n(e) : qe(e)
                        })) : this.then(null, (function(e) {
                            return e && e.name === t ? n(e) : qe(e)
                        }))
                    },
                    finally: function(e) {
                        return this.then((function(t) {
                            return e(), t
                        }), (function(t) {
                            return e(), qe(t)
                        }))
                    },
                    stack: {
                        get: function() {
                            if (this._stack) return this._stack;
                            try {
                                ye = !0;
                                var e = Ue(this, [], 20).join("\nFrom previous: ");
                                return null !== this._state && (this._stack = e), e
                            } finally {
                                ye = !1
                            }
                        }
                    },
                    timeout: function(e, t) {
                        var n = this;
                        return e < 1 / 0 ? new ke((function(r, i) {
                            var o = setTimeout((function() {
                                return i(new Q.Timeout(t))
                            }), e);
                            n.then(r, i).finally(clearTimeout.bind(null, o))
                        })) : this
                    }
                }), "undefined" != typeof Symbol && Symbol.toStringTag && d(ke.prototype, Symbol.toStringTag, "Promise"), Pe.env = at(), l(ke, {
                    all: function() {
                        var e = N.apply(null, arguments).map(nt);
                        return new ke((function(t, n) {
                            0 === e.length && t([]);
                            var r = e.length;
                            e.forEach((function(i, o) {
                                return ke.resolve(i).then((function(n) {
                                    e[o] = n, --r || t(e)
                                }), n)
                            }))
                        }))
                    },
                    resolve: function(e) {
                        if (e instanceof ke) return e;
                        if (e && "function" == typeof e.then) return new ke((function(t, n) {
                            e.then(t, n)
                        }));
                        var t = new ke(ue, !0, e);
                        return Le(t, Ae), t
                    },
                    reject: qe,
                    race: function() {
                        var e = N.apply(null, arguments).map(nt);
                        return new ke((function(t, n) {
                            e.map((function(e) {
                                return ke.resolve(e).then(t, n)
                            }))
                        }))
                    },
                    PSD: {
                        get: function() {
                            return xe
                        },
                        set: function(e) {
                            return xe = e
                        }
                    },
                    newPSD: $e,
                    usePSD: st,
                    scheduler: {
                        get: function() {
                            return _e
                        },
                        set: function(e) {
                            _e = e
                        }
                    },
                    rejectionMapper: {
                        get: function() {
                            return Se
                        },
                        set: function(e) {
                            Se = e
                        }
                    },
                    follow: function(e, t) {
                        return new ke((function(n, r) {
                            return $e((function(t, n) {
                                var r = xe;
                                r.unhandleds = [], r.onunhandled = n, r.finalize = ne((function() {
                                    var e = this;
                                    ! function(e) {
                                        function t() {
                                            e(), Ce.splice(Ce.indexOf(t), 1)
                                        }
                                        Ce.push(t), ++Me, _e((function() {
                                            0 == --Me && ze()
                                        }), [])
                                    }((function() {
                                        0 === e.unhandleds.length ? t() : n(e.unhandleds[0])
                                    }))
                                }), r.finalize), e()
                            }), t, n, r)
                        }))
                    }
                });
                var We = {
                        awaits: 0,
                        echoes: 0,
                        id: 0
                    },
                    Ge = 0,
                    Xe = [],
                    Qe = 0,
                    Je = 0,
                    Ze = 0;

                function $e(e, t, n, r) {
                    var i = xe,
                        o = Object.create(i);
                    o.parent = i, o.ref = 0, o.global = !1, o.id = ++Ze;
                    var s = Pe.env;
                    o.env = me ? {
                        Promise: ke,
                        PromiseProp: {
                            value: ke,
                            configurable: !0,
                            writable: !0
                        },
                        all: ke.all,
                        race: ke.race,
                        resolve: ke.resolve,
                        reject: ke.reject,
                        nthen: ct(s.nthen, o),
                        gthen: ct(s.gthen, o)
                    } : {}, t && a(o, t), ++i.ref, o.finalize = function() {
                        --this.parent.ref || this.parent.finalize()
                    };
                    var u = st(o, e, n, r);
                    return 0 === o.ref && o.finalize(), u
                }

                function et() {
                    return We.id || (We.id = ++Ge), ++We.awaits, We.echoes += 7, We.id
                }

                function tt(e) {
                    !We.awaits || e && e !== We.id || (0 == --We.awaits && (We.id = 0), We.echoes = 7 * We.awaits)
                }

                function nt(e) {
                    return We.echoes && e && e.constructor === ve ? (et(), e.then((function(e) {
                        return tt(), e
                    }), (function(e) {
                        return tt(), dt(e)
                    }))) : e
                }

                function rt(e) {
                    ++Je, We.echoes && 0 != --We.echoes || (We.echoes = We.id = 0), Xe.push(xe), ot(e, !0)
                }

                function it() {
                    var e = Xe[Xe.length - 1];
                    Xe.pop(), ot(e, !1)
                }

                function ot(e, t) {
                    var n, r = xe;
                    if ((t ? !We.echoes || Qe++ && e === xe : !Qe || --Qe && e === xe) || (n = t ? rt.bind(null, e) : it, he.call(le, n)), e !== xe && (xe = e, r === Pe && (Pe.env = at()), me)) {
                        var i = Pe.env.Promise,
                            a = e.env;
                        fe.then = a.nthen, i.prototype.then = a.gthen, (r.global || e.global) && (Object.defineProperty(o, "Promise", a.PromiseProp), i.all = a.all, i.race = a.race, i.resolve = a.resolve, i.reject = a.reject)
                    }
                }

                function at() {
                    var e = o.Promise;
                    return me ? {
                        Promise: e,
                        PromiseProp: Object.getOwnPropertyDescriptor(o, "Promise"),
                        all: e.all,
                        race: e.race,
                        resolve: e.resolve,
                        reject: e.reject,
                        nthen: fe.then,
                        gthen: e.prototype.then
                    } : {}
                }

                function st(e, t, n, r, i) {
                    var o = xe;
                    try {
                        return ot(e, !0), t(n, r, i)
                    } finally {
                        ot(o, !1)
                    }
                }

                function ut(e, t, n) {
                    return "function" != typeof e ? e : function() {
                        var r = xe;
                        n && et(), ot(t, !0);
                        try {
                            return e.apply(this, arguments)
                        } finally {
                            ot(r, !1)
                        }
                    }
                }

                function ct(e, t) {
                    return function(n, r) {
                        return e.call(this, ut(n, t, !1), ut(r, t, !1))
                    }
                }
                var lt = "unhandledrejection";

                function ft(e, t) {
                    var n;
                    try {
                        n = t.onuncatched(e)
                    } catch (e) {}
                    if (!1 !== n) try {
                        var r, i = {
                            promise: t,
                            reason: e
                        };
                        if (o.document && document.createEvent ? ((r = document.createEvent("Event")).initEvent(lt, !0, !0), a(r, i)) : o.CustomEvent && a(r = new CustomEvent(lt, {
                                detail: i
                            }), i), r && o.dispatchEvent && (dispatchEvent(r), !o.PromiseRejectionEvent && o.onunhandledrejection)) try {
                            o.onunhandledrejection(r)
                        } catch (e) {}
                        r.defaultPrevented || console.warn("Unhandled rejection: " + (e.stack || e))
                    } catch (e) {}
                }
                var dt = ke.reject;

                function ht(e) {
                    var t = {},
                        n = function(n, r) {
                            if (r) {
                                for (var i = arguments.length, o = new Array(i - 1); --i;) o[i - 1] = arguments[i];
                                return t[n].subscribe.apply(null, o), e
                            }
                            if ("string" == typeof n) return t[n]
                        };
                    n.addEventType = s;
                    for (var o = 1, a = arguments.length; o < a; ++o) s(arguments[o]);
                    return n;

                    function s(e, r, i) {
                        if ("object" == typeof e) return u(e);
                        r || (r = ae), i || (i = $);
                        var o = {
                            subscribers: [],
                            fire: i,
                            subscribe: function(e) {
                                -1 === o.subscribers.indexOf(e) && (o.subscribers.push(e), o.fire = r(o.fire, e))
                            },
                            unsubscribe: function(e) {
                                o.subscribers = o.subscribers.filter((function(t) {
                                    return t !== e
                                })), o.fire = o.subscribers.reduce(r, i)
                            }
                        };
                        return t[e] = n[e] = o, o
                    }

                    function u(e) {
                        r(e).forEach((function(t) {
                            var n = e[t];
                            if (i(n)) s(t, e[t][0], e[t][1]);
                            else {
                                if ("asap" !== n) throw new Q.InvalidArgument("Invalid event config");
                                var r = s(t, ee, (function() {
                                    for (var e = arguments.length, t = new Array(e); e--;) t[e] = arguments[e];
                                    r.subscribers.forEach((function(e) {
                                        b((function() {
                                            e.apply(null, t)
                                        }))
                                    }))
                                }))
                            }
                        }))
                    }
                }
                var vt, pt = "{version}",
                    mt = String.fromCharCode(65535),
                    yt = function() {
                        try {
                            return IDBKeyRange.only([
                                []
                            ]), [
                                []
                            ]
                        } catch (e) {
                            return mt
                        }
                    }(),
                    gt = -1 / 0,
                    _t = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.",
                    bt = "String expected.",
                    wt = [],
                    Et = "undefined" != typeof navigator && /(MSIE|Trident|Edge)/.test(navigator.userAgent),
                    Ot = Et,
                    At = Et,
                    St = function(e) {
                        return !/(dexie\.js|dexie\.min\.js)/.test(e)
                    };

                function Pt(e, t) {
                    var n, s, u, f, h, v = Pt.dependencies,
                        p = a({
                            addons: Pt.addons,
                            autoOpen: !0,
                            indexedDB: v.indexedDB,
                            IDBKeyRange: v.IDBKeyRange
                        }, t),
                        m = p.addons,
                        b = p.autoOpen,
                        x = p.indexedDB,
                        M = p.IDBKeyRange,
                        T = this._dbSchema = {},
                        j = [],
                        K = [],
                        F = {},
                        U = null,
                        Y = null,
                        V = !1,
                        z = null,
                        q = !1,
                        G = "readonly",
                        X = "readwrite",
                        J = this,
                        Z = new ke((function(e) {
                            n = e
                        })),
                        ne = new ke((function(e, t) {
                            s = t
                        })),
                        ae = !0,
                        ue = !!Ft(x);

                    function ce(e) {
                        this._cfg = {
                            version: e,
                            storesSource: null,
                            dbschema: {},
                            tables: {},
                            contentUpgrade: null
                        }, this.stores({})
                    }

                    function le(e, t, n) {
                        var i = J._createTransaction(X, K, T);
                        i.create(t), i._completion.catch(n);
                        var o = i._reject.bind(i);
                        $e((function() {
                            xe.trans = i, 0 === e ? (r(T).forEach((function(e) {
                                fe(t, e, T[e].primKey, T[e].indexes)
                            })), ke.follow((function() {
                                return J.on.populate.fire(i)
                            })).catch(o)) : function(e, t, n) {
                                var i = [],
                                    o = j.filter((function(t) {
                                        return t._cfg.version === e
                                    }))[0];
                                if (!o) throw new Q.Upgrade("Dexie specification of currently installed DB version is missing");
                                T = J._dbSchema = o._cfg.dbschema;
                                var a = !1;

                                function s() {
                                    return i.length ? ke.resolve(i.shift()(t.idbtrans)).then(s) : ke.resolve()
                                }
                                return j.filter((function(t) {
                                    return t._cfg.version > e
                                })).forEach((function(e) {
                                    i.push((function() {
                                        var r = T,
                                            i = e._cfg.dbschema;
                                        De(r, n), De(i, n), T = J._dbSchema = i;
                                        var o = function(e, t) {
                                            var n = {
                                                del: [],
                                                add: [],
                                                change: []
                                            };
                                            for (var r in e) t[r] || n.del.push(r);
                                            for (r in t) {
                                                var i = e[r],
                                                    o = t[r];
                                                if (i) {
                                                    var a = {
                                                        name: r,
                                                        def: o,
                                                        recreate: !1,
                                                        del: [],
                                                        add: [],
                                                        change: []
                                                    };
                                                    if (i.primKey.src !== o.primKey.src) a.recreate = !0, n.change.push(a);
                                                    else {
                                                        var s = i.idxByName,
                                                            u = o.idxByName;
                                                        for (var c in s) u[c] || a.del.push(c);
                                                        for (c in u) {
                                                            var l = s[c],
                                                                f = u[c];
                                                            l ? l.src !== f.src && a.change.push(f) : a.add.push(f)
                                                        }(a.del.length > 0 || a.add.length > 0 || a.change.length > 0) && n.change.push(a)
                                                    }
                                                } else n.add.push([r, o])
                                            }
                                            return n
                                        }(r, i);
                                        if (o.add.forEach((function(e) {
                                                fe(n, e[0], e[1].primKey, e[1].indexes)
                                            })), o.change.forEach((function(e) {
                                                if (e.recreate) throw new Q.Upgrade("Not yet support for changing primary key");
                                                var t = n.objectStore(e.name);
                                                e.add.forEach((function(e) {
                                                    de(t, e)
                                                })), e.change.forEach((function(e) {
                                                    t.deleteIndex(e.name), de(t, e)
                                                })), e.del.forEach((function(e) {
                                                    t.deleteIndex(e)
                                                }))
                                            })), e._cfg.contentUpgrade) return a = !0, ke.follow((function() {
                                            e._cfg.contentUpgrade(t)
                                        }))
                                    })), i.push((function(t) {
                                        a && Ot || function(e, t) {
                                            for (var n = 0; n < t.db.objectStoreNames.length; ++n) {
                                                var r = t.db.objectStoreNames[n];
                                                null == e[r] && t.db.deleteObjectStore(r)
                                            }
                                        }(e._cfg.dbschema, t)
                                    }))
                                })), s().then((function() {
                                    ! function(e, t) {
                                        r(e).forEach((function(n) {
                                            t.db.objectStoreNames.contains(n) || fe(t, n, e[n].primKey, e[n].indexes)
                                        }))
                                    }(T, n)
                                }))
                            }(e, i, t).catch(o)
                        }))
                    }

                    function fe(e, t, n, r) {
                        var i = e.db.createObjectStore(t, n.keyPath ? {
                            keyPath: n.keyPath,
                            autoIncrement: n.auto
                        } : {
                            autoIncrement: n.auto
                        });
                        return r.forEach((function(e) {
                            de(i, e)
                        })), i
                    }

                    function de(e, t) {
                        e.createIndex(t.name, t.keyPath, {
                            unique: t.unique,
                            multiEntry: t.multi
                        })
                    }

                    function he(e, t, n) {
                        if (q || xe.letThrough) {
                            var r = J._createTransaction(e, t, T);
                            try {
                                r.create()
                            } catch (e) {
                                return dt(e)
                            }
                            return r._promise(e, (function(e, t) {
                                return $e((function() {
                                    return xe.trans = r, n(e, t, r)
                                }))
                            })).then((function(e) {
                                return r._completion.then((function() {
                                    return e
                                }))
                            }))
                        }
                        if (!V) {
                            if (!b) return dt(new Q.DatabaseClosed);
                            J.open().catch($)
                        }
                        return Z.then((function() {
                            return he(e, t, n)
                        }))
                    }

                    function me(e, t, n) {
                        var r = arguments.length;
                        if (r < 2) throw new Q.InvalidArgument("Too few arguments");
                        for (var i = new Array(r - 1); --r;) i[r - 1] = arguments[r];
                        n = i.pop();
                        var o = I(i);
                        return [e, o, n]
                    }

                    function ye(e, t, n) {
                        this.name = e, this.schema = t, this._tx = n, this.hook = F[e] ? F[e].hook : ht(null, {
                            creating: [re, $],
                            reading: [te, ee],
                            updating: [oe, $],
                            deleting: [ie, $]
                        })
                    }

                    function ge(e, t, n) {
                        return (n ? Tt : Ct)((function(n) {
                            e.push(n), t && t()
                        }))
                    }

                    function _e(e, t, n, r, i) {
                        return new ke((function(o, a) {
                            var s = n.length,
                                u = s - 1;
                            if (0 === s) return o();
                            if (r) {
                                var c, l = Tt(a),
                                    f = Mt(null);
                                O((function() {
                                    for (var r = 0; r < s; ++r) {
                                        c = {
                                            onsuccess: null,
                                            onerror: null
                                        };
                                        var a = n[r];
                                        i.call(c, a[0], a[1], t);
                                        var d = e.delete(a[0]);
                                        d._hookCtx = c, d.onerror = l, d.onsuccess = r === u ? Mt(o) : f
                                    }
                                }), (function(e) {
                                    throw c.onerror && c.onerror(e), e
                                }))
                            } else
                                for (var d = 0; d < s; ++d) {
                                    var h = e.delete(n[d]);
                                    h.onerror = Ct(a), d === u && (h.onsuccess = He((function() {
                                        return o()
                                    })))
                                }
                        }))
                    }

                    function be(e, t, n, r) {
                        var i = this;
                        this.db = J, this.mode = e, this.storeNames = t, this.idbtrans = null, this.on = ht(this, "complete", "error", "abort"), this.parent = r || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new ke((function(e, t) {
                            i._resolve = e, i._reject = t
                        })), this._completion.then((function() {
                            i.active = !1, i.on.complete.fire()
                        }), (function(e) {
                            var t = i.active;
                            return i.active = !1, i.on.error.fire(e), i.parent ? i.parent._reject(e) : t && i.idbtrans && i.idbtrans.abort(), dt(e)
                        }))
                    }

                    function we(e, t, n) {
                        this._ctx = {
                            table: e,
                            index: ":id" === t ? null : t,
                            or: n
                        }
                    }

                    function Ee(e, t) {
                        var n = null,
                            r = null;
                        if (t) try {
                            n = t()
                        } catch (e) {
                            r = e
                        }
                        var i = e._ctx,
                            o = i.table;
                        this._ctx = {
                            table: o,
                            index: i.index,
                            isPrimKey: !i.index || o.schema.primKey.keyPath && i.index === o.schema.primKey.name,
                            range: n,
                            keysOnly: !1,
                            dir: "next",
                            unique: "",
                            algorithm: null,
                            filter: null,
                            replayFilter: null,
                            justLimit: !0,
                            isMatch: null,
                            offset: 0,
                            limit: 1 / 0,
                            error: r,
                            or: i.or,
                            valueMapper: o.hook.reading.fire
                        }
                    }

                    function Oe(e, t) {
                        return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter)
                    }

                    function Ae(e, t) {
                        return e._cfg.version - t._cfg.version
                    }

                    function Se(e, t, n) {
                        t.forEach((function(t) {
                            var r = n[t];
                            e.forEach((function(e) {
                                t in e || (e === be.prototype || e instanceof be ? d(e, t, {
                                    get: function() {
                                        return this.table(t)
                                    }
                                }) : e[t] = new ye(t, r))
                            }))
                        }))
                    }

                    function Pe(e, t, n, r, i, o) {
                        var a = He(o ? function(e, t, r) {
                            return n(o(e), t, r)
                        } : n, i);
                        e.onerror || (e.onerror = Ct(i)), e.onsuccess = E(t ? function() {
                            var n = e.result;
                            if (n) {
                                var o = function() {
                                    n.continue()
                                };
                                t(n, (function(e) {
                                    o = e
                                }), r, i) && a(n.value, n, (function(e) {
                                    o = e
                                })), o()
                            } else r()
                        } : function() {
                            var t = e.result;
                            if (t) {
                                var n = function() {
                                    t.continue()
                                };
                                a(t.value, t, (function(e) {
                                    n = e
                                })), n()
                            } else r()
                        }, i)
                    }

                    function Ie(e, t) {
                        return x.cmp(e, t)
                    }

                    function Me(e, t) {
                        return Ie(e, t) > 0 ? e : t
                    }

                    function Ce(e, t) {
                        return x.cmp(e, t)
                    }

                    function Te(e, t) {
                        return x.cmp(t, e)
                    }

                    function je(e, t) {
                        return e < t ? -1 : e === t ? 0 : 1
                    }

                    function Re(e, t) {
                        return e > t ? -1 : e === t ? 0 : 1
                    }

                    function Ne(e, t) {
                        return e ? t ? function() {
                            return e.apply(this, arguments) && t.apply(this, arguments)
                        } : e : t
                    }

                    function De(e, t) {
                        for (var n = t.db.objectStoreNames, r = 0; r < n.length; ++r) {
                            var i = n[r],
                                a = t.objectStore(i);
                            u = "getAll" in a;
                            for (var s = 0; s < a.indexNames.length; ++s) {
                                var c = a.indexNames[s],
                                    l = a.index(c).keyPath,
                                    f = "string" == typeof l ? l : "[" + y(l).join("+") + "]";
                                if (e[i]) {
                                    var d = e[i].idxByName[f];
                                    d && (d.name = c)
                                }
                            }
                        }
                        /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && o.WorkerGlobalScope && o instanceof o.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (u = !1)
                    }

                    function Ke(e) {
                        J.on("blocked").fire(e), wt.filter((function(e) {
                            return e.name === J.name && e !== J && !e._vcFired
                        })).map((function(t) {
                            return t.on("versionchange").fire(e)
                        }))
                    }
                    this.version = function(e) {
                        if (U || V) throw new Q.Schema("Cannot add version when database is open");
                        this.verno = Math.max(this.verno, e);
                        var t = j.filter((function(t) {
                            return t._cfg.version === e
                        }))[0];
                        return t || (t = new ce(e), j.push(t), j.sort(Ae), ae = !1, t)
                    }, a(ce.prototype, {
                        stores: function(e) {
                            this._cfg.storesSource = this._cfg.storesSource ? a(this._cfg.storesSource, e) : e;
                            var t = {};
                            j.forEach((function(e) {
                                a(t, e._cfg.storesSource)
                            }));
                            var n = this._cfg.dbschema = {};
                            return this._parseStoresSpec(t, n), T = J._dbSchema = n, [F, J, be.prototype].forEach((function(e) {
                                for (var t in e) e[t] instanceof ye && delete e[t]
                            })), Se([F, J, be.prototype, this._cfg.tables], r(n), n), K = r(n), this
                        },
                        upgrade: function(e) {
                            return this._cfg.contentUpgrade = e, this
                        },
                        _parseStoresSpec: function(e, t) {
                            r(e).forEach((function(n) {
                                if (null !== e[n]) {
                                    var r = {},
                                        o = function(e) {
                                            var t = [];
                                            return e.split(",").forEach((function(e) {
                                                var n = (e = e.trim()).replace(/([&*]|\+\+)/g, ""),
                                                    r = /^\[/.test(n) ? n.match(/^\[(.*)\]$/)[1].split("+") : n;
                                                t.push(new Nt(n, r || null, /\&/.test(e), /\*/.test(e), /\+\+/.test(e), i(r), /\./.test(e)))
                                            })), t
                                        }(e[n]),
                                        a = o.shift();
                                    if (a.multi) throw new Q.Schema("Primary key cannot be multi-valued");
                                    a.keyPath && S(r, a.keyPath, a.auto ? 0 : a.keyPath), o.forEach((function(e) {
                                        if (e.auto) throw new Q.Schema("Only primary key can be marked as autoIncrement (++)");
                                        if (!e.keyPath) throw new Q.Schema("Index must have a name and cannot be an empty string");
                                        S(r, e.keyPath, e.compound ? e.keyPath.map((function() {
                                            return ""
                                        })) : "")
                                    })), t[n] = new Dt(n, a, o, r)
                                }
                            }))
                        }
                    }), this._allTables = F, this._createTransaction = function(e, t, n, r) {
                        return new be(e, t, n, r)
                    }, this._whenReady = function(e) {
                        return q || xe.letThrough ? e() : new ke((function(e, t) {
                            if (!V) {
                                if (!b) return void t(new Q.DatabaseClosed);
                                J.open().catch($)
                            }
                            Z.then(e, t)
                        })).then(e)
                    }, this.verno = 0, this.open = function() {
                        if (V || U) return Z.then((function() {
                            return Y ? dt(Y) : J
                        }));
                        D && (ne._stackHolder = L()), V = !0, Y = null, q = !1;
                        var t = n,
                            i = null;
                        return ke.race([ne, new ke((function(t, n) {
                            if (!x) throw new Q.MissingAPI("indexedDB API not found. If using IE10+, make sure to run your code on a server URL (not locally). If using old Safari versions, make sure to include indexedDB polyfill.");
                            var o = ae ? x.open(e) : x.open(e, Math.round(10 * J.verno));
                            if (!o) throw new Q.MissingAPI("IndexedDB API not available");
                            o.onerror = Ct(n), o.onblocked = He(Ke), o.onupgradeneeded = He((function(t) {
                                if (i = o.transaction, ae && !J._allowEmptyDB) {
                                    o.onerror = jt, i.abort(), o.result.close();
                                    var r = x.deleteDatabase(e);
                                    r.onsuccess = r.onerror = He((function() {
                                        n(new Q.NoSuchDatabase("Database " + e + " doesnt exist"))
                                    }))
                                } else {
                                    i.onerror = Ct(n), le((t.oldVersion > Math.pow(2, 62) ? 0 : t.oldVersion) / 10, i, n)
                                }
                            }), n), o.onsuccess = He((function() {
                                if (i = null, U = o.result, wt.push(J), ae) ! function() {
                                    if (J.verno = U.version / 10, J._dbSchema = T = {}, 0 === (K = y(U.objectStoreNames, 0)).length) return;
                                    var e = U.transaction(Kt(K), "readonly");
                                    K.forEach((function(t) {
                                        for (var n = e.objectStore(t), r = n.keyPath, i = r && "string" == typeof r && -1 !== r.indexOf("."), o = new Nt(r, r || "", !1, !1, !!n.autoIncrement, r && "string" != typeof r, i), a = [], s = 0; s < n.indexNames.length; ++s) {
                                            var u = n.index(n.indexNames[s]);
                                            i = (r = u.keyPath) && "string" == typeof r && -1 !== r.indexOf(".");
                                            var c = new Nt(u.name, r, !!u.unique, !!u.multiEntry, !1, r && "string" != typeof r, i);
                                            a.push(c)
                                        }
                                        T[t] = new Dt(t, o, a, {})
                                    })), Se([F], r(T), T)
                                }();
                                else if (U.objectStoreNames.length > 0) try {
                                    De(T, U.transaction(Kt(U.objectStoreNames), G))
                                } catch (e) {}
                                U.onversionchange = He((function(e) {
                                    J._vcFired = !0, J.on("versionchange").fire(e)
                                })), ue || "__dbnames" === e || vt.dbnames.put({
                                    name: e
                                }).catch($), t()
                            }), n)
                        }))]).then((function() {
                            return z = [], ke.resolve(Pt.vip(J.on.ready.fire)).then((function e() {
                                if (z.length > 0) {
                                    var t = z.reduce(se, $);
                                    return z = [], ke.resolve(Pt.vip(t)).then(e)
                                }
                            }))
                        })).finally((function() {
                            z = null
                        })).then((function() {
                            return V = !1, J
                        })).catch((function(e) {
                            try {
                                i && i.abort()
                            } catch (e) {}
                            return V = !1, J.close(), dt(Y = e)
                        })).finally((function() {
                            q = !0, t()
                        }))
                    }, this.close = function() {
                        var e = wt.indexOf(J);
                        if (e >= 0 && wt.splice(e, 1), U) {
                            try {
                                U.close()
                            } catch (e) {}
                            U = null
                        }
                        b = !1, Y = new Q.DatabaseClosed, V && s(Y), Z = new ke((function(e) {
                            n = e
                        })), ne = new ke((function(e, t) {
                            s = t
                        }))
                    }, this.delete = function() {
                        var t = arguments.length > 0;
                        return new ke((function(n, r) {
                            if (t) throw new Q.InvalidArgument("Arguments not allowed in db.delete()");

                            function i() {
                                J.close();
                                var t = x.deleteDatabase(e);
                                t.onsuccess = He((function() {
                                    ue || vt.dbnames.delete(e).catch($), n()
                                })), t.onerror = Ct(r), t.onblocked = Ke
                            }
                            V ? Z.then(i) : i()
                        }))
                    }, this.backendDB = function() {
                        return U
                    }, this.isOpen = function() {
                        return null !== U
                    }, this.hasBeenClosed = function() {
                        return Y && Y instanceof Q.DatabaseClosed
                    }, this.hasFailed = function() {
                        return null !== Y
                    }, this.dynamicallyOpened = function() {
                        return ae
                    }, this.name = e, l(this, {
                        tables: {
                            get: function() {
                                return r(F).map((function(e) {
                                    return F[e]
                                }))
                            }
                        }
                    }), this.on = ht(this, "populate", "blocked", "versionchange", {
                        ready: [se, $]
                    }), this.on.ready.subscribe = g(this.on.ready.subscribe, (function(e) {
                        return function(t, n) {
                            Pt.vip((function() {
                                q ? (Y || ke.resolve().then(t), n && e(t)) : z ? (z.push(t), n && e(t)) : (e(t), n || e((function e() {
                                    J.on.ready.unsubscribe(t), J.on.ready.unsubscribe(e)
                                })))
                            }))
                        }
                    })), this.transaction = function() {
                        var e = me.apply(this, arguments);
                        return this._transaction.apply(this, e)
                    }, this._transaction = function(e, t, n) {
                        var r = xe.trans;
                        r && r.db === J && -1 === e.indexOf("!") || (r = null);
                        var i = -1 !== e.indexOf("?");
                        e = e.replace("!", "").replace("?", "");
                        try {
                            var o = t.map((function(e) {
                                var t = e instanceof ye ? e.name : e;
                                if ("string" != typeof t) throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
                                return t
                            }));
                            if ("r" == e || e == G) e = G;
                            else {
                                if ("rw" != e && e != X) throw new Q.InvalidArgument("Invalid transaction mode: " + e);
                                e = X
                            }
                            if (r) {
                                if (r.mode === G && e === X) {
                                    if (!i) throw new Q.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
                                    r = null
                                }
                                r && o.forEach((function(e) {
                                    if (r && -1 === r.storeNames.indexOf(e)) {
                                        if (!i) throw new Q.SubTransaction("Table " + e + " not included in parent transaction.");
                                        r = null
                                    }
                                })), i && r && !r.active && (r = null)
                            }
                        } catch (e) {
                            return r ? r._promise(null, (function(t, n) {
                                n(e)
                            })) : dt(e)
                        }
                        return r ? r._promise(e, a, "lock") : xe.trans ? st(xe.transless, (function() {
                            return J._whenReady(a)
                        })) : J._whenReady(a);

                        function a() {
                            return ke.resolve().then((function() {
                                var t, i = xe.transless || xe,
                                    a = J._createTransaction(e, o, T, r),
                                    s = {
                                        trans: a,
                                        transless: i
                                    };
                                r ? a.idbtrans = r.idbtrans : a.create(), n.constructor === pe && et();
                                var u = ke.follow((function() {
                                    if (t = n.call(a, a))
                                        if (t.constructor === ve) {
                                            var e = tt.bind(null, null);
                                            t.then(e, e)
                                        } else "function" == typeof t.next && "function" == typeof t.throw && (t = Rt(t))
                                }), s);
                                return (t && "function" == typeof t.then ? ke.resolve(t).then((function(e) {
                                    return a.active ? e : dt(new Q.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"))
                                })) : u.then((function() {
                                    return t
                                }))).then((function(e) {
                                    return r && a._resolve(), a._completion.then((function() {
                                        return e
                                    }))
                                })).catch((function(e) {
                                    return a._reject(e), dt(e)
                                }))
                            }))
                        }
                    }, this.table = function(e) {
                        if (!c(F, e)) throw new Q.InvalidTable("Table " + e + " does not exist");
                        return F[e]
                    }, l(ye.prototype, {
                        _trans: function(e, t, n) {
                            var r = this._tx || xe.trans;
                            return r && r.db === J ? r === xe.trans ? r._promise(e, t, n) : $e((function() {
                                return r._promise(e, t, n)
                            }), {
                                trans: r,
                                transless: xe.transless || xe
                            }) : he(e, [this.name], t)
                        },
                        _idbstore: function(e, t, n) {
                            var r = this.name;
                            return this._trans(e, (function(e, n, i) {
                                if (-1 === i.storeNames.indexOf(r)) throw new Q.NotFound("Table" + r + " not part of transaction");
                                return t(e, n, i.idbtrans.objectStore(r), i)
                            }), n)
                        },
                        get: function(e, t) {
                            if (e && e.constructor === Object) return this.where(e).first(t);
                            var n = this;
                            return this._idbstore(G, (function(t, r, i) {
                                var o = i.get(e);
                                o.onerror = Ct(r), o.onsuccess = He((function() {
                                    t(n.hook.reading.fire(o.result))
                                }), r)
                            })).then(t)
                        },
                        where: function(e) {
                            if ("string" == typeof e) return new we(this, e);
                            if (i(e)) return new we(this, "[" + e.join("+") + "]");
                            var t = r(e);
                            if (1 === t.length) return this.where(t[0]).equals(e[t[0]]);
                            var n = this.schema.indexes.concat(this.schema.primKey).filter((function(e) {
                                return e.compound && t.every((function(t) {
                                    return e.keyPath.indexOf(t) >= 0
                                })) && e.keyPath.every((function(e) {
                                    return t.indexOf(e) >= 0
                                }))
                            }))[0];
                            if (n && yt !== mt) return this.where(n.name).equals(n.keyPath.map((function(t) {
                                return e[t]
                            })));
                            n || console.warn("The query " + JSON.stringify(e) + " on " + this.name + " would benefit of a compound index [" + t.join("+") + "]");
                            var o = this.schema.idxByName,
                                a = t.reduce((function(t, n) {
                                    return [t[0] || o[n], t[0] || !o[n] ? Ne(t[1], (function(t) {
                                        return "" + A(t, n) == "" + e[n]
                                    })) : t[1]]
                                }), [null, null]),
                                s = a[0];
                            return s ? this.where(s.name).equals(e[s.keyPath]).filter(a[1]) : n ? this.filter(a[1]) : this.where(t).equals("")
                        },
                        count: function(e) {
                            return this.toCollection().count(e)
                        },
                        offset: function(e) {
                            return this.toCollection().offset(e)
                        },
                        limit: function(e) {
                            return this.toCollection().limit(e)
                        },
                        reverse: function() {
                            return this.toCollection().reverse()
                        },
                        filter: function(e) {
                            return this.toCollection().and(e)
                        },
                        each: function(e) {
                            return this.toCollection().each(e)
                        },
                        toArray: function(e) {
                            return this.toCollection().toArray(e)
                        },
                        orderBy: function(e) {
                            return new Ee(new we(this, i(e) ? "[" + e.join("+") + "]" : e))
                        },
                        toCollection: function() {
                            return new Ee(new we(this))
                        },
                        mapToClass: function(e, t) {
                            this.schema.mappedClass = e;
                            var n = Object.create(e.prototype);
                            t && It(n, t), this.schema.instanceTemplate = n;
                            var r = function(t) {
                                if (!t) return t;
                                var n = Object.create(e.prototype);
                                for (var r in t)
                                    if (c(t, r)) try {
                                        n[r] = t[r]
                                    } catch (e) {}
                                return n
                            };
                            return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = r, this.hook("reading", r), e
                        },
                        defineClass: function(e) {
                            return this.mapToClass(Pt.defineClass(e), e)
                        },
                        bulkDelete: function(e) {
                            return this.hook.deleting.fire === $ ? this._idbstore(X, (function(t, n, r, i) {
                                t(_e(r, i, e, !1, $))
                            })) : this.where(":id").anyOf(e).delete().then((function() {}))
                        },
                        bulkPut: function(e, t) {
                            var n = this;
                            return this._idbstore(X, (function(r, i, o) {
                                if (!o.keyPath && !n.schema.primKey.auto && !t) throw new Q.InvalidArgument("bulkPut() with non-inbound keys requires keys array in second argument");
                                if (o.keyPath && t) throw new Q.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
                                if (t && t.length !== e.length) throw new Q.InvalidArgument("Arguments objects and keys must have the same length");
                                if (0 === e.length) return r();
                                var a, s, u = function(e) {
                                        0 === c.length ? r(e) : i(new W(n.name + ".bulkPut(): " + c.length + " of " + l + " operations failed", c))
                                    },
                                    c = [],
                                    l = e.length,
                                    f = n;
                                if (n.hook.creating.fire === $ && n.hook.updating.fire === $) {
                                    s = ge(c);
                                    for (var d = 0, h = e.length; d < h; ++d)(a = t ? o.put(e[d], t[d]) : o.put(e[d])).onerror = s;
                                    a.onerror = ge(c, u), a.onsuccess = kt(u)
                                } else {
                                    var v = t || o.keyPath && e.map((function(e) {
                                            return A(e, o.keyPath)
                                        })),
                                        p = v && w(v, (function(t, n) {
                                            return null != t && [t, e[n]]
                                        }));
                                    (v ? f.where(":id").anyOf(v.filter((function(e) {
                                        return null != e
                                    }))).modify((function() {
                                        this.value = p[this.primKey], p[this.primKey] = null
                                    })).catch(H, (function(e) {
                                        c = e.failures
                                    })).then((function() {
                                        for (var n = [], r = t && [], i = v.length - 1; i >= 0; --i) {
                                            var o = v[i];
                                            (null == o || p[o]) && (n.push(e[i]), t && r.push(o), null != o && (p[o] = null))
                                        }
                                        return n.reverse(), t && r.reverse(), f.bulkAdd(n, r)
                                    })).then((function(e) {
                                        var t = v[v.length - 1];
                                        return null != t ? t : e
                                    })) : f.bulkAdd(e)).then(u).catch(W, (function(e) {
                                        c = c.concat(e.failures), u()
                                    })).catch(i)
                                }
                            }), "locked")
                        },
                        bulkAdd: function(e, t) {
                            var n = this,
                                r = this.hook.creating.fire;
                            return this._idbstore(X, (function(i, o, a, s) {
                                if (!a.keyPath && !n.schema.primKey.auto && !t) throw new Q.InvalidArgument("bulkAdd() with non-inbound keys requires keys array in second argument");
                                if (a.keyPath && t) throw new Q.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
                                if (t && t.length !== e.length) throw new Q.InvalidArgument("Arguments objects and keys must have the same length");
                                if (0 === e.length) return i();

                                function u(e) {
                                    0 === d.length ? i(e) : o(new W(n.name + ".bulkAdd(): " + d.length + " of " + h + " operations failed", d))
                                }
                                var c, l, f, d = [],
                                    h = e.length;
                                if (r !== $) {
                                    var v, p = a.keyPath;
                                    l = ge(d, null, !0), f = Mt(null), O((function() {
                                        for (var n = 0, i = e.length; n < i; ++n) {
                                            v = {
                                                onerror: null,
                                                onsuccess: null
                                            };
                                            var o = t && t[n],
                                                u = e[n],
                                                d = t ? o : p ? A(u, p) : void 0,
                                                h = r.call(v, d, u, s);
                                            null == d && null != h && (p ? S(u = C(u), p, h) : o = h), (c = null != o ? a.add(u, o) : a.add(u))._hookCtx = v, n < i - 1 && (c.onerror = l, v.onsuccess && (c.onsuccess = f))
                                        }
                                    }), (function(e) {
                                        throw v.onerror && v.onerror(e), e
                                    })), c.onerror = ge(d, u, !0), c.onsuccess = Mt(u)
                                } else {
                                    l = ge(d);
                                    for (var m = 0, y = e.length; m < y; ++m)(c = t ? a.add(e[m], t[m]) : a.add(e[m])).onerror = l;
                                    c.onerror = ge(d, u), c.onsuccess = kt(u)
                                }
                            }))
                        },
                        add: function(e, t) {
                            var n = this.hook.creating.fire;
                            return this._idbstore(X, (function(r, i, o, a) {
                                var s = {
                                    onsuccess: null,
                                    onerror: null
                                };
                                if (n !== $) {
                                    var u = null != t ? t : o.keyPath ? A(e, o.keyPath) : void 0,
                                        c = n.call(s, u, e, a);
                                    null == u && null != c && (o.keyPath ? S(e, o.keyPath, c) : t = c)
                                }
                                try {
                                    var l = null != t ? o.add(e, t) : o.add(e);
                                    l._hookCtx = s, l.onerror = Tt(i), l.onsuccess = Mt((function(t) {
                                        var n = o.keyPath;
                                        n && S(e, n, t), r(t)
                                    }))
                                } catch (e) {
                                    throw s.onerror && s.onerror(e), e
                                }
                            }))
                        },
                        put: function(e, t) {
                            var n = this,
                                r = this.hook.creating.fire,
                                i = this.hook.updating.fire;
                            if (r !== $ || i !== $) {
                                var o = this.schema.primKey.keyPath,
                                    a = void 0 !== t ? t : o && A(e, o);
                                return null == a ? this.add(e) : (e = C(e), this._trans(X, (function() {
                                    return n.where(":id").equals(a).modify((function() {
                                        this.value = e
                                    })).then((function(r) {
                                        return 0 === r ? n.add(e, t) : a
                                    }))
                                }), "locked"))
                            }
                            return this._idbstore(X, (function(n, r, i) {
                                var o = void 0 !== t ? i.put(e, t) : i.put(e);
                                o.onerror = Ct(r), o.onsuccess = He((function(t) {
                                    var r = i.keyPath;
                                    r && S(e, r, t.target.result), n(o.result)
                                }))
                            }))
                        },
                        delete: function(e) {
                            return this.hook.deleting.subscribers.length ? this.where(":id").equals(e).delete() : this._idbstore(X, (function(t, n, r) {
                                var i = r.delete(e);
                                i.onerror = Ct(n), i.onsuccess = He((function() {
                                    t(i.result)
                                }))
                            }))
                        },
                        clear: function() {
                            return this.hook.deleting.subscribers.length ? this.toCollection().delete() : this._idbstore(X, (function(e, t, n) {
                                var r = n.clear();
                                r.onerror = Ct(t), r.onsuccess = He((function() {
                                    e(r.result)
                                }))
                            }))
                        },
                        update: function(e, t) {
                            if ("object" != typeof t || i(t)) throw new Q.InvalidArgument("Modifications must be an object.");
                            if ("object" != typeof e || i(e)) return this.where(":id").equals(e).modify(t);
                            r(t).forEach((function(n) {
                                S(e, n, t[n])
                            }));
                            var n = A(e, this.schema.primKey.keyPath);
                            return void 0 === n ? dt(new Q.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(n).modify(t)
                        }
                    }), l(be.prototype, {
                        _lock: function() {
                            return _(!xe.global), ++this._reculock, 1 !== this._reculock || xe.global || (xe.lockOwnerFor = this), this
                        },
                        _unlock: function() {
                            if (_(!xe.global), 0 == --this._reculock)
                                for (xe.global || (xe.lockOwnerFor = null); this._blockedFuncs.length > 0 && !this._locked();) {
                                    var e = this._blockedFuncs.shift();
                                    try {
                                        st(e[1], e[0])
                                    } catch (e) {}
                                }
                            return this
                        },
                        _locked: function() {
                            return this._reculock && xe.lockOwnerFor !== this
                        },
                        create: function(e) {
                            var t = this;
                            if (!this.mode) return this;
                            if (_(!this.idbtrans), !e && !U) switch (Y && Y.name) {
                                case "DatabaseClosedError":
                                    throw new Q.DatabaseClosed(Y);
                                case "MissingAPIError":
                                    throw new Q.MissingAPI(Y.message, Y);
                                default:
                                    throw new Q.OpenFailed(Y)
                            }
                            if (!this.active) throw new Q.TransactionInactive;
                            return _(null === this._completion._state), (e = this.idbtrans = e || U.transaction(Kt(this.storeNames), this.mode)).onerror = He((function(n) {
                                jt(n), t._reject(e.error)
                            })), e.onabort = He((function(n) {
                                jt(n), t.active && t._reject(new Q.Abort(e.error)), t.active = !1, t.on("abort").fire(n)
                            })), e.oncomplete = He((function() {
                                t.active = !1, t._resolve()
                            })), this
                        },
                        _promise: function(e, t, n) {
                            var r = this;
                            if (e === X && this.mode !== X) return dt(new Q.ReadOnly("Transaction is readonly"));
                            if (!this.active) return dt(new Q.TransactionInactive);
                            if (this._locked()) return new ke((function(i, o) {
                                r._blockedFuncs.push([function() {
                                    r._promise(e, t, n).then(i, o)
                                }, xe])
                            }));
                            if (n) return $e((function() {
                                var e = new ke((function(e, n) {
                                    r._lock();
                                    var i = t(e, n, r);
                                    i && i.then && i.then(e, n)
                                }));
                                return e.finally((function() {
                                    return r._unlock()
                                })), e._lib = !0, e
                            }));
                            var i = new ke((function(e, n) {
                                var i = t(e, n, r);
                                i && i.then && i.then(e, n)
                            }));
                            return i._lib = !0, i
                        },
                        _root: function() {
                            return this.parent ? this.parent._root() : this
                        },
                        waitFor: function(e) {
                            var t = this._root();
                            if (e = ke.resolve(e), t._waitingFor) t._waitingFor = t._waitingFor.then((function() {
                                return e
                            }));
                            else {
                                t._waitingFor = e, t._waitingQueue = [];
                                var n = t.idbtrans.objectStore(t.storeNames[0]);
                                ! function e() {
                                    for (++t._spinCount; t._waitingQueue.length;) t._waitingQueue.shift()();
                                    t._waitingFor && (n.get(-1 / 0).onsuccess = e)
                                }()
                            }
                            var r = t._waitingFor;
                            return new ke((function(n, i) {
                                e.then((function(e) {
                                    return t._waitingQueue.push(He(n.bind(null, e)))
                                }), (function(e) {
                                    return t._waitingQueue.push(He(i.bind(null, e)))
                                })).finally((function() {
                                    t._waitingFor === r && (t._waitingFor = null)
                                }))
                            }))
                        },
                        abort: function() {
                            this.active && this._reject(new Q.Abort), this.active = !1
                        },
                        tables: {
                            get: (f = "Transaction.tables", h = function() {
                                return F
                            }, function() {
                                return console.warn(f + " is deprecated. See https://github.com/dfahlander/Dexie.js/wiki/Deprecations. " + B(L(), 1)), h.apply(this, arguments)
                            })
                        },
                        table: function(e) {
                            return new ye(e, J.table(e).schema, this)
                        }
                    }), l(we.prototype, (function() {
                        function e(e, t, n) {
                            var r = e instanceof we ? new Ee(e) : e;
                            return r._ctx.error = n ? new n(t) : new TypeError(t), r
                        }

                        function t(e) {
                            return new Ee(e, (function() {
                                return M.only("")
                            })).limit(0)
                        }

                        function n(e, t, n, r, i, o) {
                            for (var a = Math.min(e.length, r.length), s = -1, u = 0; u < a; ++u) {
                                var c = t[u];
                                if (c !== r[u]) return i(e[u], n[u]) < 0 ? e.substr(0, u) + n[u] + n.substr(u + 1) : i(e[u], r[u]) < 0 ? e.substr(0, u) + r[u] + n.substr(u + 1) : s >= 0 ? e.substr(0, s) + t[s] + n.substr(s + 1) : null;
                                i(e[u], c) < 0 && (s = u)
                            }
                            return a < r.length && "next" === o ? e + n.substr(e.length) : a < e.length && "prev" === o ? e.substr(0, n.length) : s < 0 ? null : e.substr(0, s) + r[s] + n.substr(s + 1)
                        }

                        function r(t, r, i, o) {
                            var a, s, u, c, l, f, d, h = i.length;
                            if (!i.every((function(e) {
                                    return "string" == typeof e
                                }))) return e(t, bt);

                            function v(e) {
                                a = function(e) {
                                    return "next" === e ? function(e) {
                                        return e.toUpperCase()
                                    } : function(e) {
                                        return e.toLowerCase()
                                    }
                                }(e), s = function(e) {
                                    return "next" === e ? function(e) {
                                        return e.toLowerCase()
                                    } : function(e) {
                                        return e.toUpperCase()
                                    }
                                }(e), u = "next" === e ? je : Re;
                                var t = i.map((function(e) {
                                    return {
                                        lower: s(e),
                                        upper: a(e)
                                    }
                                })).sort((function(e, t) {
                                    return u(e.lower, t.lower)
                                }));
                                c = t.map((function(e) {
                                    return e.upper
                                })), l = t.map((function(e) {
                                    return e.lower
                                })), f = e, d = "next" === e ? "" : o
                            }
                            v("next");
                            var p = new Ee(t, (function() {
                                return M.bound(c[0], l[h - 1] + o)
                            }));
                            p._ondirectionchange = function(e) {
                                v(e)
                            };
                            var m = 0;
                            return p._addAlgorithm((function(e, t, i) {
                                var o = e.key;
                                if ("string" != typeof o) return !1;
                                var a = s(o);
                                if (r(a, l, m)) return !0;
                                for (var v = null, p = m; p < h; ++p) {
                                    var y = n(o, a, c[p], l[p], u, f);
                                    null === y && null === v ? m = p + 1 : (null === v || u(v, y) > 0) && (v = y)
                                }
                                return t(null !== v ? function() {
                                    e.continue(v + d)
                                } : i), !1
                            })), p
                        }
                        return {
                            between: function(n, r, i, o) {
                                i = !1 !== i, o = !0 === o;
                                try {
                                    return Ie(n, r) > 0 || 0 === Ie(n, r) && (i || o) && (!i || !o) ? t(this) : new Ee(this, (function() {
                                        return M.bound(n, r, !i, !o)
                                    }))
                                } catch (t) {
                                    return e(this, _t)
                                }
                            },
                            equals: function(e) {
                                return new Ee(this, (function() {
                                    return M.only(e)
                                }))
                            },
                            above: function(e) {
                                return new Ee(this, (function() {
                                    return M.lowerBound(e, !0)
                                }))
                            },
                            aboveOrEqual: function(e) {
                                return new Ee(this, (function() {
                                    return M.lowerBound(e)
                                }))
                            },
                            below: function(e) {
                                return new Ee(this, (function() {
                                    return M.upperBound(e, !0)
                                }))
                            },
                            belowOrEqual: function(e) {
                                return new Ee(this, (function() {
                                    return M.upperBound(e)
                                }))
                            },
                            startsWith: function(t) {
                                return "string" != typeof t ? e(this, bt) : this.between(t, t + mt, !0, !0)
                            },
                            startsWithIgnoreCase: function(e) {
                                return "" === e ? this.startsWith(e) : r(this, (function(e, t) {
                                    return 0 === e.indexOf(t[0])
                                }), [e], mt)
                            },
                            equalsIgnoreCase: function(e) {
                                return r(this, (function(e, t) {
                                    return e === t[0]
                                }), [e], "")
                            },
                            anyOfIgnoreCase: function() {
                                var e = N.apply(R, arguments);
                                return 0 === e.length ? t(this) : r(this, (function(e, t) {
                                    return -1 !== t.indexOf(e)
                                }), e, "")
                            },
                            startsWithAnyOfIgnoreCase: function() {
                                var e = N.apply(R, arguments);
                                return 0 === e.length ? t(this) : r(this, (function(e, t) {
                                    return t.some((function(t) {
                                        return 0 === e.indexOf(t)
                                    }))
                                }), e, mt)
                            },
                            anyOf: function() {
                                var n = N.apply(R, arguments),
                                    r = Ce;
                                try {
                                    n.sort(r)
                                } catch (t) {
                                    return e(this, _t)
                                }
                                if (0 === n.length) return t(this);
                                var i = new Ee(this, (function() {
                                    return M.bound(n[0], n[n.length - 1])
                                }));
                                i._ondirectionchange = function(e) {
                                    r = "next" === e ? Ce : Te, n.sort(r)
                                };
                                var o = 0;
                                return i._addAlgorithm((function(e, t, i) {
                                    for (var a = e.key; r(a, n[o]) > 0;)
                                        if (++o === n.length) return t(i), !1;
                                    return 0 === r(a, n[o]) || (t((function() {
                                        e.continue(n[o])
                                    })), !1)
                                })), i
                            },
                            notEqual: function(e) {
                                return this.inAnyRange([
                                    [gt, e],
                                    [e, yt]
                                ], {
                                    includeLowers: !1,
                                    includeUppers: !1
                                })
                            },
                            noneOf: function() {
                                var t = N.apply(R, arguments);
                                if (0 === t.length) return new Ee(this);
                                try {
                                    t.sort(Ce)
                                } catch (t) {
                                    return e(this, _t)
                                }
                                var n = t.reduce((function(e, t) {
                                    return e ? e.concat([
                                        [e[e.length - 1][1], t]
                                    ]) : [
                                        [gt, t]
                                    ]
                                }), null);
                                return n.push([t[t.length - 1], yt]), this.inAnyRange(n, {
                                    includeLowers: !1,
                                    includeUppers: !1
                                })
                            },
                            inAnyRange: function(n, r) {
                                if (0 === n.length) return t(this);
                                if (!n.every((function(e) {
                                        return void 0 !== e[0] && void 0 !== e[1] && Ce(e[0], e[1]) <= 0
                                    }))) return e(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", Q.InvalidArgument);
                                var i = !r || !1 !== r.includeLowers,
                                    o = r && !0 === r.includeUppers;
                                var a, s = Ce;

                                function u(e, t) {
                                    return s(e[0], t[0])
                                }
                                try {
                                    (a = n.reduce((function(e, t) {
                                        for (var n = 0, r = e.length; n < r; ++n) {
                                            var i = e[n];
                                            if (Ie(t[0], i[1]) < 0 && Ie(t[1], i[0]) > 0) {
                                                i[0] = Ie(o = i[0], a = t[0]) < 0 ? o : a, i[1] = Me(i[1], t[1]);
                                                break
                                            }
                                        }
                                        var o, a;
                                        return n === r && e.push(t), e
                                    }), [])).sort(u)
                                } catch (t) {
                                    return e(this, _t)
                                }
                                var c = 0,
                                    l = o ? function(e) {
                                        return Ce(e, a[c][1]) > 0
                                    } : function(e) {
                                        return Ce(e, a[c][1]) >= 0
                                    },
                                    f = i ? function(e) {
                                        return Te(e, a[c][0]) > 0
                                    } : function(e) {
                                        return Te(e, a[c][0]) >= 0
                                    };
                                var d = l,
                                    h = new Ee(this, (function() {
                                        return M.bound(a[0][0], a[a.length - 1][1], !i, !o)
                                    }));
                                return h._ondirectionchange = function(e) {
                                    "next" === e ? (d = l, s = Ce) : (d = f, s = Te), a.sort(u)
                                }, h._addAlgorithm((function(e, t, n) {
                                    for (var r = e.key; d(r);)
                                        if (++c === a.length) return t(n), !1;
                                    return !! function(e) {
                                        return !l(e) && !f(e)
                                    }(r) || (0 === Ie(r, a[c][1]) || 0 === Ie(r, a[c][0]) || t((function() {
                                        s === Ce ? e.continue(a[c][0]) : e.continue(a[c][1])
                                    })), !1)
                                })), h
                            },
                            startsWithAnyOf: function() {
                                var n = N.apply(R, arguments);
                                return n.every((function(e) {
                                    return "string" == typeof e
                                })) ? 0 === n.length ? t(this) : this.inAnyRange(n.map((function(e) {
                                    return [e, e + mt]
                                }))) : e(this, "startsWithAnyOf() only works with strings")
                            }
                        }
                    })), l(Ee.prototype, (function() {
                        function e(e, t) {
                            e.filter = Ne(e.filter, t)
                        }

                        function t(e, t, n) {
                            var r = e.replayFilter;
                            e.replayFilter = r ? function() {
                                return Ne(r(), t())
                            } : t, e.justLimit = n && !r
                        }

                        function n(e, t) {
                            if (e.isPrimKey) return t;
                            var n = e.table.schema.idxByName[e.index];
                            if (!n) throw new Q.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
                            return t.index(n.name)
                        }

                        function i(e, t) {
                            var r = n(e, t);
                            return e.keysOnly && "openKeyCursor" in r ? r.openKeyCursor(e.range || null, e.dir + e.unique) : r.openCursor(e.range || null, e.dir + e.unique)
                        }

                        function o(e, t, n, r, o) {
                            var a = e.replayFilter ? Ne(e.filter, e.replayFilter()) : e.filter;
                            e.or ? function() {
                                var s = {},
                                    u = 0;

                                function l() {
                                    2 == ++u && n()
                                }

                                function f(e, n, i) {
                                    if (!a || a(n, i, l, r)) {
                                        var o = n.primaryKey,
                                            u = "" + o;
                                        "[object ArrayBuffer]" === u && (u = "" + new Uint8Array(o)), c(s, u) || (s[u] = !0, t(e, n, i))
                                    }
                                }
                                e.or._iterate(f, l, r, o), Pe(i(e, o), e.algorithm, f, l, r, !e.keysOnly && e.valueMapper)
                            }() : Pe(i(e, o), Ne(e.algorithm, a), t, n, r, !e.keysOnly && e.valueMapper)
                        }
                        return {
                            _read: function(e, t) {
                                var n = this._ctx;
                                return n.error ? n.table._trans(null, dt.bind(null, n.error)) : n.table._idbstore(G, e).then(t)
                            },
                            _write: function(e) {
                                var t = this._ctx;
                                return t.error ? t.table._trans(null, dt.bind(null, t.error)) : t.table._idbstore(X, e, "locked")
                            },
                            _addAlgorithm: function(e) {
                                var t = this._ctx;
                                t.algorithm = Ne(t.algorithm, e)
                            },
                            _iterate: function(e, t, n, r) {
                                return o(this._ctx, e, t, n, r)
                            },
                            clone: function(e) {
                                var t = Object.create(this.constructor.prototype),
                                    n = Object.create(this._ctx);
                                return e && a(n, e), t._ctx = n, t
                            },
                            raw: function() {
                                return this._ctx.valueMapper = null, this
                            },
                            each: function(e) {
                                var t = this._ctx;
                                return this._read((function(n, r, i) {
                                    o(t, e, n, r, i)
                                }))
                            },
                            count: function(e) {
                                var t = this._ctx;
                                if (Oe(t, !0)) return this._read((function(e, r, i) {
                                    var o = n(t, i),
                                        a = t.range ? o.count(t.range) : o.count();
                                    a.onerror = Ct(r), a.onsuccess = function(n) {
                                        e(Math.min(n.target.result, t.limit))
                                    }
                                }), e);
                                var r = 0;
                                return this._read((function(e, n, i) {
                                    o(t, (function() {
                                        return ++r, !1
                                    }), (function() {
                                        e(r)
                                    }), n, i)
                                }), e)
                            },
                            sortBy: function(e, t) {
                                var n = e.split(".").reverse(),
                                    r = n[0],
                                    i = n.length - 1;

                                function o(e, t) {
                                    return t ? o(e[n[t]], t - 1) : e[r]
                                }
                                var a = "next" === this._ctx.dir ? 1 : -1;

                                function s(e, t) {
                                    var n = o(e, i),
                                        r = o(t, i);
                                    return n < r ? -a : n > r ? a : 0
                                }
                                return this.toArray((function(e) {
                                    return e.sort(s)
                                })).then(t)
                            },
                            toArray: function(e) {
                                var t = this._ctx;
                                return this._read((function(e, r, i) {
                                    if (u && "next" === t.dir && Oe(t, !0) && t.limit > 0) {
                                        var a = t.table.hook.reading.fire,
                                            s = n(t, i),
                                            c = t.limit < 1 / 0 ? s.getAll(t.range, t.limit) : s.getAll(t.range);
                                        c.onerror = Ct(r), c.onsuccess = kt(a === ee ? e : function(t) {
                                            try {
                                                e(t.map(a))
                                            } catch (e) {
                                                r(e)
                                            }
                                        })
                                    } else {
                                        var l = [];
                                        o(t, (function(e) {
                                            l.push(e)
                                        }), (function() {
                                            e(l)
                                        }), r, i)
                                    }
                                }), e)
                            },
                            offset: function(e) {
                                var n = this._ctx;
                                return e <= 0 || (n.offset += e, Oe(n) ? t(n, (function() {
                                    var t = e;
                                    return function(e, n) {
                                        return 0 === t || (1 === t ? (--t, !1) : (n((function() {
                                            e.advance(t), t = 0
                                        })), !1))
                                    }
                                })) : t(n, (function() {
                                    var t = e;
                                    return function() {
                                        return --t < 0
                                    }
                                }))), this
                            },
                            limit: function(e) {
                                return this._ctx.limit = Math.min(this._ctx.limit, e), t(this._ctx, (function() {
                                    var t = e;
                                    return function(e, n, r) {
                                        return --t <= 0 && n(r), t >= 0
                                    }
                                }), !0), this
                            },
                            until: function(t, n) {
                                return e(this._ctx, (function(e, r, i) {
                                    return !t(e.value) || (r(i), n)
                                })), this
                            },
                            first: function(e) {
                                return this.limit(1).toArray((function(e) {
                                    return e[0]
                                })).then(e)
                            },
                            last: function(e) {
                                return this.reverse().first(e)
                            },
                            filter: function(t) {
                                return e(this._ctx, (function(e) {
                                        return t(e.value)
                                    })),
                                    function(e, t) {
                                        e.isMatch = Ne(e.isMatch, t)
                                    }(this._ctx, t), this
                            },
                            and: function(e) {
                                return this.filter(e)
                            },
                            or: function(e) {
                                return new we(this._ctx.table, e, this)
                            },
                            reverse: function() {
                                return this._ctx.dir = "prev" === this._ctx.dir ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this
                            },
                            desc: function() {
                                return this.reverse()
                            },
                            eachKey: function(e) {
                                var t = this._ctx;
                                return t.keysOnly = !t.isMatch, this.each((function(t, n) {
                                    e(n.key, n)
                                }))
                            },
                            eachUniqueKey: function(e) {
                                return this._ctx.unique = "unique", this.eachKey(e)
                            },
                            eachPrimaryKey: function(e) {
                                var t = this._ctx;
                                return t.keysOnly = !t.isMatch, this.each((function(t, n) {
                                    e(n.primaryKey, n)
                                }))
                            },
                            keys: function(e) {
                                var t = this._ctx;
                                t.keysOnly = !t.isMatch;
                                var n = [];
                                return this.each((function(e, t) {
                                    n.push(t.key)
                                })).then((function() {
                                    return n
                                })).then(e)
                            },
                            primaryKeys: function(e) {
                                var t = this._ctx;
                                if (u && "next" === t.dir && Oe(t, !0) && t.limit > 0) return this._read((function(e, r, i) {
                                    var o = n(t, i),
                                        a = t.limit < 1 / 0 ? o.getAllKeys(t.range, t.limit) : o.getAllKeys(t.range);
                                    a.onerror = Ct(r), a.onsuccess = kt(e)
                                })).then(e);
                                t.keysOnly = !t.isMatch;
                                var r = [];
                                return this.each((function(e, t) {
                                    r.push(t.primaryKey)
                                })).then((function() {
                                    return r
                                })).then(e)
                            },
                            uniqueKeys: function(e) {
                                return this._ctx.unique = "unique", this.keys(e)
                            },
                            firstKey: function(e) {
                                return this.limit(1).keys((function(e) {
                                    return e[0]
                                })).then(e)
                            },
                            lastKey: function(e) {
                                return this.reverse().firstKey(e)
                            },
                            distinct: function() {
                                var t = this._ctx,
                                    n = t.index && t.table.schema.idxByName[t.index];
                                if (!n || !n.multi) return this;
                                var r = {};
                                return e(this._ctx, (function(e) {
                                    var t = e.primaryKey.toString(),
                                        n = c(r, t);
                                    return r[t] = !0, !n
                                })), this
                            },
                            modify: function(e) {
                                var t = this,
                                    n = this._ctx.table.hook,
                                    i = n.updating.fire,
                                    o = n.deleting.fire;
                                return this._write((function(n, s, u, l) {
                                    var f;
                                    if ("function" == typeof e) f = i === $ && o === $ ? e : function(t) {
                                        var n = C(t);
                                        if (!1 === e.call(this, t, this)) return !1;
                                        if (c(this, "value")) {
                                            var a = k(n, this.value),
                                                s = i.call(this, a, this.primKey, n, l);
                                            s && (t = this.value, r(s).forEach((function(e) {
                                                S(t, e, s[e])
                                            })))
                                        } else o.call(this, this.primKey, t, l)
                                    };
                                    else if (i === $) {
                                        var d = r(e),
                                            h = d.length;
                                        f = function(t) {
                                            for (var n = !1, r = 0; r < h; ++r) {
                                                var i = d[r],
                                                    o = e[i];
                                                A(t, i) !== o && (S(t, i, o), n = !0)
                                            }
                                            return n
                                        }
                                    } else {
                                        var v = e;
                                        e = P(v), f = function(t) {
                                            var n = !1,
                                                o = i.call(this, e, this.primKey, C(t), l);
                                            return o && a(e, o), r(e).forEach((function(r) {
                                                var i = e[r];
                                                A(t, r) !== i && (S(t, r, i), n = !0)
                                            })), o && (e = P(v)), n
                                        }
                                    }
                                    var p = 0,
                                        m = 0,
                                        y = !1,
                                        g = [],
                                        _ = [],
                                        b = null;

                                    function w(e) {
                                        return e && (g.push(e), _.push(b)), s(new H("Error modifying one or more objects", g, m, _))
                                    }

                                    function E() {
                                        y && m + g.length === p && (g.length > 0 ? w() : n(m))
                                    }
                                    t.clone().raw()._iterate((function(e, t) {
                                        b = t.primaryKey;
                                        var n = {
                                            primKey: t.primaryKey,
                                            value: e,
                                            onsuccess: null,
                                            onerror: null
                                        };

                                        function r(e) {
                                            return g.push(e), _.push(n.primKey), E(), !0
                                        }
                                        if (!1 !== f.call(n, e, n)) {
                                            var i = !c(n, "value");
                                            ++p, O((function() {
                                                var e = i ? t.delete() : t.update(n.value);
                                                e._hookCtx = n, e.onerror = Tt(r), e.onsuccess = Mt((function() {
                                                    ++m, E()
                                                }))
                                            }), r)
                                        } else n.onsuccess && n.onsuccess(n.value)
                                    }), (function() {
                                        y = !0, E()
                                    }), w, u)
                                }))
                            },
                            delete: function() {
                                var e = this,
                                    t = this._ctx,
                                    n = t.range,
                                    r = t.table.hook.deleting.fire,
                                    i = r !== $;
                                if (!i && Oe(t) && (t.isPrimKey && !At || !n)) return this._write((function(e, t, r) {
                                    var i = Ct(t),
                                        o = n ? r.count(n) : r.count();
                                    o.onerror = i, o.onsuccess = function() {
                                        var a = o.result;
                                        O((function() {
                                            var t = n ? r.delete(n) : r.clear();
                                            t.onerror = i, t.onsuccess = function() {
                                                return e(a)
                                            }
                                        }), (function(e) {
                                            return t(e)
                                        }))
                                    }
                                }));
                                var o = i ? 2e3 : 1e4;
                                return this._write((function(n, a, s, u) {
                                    var c = 0,
                                        l = e.clone({
                                            keysOnly: !t.isMatch && !i
                                        }).distinct().limit(o).raw(),
                                        f = [],
                                        d = function() {
                                            return l.each(i ? function(e, t) {
                                                f.push([t.primaryKey, t.value])
                                            } : function(e, t) {
                                                f.push(t.primaryKey)
                                            }).then((function() {
                                                return i ? f.sort((function(e, t) {
                                                    return Ce(e[0], t[0])
                                                })) : f.sort(Ce), _e(s, u, f, i, r)
                                            })).then((function() {
                                                var e = f.length;
                                                return c += e, f = [], e < o ? c : d()
                                            }))
                                        };
                                    n(d())
                                }))
                            }
                        }
                    })), a(this, {
                        Collection: Ee,
                        Table: ye,
                        Transaction: be,
                        Version: ce,
                        WhereClause: we
                    }), J.on("versionchange", (function(e) {
                        e.newVersion > 0 ? console.warn("Another connection wants to upgrade database '" + J.name + "'. Closing db now to resume the upgrade.") : console.warn("Another connection wants to delete database '" + J.name + "'. Closing db now to resume the delete request."), J.close()
                    })), J.on("blocked", (function(e) {
                        !e.newVersion || e.newVersion < e.oldVersion ? console.warn("Dexie.delete('" + J.name + "') was blocked") : console.warn("Upgrade '" + J.name + "' blocked by other connection holding version " + e.oldVersion / 10)
                    })), m.forEach((function(e) {
                        e(J)
                    }))
                }

                function xt(e) {
                    if ("function" == typeof e) return new e;
                    if (i(e)) return [xt(e[0])];
                    if (e && "object" == typeof e) {
                        var t = {};
                        return It(t, e), t
                    }
                    return e
                }

                function It(e, t) {
                    return r(t).forEach((function(n) {
                        var r = xt(t[n]);
                        e[n] = r
                    })), e
                }

                function Mt(e) {
                    return He((function(t) {
                        var n = t.target,
                            r = n._hookCtx,
                            i = r.value || n.result,
                            o = r && r.onsuccess;
                        o && o(i), e && e(i)
                    }), e)
                }

                function Ct(e) {
                    return He((function(t) {
                        return jt(t), e(t.target.error), !1
                    }))
                }

                function kt(e) {
                    return He((function(t) {
                        e(t.target.result)
                    }))
                }

                function Tt(e) {
                    return He((function(t) {
                        var n = t.target,
                            r = n.error,
                            i = n._hookCtx,
                            o = i && i.onerror;
                        return o && o(r), jt(t), e(r), !1
                    }))
                }

                function jt(e) {
                    e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault()
                }

                function Rt(e) {
                    var t = function(t) {
                            return e.next(t)
                        },
                        n = o(t),
                        r = o((function(t) {
                            return e.throw(t)
                        }));

                    function o(e) {
                        return function(t) {
                            var o = e(t),
                                a = o.value;
                            return o.done ? a : a && "function" == typeof a.then ? a.then(n, r) : i(a) ? ke.all(a).then(n, r) : n(a)
                        }
                    }
                    return o(t)()
                }

                function Nt(e, t, n, r, i, o, a) {
                    this.name = e, this.keyPath = t, this.unique = n, this.multi = r, this.auto = i, this.compound = o, this.dotted = a;
                    var s = "string" == typeof t ? t : t && "[" + [].join.call(t, "+") + "]";
                    this.src = (n ? "&" : "") + (r ? "*" : "") + (i ? "++" : "") + s
                }

                function Dt(e, t, n, r) {
                    this.name = e, this.primKey = t || new Nt, this.indexes = n || [new Nt], this.instanceTemplate = r, this.mappedClass = null, this.idxByName = w(n, (function(e) {
                        return [e.name, e]
                    }))
                }

                function Kt(e) {
                    return 1 === e.length ? e[0] : e
                }

                function Ft(e) {
                    var t = e && (e.getDatabaseNames || e.webkitGetDatabaseNames);
                    return t && t.bind(e)
                }
                K(D, St), l(Pt, Z), l(Pt, {
                        delete: function(e) {
                            var t = new Pt(e),
                                n = t.delete();
                            return n.onblocked = function(e) {
                                return t.on("blocked", e), this
                            }, n
                        },
                        exists: function(e) {
                            return new Pt(e).open().then((function(e) {
                                return e.close(), !0
                            })).catch(Pt.NoSuchDatabaseError, (function() {
                                return !1
                            }))
                        },
                        getDatabaseNames: function(e) {
                            var t = Ft(Pt.dependencies.indexedDB);
                            return t ? new ke((function(e, n) {
                                var r = t();
                                r.onsuccess = function(t) {
                                    e(y(t.target.result, 0))
                                }, r.onerror = Ct(n)
                            })).then(e) : vt.dbnames.toCollection().primaryKeys(e)
                        },
                        defineClass: function() {
                            return function(e) {
                                e && a(this, e)
                            }
                        },
                        applyStructure: It,
                        ignoreTransaction: function(e) {
                            return xe.trans ? st(xe.transless, e) : e()
                        },
                        vip: function(e) {
                            return $e((function() {
                                return xe.letThrough = !0, e()
                            }))
                        },
                        async: function(e) {
                            return function() {
                                try {
                                    var t = Rt(e.apply(this, arguments));
                                    return t && "function" == typeof t.then ? t : ke.resolve(t)
                                } catch (e) {
                                    return dt(e)
                                }
                            }
                        },
                        spawn: function(e, t, n) {
                            try {
                                var r = Rt(e.apply(n, t || []));
                                return r && "function" == typeof r.then ? r : ke.resolve(r)
                            } catch (e) {
                                return dt(e)
                            }
                        },
                        currentTransaction: {
                            get: function() {
                                return xe.trans || null
                            }
                        },
                        waitFor: function(e, t) {
                            var n = ke.resolve("function" == typeof e ? Pt.ignoreTransaction(e) : e).timeout(t || 6e4);
                            return xe.trans ? xe.trans.waitFor(n) : n
                        },
                        Promise: ke,
                        debug: {
                            get: function() {
                                return D
                            },
                            set: function(e) {
                                K(e, "dexie" === e ? function() {
                                    return !0
                                } : St)
                            }
                        },
                        derive: h,
                        extend: a,
                        props: l,
                        override: g,
                        Events: ht,
                        getByKeyPath: A,
                        setByKeyPath: S,
                        delByKeyPath: function(e, t) {
                            "string" == typeof t ? S(e, t, void 0) : "length" in t && [].map.call(t, (function(t) {
                                S(e, t, void 0)
                            }))
                        },
                        shallowClone: P,
                        deepClone: C,
                        getObjectDiff: k,
                        asap: b,
                        maxKey: yt,
                        minKey: gt,
                        addons: [],
                        connections: wt,
                        MultiModifyError: Q.Modify,
                        errnames: G,
                        IndexSpec: Nt,
                        TableSchema: Dt,
                        dependencies: function() {
                            try {
                                return {
                                    indexedDB: o.indexedDB || o.mozIndexedDB || o.webkitIndexedDB || o.msIndexedDB,
                                    IDBKeyRange: o.IDBKeyRange || o.webkitIDBKeyRange
                                }
                            } catch (e) {
                                return {
                                    indexedDB: null,
                                    IDBKeyRange: null
                                }
                            }
                        }(),
                        semVer: pt,
                        version: pt.split(".").map((function(e) {
                            return parseInt(e)
                        })).reduce((function(e, t, n) {
                            return e + t / Math.pow(10, 2 * n)
                        })),
                        default: Pt,
                        Dexie: Pt
                    }), ke.rejectionMapper = function(e, t) {
                        if (!e || e instanceof q || e instanceof TypeError || e instanceof SyntaxError || !e.name || !J[e.name]) return e;
                        var n = new J[e.name](t || e.message, e);
                        return "stack" in e && d(n, "stack", {
                            get: function() {
                                return this.inner.stack
                            }
                        }), n
                    }, (vt = new Pt("__dbnames")).version(1).stores({
                        dbnames: "name"
                    }),
                    function() {
                        var e = "Dexie.DatabaseNames";
                        try {
                            void 0 !== typeof localStorage && void 0 !== o.document && (JSON.parse(localStorage.getItem(e) || "[]").forEach((function(e) {
                                return vt.dbnames.put({
                                    name: e
                                }).catch($)
                            })), localStorage.removeItem(e))
                        } catch (e) {}
                    }(), t.default = Pt
            },
            7677: e => {
                "use strict";
                e.exports = function(e, t, n, r, i, o, a, s) {
                    if (!e) {
                        var u;
                        if (void 0 === t) u = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                        else {
                            var c = [n, r, i, o, a, s],
                                l = 0;
                            (u = new Error(t.replace(/%s/g, (function() {
                                return c[l++]
                            })))).name = "Invariant Violation"
                        }
                        throw u.framesToPop = 1, u
                    }
                }
            },
            1449: (e, t) => {
                "use strict";
                t.Z = g;
                var n, r = "undefined" != typeof Promise ? Promise : null,
                    i = 0,
                    o = [],
                    a = [],
                    s = [],
                    u = {
                        sentinel: "CONTINUE_AS_IF_NO_HANDLER"
                    },
                    c = {
                        sentinel: "RETRY_ASYNCHRONOUSLY"
                    },
                    l = {
                        sentinel: "TO_STRING"
                    },
                    f = {
                        sentinel: "DID_ERROR"
                    },
                    d = null,
                    h = [],
                    v = 16,
                    p = 64,
                    m = 128,
                    y = 512;

                function g(e, t) {
                    this._flags = 0, this._value = void 0, this._onFulfilled = void 0, this._onRejected = void 0, this._context = void 0, this._resolveLevel = 0, this._control = void 0, this.x = void 0, this._thenableParent = null, this._parent = void 0, this._child = void 0, this._children = void 0, this.control = void 0, t && (this._context = t.this), "function" == typeof e && (this._onFulfilled = e, this._flags |= 4, this._flags |= 256, W(e, this._context, (e => F(this, 0, !0, !1, e)), (e => F(this, 0, !1, !1, e))))
                }

                function _(e) {
                    if (void 0 === e) return n;
                    if (D(e)) return e;
                    var t = new g;
                    return F(t, 0, !0, !1, e), Q(t, y), t
                }

                function b(e) {
                    var t = new g;
                    return t._value = e, Q(t, 514), h.push(t), t
                }

                function w(e) {
                    var t = arguments.length - 1;
                    if (0 === t) return this.then(void 0, e);
                    for (var n = new Array(t), r = 0; r < t; r++) n[r] = B(arguments[r]);
                    var i = Y(n, arguments[t]),
                        o = K(this, void 0, i);
                    return o._onRejected && Q(o, m), o
                }

                function E(e) {
                    return new g((function(t, n) {
                        var r = e.length;
                        if (0 !== r)
                            for (var i = new Array(e.length), o = 0; o < e.length; o++) i[o] = K(e[o], a, n);
                        else t([]);

                        function a(e) {
                            if (0 == --r) {
                                for (var n = [], o = 0; o < i.length; o++) {
                                    var a = i[o];
                                    n.push(a && 3 & a._flags ? a._value : e)
                                }
                                t(n)
                            }
                            return e
                        }
                    }))
                }

                function O(e, t) {
                    this.errors = e || [], this.message = t || "".concat(this.errors.length, " errors")
                }

                function A(e) {
                    var t = "";
                    if (e._flags & m) t = (e._onFulfilled || e._onRejected).call(e._context, l);
                    else if (e._control) t = ".addRawControl(".concat(e._control.name, ", ").concat(e._control.foo, ")");
                    else if (e._flags & v) t = ".endWithControls(".concat(Object.keys(e.control), ")");
                    else if (e._flags & y) t = 1 & e._flags ? "Promise.resolve(".concat(void 0 === e._value ? "" : e._value, ")") : "Promise.reject(".concat(void 0 === e._value ? "" : e._value, ")");
                    else if (256 & e._flags) switch (3 & e._flags) {
                        case 2:
                        case 0:
                        case 1:
                            t = "new Promise(".concat(e._onFulfilled, ")")
                    } else e._onFulfilled && e._onRejected ? t = ".then(".concat(e._onFulfilled, ", ").concat(e._onRejected, ")") : e._onFulfilled ? t = ".then(".concat(e._onFulfilled, ")") : e._onRejected && (t = ".catch(".concat(e._onRejected, ")"));
                    return t
                }

                function S(e) {
                    this.message = e || "StackPromise timed out"
                }

                function P(e, t, n, r) {
                    this.name = e, this.foo = t, this.lightning = !!n, this.canRunMultipleTimes = !!r
                }

                function x(e, t) {
                    return function() {
                        for (var n, r, i = e._parent; i && !(3 & i._flags) && !(i._flags & v); i = i._parent) !i._control || i._control.name !== t || 4 & i._flags || (n = i);
                        if (!n) return g.NO_ACTIVE_CONTROL;
                        if (n._control.canRunMultipleTimes || Q(n, 4), arguments.length > 0) {
                            r = new Array(arguments.length);
                            for (var o = 0; o < arguments.length; o++) r[o] = arguments[o]
                        }
                        return n._control.foo.call(n._context, (e => U(n, n._resolveLevel, !0, !1, e)), (e => U(n, n._resolveLevel, !1, !1, e)), n._parent, r)
                    }
                }

                function I(e) {
                    this.message = e, this.stack = new Error(e || this.name).stack
                }
                g.resolve = _, g.reject = b, g.prototype.then = function(e, t) {
                    "function" != typeof e && (e = void 0), "function" != typeof t && (t = void 0);
                    var n = new g;
                    n._onFulfilled = e, n._onRejected = t, n._context = this._context, this._flags & p && Q(n, p);
                    var r = 3 & this._flags;
                    return 0 === r ? j(this, n) : (Q(this, 8), (1 === r ? e : t) ? (n._parent = this, a.push(n), k()) : (n._parent = this, Q(n, r), n._value = this._value, 2 === r && h.push(n))), n
                }, g.prototype.catch = w, g.prototype.catchType = w, g.prototype.catchTypes = w, g.prototype.catchTypes3 = w, g.prototype.catchEqualTo = w, g.prototype.catchConditional = w, g.prototype.end = function(e) {
                    var t = this.then();
                    if (Q(t, v), t.control = {}, t._context = void 0, e) {
                        var n = e.controls;
                        if (n)
                            for (var r = 0; r < n.length; r++) {
                                var i = n[r];
                                t.control[i] = x(t, i)
                            }
                        return t
                    }
                }, g.prototype.endWithControls = function() {
                    var e = this.then();
                    Q(e, v), e.control = {}, e._context = void 0;
                    for (var t = 0; t < arguments.length; t++) {
                        var n = arguments[t];
                        e.control[n] = x(e, n)
                    }
                    return e
                }, g.all = E, g.allSettled = function(e) {
                    return new g((function(t) {
                        var n = Array.from(e),
                            r = n.length;
                        if (0 !== r)
                            for (var i = new Array(n.length), o = u(!1), a = u(!0), s = 0; s < n.length; s++) i[s] = K(n[s], o, a);
                        else t([]);

                        function u(e) {
                            return function(n) {
                                var o = e ? {
                                    status: "rejected",
                                    reason: n
                                } : {
                                    status: "fulfilled",
                                    value: n
                                };
                                if (0 == --r) {
                                    for (var a = [], s = 0; s < i.length; s++) {
                                        var u = i[s];
                                        a.push(u && 3 & u._flags ? u._value : o)
                                    }
                                    t(a)
                                }
                                return o
                            }
                        }
                    }))
                }, g.any = function(e) {
                    return new g((function(t, n) {
                        var r = e.length;
                        0 === r && n(new O([], "StackPromise.any called with []"));
                        var i = new Array(e.length);

                        function o(e) {
                            if (0 == --r) {
                                for (var t = [], o = 0; o < i.length; o++) {
                                    var a = i[o];
                                    t.push(a && 3 & a._flags ? a._value : e)
                                }
                                n(new O(t))
                            }
                            return e
                        }
                        for (var a = 0; a < e.length; a++) i[a] = K(e[a], t, o)
                    }))
                }, g.props = function(e) {
                    var t = Object.keys(e),
                        n = g.all(t.map((t => e[t])));

                    function r(e) {
                        for (var n = {}, r = 0; r < e.length; r++) n[t[r]] = e[r];
                        return n
                    }
                    switch (3 & n._flags) {
                        case 2:
                            return n;
                        case 0:
                            return Q(n.then(r), 32);
                        case 1:
                            return n._value = r(n._value), n
                    }
                }, g.map = function(e, t) {
                    var n = !0;
                    var r = E(e.map((function(e, r) {
                        return _(e).then(function(e) {
                            return function(r) {
                                return n && t(r, e)
                            }
                        }(r))
                    })));
                    switch (3 & r._flags) {
                        case 2:
                            n = !1;
                            break;
                        case 0:
                            Q(r = r.catch((function() {
                                return n = !1, u
                            })), 32)
                    }
                    return r
                }, g.reduce = function(e, t, n) {
                    return _(e).reduce(t, n)
                }, g.prototype.reduce = function(e, t) {
                    return t = N(t), K(this, (function(n, r) {
                        if (0 === n.length) return t;
                        if (r) return c;
                        for (var i = new Array(n.length), o = 0; o < n.length; o++) {
                            var a = i[o] = N(n[o]);
                            D(a) && Q(a, 8)
                        }
                        var s = this,
                            u = 0;
                        return function n() {
                            for (var r = i.length;;) {
                                var o = u,
                                    a = i[o];
                                if (D(a)) switch (3 & a._flags) {
                                    case 2:
                                        return a;
                                    case 0:
                                        return a.then(n);
                                    case 1:
                                        a = a._value
                                }
                                if (D(t)) switch (3 & t._flags) {
                                    case 2:
                                        return t;
                                    case 0:
                                        return t.then(n);
                                    case 1:
                                        t = t._value
                                }
                                var c = e.call(s, t, a, o, r);
                                if (++u === r) return c;
                                if (D(c = N(c))) switch (3 & c._flags) {
                                    case 2:
                                        return c;
                                    case 0:
                                        return t = c, c.then(n);
                                    case 1:
                                        Q(c, 8), t = c._value
                                } else t = c
                            }
                        }()
                    }))
                }, g.each = function(e, t) {
                    return _(e).each(t)
                }, g.prototype.each = function(e) {
                    var t = [];
                    return this.reduce((function(n, r, i, o) {
                        return t.push(r), e.call(this, r, i, o)
                    })).then((() => t))
                }, g.mapSeries = function(e, t) {
                    return _(e).mapSeries(t)
                }, g.prototype.mapSeries = function(e) {
                    return this.reduce((function(t, n, r, i) {
                        var o = N(e.call(this, n, r, i));
                        return D(o) ? o.then((e => (t.push(e), t))) : (t.push(o), t)
                    }), [])
                }, g.race = function(e) {
                    var t = N(e);
                    if (D(t)) {
                        var n = t.then((e => g.race(e)));
                        return n._context = void 0, n._flags &= -65, n
                    }
                    return new g((function(e, n) {
                        for (var r = 0; r < t.length; r++) {
                            var i = N(t[r]);
                            if (!D(i) || 3 & i._flags)
                                for (e(i), r++; r < t.length; r++) {
                                    var o = t[r];
                                    D(o) && Q(o, 8)
                                } else i.then(e, n)
                        }
                    }))
                }, O.prototype = Object.create(Error.prototype, {
                    name: {
                        value: "AggregateError"
                    }
                }), g.AggregateError = O, g.onPossiblyUnhandledRejection = function(e, t) {
                    console.error("StackPromise did not catch ".concat(e), t, e)
                }, g.prototype.toString = function() {
                    for (var e, t = [], n = this, r = !1; n; n = n._parent) {
                        e = n, !r && 3 & n._flags && (r = !0, n._flags & y || (1 & n._flags ? t.push("[resolved value: ".concat(n._value, "]")) : t.push("[rejected reason: ".concat(n._value, "]"))));
                        var i = A(n);
                        1024 & n._flags && (i = "~".concat(i)), t.push(i)
                    }
                    return t.reverse(), 768 & e._flags || (t[0] = "[Promise]".concat(t[0])), t.join("\n")
                }, g.prototype.timeout = function(e, t) {
                    if (0 != (3 & this._flags)) return this.then();
                    var n;

                    function r(r) {
                        return r === l ? ".timeout(".concat(e, ", ").concat(t, ")") : (clearTimeout(n), u)
                    }
                    var i = this.then(r, r);
                    return Q(i, 160), n = setTimeout((function(e, t) {
                        3 & e._flags || U(e, 0, !1, !1, t instanceof Error ? t : new S(t))
                    }), e, i, t), i
                }, S.prototype = Object.create(Error.prototype, {
                    name: {
                        value: "TimeoutError"
                    }
                }), g.TimeoutError = S, g.prototype.isFulfilled = function() {
                    return !!(1 & this._flags)
                }, g.prototype.isRejected = function() {
                    return !!(2 & this._flags)
                }, g.prototype.isPending = function() {
                    return !(3 & this._flags)
                }, g.prototype.value = function() {
                    if (1 & this._flags) return this._value;
                    throw new Error(2 & this._flags ? "value() called on StackPromise that was rejected" : "value() called on StackPromise that is pending")
                }, g.prototype.reason = function() {
                    if (2 & this._flags) return this._value;
                    throw new Error(1 & this._flags ? "reason() called on StackPromise that was fulfilled, not rejected" : "reason() called on StackPromise that is pending")
                }, g.loop = function(e, t) {
                    return _(t).loop(e)
                }, g.prototype.loop = function(e) {
                    var t = K(this.then((function(n) {
                        var r = this,
                            i = 0,
                            o = e => U(t, 0, !0, !1, e);
                        return function n(a) {
                            return new g((function(t) {
                                t(e.call(r, o, a, i++))
                            })).then((function(e) {
                                if (!(3 & t._flags)) return n(e)
                            }))
                        }(n)
                    })), (function(t) {
                        return t === l ? ".loop(".concat(e, ")") : u
                    }));
                    return Q(t, m), t
                }, g.prototype.checkpoint = function(e) {
                    function t(t) {
                        return t === l ? ".checkpoint(".concat(e, ")") : 2 & e._flags ? e : u
                    }
                    e = _(e);
                    var n = this.then(t, t);
                    return Q(n, m), n
                }, g.prototype.finally = function(e) {
                    function t(t) {
                        return t === l ? ".finally(".concat(e, ")") : (e.call(this, t), u)
                    }
                    return Q(this.then(t, t), m)
                }, g.prototype.get = function(e) {
                    var t = this.then((function(t) {
                        return t === l ? ".get('".concat(e, "')") : t[e]
                    }));
                    return Q(t, m), t
                }, g.prototype.tap = function(e) {
                    return Q("function" != typeof e ? this.then(T) : this.then((function(t) {
                        return t === l ? ".tap(".concat(e, ")") : (e.call(this, t), u)
                    })), m)
                }, g.prototype.spread = function(e) {
                    var t = this.then((function(t) {
                        return t === l ? ".spread(".concat(e, ")") : e.apply(this, t)
                    }));
                    return Q(t, m), t
                }, g.prototype.throw = function(e) {
                    return this.then((() => b(e)))
                }, g.Control = P, g.NO_ACTIVE_CONTROL = new Error("No active control was found."), g.prototype.addControl = function(e) {
                    if (!(e instanceof P)) throw new Error("addControl must be given Control, but got ".concat(e));
                    var t = this.then(e.lightning ? void 0 : T);
                    return t._control = e, t
                }, g.prototype.addRawControl = function(e, t, n, r) {
                    return this.addControl(new P(e, t, n, r))
                }, g.prototype.addResolveControl = function(e, t, n, r) {
                    return this.addControl(new P(e, (function(e, n, r, i) {
                        try {
                            e(t.apply(this, i))
                        } catch (e) {
                            n(e)
                        }
                    }), n, r))
                }, g.prototype.addRejectControl = function(e, t, n, r) {
                    return this.addControl(new P(e, (function(e, n, r, i) {
                        try {
                            n(t.apply(this, i))
                        } catch (e) {
                            n(e)
                        }
                    }), n, r))
                }, I.prototype = Object.create(Error.prototype, {
                    name: {
                        value: "CancellationError"
                    }
                }), g.CancellationError = I;
                var M, C = new P("cancel", (function(e, t, n, r) {
                    t(new I(r && r[0]))
                }), !1, !1);

                function k() {
                    var e, t;
                    0 === i && (a.length || h.length) && (i = 1, M || (t = 0, M = "undefined" == typeof MutationObserver || self && self.navigator && self.navigator.standalone ? r ? function() {
                        r.resolve().then(H)
                    } : "function" == typeof setImmediate ? function() {
                        setImmediate(H)
                    } : function() {
                        setTimeout(H, 0)
                    } : (e = document.createTextNode(""), new MutationObserver(H).observe(e, {
                        characterData: !0
                    }), function() {
                        e.data = t = 1 - t
                    })), M())
                }

                function T(e) {
                    return e === l ? ".tap()" : u
                }

                function j(e, t) {
                    Q(e, 8), t._parent = e, e._children ? e._children.push(t) : e._child ? (e._children = [e._child, t], e._child = void 0) : e._child = t
                }

                function R(e) {
                    if (e && ("object" == typeof e || "function" == typeof e)) {
                        var t;
                        try {
                            t = e.then
                        } catch (e) {
                            return d = e, f
                        }
                        if ("function" == typeof t) return t
                    }
                }

                function N(e) {
                    if (!e || D(e)) return e;
                    var t = R(e);
                    if (t === f) return b(d);
                    if (t) {
                        var n = new g((function(n, r) {
                            t.call(e, n, r)
                        }));
                        return n._thenableParent = e, n
                    }
                    return e
                }

                function D(e) {
                    return e instanceof g
                }

                function K(e, t, n) {
                    var r, i, o, a, s = D(e = N(e)),
                        l = !1;
                    if (s) {
                        if (!(3 & e._flags)) return Q(e.then(t, n), 32);
                        Q(e, 8), l = !!(e._flags & p), o = e._context, r = 1 & e._flags ? t : n, i = e._value
                    } else r = t, i = e;
                    if (!r) return _(e).then();
                    if ((i = X(r, o, i, !0)) === f) a = b(d);
                    else {
                        if (i === c) return _(e).then(t, n);
                        if (i === u) return s ? e.then() : _(e);
                        a = _(i)
                    }
                    return l && (a = a.cancellable()), void 0 !== o && ((a = a.then())._context = o), a
                }

                function F(e, t, n, r, i) {
                    if (t === e._resolveLevel) {
                        var o = ++e._resolveLevel;
                        if (Q(e, 4), e._thenableParent = null, n)
                            if (i === e) e._parent = void 0, V(e, !1, r, new TypeError("promise resolved to itself"));
                            else if (D(i)) {
                            var a = 3 & i._flags;
                            0 === a ? j(i, e) : (e._parent = i, Q(e, 1024), Q(i, 8), V(e, 1 === a, r, i._value))
                        } else {
                            var s = R(i);
                            s === f ? (e._parent = void 0, V(e, !1, r, d)) : s ? (e._parent = void 0, e._thenableParent = i, W(s, i, (t => F(e, o, !0, !1, t)), (t => F(e, o, !1, !1, t)))) : V(e, !0, r, i)
                        } else V(e, !1, r, i)
                    }
                }

                function U(e, t, n, r, i) {
                    t === e._resolveLevel && (L(e), F(e, t, n, r, i))
                }

                function L(e) {
                    if (e._parent) {
                        var t = e._parent;
                        if (e._parent = void 0, t._child === e) t._child = void 0;
                        else if (t._children) {
                            for (var n = t._children, r = 0; r < n.length; r++)
                                if (n[r] === e) {
                                    n.splice(r, 1);
                                    break
                                }
                            0 === n.length && (t._children = void 0)
                        }
                    }
                }

                function B(e) {
                    if (null == e) throw new Error("Invalid .catch guard ".concat(e));
                    if ("function" == typeof e) return e;
                    if ("object" == typeof e) throw new Error("Object guards in .catch are currently unsupported");
                    return function(t) {
                        return t === e
                    }
                }

                function Y(e, t) {
                    return function(n, r) {
                        return n === l ? ".catch(..., ".concat(t, ")") : e && ! function(e, t) {
                            for (var n = 0; n < e.length; n++) {
                                var r = e[n];
                                if (r === Error || r.prototype instanceof Error) {
                                    if (t instanceof r) return !0
                                } else if (r(t)) return !0
                            }
                            return !1
                        }(e, n) ? u : r ? c : t.call(this, n)
                    }
                }

                function V(e, t, n, r) {
                    if (Q(e, 4 | (t ? 1 : 2)), e._value = r, e._child) z(e._child, t, n, r), e._child = void 0;
                    else if (e._children) {
                        var i = e._children;
                        e._children = void 0;
                        for (var o = 0; o < i.length; o++) z(i[o], t, n, r)
                    } else t || 8 & e._flags || h.push(e)
                }

                function z(e, t, n, r) {
                    e._resolveLevel++;
                    var i = G(e, t);
                    if (i && 32 & e._flags) {
                        Q(e, 4);
                        var o = X(i, e._context, r, !0);
                        if (o !== c) return void(o === f ? (e._parent = void 0, V(e, !1, n, d)) : o === u ? V(e, t, n, r) : (e._parent = void 0, F(e, e._resolveLevel, !0, n, o)));
                        e._flags &= -5
                    }
                    i ? ((n ? s : a).push(e), k()) : V(e, t, n, r)
                }

                function q(e, t) {
                    for (; 0 !== e.length;) t.push(e.pop())
                }

                function H() {
                    for (; 0 !== o.length || 0 !== a.length;) {
                        0 === o.length && q(a, o);
                        var e = o.pop(),
                            t = e._parent,
                            n = !!(t && 1 & t._flags),
                            r = t && t._value,
                            l = G(e, n);
                        if (Q(e, 4), l) {
                            var v = void 0;
                            do {
                                v = X(l, e._context, r, !1)
                            } while (v === c);
                            v === f ? (r = d, n = !1, e._parent = void 0) : v !== u && (r = v, n = !0, e._parent = void 0)
                        }
                        3 & e._flags || (F(e, e._resolveLevel, n, !0, r), q(s, o))
                    }
                    for (i--; 0 !== h.length;) {
                        var p = h.pop();
                        8 & p._flags || g.onPossiblyUnhandledRejection(p._value, p)
                    }
                }

                function W(e, t, n, r) {
                    try {
                        e.call(t, n, r)
                    } catch (e) {
                        r(e)
                    }
                }

                function G(e, t) {
                    if (!(4 & e._flags)) return t ? e._onFulfilled : e._onRejected
                }

                function X(e, t, n, r) {
                    try {
                        return r ? e.call(t, n, !0) : e.call(t, n)
                    } catch (e) {
                        return d = e, f
                    }
                }

                function Q(e, t) {
                    return e._flags |= t, e
                }
                g.prototype.addCancelControl = function() {
                    return Q(this.addControl(C), p)
                }, g.sit = function(e, t) {
                    var n = new g;
                    return n._control = new P(e, (function(e, n, r, i) {
                        e(t ? t.apply(void 0, i) : i && i[0])
                    })), n
                }, g.prototype.cancellable = function() {
                    return Q(this.then(), p)
                }, g.prototype.uncancellable = function() {
                    var e = this.then();
                    return e._flags &= -65, e
                }, g.prototype.cancel = function(e) {
                    for (var t, n = this; n && !(3 & n._flags); n = n._parent) n._flags & p && (t = n);
                    if (t)
                        if (void 0 === e && (e = new I), G(t, !1)) {
                            var r = new g;
                            L(t), j(r, t), U(r, 0, !1, !1, e)
                        } else U(t, t._resolveLevel, !1, !1, e)
                }, F(n = new g, 0, !0, !1, void 0)
            },
            3487: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.ConflictResolutionState = t.SyncModelType = t.SyncActionState = t.CollectionSyncState = t.CollectionState = t.CollectionName = t.Actions = t.LABEL_ASSOCIATION_SYNC_VERSION = t.DEFAULT_COLLECTION_VERSION = t.MAX_PATCH_SIZE = t.MIN_PATCH_SIZE = t.MAX_INLINE_MUTATIONS = t.MIN_INLINE_MUTATIONS = t.FINITE_FAILURE_EXPIRY_DURATION = t.BACKOFF_BASE = t.BACKOFF_MAX_TIMEOUT = t.BACKOFF_MIN_TIMEOUT = void 0;
                t.BACKOFF_MIN_TIMEOUT = 1e3;
                t.BACKOFF_MAX_TIMEOUT = 36e5;
                t.BACKOFF_BASE = 2;
                t.FINITE_FAILURE_EXPIRY_DURATION = 6048e5;
                t.MIN_INLINE_MUTATIONS = 100;
                t.MAX_INLINE_MUTATIONS = 2e3;
                t.MIN_PATCH_SIZE = 10;
                t.MAX_PATCH_SIZE = 100;
                t.DEFAULT_COLLECTION_VERSION = 0;
                t.LABEL_ASSOCIATION_SYNC_VERSION = 3;
                var r = n(8103)({
                    Star: "star",
                    Contact: "contact",
                    Mute: "mute",
                    Pin: "pin",
                    SettingPushName: "setting_pushName",
                    LabelEdit: "label_edit",
                    LabelMessage: "label_message",
                    LabelJid: "label_jid",
                    QuickReply: "quick_reply",
                    LocaleSetting: "setting_locale",
                    Archive: "archive",
                    MarkChatAsRead: "markChatAsRead",
                    ClearChat: "clearChat",
                    DeleteMessageForMe: "deleteMessageForMe"
                });
                t.Actions = r;
                var i = n(8103)({
                    Generic: "generic",
                    Regular: "regular",
                    RegularLow: "regular_low",
                    RegularHigh: "regular_high",
                    CriticalBlock: "critical_block",
                    CriticalUnblockLow: "critical_unblock_low"
                });
                t.CollectionName = i;
                var o = n(8103).Mirrored(["Success", "SuccessHasMore", "Conflict", "ErrorRetry", "ErrorFatal", "Blocked"]);
                t.CollectionState = o;
                var a = n(8103).Mirrored(["UpToDate", "Dirty", "FailingFiniteRetry", "Fatal", "Blocked"]);
                t.CollectionSyncState = a;
                var s = n(8103).Mirrored(["Success", "Malformed", "Orphan", "Unsupported", "Skipped", "Failed"]);
                t.SyncActionState = s;
                var u = n(8103).Mirrored(["Msg", "Chat"]);
                t.SyncModelType = u;
                var c = n(8103).Mirrored(["ApplyRemoteAndDropLocal", "SkipRemote", "SkipRemoteAndDropLocal"]);
                t.ConflictResolutionState = c
            },
            7620: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(1941));
                var a = new class {
                    init() {
                        return this._promise || (this._promise = new Promise((e => {
                            this._resolver = e
                        })).timeout(5e3)), this._promise
                    }
                    isConnected() {
                        return null != this._port
                    }
                    getPort() {
                        return this._port
                    }
                    waitForConnection() {
                        return (0, o.default)(this._promise, "ConnectionManager Initialization Promise")
                    }
                    connectVia(e) {
                        if (this.isConnected()) throw new Error("Connection already established");
                        (0, i.default)(this._resolver, "ConnectionManager not initialized"), this._port = e, this._resolver()
                    }
                };
                t.default = a
            },
            4391: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = n(1800),
                    a = n(7110),
                    s = r(n(1941)),
                    u = n(4012);
                var c = new class {
                    constructor() {
                        this._pending = new Map, this._onResponseReceipt = e => {
                            var t = (0, u.unwrapResponsePayload)(e.data);
                            if (null != t) {
                                var {
                                    invocationId: n,
                                    result: r
                                } = t;
                                if (this._pending.has(n)) {
                                    var {
                                        resolve: i
                                    } = (0, s.default)(this._pending.get(n), "this._pending.get(invocationId)");
                                    i(r), this._pending.delete(n)
                                }
                            }
                        }
                    }
                    setConnectionManager(e) {
                        this._conn = e, e.waitForConnection().then((() => {
                            var t = (0, s.default)(e.getPort(), "Port obtained from ConnectionManager after connection");
                            t.addEventListener("message", this._onResponseReceipt), t.start()
                        }))
                    }
                    invoke(e, t) {
                        return (0, i.default)(this._conn, "Connection has not been inited"), this._conn.waitForConnection().then((() => {
                            (0, i.default)(this._conn, "Connection has not been inited");
                            var n = (0, s.default)(this._conn.getPort(), "Port obtained from ConnectionManager after connection"),
                                r = (0, a.genInvocationId)();
                            return n.postMessage((0, o.buildInvocationPayload)({
                                invocationId: r,
                                method: e,
                                args: t
                            })), new Promise(((e, t) => {
                                this._pending.set(r, {
                                    resolve: e,
                                    reject: t
                                })
                            }))
                        }))
                    }
                };
                t.default = c
            },
            2929: (e, t, n) => {
                "use strict";
                var r = n(3291);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = n(1800),
                    o = r(n(9458)),
                    a = n(4012);
                var s = new class {
                    constructor() {
                        this._onMessage = (e, t) => {
                            var n = t.data,
                                r = (0, i.unwrapInvocationPayload)(n);
                            if (null != r) {
                                var {
                                    method: s,
                                    args: u,
                                    invocationId: c
                                } = r;
                                o.get()[s](...u).then((t => {
                                    e.postMessage((0, a.buildResponsePayload)(c, t))
                                }))
                            }
                        }
                    }
                    respondTo(e) {
                        e.addEventListener("message", (t => this._onMessage(e, t))), e.start()
                    }
                };
                t.default = s
            },
            7110: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.genInvocationId = function() {
                    return n++
                }, t.extractInvocationId = function(e) {
                    if (null != e && "number" == typeof e) return e
                };
                var n = 1
            },
            9458: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.set = function(e) {
                    i = e
                }, t.get = u, t.sendLogs = function() {
                    throw new Error("Not yet implemented")
                }, t.log = void 0;
                var i, o = r(n(6890)),
                    a = r(n(1985)),
                    s = r(n(1941));

                function u() {
                    return (0, s.default)(i, "InvocationInterface was not inited")
                }
                var c = (0, a.default)(((e, t = !1, n, r, i) => (a, ...s) => {
                    var c, l = (0, o.default)(a, s, !t);
                    return n && (c = {
                        name: n.name,
                        stack: n.stack
                    }), u().logImpl(e, l, c, r, i), l
                }), ((e, t, n, r, i) => n || i ? null : String(e) + String(Boolean(t)) + String(Boolean(r))));
                t.log = c
            },
            3141: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.buildHandshakePayload = function(e) {
                    return {
                        __command: o.HANDSHAKE_COMMAND,
                        __port: e
                    }
                }, t.extractPortFromHandshakePayload = function(e) {
                    if (null != e && null != e.__command && e.__command === o.HANDSHAKE_COMMAND) {
                        if (null != e.__port) return (0, i.default)(e.__port instanceof MessagePort, "Malformed connection payload"), e.__port
                    }
                };
                var i = r(n(7677)),
                    o = n(4624)
            },
            1800: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.buildInvocationPayload = function({
                    invocationId: e,
                    method: t,
                    args: n
                }) {
                    return {
                        __id: e,
                        __command: a.INVOCATION_COMMAND,
                        __method: t,
                        __args: n
                    }
                }, t.unwrapInvocationPayload = function(e) {
                    if (null != e && e.__command === a.INVOCATION_COMMAND) {
                        (0, i.default)(e.__id, "Invocation ID missing");
                        var t = (0, o.extractInvocationId)(e.__id);
                        (0, i.default)(null != t && e.__method && "string" == typeof e.__method && e.__id && e.__args && Array.isArray(e.__args), "Malformed invocation message");
                        var n = e,
                            r = n.__method,
                            s = n.__args;
                        return {
                            method: r,
                            args: s,
                            invocationId: t
                        }
                    }
                };
                var i = r(n(7677)),
                    o = n(7110),
                    a = n(4624)
            },
            4012: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.buildResponsePayload = function(e, t) {
                    return {
                        __id: e,
                        __command: a.RESPONSE_COMMAND,
                        __result: t
                    }
                }, t.unwrapResponsePayload = function(e) {
                    if (null != e && e.__command === a.RESPONSE_COMMAND) {
                        (0, i.default)(null != e.__id, "Invocation ID missing");
                        var t = (0, o.extractInvocationId)(e.__id);
                        return (0, i.default)(null != t && e.hasOwnProperty("__result"), "Malformed response message"), {
                            result: e.__result,
                            invocationId: t
                        }
                    }
                };
                var i = r(n(7677)),
                    o = n(7110),
                    a = n(4624)
            },
            4624: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.RESPONSE_COMMAND = t.INVOCATION_COMMAND = t.HANDSHAKE_COMMAND = void 0;
                t.HANDSHAKE_COMMAND = "@@handshake";
                t.INVOCATION_COMMAND = "@@invoke";
                t.RESPONSE_COMMAND = "@@response"
            },
            2186: (e, t, n) => {
                "use strict";
                var r = n(3291),
                    i = n(4859);
                t.Z = function() {
                    o || ((0, a.default)("undefined" != typeof DedicatedWorkerGlobalScope && self instanceof DedicatedWorkerGlobalScope, "Connect can only be called in WebWorker scope"), self.addEventListener("message", p), o = Promise.resolve(s.default.init()), l.default.setConnectionManager(s.default), d.set(u.default));
                    return (0, h.default)(o, "connection")
                };
                var o, a = i(n(7677)),
                    s = i(n(7620)),
                    u = i(n(1612)),
                    c = n(3141),
                    l = i(n(4391)),
                    f = i(n(2929)),
                    d = r(n(9458)),
                    h = i(n(1941)),
                    v = [];

                function p(e) {
                    var t = e.data;
                    if (!s.default.isConnected()) {
                        var n = (0, c.extractPortFromHandshakePayload)(t);
                        if (null != n) return s.default.connectVia(n), e.stopImmediatePropagation(), f.default.respondTo(n), void(0, h.default)(o, "connection").then((() => {
                            (0, a.default)("undefined" != typeof DedicatedWorkerGlobalScope && self instanceof DedicatedWorkerGlobalScope, "Connect can only be called in WebWorker scope"), self.removeEventListener("message", p), v.forEach((e => {
                                self.dispatchEvent(e)
                            }))
                        }))
                    }
                    v.push(e)
                }
            },
            1612: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = n(3012),
                    o = r(n(4391)),
                    a = {
                        whoAmI: () => o.default.invoke("whoAmI", []),
                        logImpl: (e, t, n, r, i) => o.default.invoke("logImpl", [e, t, n, r, i]),
                        initFromStorage: () => (0, i.init)()
                    };
                t.default = a
            },
            2206: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(9976)),
                    o = r(n(2954)),
                    a = r(n(7715)),
                    s = r(n(7677)),
                    u = (n(522), r(n(1941))),
                    c = n(1054);

                function l() {
                    var e = (0, i.default)(["Operation ", " failed with args: "]);
                    return l = function() {
                        return e
                    }, e
                }

                function f() {
                    var e = (0, i.default)(["idb faild to do Operation: ", " on Table: ", ". Failed with error"]);
                    return f = function() {
                        return e
                    }, e
                }
                var d = n(1449).Z;

                function h() {
                    return (h = (0, o.default)((function*(e = !1) {
                        throw new Error("feature is not yet implemented")
                    }))).apply(this, arguments)
                }

                function v() {
                    return (v = (0, o.default)((function*() {
                        throw new Error("feature is not yet implemented")
                    }))).apply(this, arguments)
                }
                class p {
                    constructor(e, t, n, r, i, o) {
                        this.table = e, this.view = n, this.db = t, this.propFilter = r, this.tableEncryptedColumns = new Map(Object.keys(i).map((e => [e, i[e]]))), this.shouldUseDbMsgEncKeyForEncryptedCol = o
                    }
                    asyncView(e) {
                        var t = this;
                        return (0, o.default)((function*() {
                            if (!t._hasEncryptedColumn()) return t.view(e);
                            var n = yield t._decryptColumns(e);
                            return t.view(n)
                        }))()
                    }
                    _decryptColumns(e) {
                        var t = this;
                        return (0, o.default)((function*() {
                            (0, s.default)("object" == typeof e, "Called `_decryptColumns` with primitive value");
                            var n = Array.from(t.tableEncryptedColumns.entries()).map((([n, r]) => {
                                var i = e[n];
                                return (null == i ? void 0 : i._data) && (null == i ? void 0 : i.iv) ? function() {
                                    return v.apply(this, arguments)
                                }(i, n, r, t.shouldUseDbMsgEncKeyForEncryptedCol).then((t => {
                                    e[n] = t
                                })) : i
                            }));
                            return yield Promise.all(n), e
                        }))()
                    }
                    _encryptColumns(e, t = !1) {
                        var n = Array.from(this.tableEncryptedColumns.entries()).map((([n, r]) => {
                            var i = e[n];
                            return null == i ? i : function() {
                                return h.apply(this, arguments)
                            }(i, n, r, this.shouldUseDbMsgEncKeyForEncryptedCol, t).then((t => {
                                e[n] = t
                            }))
                        }));
                        return Promise.all(n).then((() => e))
                    }
                    _addAndEncrypt(e) {
                        var t = this;
                        return (0, o.default)((function*() {
                            if (!t._hasEncryptedColumn()) return t.table.add(e);
                            var n = yield t._encryptSingleUpdate(e);
                            return t.table.add(n)
                        }))()
                    }
                    _putAndEncrypt(e) {
                        var t = this;
                        return (0, o.default)((function*() {
                            if (!t._hasEncryptedColumn()) return t.table.put(e);
                            var n = yield t._encryptColumns(e);
                            return t.table.put(n)
                        }))()
                    }
                    _bulkAddAndEncrypt(e) {
                        return this._hasEncryptedColumn() ? this._encryptBulkUpdates(e).then((e => this.table.bulkAdd(e))) : this.table.bulkAdd(e)
                    }
                    _bulkPutAndEncrypt(e) {
                        return this._hasEncryptedColumn() ? a.default.waitFor(this._encryptBulkUpdates(e)).then((e => this.table.bulkPut(e))) : this.table.bulkPut(e)
                    }
                    _encryptBulkUpdates(e) {
                        if (!this._hasEncryptedColumn()) return d.resolve(e);
                        var t = [],
                            n = e.map(((e, n) => this._encryptColumns(e).then((e => {
                                t[n] = e
                            }))));
                        return Promise.all(n).then((() => t))
                    }
                    _encryptSingleUpdate(e) {
                        var t = this;
                        return (0, o.default)((function*() {
                            return t._hasEncryptedColumn() ? yield t._encryptColumns(e): e
                        }))()
                    }
                    asyncViewMap(e) {
                        if (!this._hasEncryptedColumn()) return Promise.resolve(e.map((e => e ? this.view(e) : null)));
                        var t = e.map((e => null != e ? this.asyncView(e) : d.resolve(null)));
                        return d.resolve(a.default.waitFor(Promise.all(t)))
                    }
                    preflightEncryptSingleRecord(e) {
                        return this.tableEncryptedColumns, Object.keys(e).forEach((t => {
                            this.tableEncryptedColumns.has(t) || delete e[t]
                        })), this._encryptColumns(e, !0)
                    }
                    bulkCreateWith_ALREADY_ENCRYPTED_RECORDS_ONLY(e) {
                        var t = Array.from(this.tableEncryptedColumns.entries());
                        return e.forEach((e => {
                            t.forEach((([t, n]) => {
                                if (e[t] && !(e[t]._keyId && e[t]._data && e[t].iv)) throw new Error("[CRITICAL] Records contain unencrypted field")
                            }))
                        })), d.resolve(this.table.bulkAdd(e)).catch((t => {
                            throw w(t, "bulkCreateWith_ALREADY_ENCRYPTED_RECORDS_ONLY", this.table.name, e), t
                        }))
                    }
                    create(e) {
                        var t = this.propFilter(e);
                        return d.resolve(this._addAndEncrypt(t)).catch((t => {
                            throw w(t, "create", this.table.name, e), t
                        }))
                    }
                    createOrReplace(e) {
                        var t = this.propFilter(e);
                        return d.resolve(this._putAndEncrypt(t)).catch((t => {
                            throw w(t, "createOrReplace", this.table.name, e), t
                        }))
                    }
                    createOrMerge(e, t) {
                        var n = this;
                        return (0, o.default)((function*() {
                            var r = n.propFilter(t),
                                i = yield n._encryptColumns(r);
                            return d.resolve(n.db.transaction("rw", n.table, (() => {
                                n.table.where(":id").equals(e).modify((e => {
                                    Object.assign(e, i)
                                })).then((e => {
                                    if (1 !== e) return n.table.add(i)
                                }))
                            })).then((() => {}))).catch((r => {
                                throw w(r, "createOrMerge", n.table.name, e, t), r
                            }))
                        }))()
                    }
                    get(e) {
                        return d.resolve(this.table.get(e)).then((e => e ? this.asyncView(e) : null)).catch((t => {
                            throw w(t, "get", this.table.name, e), t
                        }))
                    }
                    merge(e, t) {
                        var n = this;
                        return (0, o.default)((function*() {
                            var r = n.propFilter(t),
                                i = yield n._encryptSingleUpdate(r);
                            return d.resolve(n.table.update(e, i)).catch((r => {
                                throw w(r, "merge", n.table.name, e, t), r
                            }))
                        }))()
                    }
                    remove(e) {
                        return d.resolve(this.table.delete(e)).catch((t => {
                            throw w(t, "remove", this.table.name, e), t
                        }))
                    }
                    bulkCreate(e) {
                        var t = e.map((e => this.propFilter(e)));
                        return d.resolve(this.db.transaction("rw", this.table, (() => this._bulkAddAndEncrypt(t)))).catch((t => {
                            throw w(t, "bulkCreate", this.table.name, e), t
                        }))
                    }
                    bulkCreateOrReplace(e) {
                        var t = e.map((e => this.propFilter(e)));
                        return d.resolve(this.db.transaction("rw", this.table, (() => this._bulkPutAndEncrypt(t)))).catch((t => {
                            throw w(t, "bulkCreateOrReplace", this.table.name, e), t
                        }))
                    }
                    bulkCreateOrMerge(e) {
                        var t = this;
                        return (0, o.default)((function*() {
                            var n = new Map,
                                r = t._primaryKey();

                            function i() {
                                return (i = (0, o.default)((function*(e) {
                                    var n = t.table.where(":id").anyOf(Array.from(e.keys()));
                                    return yield n.modify((t => {
                                        Object.assign(t, e.get(t[r])), e.delete(t[r])
                                    })), Array.from(e.values())
                                }))).apply(this, arguments)
                            }
                            return (yield t._encryptBulkUpdates(e)).forEach((e => {
                                var i = t.propFilter(e);
                                (0, s.default)(r in i, "Called `bulkCreateOrMerge` with item(s) not including the primary key"), n.set(i[r], i)
                            })), d.resolve(t.db.transaction("rw", t.table, (() => function() {
                                return i.apply(this, arguments)
                            }(n).then((e => 0 === e.length ? d.resolve() : t.table.bulkPut(e)))))).catch((n => {
                                throw w(n, "bulkCreateOrMerge", t.table.name, e), n
                            }))
                        }))()
                    }
                    bulkGet(e) {
                        return d.resolve(this.db.transaction("r", this.table, (() => {
                            var t = e.map((e => this.table.get(e)));
                            return a.default.Promise.all(t)
                        }))).then((e => this.asyncViewMap(e))).catch((t => {
                            throw w(t, "bulkGet", this.table.name, e), t
                        }))
                    }
                    bulkRemove(e) {
                        return d.resolve(this.db.transaction("rw", this.table, (() => this.table.bulkDelete(e)))).catch((t => {
                            throw w(t, "bulkRemove", this.table.name, e), t
                        }))
                    }
                    all(e, t) {
                        var n = _(this.table.orderBy(e && e.index ? g(e.index) : ":id"), e);
                        t && (n = n.until(t));
                        var r = null;
                        switch (null == e ? void 0 : e.returnKeyType) {
                            case "keys":
                                r = d.resolve(n.keys());
                                break;
                            case "primary_key":
                                r = d.resolve(n.primaryKeys());
                                break;
                            default:
                                r = d.resolve(n.toArray()).then((e => this.asyncViewMap(e)))
                        }
                        return r.catch((t => {
                            throw w(t, "all", this.table.name, e), t
                        }))
                    }
                    count() {
                        return d.resolve(this.table.count()).catch((e => {
                            throw w(e, "count", this.table.name), e
                        }))
                    }
                    equals(e, t, n) {
                        return d.resolve(_(this.table.where(g(e)).equals(t), n).toArray()).then((e => this.asyncViewMap(e))).catch((r => {
                            throw w(r, "equals", this.table.name, e, t, n), r
                        }))
                    }
                    anyOf(e, t, n) {
                        return d.resolve(_(this.table.where(g(e)).anyOf(t), n).toArray()).then((e => this.asyncViewMap(e))).catch((r => {
                            throw w(r, "anyOf", this.table.name, e, t, n), r
                        }))
                    }
                    greaterThan(e, t, n) {
                        var r = n && n.inclusive ? this.table.where(g(e)).aboveOrEqual(t) : this.table.where(g(e)).above(t);
                        return d.resolve(_(r, n).toArray()).then((e => this.asyncViewMap(e))).catch((r => {
                            throw w(r, "greaterThan", this.table.name, e, t, n), r
                        }))
                    }
                    lessThan(e, t, n) {
                        var r = n && n.inclusive ? this.table.where(g(e)).belowOrEqual(t) : this.table.where(g(e)).below(t);
                        return d.resolve(_(r, n).toArray()).then((e => this.asyncViewMap(e))).catch((r => {
                            throw w(r, "lessThan", this.table.name, e, t, n), r
                        }))
                    }
                    between(e, t, n, r, i) {
                        var o = _(this.table.where(g(e)).between(t, n, !(!r || !r.lowerInclusive), !(!r || !r.upperInclusive)), r),
                            a = null;
                        switch (null == r ? void 0 : r.returnKeyType) {
                            case "keys":
                                a = d.resolve(o.keys());
                                break;
                            case "primary_key":
                                a = d.resolve(o.primaryKeys());
                                break;
                            default:
                                a = i ? d.resolve(o.until(i).toArray()).then((() => [])) : d.resolve(o.toArray()).then((e => this.asyncViewMap(e)))
                        }
                        return a.catch((i => {
                            throw w(i, "between", this.table.name, e, t, n, r), i
                        }))
                    }
                    forEachSortedBy(e, t) {
                        var n = this;
                        return this.table.orderBy(e).each(function() {
                            var e = (0, o.default)((function*(e) {
                                var r = yield n._decryptColumns(e);
                                return t(r)
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()).catch((n => {
                            throw w(n, "forEachSortedBy", this.table.name, e, t), n
                        }))
                    }
                    forEach(e) {
                        var t = this;
                        return this.table.each(function() {
                            var n = (0, o.default)((function*(n) {
                                var r = yield t._decryptColumns(n);
                                return e(r)
                            }));
                            return function() {
                                return n.apply(this, arguments)
                            }
                        }()).catch((t => {
                            throw w(t, "forEach", this.table.name, e), t
                        }))
                    }
                    clear() {
                        return d.resolve(this.table.clear()).catch((e => {
                            throw w(e, "clear", this.table.name), e
                        }))
                    }
                    _primaryKey() {
                        return this.table.schema.primKey.name
                    }
                    _hasEncryptedColumn() {
                        return this.tableEncryptedColumns.size > 0
                    }
                }

                function m(e) {
                    if (e.length > 1) return e.forEach((e => {
                        (0, s.default)(e.primaryKey && e.primaryKey === c.PRIMARY_KEY_TYPE.COMPOSITE, "Invalid column passed to `formatPrimaryKey`")
                    })), "[".concat(e.map((e => e.name)).join("+"), "]");
                    var t = e[0];
                    return (0, s.default)(t.primaryKey && t.primaryKey !== c.PRIMARY_KEY_TYPE.COMPOSITE, "Invalid column passed to `formatPrimaryKey`"), t.primaryKey === c.PRIMARY_KEY_TYPE.AUTO_INCREMENT ? "".concat(t.name, "++") : t.name
                }

                function y(e) {
                    switch (e.type) {
                        case c.INDEX_TYPE.SIMPLE:
                            return e.column;
                        case c.INDEX_TYPE.COMPOSITE:
                            return "[".concat(e.columns.join("+"), "]");
                        case c.INDEX_TYPE.ARRAY:
                            return "*".concat(e.column);
                        case c.INDEX_TYPE.UNIQUE:
                            return "&".concat(e.column)
                    }
                    throw new Error('Cannot format index of type "'.concat(e.type, '"'))
                }

                function g(e) {
                    return 1 === e.length ? e[0] : "[".concat(e.join("+"), "]")
                }

                function _(e, t) {
                    var n = e;
                    return t && t.reverse && (n = n.reverse()), t && null != t.offset && (n = n.offset(t.offset)), t && null != t.limit && 0 !== t.limit && (n = n.limit(t.limit)), n
                }

                function b(e) {
                    return d.resolve(e)
                }

                function w(e, t, n, ...r) {
                    __LOG__(3, !0)(f(), t, n), __LOG__(2)(l(), t)
                }
                t.default = class {
                    constructor(e, t = b) {
                        this.tableNames = new Map, this.tableColumns = new Map, this.tableEncryptedColumns = new Map, this.name = e, this.db = new a.default(this.name), this.transformSchema = t
                    }
                    initialize(e, t, n) {
                        return function(e, t, n, r, i) {
                            return Promise.reduce(e, ((e, o) => i((0, c.cloneSchema)(o)).then((i => {
                                if ((0, s.default)(!(i.name in e), "Multiple tables resulted in the same transformed name"), i.deleted) return e[i.name] = null, e;
                                t.set(o.name, i.name), n.set(o.name, i.columns.map((e => e.name))), r.set(o.name, i.encryptedColumns || {});
                                var a = i.columns.filter((e => e.primaryKey));
                                (0, s.default)(a.length >= 1, 'No primary key was defined for "'.concat(o.name, '"'));
                                var u = [m(a)].concat(i.indexes.map(y)).join(", ");
                                return e[i.name] = u, e
                            }))), {})
                        }(t, this.tableNames, this.tableColumns, this.tableEncryptedColumns, this.transformSchema).then((t => {
                            this.db.version(e + 1).stores(t).upgrade((e => {
                                var t;
                                if (n) return null === (t = e[n.name]) || void 0 === t ? void 0 : t.toCollection().modify(n.callback)
                            }))
                        }))
                    }
                    open() {
                        return d.resolve(this.db.open())
                    }
                    transact(e, t, n = "rw") {
                        return d.resolve(this.db.transaction(n, e, (() => t())))
                    }
                    close() {
                        return this.db.close(), d.resolve()
                    }
                    view(e, t, n, r) {
                        (0, s.default)(this.tableNames.has(e), 'Attemped to get view for uninitialized table "'.concat(e, '"')), (0, s.default)(this.tableColumns.has(e), 'Attemped to get columns for uninitialized table "'.concat(e, '"'));
                        var i = n ? function(e) {
                            if (!e) return e => e;
                            return t => {
                                var n = {};
                                return e.forEach((e => {
                                    t.hasOwnProperty(e) && (n[e] = t[e])
                                })), n
                            }
                        }(this.tableColumns.get(e)) : e => e;
                        return new p(this.db.table(this.tableNames.get(e)), this.db, t, i, (0, u.default)(this.tableEncryptedColumns.get(e), "this.tableEncryptedColumns.get(table)"), r)
                    }
                    available() {
                        return d.resolve(!0)
                    }
                    reset() {
                        return this.tableNames = new Map, d.resolve(this.db.delete()).finally((() => {
                            this.db = new a.default(this.name)
                        }))
                    }
                }
            },
            7433: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                t.default = class {
                    constructor(e) {
                        this._view = e
                    }
                    _read(e) {
                        return e(this._view())
                    }
                    _write(e) {
                        return e(this._view())
                    }
                    create(e) {
                        return this._write((t => t.create(e)))
                    }
                    preflightEncryptSingleRecord(e) {
                        return this._write((t => t.preflightEncryptSingleRecord(e)))
                    }
                    bulkCreateWith_ALREADY_ENCRYPTED_RECORDS_ONLY(e) {
                        return this._write((t => t.bulkCreateWith_ALREADY_ENCRYPTED_RECORDS_ONLY(e)))
                    }
                    createOrReplace(e) {
                        return this._write((t => t.createOrReplace(e)))
                    }
                    createOrMerge(e, t) {
                        return this._write((n => n.createOrMerge(e, t)))
                    }
                    get(e) {
                        return this._read((t => t.get(e)))
                    }
                    merge(e, t) {
                        return this._write((n => n.merge(e, t)))
                    }
                    remove(e) {
                        return this._write((t => t.remove(e)))
                    }
                    bulkCreate(e) {
                        return this._write((t => t.bulkCreate(e)))
                    }
                    bulkCreateOrReplace(e) {
                        return this._write((t => t.bulkCreateOrReplace(e)))
                    }
                    bulkCreateOrMerge(e) {
                        return this._write((t => t.bulkCreateOrMerge(e)))
                    }
                    bulkGet(e) {
                        return this._read((t => t.bulkGet(e)))
                    }
                    bulkRemove(e) {
                        return this._write((t => t.bulkRemove(e)))
                    }
                    all(e, t) {
                        return this._read((n => n.all(e, t)))
                    }
                    count() {
                        return this._read((e => e.count()))
                    }
                    equals(e, t, n) {
                        return this._read((r => r.equals(e, t, n)))
                    }
                    anyOf(e, t, n) {
                        return this._read((r => r.anyOf(e, t, n)))
                    }
                    greaterThan(e, t, n) {
                        return this._read((r => r.greaterThan(e, t, n)))
                    }
                    lessThan(e, t, n) {
                        return this._read((r => r.lessThan(e, t, n)))
                    }
                    between(e, t, n, r, i) {
                        return this._read((o => o.between(e, t, n, r, i)))
                    }
                    forEachSortedBy(e, t) {
                        return this._read((n => n.forEachSortedBy(e, t)))
                    }
                    forEach(e) {
                        return this._read((t => t.forEach(e)))
                    }
                    clear() {
                        return this._write((e => e.clear()))
                    }
                }
            },
            1695: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053));
                class a extends o.default {
                    constructor(e) {
                        super(), (0, i.default)("AbstractPrimaryKey" !== this.constructor.name, "Cannot instantiate abstract class AbstractPrimaryKey"), Array.isArray(e) ? this.columns = [...e] : this.columns = [e]
                    }
                    validate(e) {
                        (0, i.default)(0 === e.columns.length, "Attempted to add primary key after other columns")
                    }
                    apply() {
                        throw new Error("Subclass of `AbstractPrimaryKey` must implement `apply` method")
                    }
                }
                t.default = a
            },
            6879: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.column = e
                    }
                    validate(e) {
                        var t = e.columns.find((e => e.name === this.column));
                        (0, i.default)(t, 'Attempted to add index on non-existent column "'.concat(this.column, '" in "').concat(e.name, '"')), (0, i.default)(t && (!t.primaryKey || t.primaryKey === a.PRIMARY_KEY_TYPE.COMPOSITE), 'Cannot add index on primary key on table "'.concat(e.name, '"')), (0, i.default)(!e.indexes.some((e => (e.type === a.INDEX_TYPE.ARRAY || e.type === a.INDEX_TYPE.SIMPLE || e.type === a.INDEX_TYPE.UNIQUE) && (0, a.indexContainsColumn)(e, this.column))), 'Attempted to add index "'.concat(this.column, '" which already exists in "').concat(e.name, '"'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.indexes.push(this._getIndex()), t
                    }
                    _getIndex() {
                        return {
                            type: a.INDEX_TYPE.ARRAY,
                            column: this.column
                        }
                    }
                }
                t.default = s
            },
            530: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.name = e
                    }
                    validate(e) {
                        (0, i.default)(!e.columns.find((e => e.name === this.name)), 'Attempted to add column "'.concat(this.name, '" to "').concat(e.name, '" but it already exists'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.columns.push({
                            name: this.name
                        }), t
                    }
                }
                t.default = s
            },
            9387: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.columns = [...e]
                    }
                    validate(e) {
                        this.columns.forEach((t => {
                            (0, i.default)(e.columns.find((e => e.name === t)), 'Attempted to add index on non-existent column "'.concat(t, '" in "').concat(e.name, '"'))
                        })), (0, i.default)(this.columns.length > 1, "Attempted to add composite index for only 1 column"), (0, i.default)(-1 === (0, a.findIndex)(e, this._getIndex()), "Attempted to add index [".concat(String(this.columns), '], which already exists in "').concat(e.name, '"'));
                        var t = e.columns.filter((e => e.primaryKey && e.primaryKey === a.PRIMARY_KEY_TYPE.COMPOSITE)).map((e => e.name));
                        (0, i.default)(t.length !== this.columns.length || t.some((e => !this.columns.includes(e))), "Attempted to add index [".concat(String(this.columns), '], which already is the primary key in "').concat(e.name, '"'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.indexes.push(this._getIndex()), t
                    }
                    _getIndex() {
                        return {
                            type: a.INDEX_TYPE.COMPOSITE,
                            columns: this.columns
                        }
                    }
                }
                t.default = s
            },
            522: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = t.ENCRYPTED_VALUE_TYPE = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054),
                    s = Object.freeze({
                        STRING: "String",
                        ARRAY_BUFFER: "ArrayBuffer"
                    });
                t.ENCRYPTED_VALUE_TYPE = s;
                class u extends o.default {
                    constructor(e, t) {
                        super(), this.name = e, this.dataType = t
                    }
                    validate(e) {
                        (0, i.default)(!e.columns.find((e => e.name === this.name)), 'Attempted to add encrypted column "'.concat(this.name, '" to "').concat(e.name, '" but it already exists'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.columns.push({
                            name: this.name
                        }), t.encryptedColumns[this.name] = this.dataType, t
                    }
                }
                t.default = u
            },
            146: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.keyPath = e, this.column = e.split(".")[0]
                    }
                    validate(e) {
                        var t = e.columns.find((e => e.name === this.column));
                        (0, i.default)(t, 'Attempted to add index on non-existent column "'.concat(this.column, '" in "').concat(e.name, '"')), (0, i.default)(t && (!t.primaryKey || t.primaryKey === a.PRIMARY_KEY_TYPE.COMPOSITE), 'Cannot add index on primary key on table "'.concat(e.name, '"')), (0, i.default)(!e.indexes.some((e => (e.type === a.INDEX_TYPE.ARRAY || e.type === a.INDEX_TYPE.SIMPLE || e.type === a.INDEX_TYPE.UNIQUE) && (0, a.indexContainsColumn)(e, this.column))), 'Attempted to add index "'.concat(this.column, '" which already exists in "').concat(e.name, '"'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.indexes.push(this._getIndex()), t
                    }
                    _getIndex() {
                        return {
                            type: a.INDEX_TYPE.SIMPLE,
                            column: this.keyPath
                        }
                    }
                }
                t.default = s
            },
            5745: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.column = e
                    }
                    validate(e) {
                        var t = e.columns.find((e => e.name === this.column));
                        (0, i.default)(t, 'Attempted to add index on non-existent column "'.concat(this.column, '" in "').concat(e.name, '"')), (0, i.default)(t && (!t.primaryKey || t.primaryKey === a.PRIMARY_KEY_TYPE.COMPOSITE), 'Cannot add index on primary key on table "'.concat(e.name, '"')), (0, i.default)(!e.indexes.some((e => (e.type === a.INDEX_TYPE.ARRAY || e.type === a.INDEX_TYPE.SIMPLE || e.type === a.INDEX_TYPE.UNIQUE) && (0, a.indexContainsColumn)(e, this.column))), 'Attempted to add index "'.concat(this.column, '" which already exists in "').concat(e.name, '"'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.indexes.push(this._getIndex()), t
                    }
                    _getIndex() {
                        return {
                            type: a.INDEX_TYPE.UNIQUE,
                            column: this.column
                        }
                    }
                }
                t.default = s
            },
            2948: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(1695)),
                    a = n(1054);
                class s extends o.default {
                    validate(e) {
                        super.validate(e), (0, i.default)(this.columns && 1 === this.columns.length, "Attempted to add UserDefinedPrimaryKey over wrong number of columns")
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.columns.unshift({
                            name: this.columns[0],
                            primaryKey: a.PRIMARY_KEY_TYPE.AUTO_INCREMENT
                        }), t
                    }
                }
                t.default = s
            },
            9667: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(1695)),
                    a = n(1054);
                class s extends o.default {
                    validate(e) {
                        super.validate(e), (0, i.default)(this.columns && this.columns.length > 1, "Attempted to add composite primary key for only 1 column")
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return this.columns.forEach((e => {
                            t.columns.push({
                                name: e,
                                primaryKey: a.PRIMARY_KEY_TYPE.COMPOSITE
                            })
                        })), t
                    }
                }
                t.default = s
            },
            6053: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677));
                t.default = class {
                    constructor() {
                        (0, i.default)("Mutation" !== this.constructor.name, "Cannot instantiate abstract class Mutation")
                    }
                    validate() {
                        throw new Error("Subclasses of Mutaton must implement `validate`")
                    }
                    apply() {
                        throw new Error("Subclasses of Mutaton must implement `apply`")
                    }
                }
            },
            1252: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.column = e
                    }
                    validate(e) {
                        (0, i.default)(-1 !== (0, a.findIndex)(e, this._getIndex()), 'Attempted to remove non-existent index "'.concat(this.column, '" on "').concat(e.name, '"'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e),
                            n = (0, a.findIndex)(e, this._getIndex());
                        return t.indexes.splice(n, 1), t
                    }
                    _getIndex() {
                        return {
                            type: a.INDEX_TYPE.ARRAY,
                            column: this.column
                        }
                    }
                }
                t.default = s
            },
            6546: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.name = e
                    }
                    validate(e) {
                        var t = e.columns.find((e => e.name === this.name));
                        (0, i.default)(t, 'Attempted to remove column "'.concat(this.name, '" from "').concat(e.name, "\" but it doesn't exist")), (0, i.default)(!t.primaryKey, 'Attempted to remove primary key column "'.concat(this.name, '". Removing primary keys is not supported.')), (0, i.default)(!e.indexes.some((e => (0, a.indexContainsColumn)(e, this.name))), 'Attempted to remove column "'.concat(this.name, '" from "').concat(e.name, '" but an index exists with the column'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.columns.splice(t.columns.findIndex((e => e.name === this.name)), 1), t
                    }
                }
                t.default = s
            },
            9605: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.columns = [...e].sort()
                    }
                    validate(e) {
                        (0, i.default)(-1 !== (0, a.findIndex)(e, this._getIndex()), "Attempted to remove non-existent index [".concat(String(this.columns), '] on "').concat(e.name, '"'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e),
                            n = (0, a.findIndex)(e, this._getIndex());
                        return t.indexes.splice(n, 1), t
                    }
                    _getIndex() {
                        return {
                            type: a.INDEX_TYPE.COMPOSITE,
                            columns: this.columns
                        }
                    }
                }
                t.default = s
            },
            600: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(6053)),
                    a = n(1054);
                class s extends o.default {
                    constructor(e) {
                        super(), this.column = e
                    }
                    validate(e) {
                        (0, i.default)(-1 !== (0, a.findIndex)(e, this._getIndex()), 'Attempted to remove non-existent index "'.concat(this.column, '" on "').concat(e.name, '"'))
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e),
                            n = (0, a.findIndex)(e, this._getIndex());
                        return t.indexes.splice(n, 1), t
                    }
                    _getIndex() {
                        return {
                            type: a.INDEX_TYPE.SIMPLE,
                            column: this.column
                        }
                    }
                }
                t.default = s
            },
            8642: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(7677)),
                    o = r(n(1695)),
                    a = n(1054);
                class s extends o.default {
                    validate(e) {
                        super.validate(e), (0, i.default)(this.columns && 1 === this.columns.length, "Attempted to add UserDefinedPrimaryKey over wrong number of columns")
                    }
                    apply(e) {
                        var t = (0, a.cloneSchema)(e);
                        return t.columns.unshift({
                            name: this.columns[0],
                            primaryKey: a.PRIMARY_KEY_TYPE.USER_DEFINED
                        }), t
                    }
                }
                t.default = s
            },
            0: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.sortMutations = function(e) {
                    return [...e].sort(_)
                };
                var i = r(n(7677)),
                    o = r(n(6879)),
                    a = r(n(530)),
                    s = r(n(9387)),
                    u = r(n(522)),
                    c = r(n(146)),
                    l = r(n(5745)),
                    f = r(n(2948)),
                    d = r(n(9667)),
                    h = r(n(1252)),
                    v = r(n(6546)),
                    p = r(n(9605)),
                    m = r(n(600)),
                    y = r(n(8642)),
                    g = [p.default, h.default, m.default, v.default, f.default, y.default, d.default, a.default, c.default, o.default, s.default, l.default, u.default];

                function _(e, t) {
                    var n = g.indexOf(e.constructor),
                        r = g.indexOf(t.constructor);
                    return (0, i.default)(-1 !== n, "Mutation ".concat(e.constructor.name, " is not a known mutation type")), (0, i.default)(-1 !== r, "Mutation ".concat(e.constructor.name, " is not a known mutation type")), n - r
                }
            },
            1054: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.emptySchema = function(e) {
                    return {
                        name: e,
                        columns: [],
                        indexes: [],
                        encryptedColumns: {}
                    }
                }, t.cloneSchema = function(e) {
                    return {
                        name: e.name,
                        columns: e.columns.map((e => (0, i.default)({}, e))),
                        indexes: e.indexes.map(c),
                        encryptedColumns: (0, i.default)({}, e.encryptedColumns || {}),
                        deleted: e.deleted
                    }
                }, t.freezeSchema = function(e) {
                    return Object.freeze({
                        name: e.name,
                        columns: Object.freeze(e.columns.map(Object.freeze)),
                        indexes: Object.freeze(e.indexes.map(u)),
                        encryptedColumns: Object.freeze((0, i.default)({}, e.encryptedColumns || {})),
                        deleted: e.deleted
                    })
                }, t.findIndex = function(e, t) {
                    return e.indexes.findIndex((e => function(e, t) {
                        if (e.type !== t.type) return !1;
                        switch (e.type) {
                            case s.SIMPLE:
                            case s.ARRAY:
                            case s.UNIQUE:
                                return (0, o.default)(t.type === e.type, "Index types are not equal"), e.column === t.column;
                            case s.COMPOSITE:
                                return (0, o.default)(t.type === e.type, "Index types are not equal"), e.columns.length === t.columns.length && !e.columns.some((e => !t.columns.includes(e)))
                        }
                        throw new Error("cannot compare unknown indexes of types: ".concat(e.type, ", ").concat(t.type))
                    }(t, e)))
                }, t.indexContainsColumn = function(e, t) {
                    switch (e.type) {
                        case s.SIMPLE:
                        case s.ARRAY:
                        case s.UNIQUE:
                            return e.column === t;
                        case s.COMPOSITE:
                            return !!e.columns.find((e => e === t))
                    }
                    throw new Error("cannot check indexes of unknown index type: ".concat(e.type))
                }, t.INDEX_TYPE = t.PRIMARY_KEY_TYPE = void 0;
                var i = r(n(417)),
                    o = r(n(7677)),
                    a = Object.freeze({
                        AUTO_INCREMENT: "auto-increment",
                        USER_DEFINED: "user-defined",
                        COMPOSITE: "composite"
                    });
                t.PRIMARY_KEY_TYPE = a;
                var s = Object.freeze({
                    SIMPLE: "simple",
                    COMPOSITE: "composite",
                    ARRAY: "array",
                    UNIQUE: "unique"
                });

                function u(e) {
                    switch (e.type) {
                        case s.SIMPLE:
                            return Object.freeze({
                                type: s.SIMPLE,
                                column: e.column
                            });
                        case s.ARRAY:
                            return Object.freeze({
                                type: s.ARRAY,
                                column: e.column
                            });
                        case s.COMPOSITE:
                            return Object.freeze({
                                type: s.COMPOSITE,
                                columns: Object.freeze(e.columns.map(Object.freeze))
                            });
                        case s.UNIQUE:
                            return Object.freeze({
                                type: s.UNIQUE,
                                column: e.column
                            })
                    }
                    throw new Error("cannot freeze index of unknown type: ".concat(e.type))
                }

                function c(e) {
                    switch (e.type) {
                        case s.SIMPLE:
                            return {
                                type: s.SIMPLE,
                                column: e.column
                            };
                        case s.UNIQUE:
                            return {
                                type: s.UNIQUE,
                                column: e.column
                            };
                        case s.COMPOSITE:
                            return {
                                type: s.COMPOSITE,
                                columns: e.columns.map((e => e))
                            };
                        case s.ARRAY:
                            return {
                                type: s.ARRAY,
                                column: e.column
                            }
                    }
                    throw new Error("cannot clone unknown index type: ".concat(e.type))
                }
                t.INDEX_TYPE = s
            },
            2488: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = t.MissingVersionError = t.InvalidVersionError = t.DuplicateVersionError = void 0;
                class n extends Error {}
                t.DuplicateVersionError = n;
                class r extends Error {}
                t.InvalidVersionError = r;
                class i extends Error {}
                t.MissingVersionError = i;
                t.default = class {
                    constructor() {
                        this.versions = new Set, this._max = -1
                    }
                    claim(e) {
                        if (e < 0) throw new r("Versions must by greater than or equal to zero!");
                        if (this.versions.has(e)) throw new n("Version #".concat(e, " has already been claimed!"));
                        this.versions.add(e), this._max = Math.max(this.max, e)
                    }
                    version(e) {
                        if (e < 0) throw new r("Versions must by greater than or equal to zero!");
                        return e
                    }
                    validate() {
                        for (var e = 0; e <= this.max; ++e)
                            if (!this.versions.has(e)) throw new i("Schema version #".concat(e, " is missing!"))
                    }
                    get max() {
                        return this._max
                    }
                }
            },
            6957: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = t.NotInitializedError = t.NoSuchTableError = t.NoSuchDatabaseError = t.NoFallbackError = t.DuplicateTableError = t.DuplicateDatabaseError = t.AlreadyInitializedError = void 0;
                var i = r(n(7433)),
                    o = r(n(2488)),
                    a = r(n(8030));
                class s extends Error {}
                t.AlreadyInitializedError = s;
                class u extends Error {}
                t.DuplicateDatabaseError = u;
                class c extends Error {}
                t.DuplicateTableError = c;
                class l extends Error {}
                t.NoFallbackError = l;
                class f extends Error {}
                t.NoSuchDatabaseError = f;
                class d extends Error {}
                t.NoSuchTableError = d;
                class h extends Error {}
                t.NotInitializedError = h;
                t.default = class {
                    constructor(e) {
                        this.tables = new Map, this.views = new Map, this.state = 1, this.versions = new o.default, this._database = e
                    }
                    add(e) {
                        if (this.tables.has(e)) throw new c('Table "'.concat(e, '" already added. Reuse the definition.'));
                        var t = new a.default(e, this.versions);
                        return this.tables.set(e, t), t
                    }
                    _getBackingDB() {
                        return this._database
                    }
                    _unsafeGetOrCreateView(e) {
                        if (this.views.has(e)) return this.views.get(e);
                        var t = this._database.view(e.name, e.rowview, e.shouldEnablePropFilter, e.shouldUseDbMsgEncKeyForEncryptedCol);
                        return this.views.set(e, t), t
                    }
                    _guardInitializedThunk(e) {
                        return () => {
                            if (3 & this.state) throw new h("Storage must be initialized before accessing a table!");
                            return e()
                        }
                    }
                    table(e) {
                        var t = this.tables.get(e);
                        if (!t) throw new d("Unknown table ".concat(e, " requested, ensure table is defined!"));
                        if (!this._getBackingDB()) throw new f('Unable to find associated database with table "'.concat(e, '"'));
                        return new i.default(this._guardInitializedThunk((() => this._unsafeGetOrCreateView(t))))
                    }
                    lock(e, t) {
                        if (3 & this.state) return Promise.reject(new h("Initialize storage before attempting to lock tables!"));
                        for (var n = 0; n < e.length; ++n)
                            if (!this.tables.has(e[n])) return Promise.reject(new d('Requested lock of unknown table "'.concat(e[n], '"')));
                        var r = e.map((e => {
                            var t = this.tables.get(e);
                            if (t) return t;
                            throw new d('Requested lock of unknown table "'.concat(e, '"'))
                        })).map((e => this._unsafeGetOrCreateView(e)));
                        return this._getBackingDB().transact(e, (() => t(r)))
                    }
                    _getUpgraderForCurrentVersion(e, t) {
                        for (var n = 0; n < e.length; n++)
                            if (e[n].maxVersion === t) {
                                var r = e[n].upgraders.get(t);
                                if (r) return {
                                    name: e[n].name,
                                    callback: r
                                }
                            }
                    }
                    initialize() {
                        return 4 & this.state ? Promise.reject(new s("Storage instance has already been initialized")) : (this.versions.validate(), (this._database ? this._database.available() : Promise.reject(new f('"'.concat(this._database.constructor.name, '" failed availability check!')))).then((() => {
                            var e = Array.from(this.tables.values()),
                                t = this._getBackingDB();
                            if (e && t) {
                                var n = new Array(this.versions.max + 1);
                                return Promise.each(n, ((n, r) => {
                                    var i = r,
                                        o = e.map((e => e.schema(i))).filter(Boolean);
                                    return t.initialize(r, o, this._getUpgraderForCurrentVersion(e, i))
                                })).then((() => t.open()))
                            }
                        })).then((() => this.state = 4)).then((() => {})))
                    }
                    purge() {
                        return this.state = 2, this.views = new Map, this._getBackingDB().reset().then((() => {}))
                    }
                }
            },
            8030: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var i = r(n(417)),
                    o = r(n(7677)),
                    a = n(1054),
                    s = n(0);

                function u(e) {
                    return e
                }
                t.default = class {
                    constructor(e, t) {
                        this.maxVersion = -1, this.versions = new Map, this.upgraders = new Map, this.shouldEnablePropFilter = !0, this.shouldUseDbMsgEncKeyForEncryptedCol = !1, this.name = e, this.versionManager = t
                    }
                    version(e, t, n) {
                        this.versionManager.claim(e), (0, o.default)(!this.versions.has(e), 'Table "'.concat(this.name, '" already has version #').concat(+e, " defined!")), (0, o.default)(e > this.maxVersion, "Versions for table ".concat(this.name, " must be defined in order")), this.maxVersion = e;
                        var r = this.schema(e) || (0, a.emptySchema)(this.name),
                            i = (0, s.sortMutations)(t).reduce(((e, t) => (t.validate(e), t.apply(e))), (0, a.cloneSchema)(r));
                        return this.versions.set(e, (0, a.freezeSchema)(i)), this.upgraders.set(e, n), this
                    }
                    delete(e) {
                        this.versionManager.claim(e), (0, o.default)(!this.versions.has(e), 'Table "'.concat(this.name, '" already has version #').concat(+e, " defined!")), (0, o.default)(e > this.maxVersion, "Versions for table ".concat(this.name, " must be defined in order")), this.maxVersion = e;
                        var t = this.schema(e) || (0, a.emptySchema)(this.name),
                            n = (0, i.default)((0, i.default)({}, t), {}, {
                                deleted: !0
                            });
                        return this.versions.set(e, (0, a.freezeSchema)(n)), this
                    }
                    view(e) {
                        return this.rowview = e, this
                    }
                    enablePropFilter(e) {
                        return this.shouldEnablePropFilter = e, this
                    }
                    useDbMsgEncKeyForEncryptedCol(e) {
                        return this.shouldUseDbMsgEncKeyForEncryptedCol = e, this
                    }
                    schema(e) {
                        var t = this.versions.get(e);
                        if (t) return t;
                        var n = Array.from(this.versions.keys()).map(u).sort(((e, t) => e - t)).filter((t => t < e)).pop();
                        return n || 0 === n ? this.versions.get(n) || (0, a.emptySchema)(this.name) : null
                    }
                }
            },
            4319: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.initializeWithoutGKs = function() {
                    null == f && ((0, u.createStorage)(), (0, s.addTable)(), (0, a.addTable)(), (0, c.addTable)(), f = (0, u.getStorage)().initialize().catch((e => {
                        throw __LOG__(4, !0, new Error, !0)(l()), SEND_LOGS("Failed to initialize model storage"), e
                    })));
                    return f
                }, t.destroy = function() {
                    return (0, u.destroyStorage)().catch((() => d.resolve(new o.default(u.DATABASE_NAME).delete()))).finally((() => {
                        f = null
                    }))
                }, t.clearInitializePromise = function() {
                    f = null
                };
                var i = r(n(9976)),
                    o = r(n(7715)),
                    a = n(7211),
                    s = n(8685),
                    u = n(7993),
                    c = n(6001);

                function l() {
                    var e = (0, i.default)(["Assertion failed!"]);
                    return l = function() {
                        return e
                    }, e
                }
                var f, d = n(1449).Z
            },
            5855: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.addTable = function() {
                    (0, a.getStorage)().add("chat").version((0, u.chatCreateTable)(), [new s.default("id"), new i.default("t"), new i.default("unreadCount"), new i.default("archive"), new i.default("isReadOnly"), new i.default("isAnnounceGrpRestrict"), new i.default("modifyTag"), new i.default("muteExpiration"), new i.default("name"), new i.default("notSpam"), new i.default("pin"), new i.default("changeNumberOldJid"), new i.default("changeNumberNewJid"), new i.default("lastReceivedKey"), new i.default("endOfHistoryTransfer"), new i.default("ephemeralDuration"), new i.default("ephemeralSettingTimestamp")]).version((0, u.chatAddunreadMsgAnchorId)(), [new i.default("unreadMsgAnchorId")]).version((0, u.chatRemoveLastReceivedKey)(), [new o.default("lastReceivedKey")]).view((e => ({
                        id: e.id,
                        t: e.t,
                        unreadCount: e.unreadCount,
                        unreadMsgAnchorId: e.unreadMsgAnchorId,
                        archive: e.archive,
                        isReadOnly: e.isReadOnly,
                        isAnnounceGrpRestrict: e.isAnnounceGrpRestrict,
                        modifyTag: e.modifyTag,
                        muteExpiration: e.muteExpiration,
                        name: e.name,
                        notSpam: e.notSpam,
                        pin: e.pin,
                        changeNumberOldJid: e.changeNumberOldJid,
                        changeNumberNewJid: e.changeNumberNewJid,
                        endOfHistoryTransfer: e.endOfHistoryTransfer,
                        ephemeralDuration: e.ephemeralDuration,
                        ephemeralSettingTimestamp: e.ephemeralSettingTimestamp
                    })))
                }, t.getTable = function() {
                    return (0, a.getStorage)().table("chat")
                };
                var i = r(n(530)),
                    o = r(n(6546)),
                    a = n(7993),
                    s = r(n(8642)),
                    u = n(9290)
            },
            7211: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.addTable = function() {
                    (0, a.getStorage)().add("collection-version").version((0, u.collectionVersionCreateTable)(), [new s.default("collection"), new i.default("version"), new i.default("state"), new i.default("finiteFailureStartTime")]).version((0, u.collectionVersionAddLtHash)(), [new i.default("ltHash")]).version((0, u.collectionVersionAddMissingKeys)(), [new i.default("missingKeys")]).version((0, u.collectionVersionRemoveMissingKeys)(), [new o.default("missingKeys")]).view((e => e))
                }, t.getTable = function() {
                    return (0, a.getStorage)().table("collection-version")
                };
                var i = r(n(530)),
                    o = r(n(6546)),
                    a = n(7993),
                    s = r(n(8642)),
                    u = n(9290)
            },
            2303: (e, t, n) => {
                "use strict";
                var r = n(3291),
                    i = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.addTable = function() {
                    (0, h.getStorage)().add("message").version((0, p.messageCreateTable)(), [new v.default("id"), new a.default("internalId"), new l.default("internalId"), new a.default("rowId"), new l.default("rowId"), new u.default("body", u.ENCRYPTED_VALUE_TYPE.STRING), new a.default("type"), new a.default("subtype"), new a.default("t"), new a.default("notifyName"), new a.default("from"), new a.default("to"), new a.default("author"), new a.default("self"), new a.default("ack"), new a.default("invis"), new a.default("isStarred"), new c.default("isStarred"), new a.default("mentionedJidList"), new a.default("count"), new a.default("devicesAdded"), new a.default("devicesRemoved"), new a.default("isThisDeviceAdded"), new a.default("recipients"), new a.default("protocolMessageKey"), new a.default("templateParams"), new s.default(["internalId", "isStarred"]), new a.default("vcardWAids"), new o.default("vcardWAids"), new a.default("hasLink"), new a.default("isMediaMsg"), new a.default("isDocMsg"), new s.default(["internalId", "isMediaMsg"]), new s.default(["internalId", "isDocMsg"]), new s.default(["internalId", "hasLink"]), new a.default("offline"), new a.default("isOffline"), new u.default("offlineBuffer", u.ENCRYPTED_VALUE_TYPE.ARRAY_BUFFER), new l.default("isOffline"), new a.default("ephemeralStartTimestamp"), new a.default("ephemeralDuration"), new a.default("ephemeralSettingTimestamp"), new a.default("ephemeralOutOfSync"), new a.default("expiredTimestamp"), new c.default("expiredTimestamp"), new a.default("clientUrl"), new a.default("loc"), new a.default("lat"), new a.default("lng"), new a.default("directPath"), new a.default("mimetype"), new a.default("duration"), new a.default("filehash"), new a.default("uploadhash"), new a.default("size"), new a.default("filename"), new a.default("streamingSidecar"), new a.default("mediaKey"), new a.default("mediaKeyTimestamp"), new a.default("pageCount"), new a.default("isGif"), new a.default("gifAttribution"), new a.default("isViewOnce"), new a.default("width"), new a.default("height"), new a.default("scanLengths"), new a.default("scansSidecar"), new a.default("caption"), new a.default("interactiveAnnotations"), new a.default("firstFrameLength"), new a.default("firstFrameSidecar"), new a.default("isAnimated"), new a.default("canonicalUrl"), new a.default("matchedText"), new a.default("thumbnail"), new a.default("richPreviewType"), new a.default("doNotPlayInline"), new a.default("title"), new a.default("description"), new a.default("broadcast"), new a.default("broadcastParticipants"), new a.default("broadcastId"), new a.default("quotedMsg"), new a.default("quotedStanzaID"), new a.default("quotedRemoteJid"), new a.default("quotedParticipant"), new a.default("footer"), new a.default("hydratedButtons"), new a.default("selectedId"), new a.default("selectedIndex"), new a.default("vcardFormattedName"), new a.default("isVcardOverMmsDocument"), new a.default("businessOwnerJid"), new a.default("productId"), new a.default("currencyCode"), new a.default("priceAmount1000"), new a.default("retailerId"), new a.default("url"), new a.default("productImageCount"), new a.default("paymentCurrency"), new a.default("paymentAmount1000"), new a.default("paymentMessageReceiverJid"), new a.default("paymentTransactionTimestamp"), new a.default("paymentStatus"), new a.default("paymentNoteMsg"), new a.default("paymentRequestMessageKey"), new a.default("paymentExpiryTimestamp"), new a.default("message"), new a.default("orderTitle"), new a.default("itemCount"), new a.default("orderId"), new a.default("surface"), new a.default("status"), new a.default("token"), new a.default("textColor"), new a.default("backgroundColor"), new a.default("font"), new a.default("isForwarded"), new a.default("forwardingScore"), new a.default("ctwaContext"), new a.default("c2sTimestamp"), new c.default("c2sTimestamp"), new a.default("mdDowngrade")]).version((0, p.messageAddMessageRangeProperties)(), [new f.default("c2sTimestamp"), new d.default("c2sTimestamp"), new a.default("messageRangeIndex"), new c.default("messageRangeIndex")]).version((0, p.messageAddVcardList)(), [new a.default("vcardList")]).version((0, p.messageAddOrderTotal)(), [new a.default("totalAmount1000"), new a.default("totalCurrencyCode")]).version((0, p.messageAddDeprecatedMms3Url)(), [new a.default("deprecatedMms3Url")], (e => {
                        e.clientUrl && "location" !== e.type && (e.deprecatedMms3Url = e.clientUrl, delete e.clientUrl)
                    })).version((0, p.messageAddEncFilehash)(), [new a.default("encFilehash")], (e => {
                        var t;
                        e.encFilehash = null !== (t = e.encFilehash) && void 0 !== t ? t : e.uploadhash
                    })).version((0, p.messageAddSupportForListMessages)(), [new a.default("list"), new a.default("listResponse")]).version((0, p.messageAddSupportForButtonsMessages)(), [new a.default("isDynamicReplyButtonsMsg"), new a.default("dynamicReplyButtons"), new a.default("selectedButtonId")]).version((0, p.messageAddOrderSellerJid)(), [new a.default("sellerJid")]).view((e => e)).enablePropFilter(!0).useDbMsgEncKeyForEncryptedCol(!0)
                }, t.getTable = function() {
                    return (0, h.getStorage)().table("message")
                };
                var o = i(n(6879)),
                    a = i(n(530)),
                    s = i(n(9387)),
                    u = r(n(522)),
                    c = i(n(146)),
                    l = i(n(5745)),
                    f = i(n(6546)),
                    d = i(n(600)),
                    h = n(7993),
                    v = i(n(8642)),
                    p = n(9290)
            },
            8685: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.addTable = function() {
                    (0, u.getStorage)().add("pending-mutations").version((0, c.pendingMutationsCreateTable)(), [new a.default("id"), new i.default("collection"), new i.default("index"), new i.default("value"), new i.default("type"), new i.default("timestamp"), new o.default("collection"), new i.default("version")]).version((0, c.pendingMutationsAddIndexForIndex)(), [new o.default("index")]).version((0, c.pendingMutationsAddKeyId)(), [new i.default("_keyId")]).version((0, c.pendingMutationsAddMac)(), [new i.default("_indexMac"), new i.default("_valueMac")]).version((0, c.pendingMutationsRenameOperation)(), [new s.default("type"), new i.default("operation")]).version((0, c.pendingMutationsRemoveEncryptionDetails)(), [new s.default("_keyId"), new s.default("_indexMac"), new s.default("_valueMac")]).view((e => e))
                }, t.getTable = function() {
                    return (0, u.getStorage)().table("pending-mutations")
                };
                var i = r(n(530)),
                    o = r(n(146)),
                    a = r(n(2948)),
                    s = r(n(6546)),
                    u = n(7993),
                    c = n(9290)
            },
            6001: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.addTable = function() {
                    (0, u.getStorage)().add("sync-actions").version((0, l.syncActionsCreateTable)(), [new c.default("index"), new i.default("value"), new i.default("actionState"), new i.default("keyId"), new a.default("actionState"), new i.default("type"), new i.default("version"), new i.default("modelId"), new i.default("modelType"), new o.default(["modelId", "modelType", "actionState"])]).version((0, l.syncActionsAddMac)(), [new i.default("valueMac"), new i.default("indexMac"), new a.default("indexMac")]).version((0, l.syncActionsRenameOperation)(), [new s.default("type"), new i.default("operation")]).version((0, l.syncActionsAddCollection)(), [new s.default("operation"), new i.default("collection"), new i.default("timestamp"), new a.default("collection")]).version((0, l.syncActionsAddBinaryRawIndexValue)(), [new i.default("binaryRawIndexValue")]).version((0, l.syncActionsAddAction)(), [new i.default("action"), new a.default("action")]).view((e => e))
                }, t.getTable = function() {
                    return (0, u.getStorage)().table("sync-actions")
                };
                var i = r(n(530)),
                    o = r(n(9387)),
                    a = r(n(146)),
                    s = (n(3487), r(n(6546))),
                    u = n(7993),
                    c = r(n(8642)),
                    l = n(9290)
            },
            7993: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.createStorage = function() {
                    var e = new o.default(s);
                    u = new a.default(e)
                }, t.getStorage = function() {
                    return (0, i.default)(null != u, "[model-storage] Storage should be created first before being accessed"), u
                }, t.destroyStorage = function() {
                    if (null == u) return Promise.reject(new Error("[model-storage] Storage should be created first before being destroyed"));
                    return u.purge().then((() => {
                        u = null
                    })).catch((e => {
                        throw u = null, e
                    }))
                }, t.DATABASE_NAME = void 0;
                var i = r(n(7677)),
                    o = r(n(2206)),
                    a = r(n(6957)),
                    s = "model-storage";
                t.DATABASE_NAME = s;
                var u = null
            },
            3012: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.init = function() {
                    return (0, i.initializeWithoutGKs)().then((() => (0, r.getTable)().all().then((e => Promise.all(e.map((e => {
                        var t = e.id || "";
                        return (0, o.getTable)().between(["internalId"], "".concat(e.id, "_/"), "".concat(e.id, "_g"), {
                            reverse: !0,
                            limit: 20
                        }).then((e => e.length > 0 && null != e[0].isOffline ? {
                            chatId: t,
                            messages: [e[0]]
                        } : {
                            chatId: t,
                            messages: e.reverse()
                        }))
                    }))).then((t => [e, t]))))))
                };
                var r = n(5855),
                    i = n(4319),
                    o = n(2303);
                self.Promise = n(1449).Z
            },
            9290: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.pendingMutationsCreateTable = function() {
                    return (0, r.getStorage)().versions.version(0)
                }, t.collectionVersionCreateTable = function() {
                    return (0, r.getStorage)().versions.version(1)
                }, t.syncActionsCreateTable = function() {
                    return (0, r.getStorage)().versions.version(2)
                }, t.contactCreateTable = function() {
                    return (0, r.getStorage)().versions.version(3)
                }, t.blocklistCreateTable = function() {
                    return (0, r.getStorage)().versions.version(4)
                }, t.profilePicThumbCreateTable = function() {
                    return (0, r.getStorage)().versions.version(5)
                }, t.chatCreateTable = function() {
                    return (0, r.getStorage)().versions.version(6)
                }, t.messageCreateTable = function() {
                    return (0, r.getStorage)().versions.version(7)
                }, t.messageInfoCreateTable = function() {
                    return (0, r.getStorage)().versions.version(8)
                }, t.participantCreateTable = function() {
                    return (0, r.getStorage)().versions.version(9)
                }, t.orphanReceiptCreateTable = function() {
                    return (0, r.getStorage)().versions.version(10)
                }, t.deviceListCreateTable = function() {
                    return (0, r.getStorage)().versions.version(11)
                }, t.inactiveReceiptCreateTable = function() {
                    return (0, r.getStorage)().versions.version(12)
                }, t.verifiedBusinessNameCreateTable = function() {
                    return (0, r.getStorage)().versions.version(13)
                }, t.historySyncNotificationsCreateTable = function() {
                    return (0, r.getStorage)().versions.version(14)
                }, t.encryptedMutationsCreateTable = function() {
                    return (0, r.getStorage)().versions.version(15)
                }, t.labelCreateTable = function() {
                    return (0, r.getStorage)().versions.version(16)
                }, t.labelAssociationCreateTable = function() {
                    return (0, r.getStorage)().versions.version(17)
                }, t.quickReplyCreateTable = function() {
                    return (0, r.getStorage)().versions.version(18)
                }, t.abpropsCreateConfigTable = function() {
                    return (0, r.getStorage)().versions.version(19)
                }, t.messageAddMessageRangeProperties = function() {
                    return (0, r.getStorage)().versions.version(20)
                }, t.groupMetadataCreateTable = function() {
                    return (0, r.getStorage)().versions.version(21)
                }, t.syncKeysCreateTable = function() {
                    return (0, r.getStorage)().versions.version(22)
                }, t.pendingMutationsAddIndexForIndex = function() {
                    return (0, r.getStorage)().versions.version(23)
                }, t.tasksScheduledTimeCreateTable = function() {
                    return (0, r.getStorage)().versions.version(24)
                }, t.pendingMutationsAddKeyId = function() {
                    return (0, r.getStorage)().versions.version(25)
                }, t.activeMessageRangesCreateTable = function() {
                    return (0, r.getStorage)().versions.version(26)
                }, t.collectionVersionAddLtHash = function() {
                    return (0, r.getStorage)().versions.version(27)
                }, t.syncActionsAddMac = function() {
                    return (0, r.getStorage)().versions.version(28)
                }, t.pendingMutationsAddMac = function() {
                    return (0, r.getStorage)().versions.version(29)
                }, t.pendingMutationsRenameOperation = function() {
                    return (0, r.getStorage)().versions.version(30)
                }, t.syncActionsRenameOperation = function() {
                    return (0, r.getStorage)().versions.version(31)
                }, t.encryptedMutationsRenameIndexMac = function() {
                    return (0, r.getStorage)().versions.version(32)
                }, t.messageAddVcardList = function() {
                    return (0, r.getStorage)().versions.version(33)
                }, t.collectionVersionAddMissingKeys = function() {
                    return (0, r.getStorage)().versions.version(34)
                }, t.deviceListRemoveUsyncColumn = function() {
                    return (0, r.getStorage)().versions.version(35)
                }, t.verifiedBusinessNameAddActualActorsAndHostStorage = function() {
                    return (0, r.getStorage)().versions.version(36)
                }, t.contactAddIsAddressBookContact = function() {
                    return (0, r.getStorage)().versions.version(37)
                }, t.verifiedBusinessNameAddPrivacyModeTs = function() {
                    return (0, r.getStorage)().versions.version(38)
                }, t.chatAddunreadMsgAnchorId = function() {
                    return (0, r.getStorage)().versions.version(39)
                }, t.activeMessageRangesAddReceivedMessages = function() {
                    return (0, r.getStorage)().versions.version(40)
                }, t.messageAddOrderTotal = function() {
                    return (0, r.getStorage)().versions.version(41)
                }, t.messageAddDeprecatedMms3Url = function() {
                    return (0, r.getStorage)().versions.version(42)
                }, t.pendingMutationsRemoveEncryptionDetails = function() {
                    return (0, r.getStorage)().versions.version(43)
                }, t.syncActionsAddCollection = function() {
                    return (0, r.getStorage)().versions.version(44)
                }, t.collectionVersionRemoveMissingKeys = function() {
                    return (0, r.getStorage)().versions.version(45)
                }, t.messageAddEncFilehash = function() {
                    return (0, r.getStorage)().versions.version(46)
                }, t.collectionVersionHistorySyncWamData = function() {
                    return (0, r.getStorage)().versions.version(47)
                }, t.ftsIndexingQueueCreateTable = function() {
                    return (0, r.getStorage)().versions.version(48)
                }, t.syncActionsAddBinaryRawIndexValue = function() {
                    return (0, r.getStorage)().versions.version(49)
                }, t.syncActionsAddAction = function() {
                    return (0, r.getStorage)().versions.version(50)
                }, t.syncKeysAddEncryptedKeyData = function() {
                    return (0, r.getStorage)().versions.version(51)
                }, t.messageAddSupportForListMessages = function() {
                    return (0, r.getStorage)().versions.version(52)
                }, t.messageAddSupportForButtonsMessages = function() {
                    return (0, r.getStorage)().versions.version(53)
                }, t.messageAddOrderSellerJid = function() {
                    return (0, r.getStorage)().versions.version(54)
                }, t.chatRemoveLastReceivedKey = function() {
                    return (0, r.getStorage)().versions.version(55)
                }, t.participantAddDeviceSyncComplete = function() {
                    return (0, r.getStorage)().versions.version(56)
                };
                var r = n(7993)
            },
            1198: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t) {
                    for (var n = [], r = e.length, i = t.length, o = Math.max(r, i), a = 0; a < o; a++) a < r && n.push(e[a]), a < i && n.push(t[a]);
                    return n
                }
            },
            6890: (e, t, n) => {
                "use strict";
                var r = n(4859);
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t, n, r = String) {
                    var o = (0, i.default)(e, t.map(r)).join(""),
                        a = n ? 4e3 : Number.POSITIVE_INFINITY;
                    o.length > a && (o = o.slice(0, a).replace(/\s+$/, " [truncated]"));
                    return o
                };
                var i = r(n(1198))
            },
            1985: (e, t) => {
                "use strict";

                function n(e, t) {
                    var r = function(...n) {
                        var i = t ? t.apply(this, n) : n[0];
                        if (!i) return e.apply(this, n);
                        var o = r.cache;
                        if (o.has(i)) return o.get(i);
                        var a = e.apply(this, n);
                        return r.cache = o.set(i, a) || o, a
                    };
                    return r.cache = new(n.Cache || Map), r
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0, n.Cache = Map;
                var r = n;
                t.default = r
            },
            1941: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e, t = "?") {
                    if (null == e) throw new Error("Unexpected null or undefined: ".concat(t));
                    return e
                }
            }
        },
        t = {};

    function n(r) {
        if (t[r]) return t[r].exports;
        var i = t[r] = {
            exports: {}
        };
        return e[r](i, i.exports, n), i.exports
    }
    n.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), n.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, (() => {
        self.Promise = n(1449).Z;
        var {
            log: e,
            sendLogs: t
        } = n(9458);
        self.__LOG__ = e, self.SEND_LOGS = t;
        (0, n(2186).Z)().then((() => {
            self.addEventListener("message", (() => {}))
        }))
    })()
})();