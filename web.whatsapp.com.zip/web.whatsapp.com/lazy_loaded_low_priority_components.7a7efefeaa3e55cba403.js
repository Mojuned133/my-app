/*! Copyright (c) 2021 WhatsApp Inc. All Rights Reserved. */
(self.webpackChunkbuild = self.webpackChunkbuild || []).push([
    [275], {
        10467: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setPushname = function(e) {
                return m(e)
            };
            var r = i(a(19976)),
                n = s(a(2784)),
                l = a(12073),
                o = i(a(79711)),
                d = i(a(52737)),
                u = a(19741),
                c = i(a(17957)),
                h = i(a(28991)),
                p = a(50553);

            function f() {
                var e = (0, r.default)(["models:conn:setPushname dropped"]);
                return f = function() {
                    return e
                }, e
            }

            function m(e, t = (0, l.genId)()) {
                var a = (0, h.default)(e),
                    s = new l.ActionType(c.default.t(185)),
                    i = d.default.pushname,
                    r = a.then((() => new l.ActionType(c.default.t(182), {
                        actionText: c.default.t(197),
                        actionHandler: () => m(i, t)
                    }))).catchType(u.ServerStatusCodeError, (e => {
                        if (e.status >= 400) return new l.ActionType(c.default.t(183))
                    })).catch((() => {
                        throw __LOG__(3)(f()), new l.ActionType(c.default.t(183), {
                            actionText: c.default.t(193),
                            actionHandler: () => m(status, t)
                        })
                    }));
                return o.default.openToast(n.createElement(l.ActionToast, {
                    id: t,
                    initialAction: s,
                    pendingAction: r
                })), a.then((t => {
                    t._duplicate || (0, p.setPushnameLocally)(e)
                }))
            }
        },
        50553: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setPushnameLocally = function(e) {
                i.default.pushname = e, (0, r.setPushname)(e)
            };
            var i = s(a(52737)),
                r = a(95595)
        },
        17619: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t, a, s) {
                var i = e.map(y.vcardFromContactModel),
                    r = 1 === i.length ? i[0] : (0, y.mergeVcards)(i),
                    l = "".concat(r.displayName, ".vcf"),
                    o = (0, p.createFile)([r.vcard], l, {
                        type: T
                    }),
                    d = o.size / 1024;
                if (0 !== S.default.vcardAsDocumentSizeKb && d > S.default.vcardAsDocumentSizeKb) return void
                function() {
                    P.apply(this, arguments)
                }(o, e.length, t, a, s);
                ! function(e, t, a, s, i) {
                    var r = s && s.msgContextInfo(t.id),
                        l = (0, f.getMaybeMeUser)(),
                        o = (0, n.default)((0, n.default)({
                            ack: h.default.ACK.CLOCK,
                            from: l,
                            id: new v.default({
                                from: l,
                                to: t.id,
                                id: (0, E.default)(),
                                participant: void 0,
                                selfDir: "out"
                            }),
                            local: !0,
                            isNewMsg: !0,
                            self: "out",
                            t: u.default.globalUnixTime(),
                            to: t.id
                        }, r), {}, {
                            ctwaContext: i
                        }),
                        d = 1 === e.length ? (0, n.default)((0, n.default)({
                            type: "vcard",
                            vcardFormattedName: e[0].displayName,
                            body: e[0].vcard
                        }, o), N(t)) : (0, n.default)((0, n.default)({
                            type: "multi_vcard",
                            vcardList: e
                        }, o), N(t));
                    L((() => (0, g.addAndSendMsgToChat)(t, d)[1]), {
                        channel: m.default.CONTACT_SEND_CHANNEL.CHATD,
                        isMultiVcard: e.length > 1,
                        sizeInKb: a
                    })
                }(i, t, d, a, s)
            };
            var r = i(a(19976)),
                n = i(a(70417)),
                l = i(a(52954)),
                o = s(a(2784)),
                d = i(a(36543)),
                u = i(a(19899)),
                c = i(a(79711)),
                h = i(a(50935)),
                p = a(99888),
                f = a(95595),
                m = i(a(40210)),
                v = i(a(77865)),
                _ = i(a(61941)),
                E = i(a(49213)),
                g = a(95721),
                C = a(59420),
                S = i(a(72424)),
                I = s(a(75074)),
                y = a(84990);

            function M() {
                var e = (0, r.default)(["Error sending contact: ", ""]);
                return M = function() {
                    return e
                }, e
            }
            var T = "text/vcard";

            function P() {
                return (P = (0, l.default)((function*(e, t, a, s, i) {
                    var r = {
                            file: e,
                            type: h.default.MSG_TYPE.DOCUMENT,
                            filename: e.name,
                            mimetype: T,
                            isVcardOverMmsDocument: !0,
                            documentPageCount: t
                        },
                        n = new d.default({
                            chatParticipantCount: a.getParticipantCount()
                        });
                    yield n.processAttachments([r]);
                    var {
                        errorMsgs: l
                    } = n.uiProcessMsgs();
                    if (l) c.default.openToast(o.createElement(I.default, {
                        msg: l,
                        id: (0, I.genId)()
                    }));
                    else {
                        var u = (0, _.default)(n.getValidMedias()[0], "collection.getValidMedias()[0]");
                        L((() => u.sendToChat(a, {
                            quotedMsg: s,
                            ctwaContext: i
                        })), {
                            channel: m.default.CONTACT_SEND_CHANNEL.MMS,
                            isMultiVcard: t > 1,
                            sizeInKb: e.size / 1024
                        })
                    }
                }))).apply(this, arguments)
            }

            function L() {
                return b.apply(this, arguments)
            }

            function b() {
                return (b = (0, l.default)((function*(e, t) {
                    var a = new m.default.ContactSend({
                        channel: t.channel,
                        isMultiVcard: t.isMultiVcard,
                        vcardDataSize: Math.floor(t.sizeInKb)
                    });
                    try {
                        var s = yield e();
                        a.messageSendResult = w(s)
                    } catch (e) {
                        throw __LOG__(2)(M(), e), a.messageSendResult = m.default.MESSAGE_SEND_RESULT_TYPE.ERROR_UNKNOWN, e
                    } finally {
                        a.markMessageSendT(), a.commit()
                    }
                }))).apply(this, arguments)
            }

            function w(e) {
                switch (e) {
                    case C.SendMsgResult.OK:
                        return m.default.MESSAGE_SEND_RESULT_TYPE.OK;
                    case C.SendMsgResult.ERROR_NETWORK:
                        return m.default.MESSAGE_SEND_RESULT_TYPE.ERROR_NETWORK;
                    case C.SendMsgResult.ERROR_EXPIRED:
                        return m.default.MESSAGE_SEND_RESULT_TYPE.ERROR_EXPIRED;
                    case C.SendMsgResult.ERROR_CANCELLED:
                        return m.default.MESSAGE_SEND_RESULT_TYPE.ERROR_CANCELLED;
                    case C.SendMsgResult.ERROR_UPLOAD:
                        return m.default.MESSAGE_SEND_RESULT_TYPE.ERROR_UPLOAD;
                    case C.SendMsgResult.ERROR_UNKNOWN:
                        return m.default.MESSAGE_SEND_RESULT_TYPE.ERROR_UNKNOWN
                }
            }

            function N(e) {
                var t = {};
                if (S.default.ephemeralMessages) {
                    e.isEphemeralSettingOn() && (t.ephemeralDuration = e.getEphemeralSetting());
                    var a = e.getEphemeralSettingTimestamp();
                    null != a && (t.ephemeralSettingTimestamp = a)
                }
                return t
            }
        },
        59719: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.editBusinessProfile = void 0;
            var i = s(a(18120)),
                r = s(a(95174));
            t.editBusinessProfile = e => {
                var t;
                return i.default.supportsFeature(i.default.F.MD_BACKEND) ? t || (t = Promise.reject(new Error("md business profile edit not supported"))) : t = (0, r.default)(e), t
            }
        },
        95174: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.convertProfileToRequestData = void 0;
            var i = s(a(70417)),
                r = s(a(19976)),
                n = s(a(52954)),
                l = a(19741),
                o = s(a(15059)),
                d = s(a(12767));

            function u() {
                var e = (0, r.default)(["error editing business profile: ", ""]);
                return u = function() {
                    return e
                }, e
            }

            function c() {
                var e = (0, r.default)(["error editing business profile webd: ", ""]);
                return c = function() {
                    return e
                }, e
            }

            function h() {
                var e = (0, r.default)(["empty profile received, ignoring save"]);
                return h = function() {
                    return e
                }, e
            }
            var p = e => {
                    if (e) return {
                        category: e.map((({
                            id: e
                        }) => ({
                            id: e
                        })))
                    }
                },
                f = e => {
                    if (e) {
                        var {
                            note: t,
                            timezone: a,
                            config: s
                        } = e, i = [];
                        for (var r in s) {
                            var n = s[r],
                                {
                                    mode: l,
                                    hours: o
                                } = n;
                            if (o)
                                for (var [d, u] of o) i.push({
                                    day_of_week: r,
                                    mode: l,
                                    open_time: d,
                                    close_time: u
                                });
                            else i.push({
                                day_of_week: r,
                                mode: l
                            })
                        }
                        return {
                            timezone: a,
                            business_hours_note: t,
                            business_hours_config: i
                        }
                    }
                },
                m = ({
                    address: e,
                    description: t,
                    email: a,
                    website: s,
                    businessHours: i,
                    categories: r
                }) => {
                    var n = (0, o.default)({
                        address: e,
                        description: t,
                        email: a,
                        website: s,
                        business_hours: f(i),
                        categories: p(r)
                    });
                    return Object.keys(n).length > 0 ? n : void 0
                };
            t.convertProfileToRequestData = m;
            var v = function() {
                var e = (0, n.default)((function*(e) {
                    var t = m(e);
                    if (t) {
                        var a = (0, i.default)({
                            v: 2
                        }, t);
                        try {
                            var s = yield d.default.send2({
                                data: ["action", "editBusinessProfile", a],
                                retryOn5xx: !0
                            }), {
                                status: r
                            } = s;
                            if ((e => e >= 200 && e <= 299)(r)) return;
                            throw __LOG__(3)(c(), r), new l.ServerStatusCodeError(r, "edit business profile")
                        } catch (e) {
                            var n = e;
                            throw __LOG__(3)(u(), n), n
                        }
                    } else __LOG__(3)(h())
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }();
            t.default = v
        },
        28991: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                r.default.supportsFeature(r.default.F.MD_BACKEND);
                return n.default.setPushname(e).then((e => {
                    if (e.status && 200 !== e.status) throw new i.ServerStatusCodeError(e.status);
                    return {
                        _duplicate: e._duplicate
                    }
                }))
            };
            var i = a(19741),
                r = s(a(18120)),
                n = s(a(76022))
        },
        97e3: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.LoadType = t.EditType = void 0;
            var s = a(28103).Mirrored(["EDITING", "PENDING", "DONE", "ERROR"]);
            t.EditType = s;
            var i = a(28103).Mirrored(["PENDING", "DONE", "ERROR"]);
            t.LoadType = i
        },
        81359: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(52954)),
                n = i(a(70417)),
                l = s(a(2784)),
                o = i(a(90245)),
                d = i(a(21403)),
                u = i(a(2167)),
                c = i(a(17957)),
                h = a(71025),
                p = i(a(48234)),
                f = i(a(22948)),
                m = i(a(62193)),
                v = i(a(52100)),
                _ = a(7940),
                E = a(28103).Mirrored(["START", "END"]),
                g = h.BUSINESS_HOUR_MODES.SPECIFIC_HOURS,
                C = () => [(0, _.minutesToTime)(540), (0, _.minutesToTime)(1080)];
            class S extends l.Component {
                constructor(...e) {
                    super(...e), this.state = (({
                        businessHours: {
                            mode: e,
                            days: t
                        }
                    }) => {
                        var a = {};
                        for (var {
                                dayKey: s,
                                closed: i,
                                hours: r,
                                dayName: n
                            } of t) a[s] = {
                            closed: i,
                            hours: r || [C()],
                            dayKey: s,
                            dayName: n
                        };
                        return {
                            mode: e || g,
                            dayValues: a
                        }
                    })(this.props)
                }
                _buildDayId({
                    dayKey: e
                }) {
                    return "".concat(e, "_business_hours")
                }
                _renderCheckbox(e) {
                    var {
                        closed: t,
                        dayKey: a
                    } = e, s = this._buildDayId(e);
                    return l.createElement("div", {
                        className: o.default.dayCheckbox
                    }, l.createElement(d.default, {
                        id: s,
                        checked: !t,
                        onChange: () => {
                            var {
                                dayValues: e
                            } = this.state, t = e[a], {
                                closed: s
                            } = t;
                            this._updateDayValue(a, {
                                closed: !s
                            })
                        }
                    }))
                }
                _renderTabs() {
                    var {
                        mode: e
                    } = this.state;
                    return l.createElement(m.default, {
                        onSelect: e => {
                            if (e === h.BUSINESS_HOUR_MODES.OPEN_24H) {
                                var {
                                    dayValues: t
                                } = this.state;
                                for (var a of h.DAYS_OF_WEEK) t[a] = (0, n.default)((0, n.default)({}, t[a]), {}, {
                                    closed: !1
                                });
                                this.setState({
                                    mode: e,
                                    dayValues: t
                                })
                            } else this.setState({
                                mode: e
                            })
                        },
                        selectedId: e,
                        tabConfigs: [{
                            title: c.default.t(349),
                            id: h.BUSINESS_HOUR_MODES.SPECIFIC_HOURS
                        }, {
                            title: c.default.t(345),
                            id: h.BUSINESS_HOUR_MODES.OPEN_24H
                        }, {
                            title: c.default.t(346),
                            id: h.BUSINESS_HOUR_MODES.APPOINTMENT_ONLY
                        }]
                    })
                }
                _updateValueToUserTimeFormat(e, t, a) {
                    var {
                        dayValues: s
                    } = this.state, i = s[e], {
                        hours: r
                    } = i, n = t === E.START ? 0 : 1, l = r[a][n], o = (0, _.timeStringToMinutes)(l);
                    void 0 !== o && this._updateDayValue(e, {
                        hours: this._updateHoursValue(r, (0, _.minutesToTime)(o), t, a)
                    })
                }
                _updateHoursValue(e, t, a, s) {
                    var i = [...e],
                        r = a === E.START ? 0 : 1,
                        n = [...i[s]];
                    return n[r] = t, i[s] = n, i
                }
                _renderTimeInput(e, t, a, s) {
                    var i = (0, _.isValidTime)(t) ? null : " ";
                    return l.createElement("div", {
                        key: "".concat(e, "-").concat(a, "-").concat(s),
                        className: o.default.timeWrapper
                    }, l.createElement(v.default, {
                        managed: !0,
                        value: t,
                        theme: "small",
                        maxLength: 15,
                        customStyleThemes: ["desaturated", "noErrorInfo"],
                        error: i,
                        onChange: t => {
                            var {
                                dayValues: i
                            } = this.state, r = i[e], {
                                hours: n
                            } = r;
                            this._updateDayValue(e, {
                                hours: this._updateHoursValue(n, t, a, s)
                            })
                        },
                        onBlur: () => {
                            this._updateValueToUserTimeFormat(e, a, s)
                        }
                    }))
                }
                _updateDayValue(e, t) {
                    var {
                        dayValues: a
                    } = this.state, s = a[e];
                    this.setState({
                        dayValues: (0, n.default)((0, n.default)({}, a), {}, {
                            [e]: (0, n.default)((0, n.default)({}, s), t)
                        })
                    })
                }
                _addHours(e) {
                    var {
                        dayValues: t
                    } = this.state, a = t[e], {
                        hours: s
                    } = a;
                    this._updateDayValue(e, {
                        hours: [...s, C()]
                    })
                }
                _removeHours(e) {
                    var {
                        dayValues: t
                    } = this.state, a = t[e], {
                        hours: s
                    } = a, i = [...s];
                    i.pop(), this._updateDayValue(e, {
                        hours: i
                    })
                }
                _renderAdd(e) {
                    return l.createElement("div", {
                        className: o.default.timeWrapper
                    }, l.createElement(u.default, {
                        "aria-label": c.default.t(1),
                        label: c.default.t(214),
                        onClick: () => {
                            this._addHours(e)
                        },
                        prefixIcon: "status-ciphertext",
                        iconTheme: "padded-svg"
                    }))
                }
                _renderRemove(e) {
                    return l.createElement("div", {
                        className: o.default.timeWrapper
                    }, l.createElement(f.default, {
                        title: c.default.t(1157),
                        "aria-label": c.default.t(1157),
                        name: "x-alt",
                        onClick: () => {
                            this._removeHours(e)
                        }
                    }))
                }
                _renderHours({
                    dayKey: e,
                    hours: t
                }) {
                    var a = [],
                        s = t.length >= 2 ? this._renderRemove(e) : this._renderAdd(e);
                    return t.forEach((([t, s], i) => {
                        i > 0 && a.push(l.createElement("div", {
                            className: o.default.hoursAnd
                        }, c.default.t(342))), a.push(this._renderTimeInput(e, t, E.START, i), this._renderTimeInput(e, s, E.END, i))
                    })), l.createElement("div", {
                        className: o.default.hoursMain
                    }, a, s)
                }
                _renderDayValues(e, t) {
                    var a, {
                        closed: s
                    } = e;
                    return s ? a = c.default.t(344) : t === h.BUSINESS_HOUR_MODES.APPOINTMENT_ONLY ? a = c.default.t(343) : t === h.BUSINESS_HOUR_MODES.OPEN_24H && (a = c.default.t(351)), a ? l.createElement("div", {
                        className: o.default.dayInfoText
                    }, a) : h.BUSINESS_HOUR_MODES.SPECIFIC_HOURS && !e.closed ? this._renderHours(e) : null
                }
                _renderDayInfo(e, t) {
                    var {
                        dayName: a
                    } = e, s = this._buildDayId(e);
                    return l.createElement("div", {
                        className: o.default.dayInfo
                    }, l.createElement("label", {
                        htmlFor: s
                    }, a), this._renderDayValues(e, t))
                }
                _renderDay(e) {
                    var {
                        mode: t
                    } = this.state;
                    return l.createElement("div", {
                        key: "day-".concat(e.dayKey),
                        className: o.default.dayMain
                    }, this._renderCheckbox(e), this._renderDayInfo(e, t))
                }
                _renderBusinessHours() {
                    var {
                        businessHours: {
                            days: e
                        }
                    } = this.props;
                    return l.createElement("div", null, this._renderTabs(), l.createElement("div", {
                        className: o.default.editMain
                    }, e.map((({
                        dayKey: e
                    }) => {
                        var t = this.state.dayValues[e];
                        return this._renderDay(t)
                    }))))
                }
                render() {
                    var e = this,
                        t = this._renderBusinessHours(),
                        {
                            mode: a,
                            dayValues: s
                        } = this.state,
                        {
                            businessHours: {
                                note: i,
                                timezone: n
                            }
                        } = this.props;
                    return l.createElement(p.default, {
                        title: c.default.t(347),
                        isValid: (0, _.isValidBusinessHours)(a, s),
                        doSave: (0, r.default)((function*() {
                            yield e.props.saveBusinessProfile((0, _.convertToRawBusinessProfile)({
                                mode: a,
                                dayValues: s,
                                note: i,
                                timezone: n
                            }))
                        })),
                        afterSave: this.props.afterSave,
                        onCancel: this.props.onCancel
                    }, t)
                }
            }
            t.default = S
        },
        71025: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "RawBusinessProfile", {
                enumerable: !0,
                get: function() {
                    return s.RawBusinessProfile
                }
            }), Object.defineProperty(t, "BUSINESS_HOUR_MODES", {
                enumerable: !0,
                get: function() {
                    return i.BUSINESS_HOUR_MODES
                }
            }), Object.defineProperty(t, "DAYS_OF_WEEK", {
                enumerable: !0,
                get: function() {
                    return i.DAYS_OF_WEEK
                }
            });
            var s = a(4856),
                i = a(25975)
        },
        7940: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "minutesToTime", {
                enumerable: !0,
                get: function() {
                    return i.minutesToTime
                }
            }), Object.defineProperty(t, "timeStringToMinutes", {
                enumerable: !0,
                get: function() {
                    return i.timeStringToMinutes
                }
            }), t.convertToRawBusinessProfile = t.isValidBusinessHours = t.isValidTime = void 0;
            var s = a(71025),
                i = a(87322),
                r = e => void 0 !== (0, i.timeStringToMinutes)(e);
            t.isValidTime = r;
            t.isValidBusinessHours = (e, t) => {
                if (e === s.BUSINESS_HOUR_MODES.SPECIFIC_HOURS)
                    for (var a in t) {
                        var i = t[a],
                            {
                                closed: n,
                                hours: l
                            } = i;
                        if (!n)
                            for (var [o, d] of l)
                                if (!r(o) || !r(d)) return !1
                    }
                return !0
            };
            t.convertToRawBusinessProfile = ({
                mode: e,
                dayValues: t,
                note: a,
                timezone: r
            }) => {
                var n = {};
                for (var l in t) {
                    var o = t[l],
                        {
                            closed: d,
                            hours: u
                        } = o;
                    if (!d) {
                        var c = {
                            mode: e
                        };
                        e === s.BUSINESS_HOUR_MODES.SPECIFIC_HOURS && (c.hours = u.map((([e, t]) => [(0, i.timeStringToMinutes)(e) || 0, (0, i.timeStringToMinutes)(t) || 0]))), n[l] = c
                    }
                }
                return {
                    businessHours: {
                        config: n,
                        note: a,
                        timezone: r
                    }
                }
            }
        },
        60315: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(52954)),
                n = i(a(70417)),
                l = i(a(72779)),
                o = s(a(2784)),
                d = a(95167),
                u = a(88137),
                c = i(a(7899)),
                h = i(a(21403)),
                p = i(a(65434)),
                f = i(a(79711)),
                m = i(a(35598)),
                v = i(a(63097)),
                _ = i(a(22004)),
                E = i(a(17957)),
                g = i(a(81610)),
                C = i(a(48234)),
                S = i(a(2825)),
                I = s(a(75074));
            class y extends o.Component {
                constructor(...e) {
                    super(...e), this.state = (({
                        initialCategories: e
                    }) => ({
                        selectedCategories: e,
                        searchText: "",
                        isLoading: !1
                    }))(this.props), this.flatListController = new _.default, this.setRefList = e => {
                        this.list = e
                    }, this.renderItem = e => {
                        var t = o.createElement(h.default, {
                                id: "".concat(e.id),
                                onChange: () => {
                                    !e.disabled && this._toggleResultById(e.id)
                                },
                                checked: e.selected,
                                disabled: e.disabled
                            }),
                            a = o.createElement("label", {
                                className: (0, l.default)(c.default.rowLabel, {
                                    [c.default.disabled]: e.disabled
                                }),
                                htmlFor: e.id
                            }, e.localized_display_name);
                        return this._renderRow(a, t)
                    }, this._removeById = e => {
                        var t, a = null === (t = this.state.selectedCategories) || void 0 === t ? void 0 : t.filter((t => t.id === e))[0];
                        a && this.toggle(a)
                    }, this._toggleResultById = e => {
                        var t, a = null === (t = this.state.results) || void 0 === t ? void 0 : t.filter((t => t.id === e))[0];
                        a && this.toggle(a)
                    }, this.toggle = e => {
                        var t, a = null === (t = this.state.results) || void 0 === t ? void 0 : t.find((e => e.not_a_biz)),
                            s = this.state.selectedCategories.find((e => e.id === (null == a ? void 0 : a.id))),
                            i = this.state.selectedCategories;
                        this.state.selectedCategories.length > 0 && (e.not_a_biz && !s ? (i = [], this._showConflictWarning()) : !e.not_a_biz && s && (i = this.state.selectedCategories.filter((e => e.id !== s.id)), this._showConflictWarning())), this.isSelected(e.id) ? this.setState({
                            selectedCategories: i.filter((t => t.id !== e.id))
                        }) : this.setState({
                            selectedCategories: [...i, e]
                        })
                    }, this.setSearchText = e => {
                        this._getResults(e)
                    }, this.onRemoveItem = e => {
                        this.setState({
                            selectedCategories: this.state.selectedCategories.filter((t => t.id !== e.id))
                        })
                    }
                }
                componentDidMount() {
                    this._getResults("")
                }
                renderList() {
                    var e, t;
                    if (this.state.isLoading) return o.createElement("div", {
                        className: c.default.loadingSpinner
                    }, o.createElement(S.default, {
                        color: "highlight",
                        size: 44,
                        stroke: 6
                    }));
                    if (!this.state.results || 0 === this.state.results.length) return this._renderRow(E.default.t(379), null);
                    var a = null === (e = this.state) || void 0 === e || null === (t = e.results) || void 0 === t ? void 0 : t.map((e => (0, n.default)((0, n.default)({}, e), {}, {
                        id: e.id,
                        itemKey: e.id.toString(),
                        disabled: this.isDisabled(e),
                        selected: this.isSelected(e.id)
                    })));
                    return o.createElement(v.default, {
                        flatListControllers: [this.flatListController]
                    }, o.createElement(m.default, {
                        ref: this.setRefList,
                        data: a,
                        flatListController: this.flatListController,
                        direction: "vertical",
                        renderItem: this.renderItem,
                        defaultItemHeight: 48
                    }))
                }
                _renderRow(e, t) {
                    return o.createElement("div", {
                        className: c.default.rowMain
                    }, o.createElement("div", {
                        className: c.default.rowCheckbox
                    }, t), e)
                }
                _renderSearchBox() {
                    return o.createElement(g.default, {
                        onSearch: this.setSearchText,
                        placeholder: E.default.t(381)
                    })
                }
                _renderFooter() {
                    return this.state && this.state.selectedCategories ? o.createElement(p.default, {
                        categories: this.state.selectedCategories,
                        onRemoveItem: this._removeById
                    }) : null
                }
                _showConflictWarning() {
                    f.default.openToast(o.createElement(I.default, {
                        id: (0, I.genId)(),
                        msg: E.default.t(359)
                    }))
                }
                isSelected(e) {
                    for (var {
                            selectedCategories: t
                        } = this.state, a = 0; a < t.length; a++)
                        if (t[a].id === e) return !0;
                    return !1
                }
                isDisabled(e) {
                    return !e.not_a_biz && !this.isSelected(e.id) && this.state.selectedCategories.length >= u.MAX_BUSINESS_CATEGORIES
                }
                _getResults(e) {
                    this.setState({
                        isLoading: !0
                    }), this.props.searchCategories(e || d.BUSINESS_CATEGORY_EMPTY_STR_ID).then((t => {
                        var a = t.categories;
                        "" !== e && (a = a.filter((e => !e.not_a_biz))), this.setState({
                            isLoading: !1,
                            results: a
                        })
                    })).catch((() => {
                        f.default.openToast(o.createElement(I.default, {
                            id: (0, I.genId)(),
                            msg: E.default.t(358)
                        })), this.setState({
                            isLoading: !1,
                            results: []
                        })
                    }))
                }
                render() {
                    var e, t = this;
                    return this.state.selectedCategories.length && (e = this._renderFooter()), o.createElement(C.default, {
                        title: E.default.t(360),
                        isValid: this.state.selectedCategories.length > 0,
                        doSave: (0, r.default)((function*() {
                            yield t.props.saveBusinessProfile({
                                categories: t.state.selectedCategories
                            })
                        })),
                        afterSave: this.props.afterSave,
                        onCancel: this.props.onCancel
                    }, o.createElement("div", {
                        className: c.default.searchBackground
                    }, this._renderSearchBox()), o.createElement("div", {
                        className: c.default.editMain
                    }, o.createElement("div", {
                        className: c.default.list
                    }, this.renderList()), e))
                }
            }
            t.default = y
        },
        62231: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(58527)),
                n = s(a(2784)),
                l = i(a(75472)),
                o = i(a(81359)),
                d = a(25975),
                u = i(a(60315)),
                c = i(a(79711)),
                h = i(a(77875)),
                p = i(a(37533)),
                f = i(a(12155)),
                m = i(a(17957)),
                v = a(42390),
                _ = i(a(43562)),
                E = i(a(40210)),
                g = a(4856),
                C = a(26828),
                S = i(a(52100)),
                I = i(a(74185)),
                y = a(52567),
                {
                    useState: M,
                    useEffect: T
                } = n,
                P = 256,
                L = 512,
                b = 128,
                w = 256;
            t.default = ({
                businessProfile: e,
                saveBusinessProfile: t,
                sessionId: a,
                verifiedName: s
            }) => {
                var [i, N] = M(), [O, D] = M(), [R, k] = M(), [A, x] = M(), [U, F] = M(), [B, V] = M(), [G, H] = M(), [j, W] = M(), [K, z] = M(), [Y, q] = M(!1), [Z, X] = M();
                T((() => {
                    var t = (0, C.convertRawBusinessProfile)(e);
                    N(t.description), k(t.email), D(t.address), x(t.primaryWebsite), F(t.secondaryWebsite), V(Boolean(t.primaryWebsite && !t.secondaryWebsite))
                }), [e]), T((() => {
                    (0, y.validateEmail)(R) && H(null)
                }), [R]), T((() => {
                    (0, y.validateURL)(A) && W(null)
                }), [A]), T((() => {
                    (0, y.validateURL)(U) && z(null)
                }), [U]);
                var J, Q = () => {
                        var e = [];
                        return A && e.push(A), U && e.push(U), {
                            website: e.map(((e, t) => {
                                if (!I.default.isHttps(e) && !I.default.isHttp(e)) {
                                    var a = "https://".concat(e);
                                    return 0 === t ? x(a) : F(a), a
                                }
                                return e
                            }))
                        }
                    },
                    $ = e => n.createElement(f.default, (0, r.default)({}, e, {
                        hideEditIcon: Boolean(Z)
                    })),
                    ee = ({
                        setValue: s,
                        value: i,
                        fieldKey: l,
                        fieldMetric: o,
                        originalValue: d,
                        textFieldConfig: u,
                        formatForSave: c,
                        validate: h,
                        onError: p,
                        error: f,
                        lowProfile: m,
                        placeholder: _,
                        startActive: E
                    }) => {
                        var C = (null == Z ? void 0 : Z.fieldKey) === l,
                            I = i ? void 0 : _;
                        return n.createElement(S.default, (0, r.default)({
                            value: i,
                            editable: !Z || C,
                            pending: C && (null == Z ? void 0 : Z.editType) === g.EditType.PENDING,
                            showRemaining: !0,
                            onBeginEdit: () => {
                                (0, v.logProfileFieldOpen)(o, e, a), X({
                                    fieldKey: l,
                                    editType: g.EditType.EDITING
                                })
                            },
                            onChange: e => {
                                s(e)
                            },
                            onSave: () => {
                                (0, v.logProfileFieldSave)(o, e, a), X({
                                    fieldKey: l,
                                    editType: g.EditType.PENDING
                                }), t(c()).then((() => {
                                    X()
                                }), (() => {
                                    X()
                                }))
                            },
                            onCancel: () => {
                                (0, v.logProfileFieldDiscard)(o, e, a), s(d), X()
                            },
                            lockable: !0,
                            lowProfile: m,
                            multiline: !0,
                            inputPlaceholder: I,
                            theme: "text-input",
                            validate: h,
                            onError: p,
                            error: f,
                            a8n: "biz-profile-".concat(l, "-input"),
                            startActive: E
                        }, u))
                    },
                    te = (0, C.convertRawBusinessProfile)(e);
                return n.createElement(h.default, {
                    title: m.default.t(376),
                    theme: "refresh"
                }, (e => e ? $({
                    icon: "account-box",
                    iconClass: p.default.verifiedNameIcon,
                    content: n.createElement("div", null, n.createElement("div", null, e), n.createElement("div", {
                        className: p.default.infoText
                    }, m.default.t(378)))
                }) : null)(s), $({
                    icon: "business-description",
                    content: ee({
                        value: i,
                        setValue: N,
                        originalValue: te.description,
                        fieldKey: "description",
                        fieldMetric: E.default.BUSINESS_PROFILE_FIELD.DESCRIPTION,
                        placeholder: m.default.t(368),
                        textFieldConfig: {
                            maxLength: L,
                            supportsEmoji: !0
                        },
                        lowProfile: !0,
                        formatForSave: () => ({
                            description: i
                        })
                    })
                }), $({
                    icon: "business-category",
                    type: "container",
                    emptyText: m.default.t(367),
                    content: (J = te.categories, 0 === J.length ? null : n.createElement("div", null, J.map((e => e.localized_display_name)).join(m.default.t(579)))),
                    onEdit: () => {
                        (0, v.logProfileFieldOpen)(E.default.BUSINESS_PROFILE_FIELD.CATEGORY, e, a), c.default.openModal(n.createElement(u.default, {
                            initialCategories: te.categories,
                            saveBusinessProfile: t,
                            searchCategories: e => l.default.find(e),
                            afterSave: () => (0, v.logProfileFieldSave)(E.default.BUSINESS_PROFILE_FIELD.CATEGORY, e, a),
                            onCancel: () => {
                                (0, v.logProfileFieldDiscard)(E.default.BUSINESS_PROFILE_FIELD.CATEGORY, e, a)
                            }
                        }))
                    }
                }), $({
                    icon: "business-address",
                    content: (e => {
                        var t, a = ee({
                                value: O,
                                placeholder: m.default.t(365),
                                setValue: D,
                                originalValue: e.address,
                                fieldKey: "address",
                                fieldMetric: E.default.BUSINESS_PROFILE_FIELD.ADDRESS,
                                textFieldConfig: {
                                    maxLength: w
                                },
                                lowProfile: !0,
                                formatForSave: () => ({
                                    address: O
                                })
                            }),
                            {
                                latitude: s,
                                longitude: i
                            } = e;
                        return null != s && null != i && (t = ((e, t) => {
                            var a;
                            return "address" === (null == Z ? void 0 : Z.fieldKey) && (a = n.createElement("div", {
                                className: p.default.mapOverlay
                            }, n.createElement("div", {
                                className: p.default.overlayHint
                            }, m.default.t(371)))), n.createElement("div", {
                                style: {
                                    height: 96
                                },
                                className: p.default.businessMap
                            }, a, n.createElement(_.default, {
                                lat: e,
                                lng: t,
                                name: O,
                                width: 312,
                                height: 96
                            }))
                        })(s, i)), n.createElement(n.Fragment, null, a, t)
                    })(te)
                }), $({
                    icon: "business-hours",
                    type: "container",
                    emptyText: m.default.t(366),
                    content: (({
                        mode: e,
                        days: t
                    }) => null == e ? null : n.createElement("div", null, t.map((({
                        dayName: t,
                        dayKey: a,
                        closed: s,
                        hours: i
                    }) => n.createElement("div", {
                        key: a,
                        className: p.default.businessHoursSection
                    }, n.createElement("div", {
                        className: p.default.businessHoursDayColumn
                    }, t), n.createElement("div", {
                        className: p.default.businessHoursTimeColumn
                    }, ((e, t, a) => {
                        if (t) return m.default.t(344);
                        switch (e) {
                            case d.BUSINESS_HOUR_MODES.SPECIFIC_HOURS:
                                return n.createElement(n.Fragment, null, a && a.map((([e, t], a) => n.createElement("div", {
                                    key: a,
                                    className: p.default.businessHoursTime
                                }, e, " - ", t))));
                            case d.BUSINESS_HOUR_MODES.APPOINTMENT_ONLY:
                                return m.default.t(343);
                            case d.BUSINESS_HOUR_MODES.OPEN_24H:
                                return m.default.t(351);
                            default:
                                return null
                        }
                    })(e, s, i)))))))(te.hours),
                    onEdit: () => {
                        (0, v.logProfileFieldOpen)(E.default.BUSINESS_PROFILE_FIELD.HOURS, e, a), c.default.openModal(n.createElement(o.default, {
                            businessHours: te.hours,
                            saveBusinessProfile: t,
                            onCancel: () => {
                                (0, v.logProfileFieldDiscard)(E.default.BUSINESS_PROFILE_FIELD.HOURS, e, a)
                            },
                            afterSave: () => (0, v.logProfileFieldSave)(E.default.BUSINESS_PROFILE_FIELD.HOURS, e, a)
                        }))
                    }
                }), $({
                    icon: "business-email",
                    content: ee({
                        value: R,
                        placeholder: m.default.t(369),
                        originalValue: te.email,
                        setValue: k,
                        fieldKey: "email",
                        fieldMetric: E.default.BUSINESS_PROFILE_FIELD.EMAIL,
                        textFieldConfig: {
                            maxLength: b
                        },
                        error: G,
                        lowProfile: !1,
                        formatForSave: () => ({
                            email: R
                        }),
                        validate: e => (0, y.validateEmail)(e),
                        onError: () => {
                            H(m.default.t(642))
                        }
                    })
                }), (e => {
                    var t = ee({
                        value: A,
                        placeholder: m.default.t(377),
                        originalValue: e.primaryWebsite,
                        setValue: x,
                        fieldKey: "primaryWebsite",
                        fieldMetric: E.default.BUSINESS_PROFILE_FIELD.WEBSITE,
                        textFieldConfig: {
                            maxLength: P
                        },
                        formatForSave: Q,
                        lowProfile: !1,
                        validate: y.validateURL,
                        onError: () => {
                            W(m.default.t(650))
                        },
                        error: j
                    });
                    return $({
                        icon: "business-website",
                        theme: "small-margin",
                        content: n.createElement("div", null, t)
                    })
                })(te), (e => {
                    if (!e.primaryWebsite) return null;
                    if (U || !B) {
                        var t = ee({
                            placeholder: m.default.t(377),
                            value: U,
                            originalValue: e.secondaryWebsite,
                            setValue: F,
                            fieldKey: "secondaryWebsite",
                            fieldMetric: E.default.BUSINESS_PROFILE_FIELD.WEBSITE,
                            textFieldConfig: {
                                maxLength: P
                            },
                            formatForSave: Q,
                            lowProfile: !1,
                            validate: y.validateURL,
                            onError: () => {
                                z(m.default.t(650))
                            },
                            error: K,
                            startActive: Y
                        });
                        return $({
                            icon: "business-website",
                            theme: "no-margin",
                            content: n.createElement("div", null, t)
                        })
                    }
                    var a = n.createElement("button", {
                        className: p.default.addAnotherWebsite,
                        onClick: () => {
                            V(!1), q(!0)
                        }
                    }, m.default.t(364));
                    return $({
                        theme: "no-margin",
                        content: n.createElement("div", null, a)
                    })
                })(te))
            }
        },
        87451: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(52954)),
                n = s(a(2784)),
                l = i(a(89216)),
                o = a(59719),
                d = i(a(52737)),
                u = i(a(62231)),
                c = i(a(55561)),
                h = a(95595),
                p = i(a(17957)),
                f = a(42390),
                m = a(4856),
                v = i(a(2825)),
                _ = a(56365),
                {
                    useState: E,
                    useEffect: g
                } = n,
                C = function() {
                    var e = (0, r.default)((function*() {
                        var e = (0, h.getMeUser)(),
                            t = l.default.get(e);
                        return t && t.markStale(), (yield l.default.find(e)).serialize()
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                S = function() {
                    var e = (0, r.default)((function*() {
                        var e = (0, h.getMeUser)(),
                            t = yield l.default.update(e);
                        return (Array.isArray(t) ? t[0] : t).serialize()
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }();
            t.default = () => {
                var [e, t] = E(m.LoadType.PENDING), [a, s] = E(), i = n.useRef(Math.floor(2147483648 * Math.random()).toString()), l = function() {
                    var e = (0, r.default)((function*() {
                        t(m.LoadType.PENDING);
                        try {
                            var e = yield C();
                            s(e), t(m.LoadType.DONE), (0, f.logProfileOpen)(e, i.current)
                        } catch (e) {
                            t(m.LoadType.ERROR)
                        }
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }();
                return g((() => {
                    l()
                }), []), e === m.LoadType.PENDING ? n.createElement("div", {
                    className: c.default.loadingSpinner
                }, n.createElement(v.default, {
                    color: "default",
                    size: 24,
                    stroke: 6
                })) : e === m.LoadType.ERROR ? n.createElement("div", null, p.default.t(374)) : e === m.LoadType.DONE && a ? n.createElement(u.default, {
                    verifiedName: d.default.pushname || void 0,
                    sessionId: i.current,
                    businessProfile: a,
                    saveBusinessProfile: function() {
                        var e = (0, r.default)((function*(e) {
                            try {
                                yield(0, o.editBusinessProfile)(e)
                            } catch (e) {
                                throw (0, _.showError)(p.default.t(375)), e
                            }
                            try {
                                var t = yield S();
                                return s(t), t
                            } catch (e) {
                                throw (0, _.showError)(p.default.t(374)), e
                            }
                        }));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }()
                }) : null
            }
        },
        42390: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getProfilePopulatedFields = n, t.logProfileOpen = function(e, t) {
                var a = new r.default.EditBusinessProfile((0, i.default)({
                    editProfileAction: r.default.EDIT_PROFILE_ACTION.ACTION_OPEN,
                    businessProfileEntryPoint: r.default.BUSINESS_PROFILE_ENTRY_POINT.SETTINGS,
                    editBusinessProfileSessionId: t
                }, n(e)));
                a && a.commit()
            }, t.logProfileFieldOpen = function(e, t, a) {
                var s = new r.default.EditBusinessProfile((0, i.default)({
                    editProfileAction: r.default.EDIT_PROFILE_ACTION.ACTION_PROFILE_FIELD_OPEN,
                    businessProfileEntryPoint: r.default.BUSINESS_PROFILE_ENTRY_POINT.SETTINGS,
                    editProfileActionField: e,
                    editBusinessProfileSessionId: a
                }, n(t)));
                s && s.commit()
            }, t.logProfileFieldSave = function(e, t, a) {
                var s = new r.default.EditBusinessProfile((0, i.default)({
                    editProfileAction: r.default.EDIT_PROFILE_ACTION.ACTION_PROFILE_FIELD_SAVE,
                    businessProfileEntryPoint: r.default.BUSINESS_PROFILE_ENTRY_POINT.SETTINGS,
                    editProfileActionField: e,
                    editBusinessProfileSessionId: a
                }, n(t)));
                s && s.commit()
            }, t.logProfileFieldDiscard = function(e, t, a) {
                var s = new r.default.EditBusinessProfile((0, i.default)({
                    editProfileAction: r.default.EDIT_PROFILE_ACTION.ACTION_PROFILE_FIELD_DISCARD,
                    businessProfileEntryPoint: r.default.BUSINESS_PROFILE_ENTRY_POINT.SETTINGS,
                    editProfileActionField: e,
                    editBusinessProfileSessionId: a
                }, n(t)));
                s && s.commit()
            };
            var i = s(a(70417)),
                r = s(a(40210));

            function n(e) {
                var t, a;
                return {
                    hasDescription: null != e.description,
                    hasCategory: !!(e.categories && (null === (t = e.categories) || void 0 === t ? void 0 : t.length) > 0),
                    hasHours: null != (null === (a = e.businessHours) || void 0 === a ? void 0 : a.config),
                    hasEmail: null != e.email,
                    hasAddress: null != e.address,
                    hasWebsite: null != e.website
                }
            }
        },
        4856: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "EditType", {
                enumerable: !0,
                get: function() {
                    return s.EditType
                }
            }), Object.defineProperty(t, "LoadType", {
                enumerable: !0,
                get: function() {
                    return s.LoadType
                }
            });
            var s = a(97e3)
        },
        26828: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.convertRawBusinessProfile = void 0;
            var s = a(87322);
            t.convertRawBusinessProfile = e => {
                var {
                    description: t,
                    email: a,
                    address: i,
                    website: r,
                    categories: n,
                    businessHours: l,
                    latitude: o,
                    longitude: d
                } = e, [u, c] = r || [];
                return {
                    description: t,
                    email: a,
                    address: i,
                    primaryWebsite: u,
                    secondaryWebsite: c,
                    hours: (0, s.getBusinessHoursForEdit)(l),
                    categories: n || [],
                    latitude: o,
                    longitude: d
                }
            }
        },
        56365: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.showError = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = i(a(75074));
            t.showError = e => {
                n.default.openToast(r.createElement(l.default, {
                    msg: e,
                    duration: 6e3,
                    id: (0, l.genId)()
                }))
            }
        },
        12155: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(90809)),
                o = i(a(17957)),
                d = i(a(22948)),
                u = i(a(82631));
            t.default = ({
                icon: e,
                iconClass: t,
                content: a,
                onEdit: s,
                type: i = "field",
                emptyText: c,
                hideEditIcon: h,
                theme: p
            }) => {
                var f = s ? n.createElement("div", {
                        className: (0, r.default)(l.default.sectionEditIcon, {
                            [l.default.hidden]: h
                        })
                    }, n.createElement(d.default, {
                        "aria-label": o.default.t(563),
                        name: "pencil",
                        className: l.default.editPencil,
                        directional: !0,
                        title: o.default.t(563),
                        onClick: () => {
                            s()
                        }
                    })) : void 0,
                    m = c && !a,
                    v = m ? c : a,
                    _ = e ? n.createElement(u.default, {
                        name: e
                    }) : null;
                return n.createElement("div", {
                    className: (0, r.default)(l.default.section, {
                        [l.default.smallMargin]: "small-margin" === p,
                        [l.default.noMargin]: "no-margin" === p
                    })
                }, n.createElement("div", {
                    className: (0, r.default)(l.default.sectionPrimaryIcon, t, {
                        [l.default.fieldPrimaryIcon]: "field" === i
                    })
                }, _), n.createElement("div", {
                    className: (0, r.default)(l.default.sectionMain, {
                        [l.default.sectionContainerMain]: "container" === i,
                        [l.default.sectionEmptyText]: m
                    })
                }, v), f)
            }
        },
        83717: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.CartDetailDrawer = void 0;
            var r = i(a(19976)),
                n = s(a(2784)),
                l = i(a(64)),
                o = a(93774),
                d = i(a(99601)),
                u = i(a(60259)),
                c = i(a(18712)),
                h = i(a(79711)),
                p = i(a(9386)),
                f = i(a(50935)),
                m = s(a(37356)),
                v = i(a(58701)),
                _ = i(a(73023)),
                E = s(a(71311)),
                g = s(a(96452)),
                C = i(a(22004)),
                S = i(a(89286)),
                I = i(a(17957)),
                y = i(a(20642)),
                M = a(63865),
                T = a(49080),
                P = i(a(2446)),
                L = i(a(72259)),
                b = i(a(94461)),
                w = i(a(82631)),
                N = a(40263),
                O = i(a(74824));

            function D() {
                var e = (0, r.default)(["Unable to open the cart"]);
                return D = function() {
                    return e
                }, e
            }

            function R() {
                var e = (0, r.default)(["Unable to create catalog order"]);
                return R = function() {
                    return e
                }, e
            }
            class k extends n.Component {
                constructor(e) {
                    super(e), this._cartFlatListController = new C.default, this.updateData = e => (0, o.matchCartItemsToProducts)(this.state.cart, e).then((e => {
                        this.setState({
                            cartProductItems: e,
                            isLoading: !1
                        })
                    })), this.onSend = () => {
                        var {
                            cart: e
                        } = this.state;
                        this.setState({
                            isLoading: !0
                        }), (0, o.submitOrder)(e, this.props.chat).then((t => {
                            var a = Boolean(e.message);
                            (0, M.logSendOrderMessage)({
                                orderId: t,
                                catalogOwnerJid: e.id,
                                catalogSessionId: this.props.sessionId,
                                isOrderMsgAttached: a,
                                quantity: e.itemCount
                            }), this.props.onBack(), (0, o.clearCart)(e), e.message = void 0
                        })).catch((() => {
                            __LOG__(4, !0, new Error, !0)(R()), SEND_LOGS("submitOrder: order creation or order message send error"), (0, o.showGenericErrorToast)(), this.updateData(!0)
                        })).finally((() => {
                            this.setState({
                                isLoading: !1
                            })
                        }))
                    }, this.onChange = e => {
                        var {
                            cart: t
                        } = this.state;
                        this.setState({
                            cartMessage: e
                        }, (() => {
                            t.set("message", e)
                        }))
                    }, this._setRefMessageInput = e => {
                        this._refMessageInput = e
                    }, this.onMaxPasteExceeded = () => {
                        h.default.openModal(n.createElement(p.default, {
                            title: I.default.t(407),
                            onOK: () => {
                                h.default.closeModal()
                            },
                            okText: I.default.t(1680)
                        }, I.default.t(406)))
                    };
                    var t = d.default.findCart(this.props.sellerJid);
                    this.state = {
                        isLoading: !0,
                        cartProductItems: [],
                        cartMessage: t.message,
                        cart: t
                    }
                }
                componentDidMount() {
                    var {
                        cart: e
                    } = this.state, {
                        listeners: t,
                        sessionId: a,
                        rejectOnUnmount: s
                    } = this.props;
                    this.updateData(!0).checkpoint(s()).then((() => {
                        t.add(e, "change:cartItemCollection", (() => {
                            this.updateData()
                        })), (0, T.logCartListImpression)(e.id.toString(), a)
                    })).catchType(g.Unmount, (() => {})).catch((() => {
                        __LOG__(4, !0, new Error, !0)(D()), SEND_LOGS("openCart: failed to open the cart"), (0, o.showGenericErrorToast)(), (0, o.clearCart)(e)
                    })).finally((() => {
                        this.setState({
                            isLoading: !1
                        })
                    }))
                }
                _emptyCartContent() {
                    return n.createElement("div", {
                        className: u.default.emptyCartContainer
                    }, n.createElement(w.default, {
                        name: "shopping-cart-empty"
                    }), n.createElement(N.TextDiv, {
                        className: u.default.emptyCardHeader,
                        theme: "large"
                    }, I.default.t(399)), n.createElement(N.TextDiv, {
                        className: u.default.emptyCardText,
                        theme: "plain"
                    }, I.default.t(400)), n.createElement(l.default, {
                        onClick: this.props.onProductCatalog,
                        type: "primary"
                    }, I.default.t(1124)))
                }
                _getDrawerContent() {
                    var {
                        chat: e,
                        sellerJid: t,
                        sessionId: a
                    } = this.props, {
                        cart: s
                    } = this.state;
                    if (this.state.isLoading) return n.createElement(S.default, null);
                    var i, r, l = s.itemCount,
                        o = l > 0;
                    if (o) {
                        var d = I.default.t(814, {
                            count: l,
                            _plural: l
                        });
                        i = n.createElement(N.TextDiv, {
                            theme: "title"
                        }, d)
                    }
                    null != s.total && null != s.currency ? r = n.createElement(N.TextDiv, {
                        theme: "muted-small"
                    }, I.default.t(1093, {
                        subtotal: m.format(s.currency, s.total)
                    })) : l > 0 && (r = n.createElement(N.TextDiv, {
                        theme: "muted-small"
                    }, I.default.t(1089)));
                    var h = n.createElement(O.default, {
                            transitionName: "media-caption",
                            className: u.default.cartMessage
                        }, n.createElement(P.default, {
                            ref: this._setRefMessageInput,
                            chat: e,
                            maxLength: f.default.MAX_CART_MESSAGE_LENGTH,
                            multiline: !0,
                            onEnter: this.onSend,
                            onChange: this.onChange,
                            onMaxPasteExceeded: this.onMaxPasteExceeded,
                            placeholder: I.default.t(405),
                            showRemaining: !0,
                            spellCheck: !0,
                            supportsEmoji: !0,
                            value: this.state.cartMessage
                        })),
                        p = n.createElement("button", {
                            className: u.default.btnSend,
                            tabIndex: "-1",
                            onClick: this.onSend,
                            title: I.default.t(410)
                        }, n.createElement(b.default, {
                            large: !0
                        }, n.createElement(w.default, {
                            name: "send",
                            directional: !0
                        })));
                    return n.createElement(n.Fragment, null, !o && this._emptyCartContent(), n.createElement("div", {
                        className: u.default.info
                    }, i, r), n.createElement(c.default, {
                        flatListController: this._cartFlatListController,
                        onProductDetail: this.props.onProductDetail,
                        cart: s,
                        sellerJid: t,
                        sessionId: a,
                        cartProductItems: this.state.cartProductItems
                    }), o && n.createElement("div", {
                        className: u.default.footer
                    }, h, n.createElement(O.default, {
                        transitionAppear: !0,
                        transitionName: "btn"
                    }, p)))
                }
                render() {
                    var {
                        onBack: e
                    } = this.props;
                    return n.createElement(v.default, {
                        onDrop: e,
                        theme: "striped"
                    }, n.createElement(E.default, {
                        title: I.default.t(398),
                        type: E.DRAWER_HEADER_TYPE.SMALL,
                        onBack: e
                    }), n.createElement(_.default, {
                        flatListControllers: [this._cartFlatListController]
                    }, this._getDrawerContent()))
                }
            }
            t.CartDetailDrawer = k;
            var A = (0, L.default)((0, y.default)(k));
            t.default = A
        },
        18712: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(74930)),
                n = s(a(2784)),
                l = i(a(2374)),
                o = i(a(50935)),
                d = i(a(35598)),
                u = i(a(63097));
            class c extends n.PureComponent {
                constructor(...e) {
                    super(...e), this.getData = () => this.props.cartProductItems.map((e => ({
                        itemKey: e.cartItem.id,
                        contentKey: (0, r.default)("cartItem"),
                        product: e.product,
                        cartItem: e.cartItem
                    }))), this.renderItem = e => {
                        var {
                            onProductDetail: t,
                            sellerJid: a,
                            sessionId: s
                        } = this.props, i = {
                            productId: e.cartItem.id,
                            businessOwnerJid: a
                        };
                        return n.createElement(l.default, {
                            cartId: a,
                            product: e.product,
                            sessionId: s,
                            quantity: e.cartItem.quantity,
                            onClick: () => t(i)
                        })
                    }
                }
                render() {
                    return n.createElement(u.default, {
                        flatListControllers: [this.props.flatListController]
                    }, n.createElement(d.default, {
                        flatListController: this.props.flatListController,
                        direction: "vertical",
                        forceConsistentRenderCount: !1,
                        data: this.getData(),
                        renderItem: this.renderItem,
                        defaultItemHeight: o.default.PRODUCT_LIST_ITEM_HEIGHT
                    }))
                }
            }
            t.default = c
        },
        2374: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t, a, {
                        product: s,
                        onClick: i
                    } = e,
                    _ = r.createElement(h.default, {
                        text: s.name,
                        ellipsify: !0,
                        titlify: !0
                    }),
                    E = null === (t = s.getPreviewImage()) || void 0 === t ? void 0 : t.mediaData;
                a = E ? r.createElement(m.default, {
                    theme: "list",
                    mediaData: E
                }) : r.createElement(r.Fragment, null);

                function g(t) {
                    var {
                        cartId: a,
                        product: s,
                        sessionId: i
                    } = e, r = (0, n.deleteProductFromCart)(a, s.id.toString());
                    (0, n.deleteProductFromCart)(a, s.id.toString()), (0, f.logDeleteProduct)(s, i), 0 === r && (0, f.logCartAbandon)(s.catalogWid.toString(), i),
                        function(e) {
                            e.preventDefault(), e.stopPropagation()
                        }(t)
                }

                function C(t) {
                    var {
                        cartId: a,
                        product: s,
                        sessionId: i
                    } = e;
                    (0, n.updateProductQuantity)(a, s, t), (0, f.logEditProduct)(s, i, t)
                }
                var S = null;
                S = null != s.priceAmount1000 && null != s.currency ? u.format(s.currency, s.priceAmount1000) : p.default.t(401);
                var I = r.createElement("div", null, r.createElement(v.TextSpan, {
                    className: l.default.price
                }, S));
                return r.createElement(d.default, {
                    key: s.id.toString(),
                    image: a,
                    customImage: !0,
                    primary: _,
                    secondary: I,
                    theme: "cart-product",
                    onClick: i,
                    detail: r.createElement("div", {
                        className: l.default.actions
                    }, r.createElement(o.default, {
                        quantity: e.quantity,
                        onChange: C
                    }), r.createElement("div", {
                        className: l.default.deleteIcon
                    }, r.createElement(c.default, {
                        onClick: g
                    }))),
                    className: l.default.cartListItem
                })
            };
            var r = i(a(2784)),
                n = a(93774),
                l = s(a(53270)),
                o = s(a(56835)),
                d = s(a(96066)),
                u = i(a(37356)),
                c = s(a(85552)),
                h = s(a(91581)),
                p = s(a(17957)),
                f = a(49080),
                m = s(a(92209)),
                v = a(40263)
        },
        56835: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return r.createElement("div", {
                    className: l.default.select
                }, r.createElement("select", {
                    onClick: function(e) {
                        e.preventDefault(), e.stopPropagation()
                    },
                    value: e.quantity,
                    onChange: function(t) {
                        var a = t.target;
                        a instanceof HTMLSelectElement && e.onChange(parseInt(a.value, 10))
                    }
                }, function() {
                    for (var e = [], t = 1; t <= n.MAX_QUANTITY; t++) e.push(r.createElement("option", {
                        key: t,
                        value: t
                    }, t));
                    return e
                }()))
            };
            var r = i(a(2784)),
                n = a(69160),
                l = s(a(41163))
        },
        85552: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return r.createElement(o.default, {
                    "aria-label": l.default.t(1131),
                    name: "delete",
                    title: l.default.t(1131),
                    className: n.default.deleteIcon,
                    onClick: e.onClick
                })
            };
            var r = i(a(2784)),
                n = s(a(60075)),
                l = s(a(17957)),
                o = s(a(22948))
        },
        26583: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(32960)),
                l = s(a(96066)),
                o = s(a(19899)),
                d = s(a(19822));
            t.default = ({
                title: e,
                icon: t,
                t: a
            }) => {
                var s = null != a ? o.default.relativeDateAndTimeStr(a) : "-",
                    i = r.createElement("div", {
                        className: d.default.title,
                        "data-a8n": n.default.key("msg-info-title")
                    }, t, e);
                return r.createElement(l.default, {
                    primary: i,
                    secondary: s,
                    theme: "plain",
                    idle: !0
                })
            }
        },
        35327: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(73549)),
                l = s(a(19899)),
                o = s(a(46478)),
                d = s(a(91581)),
                u = s(a(48102)),
                c = s(a(40207));
            class h extends r.PureComponent {
                render() {
                    var e, {
                            contact: t,
                            msgInfoParticipant: a
                        } = this.props,
                        s = r.createElement(o.default, {
                            id: t.id
                        }),
                        i = l.default.relativeDateAndTimeStr(a.t),
                        c = r.createElement("span", {
                            title: i
                        }, i);
                    return !t.name && t.notifyName && (e = r.createElement(d.default, {
                        className: u.default.notifyName,
                        direction: "auto",
                        text: t.notifyName
                    })), r.createElement(n.default, {
                        contextEnabled: () => !1,
                        image: s,
                        primary: r.createElement(d.default, {
                            direction: "auto",
                            text: t.formattedName,
                            titlify: !0,
                            ellipsify: !0
                        }),
                        secondary: c,
                        secondaryDetail: e,
                        style: {
                            cursor: "auto"
                        },
                        theme: "drawer-list",
                        idle: !0
                    })
                }
            }
            h.CONCERNS = {
                msgInfoParticipant: ["t"],
                contact: ["id", "name", "formattedName", "notifyName"]
            };
            var p = (0, c.default)(h, h.CONCERNS);
            t.default = p
        },
        57950: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(17957)),
                l = s(a(87620)),
                o = s(a(40207)),
                d = s(a(82631)),
                u = a(40263);
            class c extends r.PureComponent {
                render() {
                    var {
                        numTimesForwarded: e,
                        isFrequentlyForwarded: t
                    } = this.props.msg;
                    if (e <= 0 || t) return null;
                    var a = r.createElement(d.default, {
                            name: "forwarded",
                            display: "inline",
                            className: l.default.icon
                        }),
                        s = n.default.t(670, {
                            count: e,
                            _plural: e
                        });
                    return r.createElement("div", {
                        className: l.default.title
                    }, a, r.createElement(u.TextSpan, {
                        theme: "title",
                        className: l.default.text
                    }, s))
                }
            }
            c.CONCERNS = {
                msg: ["numTimesForwarded", "isFrequentlyForwarded"]
            };
            var h = (0, o.default)(c, c.CONCERNS);
            t.default = h
        },
        23069: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(44572)),
                l = i(a(13886)),
                o = s(a(43334)),
                d = s(a(50935)),
                u = i(a(65219)),
                c = s(a(21009)),
                h = i(a(35598)),
                p = s(a(44343)),
                f = s(a(17957)),
                m = s(a(73073)),
                v = s(a(73664));
            class _ extends r.PureComponent {
                constructor(...e) {
                    super(...e), this.selection = new v.default([], (e => e.id.toString())), this._getSelectionList = () => {
                        var {
                            contacts: e,
                            frequentContacts: t
                        } = this.props, a = [], s = [];
                        return e.forEach((e => {
                            if (e.isGroup) {
                                var t = o.default.get(e.id);
                                t && s.push(t)
                            } else a.push(e)
                        })), (t || []).concat(a).concat(s)
                    }, this.onFocusGain = e => {
                        e.target === this.refList && (this.selection.index < 0 ? this.focusFirst() : this.selection.reset(!0))
                    }, this.focusFirst = () => {
                        this.selection.setFirst(!0)
                    }, this._onNextContact = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.setNext(!0)
                    }, this._onPrevContact = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.prev() > -1 ? this.selection.setPrev(!0) : (this.selection.unset(), this.props.onFocusSearch(e))
                    }, this.setRefHotKeys = e => {
                        this.refList = e
                    }, this._renderContact = (e, t) => {
                        var a;
                        return e.isBlocked() && (a = f.default.t(513)), r.createElement(u.default, {
                            active: this.selection,
                            contact: e,
                            onClick: this.props.onClick,
                            secondary: a,
                            frequent: t,
                            waitIdle: !0
                        })
                    }, this.renderItem = e => {
                        switch (e.type) {
                            case 0:
                                return r.createElement(m.default, {
                                    key: "frequent-contacts-header",
                                    header: f.default.t(1565)
                                });
                            case 3:
                                var {
                                    data: t,
                                    frequent: a
                                } = e;
                                return this._renderChat(t, a);
                            case 2:
                                var {
                                    data: s,
                                    frequent: i
                                } = e;
                                return this._renderContact(s, i);
                            case 1:
                                var {
                                    data: l,
                                    separator: o
                                } = e;
                                return r.createElement("div", {
                                    className: c.default.header
                                }, o ? r.createElement(n.default, {
                                    key: "separator-".concat(l)
                                }) : null, r.createElement(m.default, {
                                    header: l
                                }));
                            default:
                                throw new h.UnknownDataError(e)
                        }
                    }
                }
                _renderChat(e, t) {
                    return r.createElement(l.default, {
                        active: this.selection,
                        chat: e,
                        mode: l.Mode.INFO,
                        noContext: !0,
                        onClick: this.props.onClick,
                        frequent: t
                    })
                }
                _getFrequentContactsData(e) {
                    var t = [];
                    return e.forEach((e => {
                        var a = this._getContactDataItem(e, !0);
                        a && t.push(a)
                    })), t
                }
                _getContactDataItem(e, t) {
                    var a = (t ? u.FREQUENT_PREFIX : "") + e.id.toString();
                    if (e.isGroup) {
                        var s = o.default.get(e.id);
                        return s ? {
                            itemKey: a,
                            data: s,
                            type: 3,
                            frequent: t
                        } : null
                    }
                    return {
                        itemKey: a,
                        data: e,
                        type: 2,
                        frequent: t
                    }
                }
                getData() {
                    var {
                        frequentContacts: e
                    } = this.props, t = [], a = [], s = [];
                    e && e.length && (t.push({
                        itemKey: "frequent-contacts-header",
                        type: 0
                    }), t.push(...this._getFrequentContactsData(e))), this.props.contacts.forEach((e => {
                        e.isGroup ? s.push(e) : a.push(e)
                    }));
                    var i = this._getDataFromContacts(a),
                        r = this._getDataFromContacts(s);
                    if (this.props.showPersonGroupDivisionHeader && i.length > 0) {
                        var n = f.default.t(1535);
                        t.push({
                            itemKey: "header-".concat(n),
                            data: n,
                            separator: !0,
                            type: 1
                        })
                    }
                    if (t.push(...i), this.props.showPersonGroupDivisionHeader && r.length > 0) {
                        var l = f.default.t(1639);
                        t.push({
                            itemKey: "header-".concat(l),
                            data: l,
                            separator: !0,
                            type: 1
                        })
                    }
                    return t.push(...r), t
                }
                _getDataFromContacts(e) {
                    if (0 === e.length) return [];
                    for (var t = e[0].isGroup ? "group" : "contact", a = [], s = e.length > 10, i = "XXX", r = 0; r < e.length; r++) {
                        var n = e[r];
                        if (s && n.header) {
                            var l = n.header;
                            if (l !== i) {
                                var o = r < e.length - 1 && l !== e[r + 1].header;
                                a.push({
                                    itemKey: "header-".concat(t, "-").concat(l),
                                    data: l,
                                    separator: o,
                                    type: 1
                                }), i = l
                            }
                        }
                        var d = this._getContactDataItem(n);
                        d && a.push(d)
                    }
                    return a
                }
                render() {
                    this.selection.init(this._getSelectionList());
                    var e = {
                        down: this._onNextContact,
                        up: this._onPrevContact
                    };
                    return r.createElement(p.default, {
                        onRef: this.setRefHotKeys,
                        handlers: e,
                        onFocus: this.onFocusGain,
                        "data-tab": d.default.TAB_ORDERS.CHAT_CONTACT_LIST
                    }, r.createElement(h.default, {
                        data: this.getData(),
                        renderItem: this.renderItem,
                        flatListController: this.props.flatListController,
                        direction: "vertical"
                    }))
                }
            }
            t.default = _
        },
        84845: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(16760)),
                n = s(a(2784)),
                l = s(a(65219)),
                o = i(a(44343)),
                d = i(a(17957)),
                u = i(a(73664));
            class c extends n.PureComponent {
                constructor(e) {
                    super(e), this.focusLast = () => {
                        this.props.contacts && this.props.contacts.length && this.selection.setLast(!0)
                    }, this._focusPrev = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.prev() > -1 && this.selection.setPrev(!0)
                    }, this._focusNext = e => {
                        e.preventDefault(), e.stopPropagation();
                        var {
                            onFocusSearch: t
                        } = this.props, a = this.selection.next();
                        this.selection.index === a ? (this.selection.unset(), t && t(e)) : this.selection.setNext(!0)
                    }, this._deleteContact = e => {
                        e.preventDefault(), e.stopPropagation();
                        var {
                            onDelete: t
                        } = this.props, a = this.selection.getVal();
                        if (a) {
                            var s = this.props.contacts.find(a);
                            s && t && t(e, s)
                        }
                    }, this.onParticipantClick = (e, t) => {
                        this.selection.setVal(t)
                    }, this.selection = new u.default(e.contacts, (e => e.id))
                }
                componentDidUpdate() {
                    this.selection.init(this.props.contacts, !0)
                }
                render() {
                    var e = this.props.contacts;
                    if (!e) return null;
                    var t = e.length ? (0, r.default)(e, (e => n.createElement(l.default, {
                            contact: e,
                            active: this.selection,
                            onDelete: this.props.onDelete,
                            onClick: this.onParticipantClick,
                            type: l.Type.SMALL,
                            key: e.id.toString(),
                            theme: this.props.theme,
                            waitIdle: !0
                        }))) : null,
                        a = {
                            up: this._focusPrev,
                            down: this._focusNext
                        };
                    this.props.onDelete && (a[d.default.LR("left", "right")] = this._focusPrev, a[d.default.LR("right", "left")] = this._focusNext, a.backspace = this._deleteContact);
                    var s = n.createElement("ul", null, t);
                    return n.createElement(o.default, {
                        handlers: a
                    }, s)
                }
            }
            t.default = c
        },
        92569: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    ids: t,
                    size: a,
                    onClick: s,
                    showCount: i,
                    square: d,
                    border: u
                } = e, c = t.length;
                if (0 === c) return null;
                if (1 === c) return n.createElement(o.default, {
                    id: t[0],
                    size: 40,
                    onClick: s,
                    border: u
                });
                var h = t.slice(0, 4).map(((e, t) => n.createElement("div", {
                        key: "avatar-combo-image-".concat(t),
                        className: (0, r.default)(l.default.avatar, {
                            [l.default.first]: 0 === t,
                            [l.default.second]: 1 === t,
                            [l.default.third]: 2 === t,
                            [l.default.fourth]: 3 === t
                        })
                    }, n.createElement(o.default, {
                        id: e,
                        size: a,
                        square: !0
                    })))),
                    p = (0, r.default)(l.default.container, {
                        [l.default.square]: d,
                        [l.default.border]: u
                    }, {
                        [l.default.two]: 2 === c,
                        [l.default.three]: 3 === c,
                        [l.default.four]: c >= 4
                    }),
                    f = (0, o.getSize)(a),
                    m = {
                        height: f,
                        width: f,
                        cursor: s ? "pointer" : void 0
                    },
                    v = i ? n.createElement("div", {
                        className: l.default.count,
                        style: m
                    }, t.length) : null;
                return n.createElement("div", {
                    className: p,
                    style: m,
                    onClick: s
                }, h, v)
            };
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(53999)),
                o = s(a(46478))
        },
        95727: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(32960)),
                l = s(a(89306));
            class o extends r.Component {
                render() {
                    return r.createElement("div", {
                        className: l.default.overlay,
                        key: "avatar-overlay"
                    }, r.createElement("div", {
                        className: l.default.icon
                    }, this.props.icon), r.createElement("div", {
                        "data-a8n": n.default.key("avatar-text"),
                        className: l.default.text
                    }, this.props.text))
                }
            }
            t.default = o
        },
        2167: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    onClick: t,
                    className: a,
                    label: s,
                    prefixIcon: i,
                    postfixIcon: u
                } = e, c = (0, r.default)(l.default.icon, {
                    [l.default.paddedIcon]: "padded-svg" === e.iconTheme
                });
                return n.createElement(d.default, {
                    className: (0, r.default)(a, l.default.container, {
                        [l.default.hasPrefixIcon]: null != i,
                        [l.default.hasPostfixIcon]: null != u
                    }),
                    onClick: t,
                    "aria-label": e["aria-label"]
                }, i && n.createElement(o.default, {
                    name: i,
                    className: (0, r.default)(c, l.default.prefixIcon)
                }), n.createElement("div", {
                    className: l.default.content
                }, s), u && n.createElement(o.default, {
                    name: u,
                    className: c
                }))
            };
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(66650)),
                o = i(a(82631)),
                d = i(a(5174))
        },
        83994: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = i(a(16760)),
                l = i(a(72779)),
                o = s(a(2784)),
                d = i(a(50935)),
                u = a(62436),
                c = i(a(38147)),
                h = i(a(6660)),
                p = i(a(44343)),
                f = i(a(64002)),
                m = i(a(17957)),
                v = i(a(61941)),
                _ = i(a(6155)),
                E = i(a(73664)),
                g = i(a(2825)),
                C = i(a(67134)),
                S = i(a(5174));

            function I() {
                var e = (0, r.default)(["Assertion failed!"]);
                return I = function() {
                    return e
                }, e
            }
            class y extends o.PureComponent {
                constructor(...e) {
                    super(...e), this.state = {}, this._setRefBody = e => {
                        this._refBody = e
                    }, this._refImages = new Map, this.setRefImage = (e, t) => {
                        t ? this._refImages.set(e, t) : this._refImages.delete(e)
                    }, this._setImageRefCache = new _.default(this.setRefImage), this.selection = new E.default(this.props.thumbnails, (e => e.id)), this._handleHotKeysRef = e => {
                        this._refHotKeys = e
                    }, this.handleMouseDown = e => {
                        e.preventDefault(), e.stopPropagation()
                    }, this.handleClick = e => {
                        var t = e.target;
                        this.props.onImageClick && 1 === t.nodeType && "IMG" === t.tagName && this.props.onImageClick(t.src)
                    }, this.handleEnter = () => {
                        var e = this.selection.getVal();
                        e || (__LOG__(4, void 0, new Error, !0)(I()), SEND_LOGS("No value selected, but enter clicked")), this.props.onImageClick && e && this.props.onImageClick(e.thumbUrl)
                    }, this._requestMoreImagesIfNeeded = () => {
                        if (!this.props.isLoadingMore && this.props.canLoadMore && this.props.onRequestMoreImages) {
                            if (!this._refBody) throw new Error("Requesting more images when body not rendered");
                            this._refBody.scrollTop + d.default.SCROLL_FUDGE > this._refBody.scrollHeight - this._refBody.clientHeight && this.props.onRequestMoreImages()
                        }
                    }, this.handleScroll = this.props.throttle(this._requestMoreImagesIfNeeded, 100), this._selectPrev = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.setPrev(!1), this._updateSelected(!0, !0)
                    }, this.selectNext = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.setNext(!1), this._updateSelected(!0, !0)
                    }, this._selectPrevRow = e => {
                        if (e.preventDefault(), e.stopPropagation(), 0 === this.selection.index && this.props.onFocusPrev) this.props.onFocusPrev();
                        else {
                            var t = Math.max(this.selection.index - 3, 0);
                            this.selection.set(t, !1, !1), this._updateSelected(!0, !0)
                        }
                    }, this._selectNextRow = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.set(this.selection.index + 3, !1, !1), this._updateSelected(!0, !0)
                    }, this._handleFocus = e => {
                        e.stopPropagation(), e.preventDefault(), (null == this.selection.index || this.selection.index < 0) && this.selection.setFirst(!1), this._updateSelected(!0, !1);
                        var t = (0, v.default)(this._refImages.get("".concat(this.selection.index)), "this._refImages.get(`${this.selection.index}`)").getElementsByClassName(f.default.imageGalleryItemOverlay);
                        if (1 !== t.length) throw new Error("Unexpected number of overlay elements ".concat(t.length));
                        c.default.maybeIndicateFocus(t[0], f.default.focusAnimation)
                    }, this.handleRequestDismiss = () => {
                        this.selection.unset(), this.setState({
                            selectedImage: void 0
                        })
                    }
                }
                componentDidMount() {
                    this._updateSelected()
                }
                componentDidUpdate() {
                    this._requestMoreImagesIfNeeded(), this.selection.init(this.props.thumbnails, !1), this._updateSelected()
                }
                focus() {
                    this._refHotKeys && this._refHotKeys.focus()
                }
                _updateSelected(e = !1, t = !1) {
                    var a = this.selection.getVal();
                    if (a && this.state.selectedImage !== a && (this.setState({
                            selectedImage: a
                        }), this.selection.index > -1)) {
                        var s = this._refImages.get("".concat(this.selection.index));
                        h.default.focus(s), t && s && (0, u.scrollIntoViewIfNeeded)(s, !1)
                    }
                }
                render() {
                    var e = {
                            down: this._selectNextRow,
                            enter: this.handleEnter,
                            left: this._selectPrev,
                            right: this.selectNext,
                            up: this._selectPrevRow
                        },
                        t = (0, n.default)(this.props.thumbnails, (({
                            id: e,
                            name: t,
                            thumbUrl: a
                        }, s) => {
                            var i = !!this.state.selectedImage && this.state.selectedImage.id === e,
                                r = (0, l.default)(f.default.imageGalleryItem, {
                                    [f.default.selected]: i
                                }),
                                n = o.createElement("div", {
                                    className: f.default.imageGalleryItemOverlay
                                });
                            return o.createElement("div", {
                                key: e,
                                ref: this._setImageRefCache.getRefSetter("".concat(s)),
                                className: r,
                                tabIndex: -1
                            }, n, o.createElement(S.default, {
                                onClick: this.handleClick
                            }, o.createElement("img", {
                                alt: m.default.t(25, {
                                    name: t
                                }),
                                className: f.default.imageGalleryItemImage,
                                src: a
                            })))
                        })),
                        a = this.props.isLoadingMore ? o.createElement("div", {
                            tabIndex: -1,
                            className: f.default.imageGalleryFooter
                        }, o.createElement(g.default, {
                            stroke: 6,
                            size: 24
                        })) : null;
                    return o.createElement(p.default, {
                        className: f.default.imageGallery,
                        "data-tab": d.default.TAB_ORDERS.CHAT_IMAGE_GALLERY,
                        handlers: e,
                        onFocus: this._handleFocus,
                        onMouseDown: this.handleMouseDown,
                        onRef: this._handleHotKeysRef
                    }, o.createElement("div", {
                        ref: this._setRefBody,
                        className: f.default.imageGalleryList,
                        onScroll: this.handleScroll
                    }, t, o.createElement("div", {
                        tabIndex: -1,
                        className: f.default.imageGalleryItemSpacer
                    }), o.createElement("div", {
                        tabIndex: -1,
                        className: f.default.imageGalleryItemSpacer
                    }), o.createElement("div", {
                        tabIndex: -1,
                        className: f.default.imageGalleryItemSpacer
                    }), a))
                }
            }
            y.defaultProps = {
                thumbnails: []
            };
            var M = (0, C.default)(y);
            t.default = class extends M {
                focus() {
                    this.getComponent().focus()
                }
            }
        },
        2446: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(79711)),
                o = i(a(9386)),
                d = a(14457),
                u = i(a(82512)),
                c = a(40789),
                h = i(a(44343)),
                p = i(a(17957)),
                f = i(a(7742)),
                m = i(a(79674)),
                v = a(57817),
                _ = i(a(82631)),
                E = i(a(17693)),
                g = i(a(63498)),
                C = a(86145),
                S = i(a(74824));
            class I extends n.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        active: !1,
                        emojiPicker: null
                    }, this._refEmojiPanel = n.createRef(), this.onEmojiPicker = e => {
                        e && (e.preventDefault(), e.stopPropagation());
                        var t = n.createElement(u.default, {
                            ref: this._refEmojiPanel,
                            onEmoji: this.onEmoji,
                            onFocusNext: this.restoreFocus,
                            onFocusPrev: this.restoreFocus
                        });
                        this.setState({
                            emojiPicker: {
                                menu: t,
                                dirY: d.DirY.TOP,
                                type: "emoji_picker",
                                anchor: e.target
                            }
                        }), this.restoreFocus()
                    }, this.onEmojiPickerClose = () => {
                        this.setState({
                            emojiPicker: null
                        })
                    }, this.onRestoreEmojiPickerFocus = () => {
                        var e;
                        null === (e = this._refEmojiPanel.current) || void 0 === e || e.restoreFocus()
                    }, this.onEmoji = e => {
                        var t = this.refInput;
                        t && (t.focus(!1), t.replaceSelection(e)), this.onEmojiPickerClose()
                    }, this.setRefInput = e => {
                        this.refInput = e
                    }, this.onSelectionChange = e => {
                        this.selection = e
                    }, this.restoreFocus = () => {
                        this.refInput && this.refInput.focus()
                    }, this.onBlur = e => {
                        this.state.active && this.setState({
                            active: !1
                        }), this.props.onBlur && this.props.onBlur(e)
                    }, this.onFocus = e => {
                        e.stopPropagation(), this.state.active || this.setState({
                            active: !0
                        }), this.props.onFocus && this.props.onFocus(e)
                    }, this.onReset = () => {
                        this.refInput && this.refInput.reset()
                    }
                }
                componentDidMount() {
                    this.props.focusOnMount && this.restoreFocus()
                }
                render() {
                    var e, t = this.props.maxLength,
                        a = (0, C.numCodepoints)(this.props.value || ""),
                        s = (0, r.default)(m.default.textInput, {
                            [m.default.noPlaceholder]: !this.props.placeholder,
                            [m.default.active]: !0
                        }),
                        i = (0, r.default)(m.default.labelText, {
                            [m.default.float]: !!this.props.value
                        }),
                        l = this.props.supportsEmoji ? n.createElement("button", {
                            className: m.default.inputEmoji,
                            onClick: this.onEmojiPicker
                        }, n.createElement(_.default, {
                            "aria-label": p.default.t(22),
                            name: "emoji-input"
                        })) : void 0,
                        {
                            value: o
                        } = this.props;
                    e = o && "" !== o ? n.createElement("div", {
                        role: "button",
                        className: m.default.clearInput,
                        onClick: this.onReset
                    }, n.createElement(_.default, {
                        name: "x-alt"
                    })) : null;
                    var d, u = this.props.showRemaining ? n.createElement("div", {
                        className: (0, r.default)(m.default.buttonContainer, m.default.charCounter, {
                            [m.default.charCounterWithClearBtn]: !!e
                        })
                    }, n.createElement("div", {
                        className: m.default.charCounter
                    }, t - a < 50 ? p.default.n(t - a) : null)) : null;
                    return this.state.emojiPicker && (d = n.createElement(E.default, {
                        displayName: "EmojiPicker",
                        escapable: !0,
                        popable: !0,
                        requestDismiss: this.onEmojiPickerClose,
                        requestFocus: this.onRestoreEmojiPickerFocus
                    }, n.createElement(g.default, {
                        contextMenu: this.state.emojiPicker
                    }))), n.createElement(h.default, {
                        className: s,
                        onFocus: this.restoreFocus
                    }, n.createElement("span", {
                        className: i
                    }, this.props.placeholder), n.createElement("div", {
                        className: m.default.spacer
                    }), n.createElement("div", {
                        className: m.default.suggestionsPositioner
                    }, n.createElement("div", {
                        className: m.default.suggestionsContainer
                    }, n.createElement(f.default.MentionSuggestions, {
                        chat: this.props.chat,
                        theme: v.ThemeOptions.MEDIA_CAPTION
                    }), n.createElement(f.default.EmojiSuggestions, {
                        chat: this.props.chat,
                        theme: c.ThemeOptions.MEDIA_CAPTION
                    }))), n.createElement("div", {
                        className: (0, r.default)(m.default.wrapper, {
                            [m.default.textActive]: this.state.active
                        })
                    }, n.createElement(f.default, {
                        ref: this.setRefInput,
                        initialValue: this.props.value,
                        initialSelection: this.selection,
                        readOnly: !1,
                        spellCheck: this.props.spellCheck,
                        multiline: this.props.multiline,
                        maxLength: this.props.maxLength,
                        onEnter: this.props.onEnter,
                        onMaxPasteExceeded: this.props.onMaxPasteExceeded,
                        onFiles: this.props.onFiles,
                        onChange: this.props.onChange,
                        onSelect: this.onSelectionChange,
                        theme: "media-caption"
                    }), n.createElement("div", {
                        className: m.default.inputControls
                    }, n.createElement(S.default, {
                        transitionName: "pop",
                        component: "div",
                        className: m.default.buttonContainer
                    }, e, l), u)), d)
                }
            }
            t.default = I, I.defaultProps = {
                maxLength: 25,
                onMaxPasteExceeded: () => {
                    l.default.openModal(n.createElement(o.default, {
                        title: p.default.t(397),
                        onOK: () => {
                            l.default.closeModal()
                        },
                        okText: p.default.t(1680)
                    }, p.default.t(396)))
                }
            }
        },
        16981: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(50935)),
                l = s(a(47106)),
                o = s(a(48695)),
                d = s(a(40207));
            class u extends r.Component {
                constructor(...e) {
                    super(...e), this._setRefContainer = e => {
                        this._refContainer = e
                    }
                }
                getContainer() {
                    return this._refContainer
                }
                render() {
                    var {
                        chatPreference: e
                    } = this.props, {
                        wallpaperColor: t,
                        showDoodle: a
                    } = e, s = {};
                    return t !== n.default.DEFAULT_CHAT_WALLPAPER && (s = {
                        backgroundColor: t
                    }), r.createElement("div", {
                        className: o.default.container,
                        ref: this._setRefContainer
                    }, r.createElement("div", {
                        className: o.default.body,
                        style: s
                    }, r.createElement(l.default, {
                        wallpaperColor: t,
                        showDoodle: a
                    }), this.props.children))
                }
            }
            u.CONCERNS = {
                chatPreference: ["wallpaperColor", "showDoodle"]
            };
            var c = (0, d.default)(u, u.CONCERNS);
            t.default = class extends c {
                get container() {
                    return this.getComponent().getContainer()
                }
            }
        },
        87881: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = i(a(90882)),
                l = s(a(2784)),
                o = i(a(95727)),
                d = i(a(72174)),
                u = i(a(79711)),
                c = i(a(9386)),
                h = i(a(50935)),
                p = i(a(7470)),
                f = i(a(28515)),
                m = i(a(71201)),
                v = i(a(56027)),
                _ = a(99888),
                E = i(a(68476)),
                g = i(a(98294)),
                C = i(a(48189)),
                S = i(a(53632)),
                I = i(a(17957)),
                y = s(a(23765)),
                M = s(a(41967)),
                T = i(a(88352)),
                P = i(a(29516)),
                L = i(a(96183)),
                b = i(a(53865)),
                w = i(a(82631)),
                N = i(a(36457)),
                O = i(a(77626)),
                D = i(a(17693)),
                R = i(a(63498)),
                k = i(a(74824));

            function A() {
                var e = (0, r.default)(["PhotoPicker:onImageReceived failed to load image: ", ""]);
                return A = function() {
                    return e
                }, e
            }
            class x extends l.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        img: this.props.startImage,
                        hover: !1,
                        imageSize: null
                    }, this._setRefImageContainer = e => {
                        this._refImageContainer = e
                    }, this._setRefImageInput = e => {
                        this._refImageInput = e
                    }, this._onUpload = () => {
                        var e = this._refImageInput;
                        if (e) return e.click(), !0
                    }, this._removeImage = () => {
                        this.props.onImageSet(), u.default.closeModal()
                    }, this._onRemove = () => {
                        var e = this.props.type === L.default.GROUP ? I.default.t(1158) : I.default.t(1161);
                        u.default.openModal(l.createElement(c.default, {
                            onOK: this._removeImage,
                            okText: I.default.t(1157),
                            onCancel: () => u.default.closeModal(),
                            cancelText: I.default.t(1518)
                        }, e))
                    }, this._onView = () => {
                        var e = this._refImageContainer,
                            {
                                id: t,
                                attachToChat: a
                            } = this.props;
                        if (e && t) {
                            var s = p.default.assertGet(t),
                                i = {
                                    transition: "profile-viewer"
                                };
                            a && (i.uim = this.props.uim), u.default.openModalMedia(l.createElement(b.default, {
                                contact: s,
                                profilePicThumb: s.getProfilePicThumb(),
                                animateBorderRadius: !0,
                                getZoomNode: t => {
                                    t(e)
                                }
                            }), i)
                        }
                    }, this.onPaste = e => {
                        if (this.state.contextMenu) {
                            var t = new f.default(e.clipboardData),
                                a = (0, n.default)(t.getFiles(), (e => "image" === (0, _.typeFromMimetype)(e.type)));
                            if (a.length) {
                                e.preventDefault(), e.stopPropagation(), this.closeContextMenu();
                                var s = a[0];
                                this._onImagePick(s)
                            }
                        }
                    }, this.onImageSelected = e => {
                        this.closeContextMenu();
                        var t = e.target.files[0];
                        if (!t) return !1;
                        this._onImagePick(t), e.target.value = ""
                    }, this._onImageReceived = (e, t) => {
                        e ? y.loadImage(e).then((() => {
                            this.setState({
                                img: e
                            }), this.props.onImageSet(e, t)
                        })).catch((e => {
                            __LOG__(3)(A(), String(e));
                            var t = this.props.type === L.default.GROUP ? I.default.t(110) : I.default.t(179);
                            u.default.openModal(l.createElement(c.default, {
                                onOK: () => u.default.closeModal()
                            }, t))
                        })) : this.setState({
                            img: null,
                            imageSize: null
                        })
                    }, this.onSearch = () => {
                        u.default.openModal(l.createElement(M.default, {
                            type: M.BoxModalType
                        }, l.createElement(C.default, {
                            onFinished: this._onImageReceived
                        })))
                    }, this._onImagePick = e => {
                        var t = URL.createObjectURL(e);
                        y.loadImage(t).then((t => {
                            t && (t.width < h.default.MIN_PIC_SIDE || t.height < h.default.MIN_PIC_SIDE) ? u.default.openModal(l.createElement(c.default, {
                                onOK: () => u.default.closeModal()
                            }, I.default.t(1149, {
                                size: h.default.MIN_PIC_SIDE,
                                _plural: h.default.MIN_PIC_SIDE
                            }))) : u.default.openModal(l.createElement(M.default, {
                                type: M.BoxModalType
                            }, l.createElement(v.default, {
                                img: e,
                                onFinished: this._onImageReceived,
                                onRetake: this._onUpload
                            })))
                        })).catch((() => {
                            var e = this.props.type === L.default.GROUP ? I.default.t(110) : I.default.t(179);
                            u.default.openModal(l.createElement(c.default, {
                                onOK: () => u.default.closeModal()
                            }, e))
                        })).finally((() => {
                            URL.revokeObjectURL(t)
                        }))
                    }, this.onImageClick = e => {
                        if (this.props.readOnly) this.state.img && this._onView();
                        else {
                            e.stopPropagation(), e.preventDefault();
                            var t = [];
                            this.props.id && this.state.img && t.push(l.createElement(m.default, {
                                a8n: "mi-view-photo",
                                key: "view",
                                action: this._onView
                            }, I.default.t(1408))), E.default && t.push(l.createElement(N.default, {
                                key: "take",
                                onImageTake: this._onImageReceived
                            })), t.push(l.createElement(m.default, {
                                a8n: "mi-upload-photo",
                                key: "upload",
                                action: this._onUpload
                            }, I.default.t(1366))), O.default.isElectron && this.props.type === L.default.GROUP && t.push(l.createElement(m.default, {
                                a8n: "mi-search-photo",
                                key: "search",
                                action: this.onSearch
                            }, I.default.t(1739))), this.state.img && t.push(l.createElement(m.default, {
                                a8n: "mi-remove-photo",
                                key: "remove",
                                action: this._onRemove
                            }, I.default.t(1160))), e.persist(), this.setState({
                                contextMenu: {
                                    menu: t,
                                    event: e
                                }
                            })
                        }
                    }, this.closeContextMenu = () => {
                        this.setState({
                            contextMenu: null
                        })
                    }, this.onMouseOver = () => {
                        this.state.hover || this.setState({
                            hover: !0
                        })
                    }, this.onMouseEnter = () => {
                        this.state.hover || this.setState({
                            hover: !0
                        })
                    }, this.onMouseLeave = () => {
                        this.state.hover && this.setState({
                            hover: !1
                        })
                    }, this.onLoad = e => {
                        var t = e.target.clientWidth,
                            a = e.target.clientHeight;
                        this.setState({
                            imageSize: {
                                width: t,
                                height: a
                            }
                        })
                    }
                }
                static getDerivedStateFromProps(e) {
                    return e.startImage ? {
                        img: e.startImage
                    } : {
                        img: e.startImage,
                        imageSize: null
                    }
                }
                render() {
                    var e, t;
                    this.state.img && (e = l.createElement(T.default, {
                        type: "cover",
                        size: this.state.imageSize
                    }, l.createElement(S.default, {
                        src: this.state.img,
                        crossOrigin: !1,
                        style: {
                            height: "100%",
                            width: "100%"
                        },
                        onLoad: this.onLoad
                    }))), (this.props.pending || this.state.img && !this.state.imageSize) && (t = l.createElement(d.default, null));
                    var a = null;
                    if (!this.props.pending && !this.props.readOnly && (!this.state.img || this.state.imageSize) && (!this.state.img || this.state.contextMenu || this.state.hover)) {
                        var s = "";
                        switch (this.props.type) {
                            case L.default.GROUP:
                                s = this.state.img ? I.default.t(441) : I.default.t(206);
                                break;
                            case L.default.PROFILE:
                                s = this.state.img ? I.default.t(446) : I.default.t(213)
                        }
                        a = l.createElement(o.default, {
                            icon: l.createElement(w.default, {
                                name: "camera"
                            }),
                            text: s
                        })
                    }
                    var i, r, n = this.props.pending || !this.state.imageSize && this.state.img ? () => {} : this.onImageClick;
                    if (this.state.contextMenu && (i = l.createElement(D.default, {
                            displayName: "PhotoPickerContextMenu",
                            escapable: !0,
                            popable: !0,
                            requestDismiss: this.closeContextMenu
                        }, l.createElement(R.default, {
                            contextMenu: this.state.contextMenu
                        }))), this.props.pending || !this.state.img || this.state.img && !this.state.imageSize) {
                        var u = this.props.type === L.default.PROFILE ? "default-user" : "default-group";
                        r = l.createElement("div", {
                            className: P.default.defaultIcon
                        }, l.createElement(w.default, {
                            name: u
                        }))
                    }
                    return l.createElement("div", {
                        className: P.default.container
                    }, l.createElement("div", {
                        className: P.default.body,
                        onClick: n,
                        onMouseOver: this.onMouseOver,
                        onMouseEnter: this.onMouseEnter,
                        onMouseLeave: this.onMouseLeave,
                        onPaste: this.onPaste,
                        ref: this._setRefImageContainer,
                        dir: "ltr"
                    }, l.createElement("div", {
                        className: P.default.imageContainer
                    }, e, r), l.createElement(k.default, {
                        transitionName: "fade"
                    }, t, a)), l.createElement("input", {
                        ref: this._setRefImageInput,
                        type: "file",
                        accept: "image/gif,image/jpeg,image/jpg,image/png",
                        style: {
                            display: "none"
                        },
                        onChange: this.onImageSelected
                    }), i)
                }
            }
            var U = (0, g.default)(x);
            t.default = U
        },
        7742: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(a(67804)),
                r = s(a(37688)),
                n = s(a(40789)),
                l = s(a(20881)),
                o = s(a(81059)),
                d = s(a(55765)),
                u = s(a(57817)),
                c = s(a(40314)),
                h = new l.default,
                p = new i.default;
            class f extends((0, o.default)([r.default, p, h, d.default])) {}
            t.default = f, f.MentionSuggestions = (0, c.default)(u.default, {
                plugin: h
            }), f.EmojiSuggestions = (0, c.default)(n.default, {
                plugin: p
            })
        },
        48234: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(58527)),
                n = s(a(2784)),
                l = i(a(79711)),
                o = i(a(9386)),
                d = s(a(71311)),
                u = i(a(17957)),
                c = a(97e3),
                {
                    useState: h
                } = n;
            t.default = ({
                doSave: e,
                afterSave: t,
                isValid: a,
                children: s,
                modalConfig: i,
                onError: p,
                title: f,
                onCancel: m
            }) => {
                var [v, _] = h(c.EditType.EDITING), E = n.createElement(d.default, {
                    title: f,
                    type: d.DRAWER_HEADER_TYPE.POPUP,
                    onCancel: () => {
                        l.default.closeModal(), m && m()
                    }
                });
                return n.createElement(o.default, (0, r.default)({
                    children: s,
                    okText: u.default.t(1198),
                    type: "auto",
                    onOK: () => {
                        _(c.EditType.PENDING), e().then((() => {
                            _(c.EditType.DONE), t && t(), l.default.closeModal()
                        }), (e => {
                            _(c.EditType.ERROR), p && p(e)
                        }))
                    },
                    okSpinner: v === c.EditType.PENDING,
                    okDisabled: v === c.EditType.PENDING || !a,
                    title: E
                }, i))
            }
        },
        62193: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(72779)),
                l = s(a(44343)),
                o = s(a(7116)),
                {
                    useRef: d
                } = r,
                u = ({
                    tabConfigs: e,
                    selectedId: t,
                    onSelect: a,
                    tabClass: s,
                    className: i
                }) => {
                    var u = d(t),
                        c = d([]),
                        h = e.map((({
                            id: e
                        }) => e)),
                        p = h.length - 1;
                    return r.createElement(l.default, {
                        handlers: {
                            right: () => {
                                var e = h.indexOf(u.current),
                                    t = e === p ? 0 : e + 1,
                                    a = c.current[t];
                                a && a.focus()
                            },
                            left: () => {
                                var e = h.indexOf(u.current),
                                    t = 0 === e ? p : e - 1,
                                    a = c.current[t];
                                a && a.focus()
                            }
                        }
                    }, r.createElement("div", {
                        role: "tablist",
                        className: (0, n.default)(o.default.tabContainer, i)
                    }, e.map(((e, i) => (({
                        title: e,
                        id: i
                    }, l) => {
                        var d = i === t;
                        return r.createElement("button", {
                            role: "tab",
                            tabIndex: d ? 0 : -1,
                            "aria-selected": Boolean(d),
                            title: e,
                            className: (0, n.default)(o.default.tab, {
                                [o.default.selected]: d
                            }, s),
                            onClick: () => {
                                d || a(i)
                            },
                            onFocus: () => {
                                u.current = i
                            },
                            ref: e => c.current[l] = e,
                            key: e
                        }, e)
                    })(e, i)))))
                };
            t.default = u
        },
        36457: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(71201)),
                o = s(a(97473)),
                d = s(a(17957));
            class u extends r.Component {
                constructor(...e) {
                    super(...e), this.onCapture = () => {
                        n.default.openModal(r.createElement(o.default, {
                            onFinished: this.props.onImageTake
                        }))
                    }
                }
                render() {
                    return r.createElement(l.default, {
                        action: this.onCapture,
                        a8n: "mi-take-photo",
                        disabled: this.props.disabled
                    }, d.default.t(1316))
                }
            }
            t.default = u
        },
        95062: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = i(a(50935)),
                d = i(a(17957)),
                u = a(66615),
                c = i(a(19518));
            class h extends n.PureComponent {
                render() {
                    var e = o.default.VERSION_STR;
                    return n.createElement(u.SelectableDiv, {
                        "data-a8n": l.default.key("version"),
                        className: (0, r.default)(c.default.versionInfo, this.props.className),
                        selectable: !0
                    }, d.default.t(1388, {
                        version: ""
                    }), n.createElement("span", {
                        dir: "LTR"
                    }, e), null, null)
                }
            }
            t.default = h
        },
        81853: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(54073)),
                n = s(a(2784)),
                l = i(a(79711)),
                o = i(a(50935)),
                d = a(95595),
                u = i(a(20642)),
                c = i(a(40207)),
                h = i(a(77626)),
                p = s(a(12767)),
                f = (0, r.default)(((e, t) => {
                    (0, d.setVideoVolumeSettings)(e, t)
                }), 500);
            class m extends n.PureComponent {
                constructor(...e) {
                    super(...e), this.checkIteration = 0, this.checkForSuccessInterval = 0, this.hasCalledPlaying = !1, this.mediaBlobWasDownloadedBeforeMount = Boolean(this.props.mediaData.mediaBlob), this.refVideo = n.createRef(), this.onVolumeChange = () => {
                        var e = this.refVideo && this.refVideo.current;
                        e && f(e.volume, e.muted)
                    }, this.startCheckForSuccess = () => {
                        this.checkIteration = 0, this.checkForSuccessInterval || (this.checkForSuccessInterval = setInterval(this.checkForSuccess, 250))
                    }, this.clearCheckForSuccess = () => {
                        this.checkForSuccessInterval && (clearInterval(this.checkForSuccessInterval), this.checkIteration = 0, this.checkForSuccessInterval = 0)
                    }, this.checkForSuccess = () => {
                        if (p.default.state === p.STATE.CONNECTED) {
                            this.checkIteration++;
                            var e = this.refVideo && this.refVideo.current,
                                t = e && e.buffered;
                            t && t.length && t.end(0) > 0 ? this.onPlaying() : this.checkIteration > 240 && this.clearCheckForSuccess()
                        }
                    }, this.onPlayerError = () => {
                        this.clearCheckForSuccess()
                    }, this.onOtherPlaying = e => {
                        e !== this && this.pause()
                    }, this.pause = () => {
                        var e = this.refVideo && this.refVideo.current;
                        e && (e.paused || e.pause())
                    }, this.onPlaying = () => {
                        this.clearCheckForSuccess(), l.default.mediaPlaying(this)
                    }, this.onLoadedMetadata = e => {
                        this.setStartTime();
                        var {
                            onLoadedMetadata: t
                        } = this.props;
                        t && t(e)
                    }, this.setStartTime = () => {
                        var e = this.refVideo && this.refVideo.current;
                        null != this.props.startTime && 0 !== this.props.startTime && e && (e.currentTime = this.props.startTime)
                    }, this.onContextMenu = e => {
                        this.props.disableContextMenu && e.preventDefault()
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(l.default, "mediaPlaying", this.onOtherPlaying), this.props.listeners.add(l.default, "pttRecording", this.pause), this._updateVideoUserPrefs(), this.props.refVideo && this.props.refVideo(this.refVideo)
                }
                componentWillUnmount() {
                    f.flush(), this.clearCheckForSuccess(), this.pause()
                }
                componentDidUpdate(e) {
                    this._updateVideoUserPrefs(), e.startTime !== this.props.startTime && this.setStartTime(), this.props.refVideo && this.props.refVideo(this.refVideo)
                }
                _updateVideoUserPrefs() {
                    var e = this.refVideo && this.refVideo.current;
                    if (e) {
                        var t = (0, d.getVideoVolumeSettings)();
                        t && ("number" == typeof t.volume && (e.volume = t.volume), "boolean" == typeof t.muted && (e.muted = t.muted)), _() && this.props.autoPlay && this.startCheckForSuccess()
                    }
                }
                render() {
                    var e, t = this.props,
                        {
                            mediaData: a
                        } = t,
                        s = a.mediaBlob,
                        i = a.streamable && a.isStreamable();
                    if (!this.mediaBlobWasDownloadedBeforeMount && i || !s) {
                        if (!a.streamable || !a.isStreamable()) return null;
                        e = "".concat(o.default.VIDEO_STREAM_URL, "?key=").concat(this.props.msg.id.toString())
                    } else e = s.url();
                    var r = _() && !t.autoPlay ? this.startCheckForSuccess : void 0;
                    return n.createElement("video", {
                        ref: this.refVideo,
                        src: e,
                        poster: t.poster,
                        className: t.className,
                        controls: t.controls,
                        autoPlay: t.autoPlay,
                        onClick: t.onClick,
                        onDoubleClick: t.onDoubleClick,
                        onVolumeChange: this.onVolumeChange,
                        onLoadedMetadata: this.onLoadedMetadata,
                        onPlay: r,
                        onPlaying: this.onPlaying,
                        onError: this.clearCheckForSuccess,
                        onContextMenu: this.onContextMenu
                    }, t.children)
                }
            }
            m.CONCERNS = {
                msg: ["id"],
                mediaData: ["mediaBlob", "streamable"]
            };
            var v = (0, u.default)((0, c.default)(m, m.CONCERNS));

            function _() {
                return h.default.isGecko || h.default.isSafari
            }
            t.default = v
        },
        66681: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(43334)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = s(a(91581)),
                u = s(a(29505)),
                c = s(a(6660)),
                h = s(a(54123)),
                p = s(a(17957)),
                f = a(45515);
            class m extends u.default {
                constructor(...e) {
                    super(...e), this.filter = e => {
                        var t = e.groupMetadata;
                        return !(!e.isGroup || e.isGroup && !t.participants.iAmMember()) && (t.participants.get(this.props.contact.id) ? p.default.t(218) : !!t.participants.iAmAdmin() || p.default.t(465))
                    }, this._confirmAddToGroup = e => {
                        this.props.requestFocus && this.props.requestFocus(), this.push(r.createElement(o.default, {
                            cancelText: p.default.t(1518),
                            okText: p.default.t(207),
                            onOK: this._addToGroup.bind(null, e),
                            onCancel: this._pop
                        }, r.createElement(d.default, {
                            text: p.default.t(488, {
                                participant: this.props.contact.formattedName,
                                subject: e.contact.name
                            })
                        })))
                    }, this.requestFocus = () => {
                        if (this.refUIE) {
                            var e = this.refUIE.getNode();
                            e && !e.contains(document.activeElement) && c.default.focus(e)
                        }
                    }, this._addToGroup = e => {
                        (0, f.addParticipants)(e, [this.props.contact]).then((() => {
                            l.default.openChatFromUnread(e).then((t => {
                                t && l.default.focusChatTextInput(e)
                            }))
                        })).catch((() => {})), this.end()
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(h.default, {
                        chats: n.default.filter((e => e.isGroup)),
                        filter: this.filter,
                        onCancel: this._pop,
                        onGroup: this._confirmAddToGroup
                    }))
                }
            }
            t.default = m
        },
        84642: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(98874)),
                n = i(a(25291)),
                l = s(a(2784)),
                o = a(26360),
                d = i(a(48163)),
                u = i(a(79711)),
                c = i(a(29505)),
                h = a(47410),
                p = i(a(77626));
            class f extends c.default {
                constructor() {
                    super(...arguments), this.onCancel = () => {
                        this.props.onComplete && this.props.onComplete(!1), this._clearAttachMedia(), this.props.mediaCollection.mediaPickerStatsLogger.logCancel(), this.end()
                    }, this.onFailedMedias = e => {
                        var t = e.filter((e => e.isGif));
                        if (t.length > 0) {
                            var a = t.map((e => e.filename));
                            u.default.once("ui_idle", (() => {
                                u.default.pasteChatTextInput(this.props.chat, a.join(" "))
                            })), this.props.onComplete && this.props.onComplete(!1), this._clearAttachMedia(), this.props.mediaCollection.mediaPickerStatsLogger.logCancel(), this.end()
                        }
                    }, this._sendMediaWithMentions = (e, t) => {
                        var {
                            chat: a
                        } = this.props;
                        u.default.once("ui_idle", (() => {
                            e.forEach(((e, t) => {
                                var s = e.media,
                                    i = {};
                                if (0 === t && (i.quotedMsg = a.composeQuotedMsg, a.composeQuotedMsg = null), i.mentionedJidList = e.mentionedJidList, i.caption = s.caption, i.addEvenWhilePreparing = s.previewable && s.state === o.ATTACH_MEDIA_STATE.PROCESSING, this.props.initCaption && this.props.initCaption.ctwaContextLinkData) {
                                    var {
                                        ctwaContextLinkData: r,
                                        ctwaContext: n
                                    } = this.props.initCaption;
                                    i.ctwaContext = (0, h.prepareCtwaContextSend)(r, n)
                                }
                                s.sendToChat(a, i)
                            })), this._clearAttachMedia()
                        })), this.props.onComplete && this.props.onComplete(!0, t), this.props.mediaCollection.mediaPickerStatsLogger.logSend(), this.end()
                    }, this.setText = e => {
                        null != e && u.default.once("ui_idle", (() => {
                            u.default.pasteChatTextInput(this.props.chat, e)
                        })), this.end()
                    }, this._clearAttachMedia = () => {
                        this.props.chat && this.props.chat.setAttachMediaContents(null)
                    }, this.handleRequestDismiss = this.handleRequestDismiss.bind(this)
                }
                componentDidMount() {
                    u.default.closeContextMenu(), u.default.closeTooltip(), this.push(l.createElement(d.default, {
                        chat: this.props.chat,
                        onBack: this.onCancel,
                        initCaption: this.props.initCaption,
                        onSendMedia: (0, n.default)(this._sendMediaWithMentions),
                        onDropText: (0, n.default)(this.setText),
                        onFailedMedias: this.onFailedMedias,
                        mediaCollection: this.props.mediaCollection
                    }))
                }
                componentWillUnmount() {
                    p.default.isGecko ? (0, r.default)((() => u.default.focusChatTextInput(this.props.chat))) : u.default.focusChatTextInput(this.props.chat)
                }
                handleRequestDismiss(e) {
                    !1 === e && (this._clearAttachMedia(), this.props.mediaCollection.mediaPickerStatsLogger.logCancel()), super.handleRequestDismiss()
                }
            }
            t.default = f
        },
        60719: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(29505)),
                o = s(a(17957)),
                d = a(83974),
                u = s(a(5231)),
                c = a(24517);
            class h extends l.default {
                constructor(...e) {
                    super(...e), this.requestFocus = () => {
                        var e, t = null === (e = this.refUIE) || void 0 === e ? void 0 : e.getRef();
                        null != t && (t instanceof HTMLElement || "function" != typeof t.onFocusList || t.onFocusList())
                    }, this._sendProducts = e => {
                        var {
                            chat: t
                        } = this.props;
                        e.forEach(((e, a) => {
                            var s = 0 === a ? t.composeQuotedMsg : null;
                            t.sendProductMessage(e, s).then((() => {
                                (0, d.logProductMessageSent)({
                                    product: e,
                                    catalogSessionId: this.props.sessionId
                                })
                            }))
                        })), t.composeQuotedMsg = null, this.end()
                    }, this._shareCatalog = e => {
                        var {
                            chat: t
                        } = this.props, a = (0, c.createCatalogLink)(e.id.user), s = "".concat(o.default.t(1121), " ").concat(a);
                        n.default.pasteChatTextInput(t, s), (0, d.logSendCatalogClick)({
                            catalogOwnerWid: e.id,
                            catalogSessionId: this.props.sessionId
                        }), this.end()
                    }, this._pop = () => {
                        this.pop()
                    }, this._popNone = () => {
                        this.pop("none")
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(u.default, {
                        onCancel: this._pop,
                        onConfirm: this._sendProducts,
                        onShare: this._shareCatalog
                    }))
                }
            }
            var p = h;
            t.default = p
        },
        84834: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(58527)),
                n = s(a(2784)),
                l = i(a(29505)),
                o = i(a(17957)),
                d = s(a(51079)),
                u = i(a(17619)),
                c = i(a(72424)),
                h = i(a(44031));
            class p extends l.default {
                constructor(...e) {
                    super(...e), this._confirmSendContacts = e => {
                        this.push(n.createElement(h.default, {
                            contactList: e,
                            onSend: () => this._sendContacts(e),
                            onBack: this._popNone,
                            chat: this.props.chat
                        }), "none"), this.contacts = e
                    }, this._sendContacts = e => {
                        var {
                            chat: t
                        } = this.props, a = t.composeQuotedMsg, s = t.getComposeContents().ctwaContext || void 0;
                        (0, u.default)(e, t, a, s), t.composeQuotedMsg = null, this.props.onContactsSent(), this.end()
                    }, this._getContacts = () => this.contacts, this._pop = () => {
                        this.pop()
                    }, this._popNone = () => {
                        this.pop("none")
                    }
                }
                componentDidMount() {
                    var e = this.props.serverProps.maxParticipants;
                    this.contacts = [], this.push(n.createElement(d.default, {
                        title: o.default.t(1233),
                        onCancel: this._pop,
                        onConfirm: this._confirmSendContacts,
                        getInitialItems: this._getContacts,
                        listType: d.ListType.CONTACT_SELECT_MODAL,
                        maxItems: e,
                        allowBlockedContacts: !0
                    }))
                }
            }
            t.default = e => n.createElement(p, (0, r.default)({}, e, {
                serverProps: c.default
            }))
        },
        26458: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(90059)),
                l = s(a(29505)),
                o = a(28278);
            class d extends l.default {
                constructor(...e) {
                    super(...e), this.sendMedia = ({
                        getImg: e,
                        caption: t,
                        mentionedJidList: a
                    }) => {
                        var s = this.props.chat,
                            i = s.composeQuotedMsg;
                        s.composeQuotedMsg = null;
                        var r = s.getComposeContents().ctwaContext || void 0;
                        (0, o.prepRawMedia)(e, {}).sendToChat(s, {
                            caption: t,
                            mentionedJidList: a,
                            quotedMsg: i,
                            ctwaContext: r
                        }), this.props.onCaptureSent(), this.end()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(n.default, {
                        onBack: () => {
                            this.end()
                        },
                        chat: this.props.chat,
                        caption: !0,
                        theme: "capture-contain",
                        onSend: this.sendMedia,
                        stream: this.props.stream
                    }))
                }
            }
            t.default = d
        },
        96858: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(83717)),
                l = s(a(79711)),
                o = s(a(29505)),
                d = s(a(13531));
            class u extends o.default {
                constructor(...e) {
                    super(...e), this.onProductCatalog = () => {
                        var {
                            sellerJid: e,
                            chat: t,
                            sessionId: a
                        } = this.props;
                        this.push(r.createElement(d.default, {
                            chat: t,
                            sessionId: a,
                            catalogOwnerJid: e
                        }))
                    }, this.onProductDetail = e => {
                        var {
                            chat: t,
                            sessionId: a
                        } = this.props;
                        this.push(r.createElement(d.default, {
                            refreshCarousel: !0,
                            chat: t,
                            productInfo: e,
                            sessionId: a,
                            onEnd: this._pop
                        }))
                    }, this._end = () => {
                        this.end(!0)
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    var {
                        sellerJid: e,
                        chat: t,
                        sessionId: a
                    } = this.props;
                    this.push(r.createElement(n.default, {
                        chat: t,
                        sellerJid: e,
                        sessionId: a,
                        onProductDetail: this.onProductDetail,
                        onProductCatalog: this.onProductCatalog,
                        onBack: this._end
                    })), l.default.existsDrawerLeft((e => {
                        e && l.default.closeDrawerLeft()
                    })), l.default.existsDrawerMid((e => {
                        e && l.default.closeDrawerMid()
                    }))
                }
            }
            t.default = u
        },
        59693: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = a(90440),
                l = s(a(65468)),
                o = s(a(16285)),
                d = s(a(79711)),
                u = s(a(7470)),
                c = a(71311),
                h = s(a(27154)),
                p = s(a(29505)),
                f = s(a(17957)),
                m = s(a(68617)),
                v = s(a(37163)),
                _ = s(a(55043)),
                E = s(a(32719)),
                g = s(a(63163));
            class C extends p.default {
                constructor(...e) {
                    super(...e), this._handleAddFirstProduct = e => {
                        this._showProductList(e), l.default.find(this.props.catalogId).then((() => {
                            this._onAddProduct(e)
                        }))
                    }, this._showProductList = e => {
                        var t = u.default.get(this.props.catalogId);
                        t && this.push(r.createElement(g.default, {
                            contact: t,
                            onCatalogLinkClick: this._onCatalogShare,
                            onProductShare: this.onProductShare,
                            onProductDetail: this.onEditProduct,
                            onAddProduct: this._onAddProduct,
                            catalogId: this.props.catalogId,
                            sessionId: e,
                            onBack: this._end,
                            onCartClick: this.onCartClick,
                            businessProfile: null,
                            headerType: c.DRAWER_HEADER_TYPE.LARGE,
                            canManageCatalog: !0,
                            autoUpdate: !0
                        }))
                    }, this.onEditProduct = (e, t) => {
                        var a = l.default.assertGet(this.props.catalogId);
                        d.default.openDrawerMid(r.createElement(h.default, {
                            catalog: a,
                            product: e,
                            sessionId: t
                        }), "slide-left")
                    }, this.onCartClick = (e, t) => {
                        (0, n.showCartFlow)(e, t)
                    }, this._onAddProduct = e => {
                        var t = l.default.assertGet(this.props.catalogId),
                            a = new v.default({
                                catalogWid: t.id,
                                additionalImageCdnUrl: []
                            });
                        d.default.openDrawerMid(r.createElement(h.default, {
                            catalog: t,
                            product: a,
                            sessionId: e,
                            newProduct: !0
                        }), "slide-left")
                    }, this._onCatalogShare = (e, t, a) => {
                        d.default.openDrawerMid(r.createElement(o.default, {
                            onCancel: () => {
                                d.default.closeDrawerMid()
                            },
                            catalog: e,
                            sessionId: a,
                            contact: t,
                            prompt: f.default.t(438),
                            onSend: () => d.default.closeDrawerMid(),
                            centerDrawer: !0
                        }), "slide-left")
                    }, this.onProductShare = (e, t) => {
                        d.default.openDrawerMid(r.createElement(E.default, {
                            onCancel: () => {
                                d.default.closeDrawerMid()
                            },
                            product: e,
                            sessionId: t,
                            prompt: f.default.t(438),
                            onSend: () => d.default.closeDrawerMid(),
                            centerDrawer: !0,
                            sendProductMsg: !0
                        }), "slide-left")
                    }, this._pop = () => {
                        this.pop(), d.default.closeDrawerMid()
                    }, this._end = () => {
                        this.end(!0), d.default.closeDrawerMid()
                    }
                }
                componentDidMount() {
                    var e = (new _.default).toString();
                    null != this.props.catalog ? (this._showProductList(e), null != this.props.product && this.onEditProduct(this.props.product, e)) : this._showNewCatalog(e)
                }
                _showNewCatalog(e) {
                    this.push(r.createElement(m.default, {
                        onBack: this._pop,
                        onAddProductClick: this._handleAddFirstProduct,
                        onCatalogAlreadyCreated: this._showProductList,
                        sessionId: e
                    }))
                }
            }
            t.default = C
        },
        77619: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(23591)),
                l = s(a(29505)),
                o = s(a(13531));
            class d extends l.default {
                constructor(...e) {
                    super(...e), this.onProductClick = (e, t) => {
                        this.push(r.createElement(o.default, {
                            refreshCarousel: !0,
                            chat: this.props.msg.chat,
                            product: e,
                            sessionId: t,
                            onEnd: this._pop
                        }))
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(n.default, {
                        msg: this.props.msg,
                        onProductClick: this.onProductClick
                    }))
                }
            }
            t.default = d
        },
        5918: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(90059)),
                l = s(a(79711)),
                o = i(a(89364)),
                d = i(a(96452)),
                u = s(a(29505)),
                c = i(a(45356)),
                h = i(a(16622)),
                p = i(a(41967)),
                f = s(a(72259));
            class m extends u.default {
                constructor(...e) {
                    super(...e), this._refCaptureDrawer = null, this._setRefCaptureDrawer = e => {
                        this._refCaptureDrawer = e
                    }, this._pushPermissionModal = () => {
                        this.push(r.createElement(c.default, {
                            messaging: c.Messaging.CAMERA,
                            type: c.default.TYPE.GUIDE_ALLOW,
                            onConfirm: this._popModal
                        }), "modal")
                    }, this._popModal = () => {
                        this.pop("modal")
                    }, this._startCaptureDrawer = () => {
                        var e = h.start("camera", this._pushPermissionModal);
                        Promise.race([e, this.props.rejectOnUnmount()]).checkpoint(this.props.rejectOnUnmount()).then((e => {
                            this._refCaptureDrawer || this._popModal(), e && this._refCaptureDrawer && this._refCaptureDrawer.loadNewStream(e)
                        })).catchType(d.GUM.NotAllowedError, (() => {
                            this.cleanUp(), l.default.openModal(r.createElement(c.default, {
                                messaging: c.Messaging.CAMERA_FAIL,
                                type: c.default.TYPE.GUIDE_UNBLOCK
                            }))
                        })).catchType(d.GUM.GUMError, (() => {
                            this.cleanUp(), l.default.openModal(r.createElement(c.default, {
                                messaging: c.Messaging.CAMERA_MISSING,
                                type: c.default.TYPE.GUIDE_NONE
                            }))
                        }))
                    }, this.onFinished = (e, t) => {
                        this.props.onFinished(e, t), this.cleanUp()
                    }, this.cleanUp = () => {
                        this.end()
                    }, this.onRetake = () => {
                        this.pop("flow-transition-box-size-drawer-pop"), this._startCaptureDrawer()
                    }, this.onCaptured = e => {
                        this.push(r.createElement(p.default, {
                            type: p.BoxModalType
                        }, r.createElement(o.default, {
                            onRetake: this.onRetake,
                            retryText: o.RETRY_OPTIONS.RETAKE,
                            onFinished: this.onFinished,
                            onCancel: this.cleanUp,
                            img: e
                        })), "flow-transition-box-size-drawer-push")
                    }, this.handleRequestDismiss = e => {
                        !1 === e && this.stackSize() > 1 ? this.onRetake() : this.cleanUp()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(p.default, {
                        type: p.BoxModalType
                    }, r.createElement(n.default, {
                        ref: this._setRefCaptureDrawer,
                        stream: void 0,
                        caption: !1,
                        theme: "capture-cover",
                        onBack: this.cleanUp,
                        onSend: null,
                        onCaptured: this.onCaptured,
                        chat: void 0
                    }))), this._startCaptureDrawer()
                }
            }
            var v = (0, f.default)(m);
            t.default = v
        },
        56027: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = i(a(89364)),
                l = s(a(29505));
            class o extends l.default {
                constructor(...e) {
                    super(...e), this.onEnd = () => {
                        this.end()
                    }, this.onFinished = (e, t) => {
                        this.props.onFinished(e, t), this.end()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(n.default, {
                        onCancel: this.onEnd,
                        onFinished: this.onFinished,
                        onRetake: this.props.onRetake,
                        retryText: n.RETRY_OPTIONS.RESTART,
                        img: this.props.img
                    }))
                }
            }
            t.default = o
        },
        27154: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(65995)),
                o = s(a(29505)),
                d = s(a(17957)),
                u = s(a(49306)),
                c = s(a(32719));
            class h extends o.default {
                constructor(...e) {
                    super(...e), this._showInfoDrawer = e => {
                        var {
                            catalog: t,
                            sessionId: a
                        } = this.props;
                        this.push(r.createElement(u.default, {
                            catalog: t,
                            product: e,
                            onCancel: this.end,
                            onEditProduct: this._onProductEdit,
                            onShareProduct: this.onShareProduct,
                            sessionId: a
                        }))
                    }, this.onShareProduct = e => {
                        this.push(r.createElement(c.default, {
                            onBack: this._pop,
                            product: e,
                            sessionId: this.props.sessionId,
                            prompt: r.createElement("div", null, d.default.t(438)),
                            onSend: () => n.default.closeDrawerMid(),
                            centerDrawer: !0,
                            sendProductMsg: !0
                        }))
                    }, this._onProductEdit = (e, t) => {
                        this.push(r.createElement(l.default, {
                            catalog: this.props.catalog,
                            sessionId: t,
                            onBack: this._pop,
                            onEditSuccess: this._showInfoDrawer,
                            product: e,
                            onDelete: this.props.onDelete
                        }))
                    }, this._pop = () => {
                        this.pop()
                    }, this._end = () => {
                        this.end(!0)
                    }
                }
                componentDidMount() {
                    var {
                        catalog: e,
                        product: t,
                        sessionId: a,
                        onCreate: s,
                        newProduct: i
                    } = this.props;
                    i ? this.push(r.createElement(l.default, {
                        sessionId: a,
                        onCancel: this._pop,
                        onEditSuccess: e => {
                            s && s(), this._showInfoDrawer(e)
                        },
                        catalog: e,
                        product: t,
                        newProduct: !0
                    })) : this._showInfoDrawer(t)
                }
            }
            t.default = h
        },
        90561: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(43334)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = s(a(50935)),
                u = s(a(29505)),
                c = s(a(22182)),
                h = s(a(3570)),
                p = s(a(17957)),
                f = i(a(51079)),
                m = s(a(72424));
            class v extends u.default {
                constructor(...e) {
                    super(...e), this.requestFocus = () => {
                        var e, t = null === (e = this.refUIE) || void 0 === e ? void 0 : e.getRef();
                        null != t && (t instanceof HTMLElement || "function" != typeof t.onFocusList || t.onFocusList())
                    }, this.onForwardConfirmed = e => {
                        var {
                            msgs: t,
                            onForward: a
                        } = this.props;
                        n.default.forwardMessagesToChats(t, e).catchType(c.default, (e => {
                            this._showMediaSendError(e.reasons)
                        })), this.end(), a && a(t), l.default.openChatFromUnread(e[0])
                    }, this._showMediaSendError = e => {
                        var t = e.map((({
                            chat: e,
                            reason: t
                        }) => r.createElement("p", {
                            key: e.id.toString()
                        }, e.formattedTitle, " : ", t)));
                        l.default.openModal(r.createElement(o.default, {
                            onOK: () => l.default.closeModal(),
                            okText: p.default.t(1680)
                        }, t), void 0)
                    }
                }
                componentDidMount() {
                    var e, {
                            msgs: t
                        } = this.props,
                        a = p.default.t(668, {
                            _plural: t.length || 1
                        }),
                        s = t[0],
                        i = s && s.chat;
                    e = "video" !== s.type && "image" !== s.type ? "message" : s.type;
                    var n, l = t.some((e => e.isFrequentlyForwarded)),
                        o = t.filter((e => !e.isFrequentlyForwarded && e.getForwardingScoreWhenForwarded() === d.default.FREQUENTLY_FORWARDED_SENTINEL));
                    m.default.frequentlyForwardedMessages && o.length && (n = r.createElement(h.default, {
                        frequentlyForwardedCount: o.length,
                        totalCount: t.length
                    }));
                    var u = m.default.frequentlyForwardedMessages && l ? m.default.frequentlyForwardedMax : m.default.multicastLimitGlobal;
                    this.push(r.createElement(f.default, {
                        onConfirm: this.onForwardConfirmed,
                        maxItems: u,
                        excludeChat: i,
                        excludeBroadcast: !0,
                        msgType: e,
                        title: a,
                        listType: f.ListType.CHAT_SELECT_MODAL,
                        customHeader: n,
                        hasFrequentlyForwarded: l,
                        showEphemeralIcon: !0
                    }))
                }
            }
            t.default = v
        },
        93138: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(29505)),
                l = s(a(42878));
            class o extends n.default {
                componentDidMount() {
                    this.push(r.createElement(l.default, {
                        chat: this.props.chat,
                        onConfirm: this.props.onConfirm
                    }))
                }
            }
            t.default = o
        },
        17302: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(29505)),
                l = s(a(3784)),
                o = s(a(13531));
            class d extends n.default {
                constructor(...e) {
                    super(...e), this.onProductClick = (e, t) => {
                        this.push(r.createElement(o.default, {
                            refreshCarousel: !0,
                            chat: this.props.msg.chat,
                            product: e,
                            sessionId: t,
                            onEnd: this._pop
                        }))
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(l.default, {
                        msg: this.props.msg,
                        onProductClick: this.onProductClick
                    }))
                }
            }
            t.default = d
        },
        5727: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(43334)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = s(a(29505)),
                u = s(a(99922)),
                c = s(a(17402)),
                h = s(a(17957)),
                p = s(a(43486)),
                f = s(a(60949)),
                m = a(59420),
                v = i(a(75074));
            class _ extends d.default {
                constructor(...e) {
                    super(...e), this.onSendInvite = (e = "", t) => {
                        l.default.closeModal(), Promise.all(this.props.participantNeedInvite.map((a => {
                            var {
                                contact: s,
                                invite_code: i,
                                invite_code_exp: r
                            } = a;
                            return n.default.find(s.id).then((a => {
                                var n = this.props.groupGid.toString(),
                                    l = u.default.assertGet(n);
                                return a.sendGroupInviteMessage(n, this.props.subject, i || "", r, e, t).then((e => e === m.SendMsgResult.OK && (l.pendingParticipants.add({
                                    id: s.id
                                }), !0)))
                            }))
                        }))).then((e => {
                            var t = e.filter(Boolean).length;
                            l.default.openToast(r.createElement(v.default, {
                                msg: h.default.t(1637, {
                                    num: t,
                                    _plural: t
                                }),
                                id: (0, v.genId)()
                            }))
                        }))
                    }, this._addInviteCommment = e => {
                        this.push(r.createElement(c.default, {
                            participants: e,
                            gid: this.props.groupGid,
                            subject: this.props.subject,
                            groupDesc: this.props.groupDesc,
                            onClose: this._pop,
                            onSend: this.onSendInvite
                        }))
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    var {
                        participantNeedInvite: e
                    } = this.props, t = this._getFormattedNames(e.map((e => e.contact)), !0), a = h.default.t(751, {
                        participant: t,
                        _plural: e.length
                    });
                    this.push(r.createElement(o.default, {
                        onOK: this._addInviteCommment.bind(this, e),
                        okText: h.default.t(1636),
                        onCancel: this._pop,
                        cancelText: h.default.t(1518)
                    }, a))
                }
                _getFormattedName(e, t = !1) {
                    return t ? e.formattedUser : r.createElement(f.default, {
                        contact: e
                    })
                }
                _getFormattedNames(e, t = !1) {
                    if (!Array.isArray(e)) return this._getFormattedName(e, t);
                    var a = e.map((e => this._getFormattedName(e, t)));
                    return (0, p.default)(a, t)
                }
            }
            t.default = _, _.defaultProps = {
                removeTopDrawer: !0,
                pushTransition: "none",
                popTransition: "none"
            }
        },
        48189: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(89364)),
                n = s(a(29505)),
                l = s(a(18775)),
                o = i(a(2784));
            class d extends n.default {
                constructor(...e) {
                    super(...e), this.onImageSelected = (e, t) => {
                        this.push(o.createElement(r.default, {
                            onCancel: this._handleCancel,
                            attributionUrl: t,
                            onFinished: this.onFinished,
                            onRetake: this._pop,
                            retryText: r.RETRY_OPTIONS.NONE,
                            img: e
                        }))
                    }, this._handleCancel = () => {
                        this.end()
                    }, this._pop = () => {
                        this.pop()
                    }, this.onFinished = (e, t) => {
                        this.props.onFinished(e, t), this.end()
                    }
                }
                componentDidMount() {
                    this.push(o.createElement(l.default, {
                        onCancel: this._pop,
                        onImageSelected: this.onImageSelected
                    }))
                }
            }
            t.default = d
        },
        51937: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(80605)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = s(a(50935)),
                u = s(a(29505)),
                c = s(a(17957)),
                h = s(a(23539)),
                p = s(a(37350)),
                f = s(a(86895)),
                m = s(a(26432));
            class v extends u.default {
                constructor(...e) {
                    super(...e), this.onDeleteLabel = e => {
                        e.forEach((({
                            id: e
                        }) => {
                            h.default.deleteLabel(e)
                        }))
                    }, this._onManageLabels = e => {
                        l.default.openModal(r.createElement(m.default, {
                            modelsToUpdate: e
                        }))
                    }, this.onEditLabel = e => {
                        l.default.openModal(r.createElement(n.default, {
                            labelId: e,
                            onUpdateLabel: this.onUpdateLabel,
                            onCancel: l.default.closeModal()
                        }))
                    }, this.onLabelClick = e => {
                        var t = a(37972).Z;
                        this.push(r.createElement(t, {
                            openLabelColorDrawer: this.openLabelColorDrawer,
                            labelId: e,
                            onManageLabels: this._onManageLabels,
                            onClose: this._pop,
                            onRemoveLabel: this.onRemoveLabel,
                            onEditLabel: this.onEditLabel
                        }))
                    }, this.openAddLabel = () => {
                        h.default.toArray().length >= d.default.MAX_SMB_LABEL_COUNT ? l.default.openModal(r.createElement(o.default, {
                            okText: c.default.t(1080),
                            onOK: () => l.default.closeModal()
                        }, c.default.t(1835, {
                            count: d.default.MAX_SMB_LABEL_COUNT
                        }))) : l.default.openModal(r.createElement(n.default, {
                            onAddLabel: this.onAddLabel,
                            onCancel: l.default.closeModal()
                        }))
                    }, this.onUpdateLabel = (e, t) => {
                        h.default.updateLabel(e, t)
                    }, this.openLabelColorDrawer = (e, t) => {
                        this.push(r.createElement(p.default, {
                            labelId: e,
                            onClose: this._pop,
                            onUpdateColor: this.onUpdateLabel,
                            currentColor: t
                        }))
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(f.default, {
                        onDeleteLabel: this.onDeleteLabel,
                        onLabelClick: this.onLabelClick,
                        onClose: this._pop,
                        openAddLabel: this.openAddLabel
                    }))
                }
                onAddLabel(e, t) {
                    h.default.addNewLabel(e, t)
                }
                onRemoveLabel(e, t) {
                    h.default.addOrRemoveLabels([{
                        id: e,
                        type: "remove"
                    }], t)
                }
            }
            t.default = v
        },
        24180: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(80605)),
                l = s(a(46774)),
                o = s(a(79711)),
                d = s(a(9386)),
                u = s(a(50935)),
                c = s(a(29505)),
                h = s(a(17957)),
                p = s(a(23539)),
                f = a(74282),
                m = s(a(75198)),
                v = s(a(40210));
            class _ extends c.default {
                constructor(...e) {
                    super(...e), this._newlyAddedLabels = new Set, this._logWamEvent = () => {
                        var e = this.props.modelsToUpdate.length;
                        this._labelViewType = 1 === e ? this.props.modelsToUpdate[0] instanceof l.default ? v.default.LABEL_TARGETS.LABEL_CHAT_DIALOG : v.default.LABEL_TARGETS.LABEL_MESSAGE_DIALOG : v.default.LABEL_TARGETS.LABEL_COMBINED_DIALOG, (0, f.logLabelOperationEvent)(v.default.LABEL_OPERATIONS.VIEW, e, this._labelViewType)
                    }, this.onLabelUpdateComplete = () => {
                        this.props.onLabelUpdateComplete && this.props.onLabelUpdateComplete(), this._pop()
                    }, this.onAddLabel = (e, t) => {
                        p.default.addNewLabel(e, t).then((() => {
                            this._newlyAddedLabels.add(e)
                        }))
                    }, this.shouldScrollIntoViewAndSelect = e => this._newlyAddedLabels.has(e) ? (this._newlyAddedLabels.delete(e), {
                        shouldScrollIntoView: !0,
                        shouldSelect: !0
                    }) : {
                        shouldScrollIntoView: !1,
                        shouldSelect: !1
                    }, this.onAddNewLabel = () => {
                        p.default.toArray().length >= u.default.MAX_SMB_LABEL_COUNT ? o.default.openModal(r.createElement(d.default, {
                            okText: h.default.t(1080),
                            onOK: () => o.default.closeModal()
                        }, h.default.t(1835, {
                            count: u.default.MAX_SMB_LABEL_COUNT
                        }))) : this.push(r.createElement(n.default, {
                            onAddLabel: this.onAddLabel,
                            onCancel: this._pop
                        }))
                    }, this._popAndLogEvent = () => {
                        this._labelViewType && (0, f.logLabelOperationEvent)(v.default.LABEL_OPERATIONS.CLICK_NEGATIVE, this.props.modelsToUpdate.length, this._labelViewType), this.pop()
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this._logWamEvent(), this.push(r.createElement(m.default, {
                        shouldScrollIntoViewAndSelect: this.shouldScrollIntoViewAndSelect,
                        onAddNewLabel: this.onAddNewLabel,
                        onLabelUpdateComplete: this.onLabelUpdateComplete,
                        onCancel: this._popAndLogEvent,
                        modelsToUpdate: this.props.modelsToUpdate
                    }))
                }
            }
            t.default = _, _.defaultProps = {
                removeTopDrawer: !0,
                pushTransition: "none",
                popTransition: "none"
            }
        },
        26298: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(43334)),
                l = s(a(79711)),
                o = s(a(7470)),
                d = s(a(55086)),
                u = s(a(29505)),
                c = s(a(17957)),
                h = s(a(91846)),
                p = s(a(8180));
            class f extends u.default {
                constructor(...e) {
                    super(...e), this.onClick = (e, t) => {
                        n.default.find(t.id).then(l.default.openChatFromUnread.bind(l.default)), this.end()
                    }, this.onNewGroup = () => {
                        this.push(r.createElement(p.default, {
                            onBack: this.pop,
                            onContinue: this.onSetGroupInfo
                        }))
                    }, this.onSetGroupInfo = e => {
                        this.push(r.createElement(h.default, {
                            participants: e,
                            onBack: () => {
                                this.popAndUpdate({
                                    participants: e
                                })
                            },
                            onContinue: this.end
                        }))
                    }
                }
                componentDidMount() {
                    o.default.ensureSorted(), this.push(r.createElement(d.default, {
                        title: c.default.t(1054),
                        onBack: this.end,
                        onClick: this.onClick,
                        onNewGroup: this.onNewGroup
                    }))
                }
            }
            t.default = f
        },
        75238: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(7470)),
                l = s(a(29505)),
                o = s(a(91846)),
                d = s(a(8180));
            class u extends l.default {
                constructor(...e) {
                    super(...e), this.onSetGroupInfo = e => {
                        this.push(r.createElement(o.default, {
                            participants: e,
                            onBack: () => {
                                this.popAndUpdate({
                                    participants: e
                                })
                            },
                            onContinue: this.end
                        }))
                    }
                }
                componentDidMount() {
                    n.default.ensureSorted(), this.push(r.createElement(d.default, {
                        onBack: this.end,
                        onContinue: this.onSetGroupInfo
                    }))
                }
            }
            t.default = u
        },
        46178: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(89216)),
                l = a(93774),
                o = s(a(16285)),
                d = s(a(7470)),
                u = s(a(29505)),
                c = a(83974),
                h = s(a(6099)),
                p = s(a(96082)),
                f = s(a(83330)),
                m = s(a(32719)),
                v = s(a(63163)),
                _ = s(a(78492)),
                E = a(75637);
            class g extends u.default {
                constructor(...e) {
                    super(...e), this.scrollOffset = 0, this.setScrollOffset = e => {
                        this.scrollOffset = e
                    }, this._pushProductDetails = (e, t) => {
                        var {
                            chat: a,
                            refreshCarousel: s
                        } = this.props, i = r.createElement(p.default, {
                            chat: a,
                            product: e,
                            onEnd: this._end,
                            onBack: this._popAndUpdate,
                            onProductDetail: this.onProductDetail,
                            onProductCatalog: this.onProductCatalogHeaderClick,
                            onProductLinkClick: this._onProductLinkClick,
                            refreshCarousel: s,
                            sessionId: t,
                            onCartClick: this._onCartClick
                        });
                        this.push(i)
                    }, this._pushProductDetailsWithDeepLink = (e, t) => {
                        var a = r.createElement(f.default, {
                            chat: this.props.chat,
                            productInfo: e,
                            onEnd: this._end,
                            onBack: this._pop,
                            onProductDetail: this.onProductDetail,
                            onProductCatalog: this.onProductCatalogHeaderClick,
                            sessionId: t,
                            onProductLinkClick: this._onProductLinkClick,
                            onCartClick: this._onCartClick
                        });
                        this.push(a)
                    }, this.pushProductCatalog = (e, t) => {
                        var a = d.default.gadd(t);
                        n.default.find(t).then((s => {
                            var i = r.createElement(v.default, {
                                contact: a,
                                onProductDetail: this.onProductDetail,
                                catalogId: t,
                                onBack: this._pop,
                                sessionId: e,
                                businessProfile: s,
                                setScrollOffset: this.setScrollOffset,
                                onCatalogLinkClick: this._onCatalogLinkClick,
                                onCartClick: this._onCartClick
                            });
                            this.push(i)
                        }))
                    }, this._pushOrderDetail = (e, t, a, s, i) => {
                        var n = r.createElement(h.default, {
                            orderId: e,
                            token: t,
                            sellerJid: s,
                            sessionId: a,
                            userIsCartOwner: i,
                            onProductDetail: this._onProductDetailFromInfo
                        });
                        this.push(n)
                    }, this._pushProductList = (e, t, a) => {
                        var s = d.default.gadd(a),
                            i = r.createElement(_.default, {
                                contact: s,
                                productListId: e,
                                sessionId: t,
                                onProductDetail: this.onProductDetail,
                                onCartClick: this._onCartClick,
                                onBack: this._pop,
                                setScrollOffset: this.setScrollOffset
                            });
                        this.push(i)
                    }, this.onProductDetail = (e, t) => {
                        this._pushProductDetails(e, t)
                    }, this._onProductDetailFromInfo = (e, t) => {
                        this._pushProductDetailsWithDeepLink(e, t)
                    }, this.onProductCatalogHeaderClick = (e, t) => {
                        (0, c.logCarouselViewMoreClick)({
                            catalogOwnerWid: e,
                            catalogSessionId: t
                        }), this.pushProductCatalog(t, e)
                    }, this._onProductLinkClick = (e, t) => {
                        this.push(r.createElement(m.default, {
                            product: e,
                            onBack: this._pop,
                            sessionId: t
                        }))
                    }, this._onCatalogLinkClick = (e, t, a) => {
                        this.push(r.createElement(o.default, {
                            catalog: e,
                            contact: t,
                            sessionId: a,
                            onBack: this._pop
                        }))
                    }, this._onCartClick = (e, t) => {
                        var a = (0, l.showCart)(e, t, this.props.chat);
                        a && this.push(a)
                    }, this._pop = () => {
                        this.pop()
                    }, this._end = () => {
                        this.end(!0)
                    }, this._popAndUpdate = () => {
                        this.popAndUpdate({
                            scrollOffset: this.scrollOffset
                        })
                    }
                }
                componentDidMount() {
                    var {
                        catalogOwnerJid: e,
                        orderId: t,
                        product: a,
                        productInfo: s,
                        productListId: i,
                        sessionId: r
                    } = this.props;
                    if (e) null != i ? this._pushProductList(i, r, (0, E.createWid)(e)) : this.pushProductCatalog(r, (0, E.createWid)(e));
                    else if (a) this._pushProductDetails(a, r);
                    else if (s) this._pushProductDetailsWithDeepLink(s, r);
                    else {
                        if (!t) throw new Error("ProductDetailsFlow:no-product");
                        var {
                            token: n,
                            sellerJid: l,
                            userIsCartOwner: o
                        } = this.props;
                        null != n && null != l && null != o && this._pushOrderDetail(t, n, r, l, o)
                    }
                }
            }
            t.default = g
        },
        82297: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(29505)),
                l = s(a(6901));
            class o extends n.default {
                constructor(...e) {
                    super(...e), this.closeStatusViewer = () => {
                        this.end()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(l.default, {
                        initialStatusV3: this.props.statusV3,
                        quotedMsgKey: this.props.msgKey,
                        closeStatusViewer: this.closeStatusViewer,
                        onMsgNotFound: this.props.onMsgNotFound
                    }), "none")
                }
            }
            t.default = o
        },
        4924: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    chat: t
                } = e, a = (0, l.default)(t.groupMetadata.groupInviteLink, "chat.groupMetadata.groupInviteLink"), s = "".concat(n.default.t(745), " ").concat(a);
                return r.createElement(o.default, {
                    title: n.default.t(730),
                    text: s,
                    pushTransition: "none",
                    popTransition: "none"
                })
            };
            var r = i(a(2784)),
                n = s(a(17957)),
                l = s(a(61941)),
                o = s(a(54251))
        },
        47207: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(58527)),
                n = s(a(2784)),
                l = a(43322),
                o = i(a(79711)),
                d = i(a(29505)),
                u = i(a(17957)),
                c = s(a(51079)),
                h = a(37960),
                p = i(a(72424));
            class f extends d.default {
                constructor(...e) {
                    super(...e), this.onForwardConfirmed = e => {
                        var t = this.props.msgText;
                        if (1 === e.length) {
                            var a = e[0];
                            (a.isUser && a.contact.isBlocked() ? (0, l.unblockContact)(a.contact) : Promise.resolve(!0)).then((() => {
                                if (t) {
                                    if (a.urlText = this.props.urlText, a.active) return void o.default.pasteChatTextInput(a, t);
                                    a.setComposeContents({
                                        text: t
                                    })
                                }
                                return o.default.openChatFromUnread(a).then((e => {
                                    e && o.default.focusChatTextInput(a)
                                }))
                            }))
                        } else Promise.map(e, (e => {
                            (e.isUser && e.contact.isBlocked() ? (0, l.unblockContact)(e.contact) : Promise.resolve(!0)).then((() => {
                                e.urlText = this.props.urlText, (0, h.sendTextMsgToChat)(e, t)
                            }))
                        })), o.default.openChatFromUnread(e[0]);
                        this.end()
                    }
                }
                componentDidMount() {
                    this.push(n.createElement(c.default, {
                        onConfirm: this.onForwardConfirmed,
                        maxItems: this.props.serverProps.multicastLimitGlobal,
                        title: u.default.t(964),
                        listType: c.ListType.CHAT_SELECT_MODAL
                    }))
                }
            }
            t.default = e => n.createElement(f, (0, r.default)({}, e, {
                serverProps: p.default
            }))
        },
        91047: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(52954)),
                n = s(a(2784)),
                l = a(43322),
                o = i(a(79711)),
                d = i(a(50935)),
                u = i(a(29505)),
                c = i(a(17957)),
                h = s(a(51079)),
                p = i(a(72424));
            class f extends u.default {
                constructor(...e) {
                    var t;
                    super(...e), t = this, this._handleForwardConfirmed = e => {
                        e.forEach(function() {
                            var e = (0, r.default)((function*(e) {
                                e.isUser && e.contact.isBlocked() && (yield(0, l.unblockContact)(e.contact)), t._sendProduct(e)
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()), this.end(), 1 === e.length && (o.default.openChatFromUnread(e[0]), window.innerWidth <= d.default.LAYOUT_2COLUMNS_MAX_WIDTH && o.default.closeDrawerRight()), this.props.onSend && this.props.onSend()
                    }, this._handleCancel = () => {
                        this.end()
                    }, this._sendProduct = e => {
                        var {
                            product: t
                        } = this.props;
                        o.default.once("ui_idle", (() => {
                            e.sendProductMessage(t)
                        }))
                    }
                }
                componentDidMount() {
                    o.default.closeContextMenu(), o.default.closeTooltip(), this.push(n.createElement(h.default, {
                        onConfirm: this._handleForwardConfirmed,
                        maxItems: p.default.multicastLimitGlobal,
                        title: c.default.t(964),
                        listType: h.ListType.CHAT_SELECT_MODAL,
                        onCancel: this._handleCancel
                    }))
                }
            }
            t.default = f
        },
        44774: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(64946)),
                l = i(a(3594)),
                o = s(a(79711)),
                d = s(a(52737)),
                u = s(a(29505)),
                c = a(95595),
                h = s(a(83848)),
                p = s(a(14949)),
                f = s(a(64907)),
                m = s(a(35194)),
                v = s(a(15118)),
                _ = s(a(29192)),
                E = s(a(76019)),
                g = s(a(93869)),
                C = s(a(2663));
            class S extends u.default {
                constructor(...e) {
                    super(...e), this._showWallpaperDrawer = () => {
                        this.push(r.createElement(C.default, {
                            onClose: this._pop
                        }))
                    }, this._showBlockedDrawer = () => {
                        this.push(r.createElement(n.default, {
                            onClose: this._pop
                        }))
                    }, this._showProfileDrawer = () => {
                        var e = (0, c.getMaybeMeUser)(),
                            t = E.default.assertGet(e),
                            a = v.default.assertGet(e);
                        this.push(r.createElement(m.default, {
                            status: t,
                            profilePicThumb: a,
                            conn: d.default,
                            onClose: this._pop
                        }))
                    }, this._showNotifications = () => {
                        this.push(r.createElement(f.default, {
                            onClose: this._pop
                        }))
                    }, this._showHelp = () => {
                        l.upload({
                            reason: "help-page-opened",
                            isHighPri: !0
                        }), this.push(r.createElement(h.default, {
                            onClose: this._pop
                        }))
                    }, this._showThemePopup = () => {
                        o.default.openModal(r.createElement(g.default, null))
                    }, this.showKeyboardShortcuts = () => {
                        o.default.openModal(r.createElement(p.default, null))
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(_.default, {
                        profileId: (0, c.getMaybeMeUser)(),
                        onWallpaper: this._showWallpaperDrawer,
                        onBlocked: this._showBlockedDrawer,
                        onProfile: this._showProfileDrawer,
                        onNotifications: this._showNotifications,
                        onHelp: this._showHelp,
                        onThemeSettings: this._showThemePopup,
                        onKeyboardShortcuts: this.showKeyboardShortcuts,
                        onClose: this._pop
                    }))
                }
            }
            t.default = S
        },
        34044: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(29505)),
                o = s(a(20642)),
                d = s(a(40618)),
                u = s(a(6901));
            class c extends l.default {
                constructor(...e) {
                    super(...e), this.sessionId = Math.round(1e9 * Math.random()), this._openStatusViewer = (e, t, a) => {
                        this.push(r.createElement(u.default, {
                            initialStatusV3: e,
                            initialStatusMsg: t,
                            closeStatusViewer: this.closeStatusViewer,
                            sessionId: this.sessionId,
                            rowIdx: a
                        }), "none")
                    }, this.closeStatusViewer = e => {
                        e ? this.end() : this.pop("none")
                    }
                }
                componentDidMount() {
                    this.push(r.createElement(d.default, {
                        onOpenStatus: this._openStatusViewer,
                        closeStatusViewer: this.closeStatusViewer,
                        sessionId: this.sessionId
                    }), "status-v3-modal"), this.props.listeners.add(n.default, "close_status_viewer", (() => {
                        this.closeStatusViewer(!0)
                    }))
                }
                componentWillUnmount() {
                    this.props.onFlowEnd()
                }
            }
            var h = (0, o.default)(c);
            t.default = h
        },
        44156: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(96066)),
                l = s(a(91581)),
                o = a(75459),
                d = s(a(17957)),
                u = s(a(23539)),
                c = i(a(49984)),
                h = s(a(20642));
            class p extends r.PureComponent {
                constructor(...e) {
                    super(...e), this._updateLabels = () => {
                        this.forceUpdate()
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(u.default, "label_updated_".concat(this.props.label), this._updateLabels)
                }
                render() {
                    var {
                        label: e
                    } = this.props, t = u.default.get(e);
                    if (!t || !t.name) return null;
                    if ("label-list" === this.props.theme) {
                        var a = r.createElement(c.default, {
                                renderAsCircle: "label-list" === this.props.theme,
                                theme: this.props.theme,
                                labels: [e]
                            }),
                            s = r.createElement(l.default, {
                                text: t.name,
                                ellipsify: !0,
                                titlify: !0
                            });
                        return r.createElement(n.default, {
                            theme: (0, o.canEditLabel)() ? "chat-checkbox" : void 0,
                            image: a,
                            primary: s,
                            secondary: d.default.t(814, {
                                count: parseInt(t.count || 0, 10),
                                _plural: parseInt(t.count || 0, 10)
                            })
                        })
                    }
                    var i = (0, c.renderLabelSvg)(t.hexColor),
                        h = r.createElement(l.default, {
                            text: t.name,
                            ellipsify: !0,
                            titlify: !0
                        });
                    return r.createElement(n.default, {
                        theme: "label-selection",
                        image: i,
                        primary: h
                    })
                }
            }
            var f = (0, h.default)(p);
            t.default = f
        },
        96996: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(68580)),
                l = s(a(18120)),
                o = a(75459),
                d = s(a(23539)),
                u = s(a(44156)),
                c = s(a(20642)),
                h = s(a(38362));
            class p extends r.PureComponent {
                constructor() {
                    super(), this._refLastLabel = null, this.updateData = (e, t, a) => {
                        var {
                            shouldScrollIntoViewAndSelect: s
                        } = this.props;
                        this.setState({
                            labels: d.default.toArray()
                        }, (() => {
                            if (a.add && s) {
                                var {
                                    shouldScrollIntoView: t,
                                    shouldSelect: i
                                } = s(e.name);
                                t && this._refLastLabel && this._refLastLabel.scrollIntoView({
                                    behavior: "smooth"
                                }), i && this.onMultiSelect(e, !0, !1)
                            }
                        }))
                    }, this._setRefLastLabel = e => {
                        this._refLastLabel = e
                    }, this.onMultiSelect = (e, t, a) => {
                        var {
                            selectedLabels: s,
                            onMultiSelect: i
                        } = this.props;
                        s && s.setVal(e, t, a), i && i(e.id)
                    }, this._renderLabelRow = () => {
                        var {
                            renderContext: e,
                            onLabelClick: t,
                            initialLabelState: a = {}
                        } = this.props, s = this.props.SelectableState || new h.default(!0), i = l.default.supportsFeature(l.default.F.MD_BACKEND) ? [...this.state.labels].sort(((e, t) => {
                            var a = parseInt(e.id, 10),
                                s = parseInt(t.id, 10);
                            return isNaN(a) || isNaN(s) ? 0 : a - s
                        })) : this.state.labels;
                        return i.reduce(((l, c, h) => {
                            var p = d.default.assertGet(c.id);
                            if (!c.name) return l;
                            var f = "label-selection" === e || (0, o.canEditLabel)() ? r.createElement(n.default, {
                                theme: e,
                                model: p,
                                initialSelection: a[c.id] || 0,
                                multiSelection: this.props.selectedLabels,
                                selectableState: s,
                                onSelect: this.onMultiSelect
                            }, r.createElement(u.default, {
                                label: c.id
                            })) : r.createElement(u.default, {
                                label: c.id,
                                theme: e
                            });
                            return [...l, r.createElement("div", {
                                key: "label_item_".concat(c.id),
                                ref: h === i.length - 1 ? this._setRefLastLabel : () => {},
                                onClick: t ? t.bind(null, c.id) : () => {}
                            }, f)]
                        }), [])
                    }, this.state = {
                        labels: d.default.toArray()
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(d.default, "add remove", this.updateData)
                }
                render() {
                    return r.createElement("div", null, this._renderLabelRow())
                }
            }
            var f = (0, c.default)(p);
            t.default = f
        },
        7266: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "LiveLocationDrawer", {
                enumerable: !0,
                get: function() {
                    return i.default
                }
            }), Object.defineProperty(t, "ExpiredLocationDrawer", {
                enumerable: !0,
                get: function() {
                    return r.default
                }
            });
            var i = s(a(97264)),
                r = s(a(89926))
        },
        20620: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.requireBundle = void 0;
            var r = i(a(2784)),
                n = s(a(89028)),
                l = s(a(50935)),
                o = s(a(17957)),
                d = s(a(91755)),
                u = (0, s(a(95561)).default)((() => Promise.all([a.e(8295), a.e(1702), a.e(9488), a.e(275)]).then(a.bind(a, 70482)).then((e => e.default))), "ContactUsModal");
            t.requireBundle = u;
            var c = (0, n.default)({
                loader: u,
                loading: e => r.createElement(d.default, {
                    title: o.default.t(1304),
                    okText: o.default.t(1236),
                    error: Boolean(e.error)
                }),
                delay: l.default.LOADABLE_DELAY
            });
            t.default = c
        },
        11285: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(a(98537)),
                r = a(99888),
                n = s(a(74185));
            class l {
                constructor(e, t, a, s) {
                    this.updateEditData = e => {
                        this.saveEdits(), this.editData = (0, i.default)({}, this.editData, e)
                    }, this.updateEditItems = (e, t) => {
                        this.saveEdits();
                        var a = [];
                        this.editData.items && this.editData.items.forEach((e => {
                            e !== t && a.push(e)
                        })), a.push(e), this.editData.items = a
                    }, this.saveEdits = () => {
                        var e = new l(this.media, this.originalImage, this.editData, this.previous);
                        this.previous = e
                    }, this.revertEdit = () => {
                        this.previous && (this.editData = this.previous.editData, this.previous = this.previous.previous)
                    }, this.saveEditsFromCanvas = e => {
                        var t = e.toDataURL();
                        this.editedImage || (this.editedImage = new Image), this.editedImage.src = t
                    }, this.exportEditedMedia = () => {
                        if (this.hasEdits() && this.editedImage) {
                            var e = this.editedImage.src;
                            return n.default.dataURLtoFile(e)
                        }
                        return this.media instanceof File ? this.media : (0, r.createFile)([this.media], "", {
                            type: this.media.type
                        })
                    }, this.hasEdits = () => !!this.previous && this.editedImage, this.cleanUp = () => {
                        window.URL.revokeObjectURL(this.originalImage.src)
                    }, this.media = e, t ? this.originalImage = t : (this.originalImage = new Image, this.originalImage.src = window.URL.createObjectURL(e)), this.previous = s, this.editData = {
                        height: 0,
                        width: 0,
                        offsetX: 0,
                        offsetY: 0,
                        rotation: 0,
                        scale: 1,
                        items: [],
                        baseItem: null
                    }, (0, i.default)(this.editData, a)
                }
            }
            t.default = l
        },
        5680: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.Component = void 0;
            var r = a(37426),
                n = i(a(2784)),
                l = s(a(50935)),
                o = i(a(44202)),
                d = s(a(20642)),
                u = s(a(73621)),
                c = s(a(82631)),
                h = 1.1;
            class p extends n.Component {
                constructor(...e) {
                    super(...e), this._validateTranslate = (e, t) => {
                        var a = this.props.editedMedia.editData,
                            s = (e - a.width / 2) * a.scale,
                            i = (e + a.width / 2) * a.scale,
                            r = (t + a.height / 2) * a.scale,
                            n = (t - a.height / 2) * a.scale;
                        return {
                            x: s < -this._cropRadius && i > this._cropRadius,
                            y: n < -this._cropRadius && r > this._cropRadius
                        }
                    }, this._validateScale = e => {
                        var t = this.props.editedMedia.editData,
                            a = Math.max(2 * this._cropRadius / t.width, 2 * this._cropRadius / t.height),
                            s = Math.max(e, a);
                        if (t.width * e < this._cropRadius || t.height * e < this._cropRadius) return !1;
                        var i = -this._cropRadius / s + t.width / 2,
                            r = this._cropRadius / s - t.width / 2,
                            n = -this._cropRadius / s + t.height / 2,
                            l = this._cropRadius / s - t.height / 2;
                        return {
                            scale: s,
                            offsetX: Math.min(Math.max(t.offsetX, r), i),
                            offsetY: Math.min(Math.max(t.offsetY, l), n)
                        }
                    }, this._onPressMove = (e, t) => {
                        var a = this.props.editedMedia.editData,
                            s = e.stageX - t.x,
                            i = e.stageY - t.y,
                            r = a.offsetX + s / a.scale,
                            n = a.offsetY + i / a.scale,
                            l = this._validateTranslate(r, n);
                        l.x && (a.offsetX = r), l.y && (a.offsetY = n), t.x = e.stageX, t.y = e.stageY, this.props.drawCanvas()
                    }, this._onEnlarge = (e = 1.1) => {
                        var t = this.props.editedMedia.editData,
                            a = 0 !== e ? e : h,
                            s = this._validateScale(t.scale * a);
                        s && (t.scale = s.scale, t.offsetX = s.offsetX, t.offsetY = s.offsetY, this.props.drawCanvas())
                    }, this._onReduce = (e = 1.1) => {
                        var t = this.props.editedMedia.editData,
                            a = 0 !== e ? e : h,
                            s = this._validateScale(t.scale / a);
                        s && (t.scale = s.scale, t.offsetX = s.offsetX, t.offsetY = s.offsetY, this.props.drawCanvas())
                    }, this.crop = () => {
                        var e, t = this.props.editedMedia,
                            a = t.editData,
                            s = t.editedImage && t.editedImage.src;
                        if (!s) return Promise.reject("empty image");
                        var i = 2 * this._cropRadius,
                            r = i;
                        return i > l.default.MAX_PIC_SIDE ? r = l.default.MAX_PIC_SIDE : i < l.default.MIN_PIC_SIDE && (r = l.default.MIN_PIC_SIDE), o.crop(s, (a.width - 2 * this._cropRadius) / 2, (a.height - 2 * this._cropRadius) / 2, 2 * this._cropRadius, 2 * this._cropRadius, r, r, o.DATA_URL | o.CANVAS).then((({
                            images: t
                        }) => (e = t.dataUrl, o.crop(t.canvas, 0, 0, l.default.PROF_PIC_THUMB_SIDE, l.default.PROF_PIC_THUMB_SIDE)))).then((({
                            images: t
                        }) => ({
                            thumb: t.dataUrl,
                            full: e
                        })))
                    }
                }
                render() {
                    return n.createElement("div", {
                        className: u.default.scaler
                    }, n.createElement("div", {
                        className: u.default.scalerButton,
                        onClick: () => {
                            this._onEnlarge()
                        }
                    }, n.createElement(c.default, {
                        name: "plus"
                    })), n.createElement("div", {
                        className: u.default.scalerButton,
                        onClick: () => {
                            this._onReduce()
                        }
                    }, n.createElement(c.default, {
                        name: "minus"
                    })))
                }
                componentDidMount() {
                    this.props.editedMedia.saveEdits();
                    var e, t = this.props.editedMedia.editData,
                        a = this.props.cropOverlay,
                        s = a.canvas;
                    e = t.baseItem ? t.baseItem.getBounds() : {
                        width: 0,
                        height: 0
                    }, s.style.display = "block", s.width = e.width, s.height = e.height;
                    var i = new r.Easel.Shape;
                    i.graphics.beginFill("rgba(0, 0, 0, 0.1)"), i.graphics.drawRect(0, 0, e.width, e.height), i.regX = e.width / 2, i.regY = e.height / 2, i.x = e.width / 2, i.y = e.height / 2, i.on("mousedown", (e => {
                        var t = {
                                x: e.stageX,
                                y: e.stageY
                            },
                            a = i.on("pressmove", this._onPressMove, null, !1, t);
                        i.on("pressup", (() => {
                            i.off("pressmove", a)
                        }), null, !0)
                    })), i.cursor = "move", this.props.listeners.add(s, "mousewheel", (e => {
                        e.deltaY > 0 ? this._onEnlarge(1.02) : this._onReduce(1.02)
                    }));
                    var n = s.getContext("2d"),
                        l = s.width,
                        o = s.height,
                        d = l / o > 500 / 361 ? o / 361 : l / 500;
                    this._cropRadius = Math.min(361, 500) / 2 * .9 * d, n.fillStyle = "rgba(0, 0, 0, 0.5)", n.fillRect(0, 0, l, o), n.globalCompositeOperation = "destination-out", n.beginPath(), n.arc(l / 2, o / 2, this._cropRadius, 0, 2 * Math.PI, !0), n.fillStyle = "#ffffff", n.fill(), a.addChild(i), a.update()
                }
            }
            var f = p;
            t.Component = f;
            var m = (0, d.default)(p);
            t.default = m
        },
        80605: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(4085)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = s(a(50935)),
                u = s(a(17957)),
                c = a(51905),
                h = i(a(23539)),
                p = a(74282),
                f = a(49984),
                m = s(a(40210)),
                v = s(a(2825)),
                _ = s(a(52100));
            class E extends r.Component {
                constructor(e) {
                    super(e), this._labelModel = null, this.onOk = () => {
                        var {
                            labelName: e,
                            labelColor: t,
                            labelNameError: a
                        } = this.state;
                        if (!a) {
                            (0, p.logLabelOperationEvent)(m.default.LABEL_OPERATIONS.CLICK_POSITIVE, 1, this.props.onAddLabel ? m.default.LABEL_TARGETS.ADD_LABEL_DIALOG : m.default.LABEL_TARGETS.EDIT_LABEL_DIALOG);
                            var s = e && e.trim(),
                                i = this._validateLabelName(s || "");
                            i.passed ? (this.props.labelId && this.props.onUpdateLabel ? this.props.onUpdateLabel({
                                id: this.props.labelId,
                                color: t,
                                name: e
                            }, h.LABEL_PROPERTIES.NAME) : this.props.onAddLabel && this.props.onAddLabel(e || "", t), this.props.onCancel ? this.props.onCancel() : l.default.closeModal()) : this.setState({
                                labelNameError: i.error
                            })
                        }
                    }, this.onCancel = () => {
                        (0, p.logLabelOperationEvent)(m.default.LABEL_OPERATIONS.CLICK_NEGATIVE, 1, this.props.onAddLabel ? m.default.LABEL_TARGETS.ADD_LABEL_DIALOG : m.default.LABEL_TARGETS.EDIT_LABEL_DIALOG), this.props.onCancel ? this.props.onCancel() : l.default.closeModal()
                    }, this._onLabelNameChange = e => {
                        var t = this._validateLabelName(e);
                        this.setState({
                            labelName: e,
                            labelNameError: t.passed ? void 0 : t.error
                        })
                    }, this._validateLabelName = e => {
                        var t = !0,
                            a = null;
                        return e && "" !== e.trim() || (t = !1), this._labelModel && this._labelModel.name === e || 0 === h.default.where({
                            name: e
                        }).length || (t = !1, a = u.default.t(209)), {
                            passed: t,
                            error: a
                        }
                    }, this._handleKeyEnter = e => {
                        e.stopPropagation(), this.onOk()
                    }, this.props.labelId && (this._labelModel = h.default.assertGet(this.props.labelId)), this.state = {
                        labelColor: this._labelModel && this._labelModel.color || void 0,
                        labelName: this._labelModel && this._labelModel.name || "",
                        labelNameError: void 0
                    }
                }
                componentDidMount() {
                    this.props.onAddLabel ? (h.default.getNewLabelColor().then((e => {
                        this.setState({
                            labelColor: e || d.default.DEFAULT_SMB__NEW_LABEL_COLOR
                        })
                    })), (0, p.logLabelOperationEvent)(m.default.LABEL_OPERATIONS.VIEW, 1, m.default.LABEL_TARGETS.ADD_LABEL_DIALOG)) : this.props.onUpdateLabel && (0, p.logLabelOperationEvent)(m.default.LABEL_OPERATIONS.VIEW, 1, m.default.LABEL_TARGETS.EDIT_LABEL_DIALOG)
                }
                render() {
                    var e = !this._validateLabelName(this.state.labelName.trim()).passed;
                    return r.createElement(o.default, {
                        title: this.props.onUpdateLabel ? u.default.t(566) : u.default.t(212),
                        okText: u.default.t(1680),
                        onOK: this.onOk,
                        okDisabled: e,
                        onCancel: this.onCancel
                    }, r.createElement("div", {
                        className: n.default.inputContainer
                    }, r.createElement("div", {
                        className: n.default.label
                    }, this.state.labelColor ? (0, f.renderLabelSvg)((0, c.intColorToHex)(this.state.labelColor)) : r.createElement(v.default, {
                        stroke: 5,
                        size: 20
                    })), r.createElement("div", {
                        className: n.default.input
                    }, r.createElement(_.default, {
                        a8n: "add-new-label-name-input",
                        focusOnMount: !0,
                        hideFloatingLabel: !0,
                        showRemaining: !0,
                        supportsEmoji: !0,
                        value: this.state.labelName,
                        error: this.state.labelNameError,
                        maxLength: d.default.SMB_LABELS.MAX_LABEL_LENGTH,
                        onChange: this._onLabelNameChange,
                        onEnter: this._handleKeyEnter,
                        placeholder: u.default.t(211)
                    }))))
                }
            }
            t.default = E
        },
        94180: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(9386)),
                o = s(a(50935)),
                d = a(19741),
                u = s(a(35387)),
                c = s(a(17957)),
                h = a(83974),
                p = a(93649),
                f = a(38350),
                m = a(40263),
                v = s(a(52100)),
                _ = i(a(75074));
            class E extends r.PureComponent {
                constructor(...e) {
                    super(...e), this.state = {
                        isSubmitting: !1,
                        submitted: !1,
                        reason: ""
                    }, this._onInputChange = e => {
                        this.setState({
                            reason: e
                        })
                    }, this._handleOk = () => {
                        var {
                            product: e,
                            sessionId: t
                        } = this.props;
                        (0, h.logAppealProductCatalogClick)(t), this.setState({
                            isSubmitting: !0
                        }), (0, p.appealProduct)(e.id.toString(), this.state.reason).then((() => {
                            e.canAppeal = !1, e.reviewStatus = f.PRODUCT_REVIEW_STATUS.PENDING, (0, h.logAppealProductCatalogSuccess)(t), this.setState({
                                isSubmitting: !1,
                                submitted: !0
                            })
                        })).catchType(d.ServerStatusCodeError, (e => {
                            n.default.openToast(r.createElement(_.default, {
                                msg: c.default.t(415),
                                id: (0, _.genId)("catalog_appeal_submission_failed")
                            })), (0, h.logAppealProductCatalogFailed)(t, e.status), this.setState({
                                isSubmitting: !1
                            })
                        }))
                    }, this._handleCancel = () => {
                        n.default.closeModal()
                    }
                }
                render() {
                    var {
                        submitted: e,
                        isSubmitting: t,
                        reason: a
                    } = this.state;
                    return e ? r.createElement(l.default, {
                        title: c.default.t(1184),
                        onOK: this._handleCancel
                    }, r.createElement(m.TextDiv, null, c.default.t(423))) : r.createElement(l.default, {
                        title: c.default.t(1184),
                        onOK: this._handleOk,
                        onCancel: this._handleCancel,
                        okDisabled: t
                    }, r.createElement("form", null, r.createElement(v.default, {
                        a8n: "confirm-popup-text-input",
                        placeholder: c.default.t(821),
                        onChange: this._onInputChange,
                        value: a,
                        maxLength: 1e3
                    }), r.createElement(u.default, {
                        href: o.default.WA_COMMERCE_POLICY_URL
                    }, c.default.t(825))))
                }
            }
            t.default = E
        },
        48163: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = a(26360),
                o = i(a(97152)),
                d = i(a(75720)),
                u = i(a(4440)),
                c = i(a(86432)),
                h = i(a(74531)),
                p = i(a(65803)),
                f = i(a(51717)),
                m = i(a(9779)),
                v = i(a(41353)),
                _ = i(a(79711)),
                E = i(a(9386)),
                g = i(a(50935)),
                C = i(a(28515)),
                S = i(a(48535)),
                I = i(a(58701)),
                y = i(a(73023)),
                M = s(a(71311)),
                T = a(555),
                P = s(a(96452)),
                L = a(99888),
                b = i(a(6660)),
                w = i(a(44343)),
                N = i(a(17957)),
                O = i(a(20642)),
                D = i(a(2446)),
                R = i(a(40210)),
                k = a(41501),
                A = i(a(72259)),
                x = i(a(94461)),
                U = i(a(72424)),
                F = i(a(2825)),
                B = i(a(82631)),
                V = s(a(75074)),
                G = i(a(74824)),
                {
                    IMAGE: H,
                    VIDEO: j,
                    DOCUMENT: W,
                    AUDIO: K
                } = g.default.MSG_TYPE,
                {
                    PROCESSING: z
                } = l.ATTACH_MEDIA_STATE;
            class Y extends n.Component {
                static getDerivedStateFromProps(e, t) {
                    var a = e.mediaCollection.getActive(),
                        s = e.initCaption && e.initCaption.text,
                        i = t.isInitCaptionUsed;
                    return i || t.activeMedia || !s || !a || a.type !== H && a.type !== j || (a.caption = s, i = !0), {
                        prevActiveMedia: t.activeMedia,
                        activeMedia: a,
                        isInitCaptionUsed: i
                    }
                }
                constructor(e) {
                    super(e), this._attachMediaRefMap = new Map, this.setRefContainer = e => {
                        this.refContainer = e
                    }, this.setRefInput = e => {
                        this.refInput = e
                    }, this._setAttachMediaRef = (e, t) => {
                        this._attachMediaRefMap.set(e, t)
                    }, this._onMediaProcessUpdate = () => {
                        var {
                            mediaCollection: e
                        } = this.props;
                        if (e.canSend()) {
                            clearTimeout(this._mediaProcessTimer), this._mediaProcessTimer = null, this.setState({
                                showLoadingState: !1
                            });
                            var {
                                errorMsgs: t
                            } = e.uiProcessMsgs(), a = e.getPreviewableMedias();
                            t && a.length > 0 && _.default.openToast(n.createElement(V.default, {
                                msg: t,
                                id: (0, V.genId)()
                            })), this.forceUpdate()
                        } else this._mediaProcessTimer || (this._mediaProcessTimer = setTimeout((() => {
                            this._mediaProcessTimer = null, this.setState({
                                showLoadingState: !0
                            })
                        }), 500))
                    }, this._onFilesNotSupported = () => {
                        var e = this.props.mediaCollection.filter((e => e.exception));
                        e.length > 0 && this.props.onFailedMedias(e)
                    }, this._showIgnoredToast = e => {
                        if (e > 0) {
                            var t = N.default.t(1329, {
                                number: e,
                                _plural: e
                            });
                            _.default.openToast(n.createElement(V.default, {
                                msg: t,
                                id: (0, V.genId)()
                            }))
                        }
                    }, this.onDrop = e => {
                        this.onFilePick(e)
                    }, this.onDragLeave = () => {
                        this.props.mediaCollection.length || this.props.onBack()
                    }, this.onDragChange = (e, t) => {
                        this.setState({
                            isDragging: e
                        }), e || t || this.props.mediaCollection.length || this.props.onBack()
                    }, this.onEnter = e => {
                        this.state.activeMedia && (e.repeat || e.shiftKey || this.onSend())
                    }, this._onArrowLeft = e => {
                        if (this.state.activeMedia && !e.repeat) {
                            var t = this.state.activeMedia && !this.state.activeMedia.caption,
                                a = this.refCaptionInput && this.refCaptionInput.refInput;
                            (t || a && !a.isFocused() || a && a.cursorIsAtStart()) && this.onPrev()
                        }
                    }, this._onArrowRight = e => {
                        if (this.state.activeMedia && !e.repeat) {
                            var t = this.state.activeMedia && !this.state.activeMedia.caption,
                                a = this.refCaptionInput && this.refCaptionInput.refInput;
                            (t || a && !a.isFocused() || a && a.cursorIsAtEnd()) && this.onNext()
                        }
                    }, this.onNext = () => {
                        this.props.mediaCollection.setNextAsActive() && (this._refSendButton && b.default.focus(this._refSendButton), this._scrollIntoView())
                    }, this.onPrev = () => {
                        this.props.mediaCollection.setPrevAsActive() && (this._refSendButton && b.default.focus(this._refSendButton), this._scrollIntoView())
                    }, this._scrollIntoView = () => {
                        var e = this.props.mediaCollection.getActive();
                        if (e) {
                            var t = this._attachMediaRefMap.get(e.id);
                            t && t.scrollIntoView()
                        }
                    }, this.onSelectThumb = e => {
                        this.props.mediaCollection.setActive(e)
                    }, this.onSend = e => {
                        e && e.preventDefault(), e && e.shiftKey || this.props.mediaCollection.canSend() && Promise.all([]).then((() => {
                            var e = this.props.mediaCollection.getPreviewableMedias();
                            if (0 !== e.length) {
                                var t = e.map((e => {
                                    var t = e.caption,
                                        a = [],
                                        s = this.refCaptionInput && this.refCaptionInput.refInput;
                                    if (t && s) {
                                        var i = s.serialize(t),
                                            [r, n] = [i[0].trim(), i[1]];
                                        r.length && (t = r, a = n.mentionedJidList || [])
                                    }
                                    return e.caption = t || void 0, {
                                        media: e,
                                        mentionedJidList: a
                                    }
                                }));
                                this.props.onSendMedia(t, this.state.isInitCaptionUsed, this.state.isViewOnce)
                            }
                        }))
                    }, this.onAddFileClick = () => {
                        this.refInput && this.refInput.click()
                    }, this.onFilePick = e => {
                        (0, T.getFiles)(e).then((e => this.props.mediaCollection.processAttachments(e.map((e => ({
                            file: e
                        }))), R.default.MEDIA_PICKER_ORIGIN_TYPE.CHAT_PHOTO_LIBRARY))).checkpoint(this.props.rejectOnUnmount()).catchType(P.Unmount, (() => {})).catchType(P.MediaDragDropError, (e => {
                            this.props.mediaCollection.length || this.props.onDropText(e.src)
                        })), e.target && e.target.value && (e.target.value = "")
                    }, this._onRemoveThumb = (e, t) => {
                        t.stopPropagation(), t.preventDefault(), this.props.mediaCollection.remove(e), 0 === this.props.mediaCollection.getValidMedias().length ? this._delayedClose = setTimeout((() => {
                            this.props.onBack()
                        }), 200) : this._refSendButton && b.default.focus(this._refSendButton)
                    }, this.onCaptionChange = e => {
                        var {
                            activeMedia: t,
                            isInitCaptionUsed: a
                        } = this.state;
                        if (t) {
                            var s = this.props.mediaCollection.indexOf(t);
                            t.caption = e, 0 === s && "" === e && a ? this.setState({
                                isInitCaptionUsed: !1
                            }) : this.forceUpdate()
                        }
                    }, this.onPaste = e => {
                        e.preventDefault(), e.stopPropagation();
                        var t = new C.default(e.clipboardData);
                        t.hasFiles() && this.onFiles(t)
                    }, this.onFiles = e => {
                        var t = e.getFiles().filter((e => {
                            var t = (0, L.typeFromMimetype)(e.type);
                            return "image" === t || "video" === t
                        })).map((e => ({
                            file: e
                        })));
                        this.props.mediaCollection.processAttachments(t, R.default.MEDIA_PICKER_ORIGIN_TYPE.PASTE)
                    }, this._onViewOnceChange = e => {
                        this.setState({
                            isViewOnce: e
                        })
                    }, this.setRefCaptionInput = e => {
                        this.state.activeMedia && !e || (this.refCaptionInput = e)
                    }, this._canViewOnce = () => {
                        var e, {
                            mediaCollection: t
                        } = this.props;
                        return U.default.viewOnceWrite && 1 === t.length && !0 === (null === (e = t.at(0)) || void 0 === e ? void 0 : e.isViewableOnce())
                    }, this._getMedia = e => {
                        var t, a, s;
                        switch (e.type) {
                            case H:
                            case j:
                                t || (t = n.createElement(p.default, {
                                    mimeType: e.mimetype,
                                    url: e.fullPreview,
                                    isGif: e.isGif,
                                    size: e.fullPreviewSize,
                                    processing: e.state === z,
                                    preview: e.preview
                                })), a = n.createElement("div", {
                                    className: o.default.captionInput,
                                    "data-animate-media-caption": !0
                                }, n.createElement(D.default, {
                                    ref: this.setRefCaptionInput,
                                    value: e.caption,
                                    placeholder: N.default.t(198),
                                    maxLength: g.default.MAX_CAPTION_LENGTH,
                                    onEnter: this.onSend,
                                    onChange: this.onCaptionChange,
                                    onFiles: this.onFiles,
                                    chat: this.props.chat,
                                    showRemaining: !0,
                                    spellCheck: !0,
                                    multiline: !0,
                                    supportsEmoji: !0
                                }), this._canViewOnce() ? n.createElement(m.default, {
                                    isOn: this.state.isViewOnce,
                                    mediaType: e.type,
                                    onChange: this._onViewOnceChange
                                }) : null);
                                break;
                            case K:
                                t = n.createElement(u.default, {
                                    mimeType: e.mimetype,
                                    url: e.fullPreview
                                });
                                break;
                            case W:
                                switch ((0, k.previewType)(e.mimetype)) {
                                    case "pdf":
                                        t = n.createElement(f.default, {
                                            fullPreview: e.fullPreview,
                                            fullPreviewSize: e.fullPreviewSize,
                                            pageCount: e.documentPageCount,
                                            mimeType: e.mimetype,
                                            filename: e.filename
                                        });
                                        break;
                                    case "msoffice":
                                        t = n.createElement(c.default, {
                                            fullPreview: e.fullPreview,
                                            fullPreviewSize: e.fullPreviewSize,
                                            mimeType: e.mimetype,
                                            filename: e.filename
                                        });
                                        break;
                                    default:
                                        t = n.createElement(h.default, {
                                            mimeType: e.mimetype,
                                            filename: e.filename
                                        })
                                }
                        }
                        return "image/gif" === e.originalMimetype && (s = n.createElement("div", {
                            className: o.default.mediaWarning,
                            "data-animate-attach-media": !0
                        }, N.default.t(895), " ", n.createElement(v.default, {
                            onClick: this._onWarningCtaClick
                        }, N.default.t(825)))), n.createElement("div", {
                            className: o.default.mediaBody,
                            key: e.id
                        }, t, s, a)
                    }, this._onWarningCtaClick = e => {
                        e.preventDefault(), _.default.openModal(n.createElement(E.default, {
                            onOK: () => _.default.closeModal()
                        }, N.default.t(686)))
                    }, this.getThumbs = e => e.map((e => n.createElement(d.default, {
                        id: e.id,
                        key: "media-" + e.id,
                        active: e === this.state.activeMedia,
                        attachMedia: e,
                        onClick: this.onSelectThumb,
                        onClose: this._onRemoveThumb,
                        onRef: this._setAttachMediaRef
                    }))), this._setRefSendButton = e => {
                        this._refSendButton = e
                    }, this.state = {
                        activeMedia: null,
                        prevActiveMedia: null,
                        isDragging: !1,
                        isInitCaptionUsed: !1,
                        isViewOnce: !1,
                        showLoadingState: !1
                    }
                }
                componentDidMount() {
                    var {
                        mediaCollection: e,
                        listeners: t
                    } = this.props;
                    t.add(e, "add remove reset", (() => {
                        this.forceUpdate()
                    })), t.add(e, "active-change change:state change:previewable", this._onMediaProcessUpdate), t.add(e, "files_not_supported", this._onFilesNotSupported), t.add(e, "max_upload_limit", this._showIgnoredToast), e.mediaPickerStatsLogger.resumeTimer()
                }
                componentDidUpdate(e, t) {
                    !t.activeMedia && this.state.activeMedia && this.refCaptionInput ? this.props.listeners.uiIdle((() => {
                        this.refCaptionInput && this.refCaptionInput.restoreFocus()
                    })) : this._refSendButton && this.refContainer && !this.refContainer.contains(document.activeElement) && b.default.focus(this._refSendButton)
                }
                componentWillUnmount() {
                    this._delayedClose && clearTimeout(this._delayedClose), this._mediaProcessTimer && clearTimeout(this._mediaProcessTimer), this.props.mediaCollection.mediaPickerStatsLogger.pauseTimer()
                }
                render() {
                    var e, t, a, {
                            mediaCollection: s
                        } = this.props,
                        {
                            activeMedia: i,
                            prevActiveMedia: l
                        } = this.state,
                        d = 0,
                        u = s.getPreviewableMedias();
                    u.length > g.default.MAX_FILES && (u = u.slice(0, g.default.MAX_FILES)), this.state.showLoadingState ? e = n.createElement(F.default, {
                        key: "processing",
                        color: "highlight"
                    }) : i ? e = this._getMedia(i) : 0 === u.length && s.errorMsgs && (e = n.createElement("div", {
                        className: o.default.invalidContainer,
                        key: "pending"
                    }, n.createElement("div", {
                        className: o.default.invalidMedia
                    }, s.errorMsgs))), u.length > 0 && (t = this.getThumbs(u), d = 1 === u.length ? 400 : 400 + (150 + 15 * u.length), a = this.state.showLoadingState ? null : n.createElement("div", {
                        className: o.default.btnSend,
                        tabIndex: "-1",
                        ref: this._setRefSendButton,
                        onKeyPress: e => e.preventDefault()
                    }, n.createElement(x.default, {
                        large: !0,
                        onClick: this.onSend
                    }, n.createElement(B.default, {
                        name: "send",
                        directional: !0
                    }))));
                    var c = this.state.isDragging ? n.createElement(S.default, null) : null,
                        h = u.length < g.default.MAX_FILES ? n.createElement("div", {
                            className: (0, r.default)(o.default.btnAdd, {
                                [o.default.btnAddDisabled]: this.state.isViewOnce
                            }),
                            key: "media-more",
                            onClick: this.state.isViewOnce ? void 0 : this.onAddFileClick,
                            role: "button"
                        }, n.createElement(B.default, {
                            name: "add-alt"
                        }), n.createElement("div", {
                            className: o.default.btnAddText
                        }, N.default.t(204))) : null,
                        p = {
                            enter: this.onEnter,
                            left: this._onArrowLeft,
                            right: this._onArrowRight
                        },
                        f = "*" === k.DOC_MIMES ? "*" : [g.default.IMAGE_MIMES, g.default.VIDEO_MIMES, k.DOC_MIMES].join(),
                        m = "media-scale";
                    return i && l && i !== l && (m = s.indexOf(i) > s.indexOf(l) ? "media-slide-forward" : "media-slide-back"), n.createElement(w.default, {
                        handlers: p,
                        onRef: this.setRefContainer
                    }, n.createElement(I.default, {
                        key: "attach-image-modal",
                        theme: "media",
                        onDrop: this.onDrop,
                        onDragChange: this.onDragChange
                    }, n.createElement(M.default, {
                        title: N.default.t(1730),
                        type: M.DRAWER_HEADER_TYPE.OFFSET,
                        onCancel: this.props.onBack
                    }), n.createElement(y.default, {
                        tabIndex: "-1",
                        overflow: "hidden",
                        onPaste: this.onPaste
                    }, c, n.createElement("div", {
                        className: o.default.body
                    }, n.createElement(G.default, {
                        transitionName: m
                    }, e)), n.createElement("div", {
                        className: o.default.thumbs
                    }, n.createElement(G.default, {
                        transitionAppear: !0,
                        transitionName: "thumb-scale",
                        className: o.default.thumbsContainer
                    }, t), h), n.createElement(G.default, {
                        transitionAppear: !0,
                        transitionName: "btn",
                        delay: d
                    }, a), n.createElement("input", {
                        ref: this.setRefInput,
                        type: "file",
                        accept: f,
                        style: {
                            display: "none"
                        },
                        onChange: this.onFilePick,
                        multiple: !0
                    }))))
                }
            }
            var q = (0, A.default)((0, O.default)(Y));
            t.default = q
        },
        75720: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = i(a(42208)),
                l = i(a(72779)),
                o = s(a(2784)),
                d = i(a(73366)),
                u = i(a(50935)),
                c = a(41501),
                h = i(a(40207)),
                p = a(64658),
                f = i(a(82631));

            function m() {
                var e = (0, r.default)(["media is"]);
                return m = function() {
                    return e
                }, e
            }
            var {
                IMAGE: v,
                VIDEO: _,
                DOCUMENT: E,
                AUDIO: g
            } = u.default.MSG_TYPE, C = (0, n.default)(c.MIMETYPES, (e => e.msgType === E));
            class S extends o.PureComponent {
                constructor(...e) {
                    super(...e), this._onClick = e => {
                        this.props.onClick && this.props.onClick((0, p.unproxy)(this.props.attachMedia), e)
                    }, this._onClose = e => {
                        this.props.onClose && this.props.onClose((0, p.unproxy)(this.props.attachMedia), e)
                    }, this.setRef = e => {
                        e && this.props.onRef(this.props.id, e)
                    }
                }
                _renderBody() {
                    var e, t, a, s = this.props.attachMedia;
                    switch (s.type) {
                        case v:
                            a = {
                                backgroundImage: "url(".concat(s.preview, ")")
                            }, e = o.createElement("div", {
                                className: d.default.body,
                                style: a
                            });
                            break;
                        case _:
                            a = {
                                backgroundImage: "url(data:image/jpeg;base64,".concat(s.preview, ")")
                            }, e = o.createElement("div", {
                                className: d.default.body,
                                style: a
                            });
                            break;
                        case g:
                            e = o.createElement("div", {
                                className: (0, l.default)(d.default.body, "attach-media-audio-thumb")
                            });
                            break;
                        case E:
                            if (__LOG__(2)(m()), s.preview) {
                                var i = {
                                    backgroundImage: "url(" + s.preview + ")"
                                };
                                e = o.createElement("div", {
                                    className: d.default.body,
                                    style: i
                                });
                                break
                            }
                            C[s.mimetype] && (t = C[s.mimetype].icon);
                        default:
                            t = (0, l.default)(d.default.body, d.default.bodyDoc, t, {
                                "icon-doc-generic": !t
                            }), e = o.createElement("div", {
                                className: t
                            })
                    }
                    return e
                }
                render() {
                    var e = (0, l.default)(d.default.thumb, {
                        [d.default.active]: this.props.active
                    });
                    return o.createElement("div", {
                        className: e,
                        onClick: this._onClick,
                        role: "button",
                        ref: this.setRef
                    }, o.createElement("div", {
                        className: d.default.btnDelete,
                        onClick: this._onClose,
                        role: "button"
                    }, o.createElement(f.default, {
                        name: "x-alt"
                    })), this._renderBody())
                }
            }
            S.CONCERNS = {
                attachMedia: ["mimetype", "preview", "type"]
            };
            var I = (0, h.default)(S, S.CONCERNS);
            t.default = I
        },
        4440: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function({
                mimeType: e,
                url: t
            }) {
                return r.createElement("div", {
                    className: n.default.container,
                    "data-animate-attach-media": !0
                }, r.createElement("div", {
                    className: n.default.media
                }, r.createElement("audio", {
                    controls: !0,
                    type: e,
                    src: t
                })))
            };
            var r = i(a(2784)),
                n = s(a(59335))
        },
        86432: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function({
                fullPreview: e,
                fullPreviewSize: t,
                mimeType: a,
                filename: s
            }) {
                return e && t ? r.createElement("div", {
                    className: n.default.container,
                    "data-animate-attach-media": !0
                }, r.createElement("div", {
                    className: n.default.preview
                }, r.createElement(d.default, {
                    type: "scaleDown",
                    size: t
                }, r.createElement("img", {
                    alt: o.default.t(1730),
                    src: e,
                    className: n.default.img
                })))) : r.createElement(l.default, {
                    mimeType: a,
                    filename: s
                })
            };
            var r = i(a(2784)),
                n = s(a(11793)),
                l = s(a(74531)),
                o = s(a(17957)),
                d = s(a(88352))
        },
        74531: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function({
                mimeType: e,
                filename: t
            }) {
                var a = (0, l.default)(o.default.icon, u[e] ? u[e].icon : "icon-doc-generic");
                return n.createElement("div", {
                    className: o.default.container,
                    "data-animate-attach-media": !0
                }, n.createElement("div", {
                    className: o.default.media
                }, n.createElement("div", {
                    className: o.default.document
                }, n.createElement("div", {
                    className: a
                }), n.createElement("div", {
                    className: o.default.text
                }, t))))
            };
            var r = i(a(42208)),
                n = s(a(2784)),
                l = i(a(72779)),
                o = i(a(32001)),
                d = a(41501),
                u = (0, r.default)(d.MIMETYPES, (e => "document" === e.msgType))
        },
        65803: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function({
                mimeType: e,
                url: t,
                isGif: a,
                size: s,
                processing: i,
                preview: n
            }) {
                var c;
                switch (m[e].msgType) {
                    case "image":
                        c = o.createElement("img", {
                            alt: u.default.t(1730),
                            src: t,
                            className: d.default.img
                        });
                        break;
                    case "video":
                        var v = a ? {
                                loop: !i,
                                autoPlay: !i,
                                muted: !1,
                                controls: !1
                            } : {},
                            _ = i ? o.createElement("div", {
                                className: d.default.spinner
                            }, o.createElement(p.default, {
                                color: p.colorOptions.white,
                                size: 50,
                                stroke: 3
                            })) : null,
                            E = n ? o.createElement("img", {
                                alt: u.default.t(1730),
                                className: d.default.staticPreview,
                                src: "data:image/jpeg;base64,".concat(n)
                            }) : null,
                            g = i ? null : o.createElement(f.default, (0, r.default)({
                                controls: !0,
                                controlsList: "nodownload nofullscreen",
                                className: d.default.video
                            }, v, {
                                src: t
                            }));
                        c = o.createElement("div", {
                            className: (0, l.default)(d.default.img, d.default.videoContainer)
                        }, _, g, E);
                        break;
                    case "audio":
                        c = o.createElement("audio", {
                            controls: !0,
                            className: d.default.audio,
                            type: e,
                            src: t
                        })
                }
                return o.createElement("div", {
                    className: d.default.container,
                    "data-animate-attach-media": !0
                }, o.createElement("div", {
                    className: d.default.media
                }, o.createElement(h.default, {
                    type: "scaleDown",
                    size: s
                }, c)))
            };
            var r = i(a(58527)),
                n = i(a(42208)),
                l = i(a(72779)),
                o = s(a(2784)),
                d = i(a(12621)),
                u = i(a(17957)),
                c = a(41501),
                h = i(a(88352)),
                p = s(a(2825)),
                f = i(a(15668)),
                m = (0, n.default)(c.MIMETYPES, (e => "image" === e.msgType || "video" === e.msgType))
        },
        51717: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function({
                fullPreview: e,
                fullPreviewSize: t,
                pageCount: a,
                mimeType: s,
                filename: i
            }) {
                if (e && t && null != a && a > 0) {
                    var u = o.default.t(234, {
                        count: a,
                        _plural: a
                    });
                    return r.createElement("div", {
                        className: l.default.container,
                        "data-js-attach-preview": !0
                    }, r.createElement("div", {
                        className: l.default.preview
                    }, r.createElement(d.default, {
                        type: "scaleDown",
                        size: t
                    }, r.createElement("img", {
                        alt: o.default.t(1730),
                        src: e,
                        className: l.default.img
                    }))), r.createElement("div", {
                        className: l.default.caption
                    }, u))
                }
                return r.createElement(n.default, {
                    mimeType: s,
                    filename: i
                })
            };
            var r = i(a(2784)),
                n = s(a(74531)),
                l = s(a(96757)),
                o = s(a(17957)),
                d = s(a(88352))
        },
        9779: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function({
                isOn: e,
                mediaType: t,
                onChange: a
            }) {
                var [s, i] = n.useState((0, c.shouldShowNUX)(u.default.NUX.EPHEMERAL_VIEW_ONCE));
                return n.useEffect((() => {
                    if (e) {
                        if (!s) {
                            var a = t === p.TYPE.VIDEO ? h.default.t(1402) : h.default.t(1401),
                                r = n.createElement(m.default, {
                                    msg: a,
                                    id: (0, m.genId)("view-once-toast")
                                });
                            return d.default.openToast(r), () => {
                                d.default.closeToast(r)
                            }
                        }
                        var l = n.createElement(o.default, {
                            onOkClick: () => {
                                i(!1), d.default.closeModal()
                            }
                        });
                        d.default.openModal(l)
                    }
                }), [s, t, e]), n.createElement(v.default, {
                    "aria-pressed": e,
                    className: (0, r.default)(l.default.btnViewOnce, {
                        [l.default.btnViewOnceActive]: e
                    }),
                    onClick: () => a(!e)
                }, n.createElement(f.default, {
                    "aria-label": e ? h.default.t(29) : h.default.t(30),
                    name: "view-once"
                }))
            };
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(30933)),
                o = i(a(99379)),
                d = i(a(79711)),
                u = i(a(50935)),
                c = a(95595),
                h = i(a(17957)),
                p = a(27e3),
                f = i(a(82631)),
                m = s(a(75074)),
                v = i(a(5174))
        },
        99379: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return r.useEffect((() => () => {
                    (0, p.setNUX)(o.default.NUX.EPHEMERAL_VIEW_ONCE, {
                        views: 1,
                        maxViews: 1
                    })
                }), []), r.createElement(l.default, {
                    onOK: e.onOkClick,
                    cancelText: f.default.t(825),
                    onCancel: () => {
                        (0, u.openExternalLink)((0, c.getViewOnceFaqUrl)())
                    }
                }, r.createElement(h.FlexColumn, null, r.createElement(d.default, {
                    type: "view-once"
                }), r.createElement(m.TextHeader, {
                    className: n.default.text,
                    theme: "popup-title"
                }, f.default.t(1399)), r.createElement(m.TextParagraph, {
                    className: n.default.text
                }, f.default.t(1397)), r.createElement(m.TextParagraph, {
                    className: n.default.text
                }, f.default.t(1398))))
            };
            var r = i(a(2784)),
                n = s(a(32661)),
                l = s(a(9386)),
                o = s(a(50935)),
                d = s(a(56241)),
                u = a(35387),
                c = a(95585),
                h = a(90973),
                p = a(95595),
                f = s(a(17957)),
                m = a(40263)
        },
        64946: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(25291)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = a(43322),
                d = i(a(31377)),
                u = i(a(79148)),
                c = i(a(79711)),
                h = i(a(9386)),
                p = i(a(65219)),
                f = i(a(7470)),
                m = i(a(77977)),
                v = i(a(58701)),
                _ = i(a(73023)),
                E = i(a(6162)),
                g = s(a(71311)),
                C = a(20485),
                S = i(a(35598)),
                I = i(a(63097)),
                y = i(a(22004)),
                M = i(a(17957)),
                T = i(a(20642)),
                P = i(a(82631));
            class L extends n.Component {
                constructor(...e) {
                    super(...e), this.flatListController = new y.default, this._onBlockConfirm = e => {
                        (0, o.blockContact)(e).catch((() => {})), c.default.closeModal()
                    }, this.onBlock = () => {
                        c.default.openModal(n.createElement(m.default, {
                            title: M.default.t(201),
                            filter: function(e) {
                                return !!f.default.isFilteredContact(e) && (!u.default.get(e.id) || M.default.t(1101))
                            },
                            onCancel: () => c.default.closeModal(),
                            onSelect: (0, r.default)(this._onBlockConfirm)
                        }))
                    }, this._onUnblockConfirm = e => {
                        (0, o.unblockContact)(e).catch((() => {})), c.default.closeModal()
                    }, this._onUnblockCancel = () => {
                        c.default.closeModal()
                    }, this._onUnblock = (e, t) => {
                        c.default.openModal(n.createElement(h.default, {
                            okText: M.default.t(1336),
                            onOK: this._onUnblockConfirm.bind(this, t),
                            cancelText: M.default.t(1518),
                            onCancel: this._onUnblockCancel
                        }, M.default.t(1337, {
                            contact: t.formattedName
                        })))
                    }, this.renderItem = e => {
                        var {
                            blocklist: t
                        } = e, a = t.contact();
                        return n.createElement(p.default, {
                            contact: a,
                            key: a.id.toString(),
                            onClick: this._onUnblock,
                            onDelete: this._onUnblock,
                            waitIdle: !0
                        })
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(u.default, "add remove", (() => {
                        this.forceUpdate()
                    }))
                }
                getData() {
                    return u.default.map((e => ({
                        itemKey: e.id.toString(),
                        blocklist: e
                    })))
                }
                render() {
                    var e, t;
                    return u.default.length > 0 ? (e = n.createElement(I.default, {
                        flatListControllers: [this.flatListController],
                        className: d.default.list
                    }, n.createElement(S.default, {
                        flatListController: this.flatListController,
                        direction: "vertical",
                        data: this.getData(),
                        renderItem: this.renderItem
                    })), t = n.createElement("div", {
                        "data-a8n": l.default.key("blocked-description"),
                        className: d.default.hint
                    }, M.default.t(200))) : e = n.createElement(C.Blocked, null), n.createElement(v.default, null, n.createElement(g.default, {
                        title: M.default.t(275),
                        onBack: this.props.onClose,
                        type: g.DRAWER_HEADER_TYPE.LARGE
                    }), n.createElement("div", {
                        className: d.default.button
                    }, n.createElement(E.default, {
                        a8nText: "li-add-blocked",
                        onClick: this.onBlock,
                        icon: n.createElement(P.default, {
                            name: "add-user",
                            directional: !0
                        })
                    }, M.default.t(201))), n.createElement(_.default, null, e, t))
                }
            }
            var b = (0, T.default)(L);
            t.default = b
        },
        90059: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = i(a(72779)),
                l = a(39329),
                o = s(a(2784)),
                d = i(a(83764)),
                u = i(a(79711)),
                c = i(a(50935)),
                h = i(a(58701)),
                p = i(a(73023)),
                f = s(a(71311)),
                m = s(a(96452)),
                v = s(a(45356)),
                _ = a(13414),
                E = s(a(44202)),
                g = i(a(17957)),
                C = i(a(44422)),
                S = i(a(2446)),
                I = s(a(16622)),
                y = i(a(40210)),
                M = i(a(88352)),
                T = i(a(25012)),
                P = i(a(72259)),
                L = i(a(94461)),
                b = i(a(2825)),
                w = i(a(82631)),
                N = i(a(74185)),
                O = i(a(74824)),
                D = i(a(15668));

            function R() {
                var e = (0, r.default)(["captureDrawer:render Unhandled video capture state ", ""]);
                return R = function() {
                    return e
                }, e
            }

            function k() {
                var e = (0, r.default)(["Assertion failed!"]);
                return k = function() {
                    return e
                }, e
            }

            function A() {
                var e = (0, r.default)(["Assertion failed!"]);
                return A = function() {
                    return e
                }, e
            }

            function x() {
                var e = (0, r.default)(["CaptureDrawer:onCapture can not get 2d context"]);
                return x = function() {
                    return e
                }, e
            }
            var U = "ANIMATING",
                F = "LOADING",
                B = "RECORDING",
                V = "SENDING";
            class G extends o.PureComponent {
                constructor(...e) {
                    super(...e), this.state = {
                        state: U,
                        stream: void 0,
                        img: void 0,
                        caption: void 0,
                        videoSize: void 0
                    }, this.videoRef = null, this._startTimer = new l.ShiftTimer((e => {
                        this.loadNewStream(e)
                    })), this.loadNewStream = e => {
                        e ? (this.setState({
                            state: F,
                            stream: e
                        }), (0, I.isSrcObjectInVideoElement)() || (e ? (window.URL.revokeObjectURL(this.url), this.url = window.URL.createObjectURL(e)) : (window.URL.revokeObjectURL(this.url), this.url = void 0))) : this.state.state === U && this.setState({
                            state: F
                        })
                    }, this._stopStreamTimer = new l.ShiftTimer((e => {
                        e && I.stop(e), (0, I.isSrcObjectInVideoElement)() || (this.url = window.URL.revokeObjectURL(this.url))
                    })), this.onCapture = () => {
                        if (this.videoRef) {
                            var e = this.videoRef.underlyingVideo();
                            if (e) {
                                var {
                                    chat: t
                                } = this.props, a = document.createElement("canvas");
                                a.height = e.videoHeight, a.width = e.videoWidth;
                                var s = a.getContext("2d");
                                if (s) {
                                    s.translate(a.width, 0), s.scale(-1, 1), s.drawImage(e, 0, 0, e.videoWidth, e.videoHeight);
                                    var i = this.props.onCaptured;
                                    if (i) E.canvasToBlob(a).then((e => {
                                        i(e)
                                    }));
                                    else {
                                        this._stopStreamTimer.onOrBefore(500, this.state.stream), this._mediaLogger = new C.default, this._mediaLogger.logAdd("CAPTURE_MEDIA", "image", y.default.MEDIA_PICKER_ORIGIN_TYPE.MENU_CAMERA_CAPTURE), this._mediaLogger.chatRecipients = t && t.groupMetadata ? t.groupMetadata.participants.length : 1;
                                        var r = a.toDataURL("image/jpeg");
                                        this.setState({
                                            state: V,
                                            stream: void 0,
                                            img: r
                                        })
                                    }
                                } else __LOG__(3)(x())
                            }
                        }
                    }, this.onVideoLoaded = e => {
                        this.setState({
                            state: B,
                            videoSize: {
                                width: e.videoWidth,
                                height: e.videoHeight
                            }
                        })
                    }, this.onRetake = () => {
                        this.setState({
                            state: F,
                            caption: void 0
                        });
                        var e = I.start("camera");
                        Promise.race([e, this.props.rejectOnUnmount()]).checkpoint(this.props.rejectOnUnmount()).then((e => {
                            e && ((0, I.isSrcObjectInVideoElement)() || (this.url = window.URL.createObjectURL(e)), this.setState({
                                stream: e
                            }))
                        })).catchType(m.Unmount, (() => {
                            e.then((e => I.stop(e))).catch((() => {}))
                        })).catchType(m.GUM.NotAllowedError, (() => {
                            this.props.onBack(), u.default.openModal(o.createElement(v.default, {
                                messaging: v.Messaging.CAMERA_FAIL,
                                type: v.default.TYPE.GUIDE_UNBLOCK
                            }))
                        })).catchType(m.GUM.GUMError, (() => {
                            this.props.onBack(), u.default.openModal(o.createElement(v.default, {
                                messaging: v.Messaging.CAMERA_MISSING,
                                type: v.default.TYPE.GUIDE_NONE
                            }))
                        }))
                    }, this.onSend = () => {
                        var {
                            img: e,
                            caption: t
                        } = this.state, a = this.props.onSend;
                        if (a)
                            if (e) {
                                var s = this.refCaptionInput && this.refCaptionInput.refInput,
                                    i = [];
                                if (t && s) {
                                    var r = s.serialize(t),
                                        [n, l] = [r[0].trim(), r[1]];
                                    n.length && (t = n, i = l.mentionedJidList || [])
                                }
                                a({
                                    getImg: T.default.createFromBase64Jpeg(N.default.parseDataURL(e).data),
                                    caption: t,
                                    mentionedJidList: i
                                }), this._mediaLogger.logSend()
                            } else e || (__LOG__(4, void 0, new Error, !0)(k()), SEND_LOGS("capture-drawer-no-img"));
                        else a || (__LOG__(4, void 0, new Error, !0)(A()), SEND_LOGS("capture-drawer-no-onSend"))
                    }, this.onCaptionChange = e => {
                        this.setState({
                            caption: e
                        })
                    }, this.setRefCaptionInput = e => {
                        this.refCaptionInput = e
                    }
                }
                componentDidMount() {
                    this._startTimer.onOrBefore(300, this.props.stream)
                }
                componentWillUnmount() {
                    this._startTimer.cancel(), this.url && window.URL.revokeObjectURL(this.url), this.state.stream && I.stop(this.state.stream), this._mediaLogger && this._mediaLogger.logCancel()
                }
                render() {
                    var e, t, a, s, i, r = "capture-cover" === this.props.theme ? "cover" : "contain";
                    switch (this.state.state) {
                        case U:
                        case F:
                            if (i = o.createElement(b.default, {
                                    stroke: 4,
                                    size: 50
                                }), this.state.state === U) break;
                        case B:
                            var l = (0, n.default)(d.default.video, {
                                    [d.default.videoInactive]: this.state.stream && this.state.state === F
                                }),
                                u = this.state.stream ? o.createElement(D.default, {
                                    autoPlay: !0,
                                    ref: (0, _.GetRef)((e => {
                                        this.videoRef = e
                                    })),
                                    onPlay: this.onVideoLoaded,
                                    src: this.url ? this.url : void 0,
                                    srcObject: this.url ? void 0 : this.state.stream
                                }) : null;
                            a = this.state.stream ? o.createElement("div", {
                                key: "webcam"
                            }, o.createElement(M.default, {
                                type: r,
                                size: this.state.videoSize
                            }, o.createElement("div", {
                                className: l,
                                "data-animage-capture-webcam": !0
                            }, u))) : null, e = this.state.state === B ? o.createElement("div", {
                                className: d.default.btn,
                                key: "btn-capture"
                            }, o.createElement(L.default, {
                                large: !0,
                                onClick: this.onCapture
                            }, o.createElement(w.default, {
                                name: "camera"
                            }))) : null;
                            break;
                        case V:
                            a = o.createElement(M.default, {
                                type: r,
                                size: this.state.videoSize
                            }, o.createElement("img", {
                                alt: "",
                                className: d.default.image,
                                "data-animate-capture-snapshot": !0,
                                src: this.state.img
                            })), e = o.createElement("div", {
                                className: (0, n.default)(d.default.btn, d.default.btnSend),
                                key: "btn-send"
                            }, o.createElement(L.default, {
                                large: !0,
                                onClick: this.onSend
                            }, o.createElement(w.default, {
                                name: "send",
                                directional: !0
                            }))), t = o.createElement("div", {
                                className: d.default.retakeBtn,
                                onClick: this.onRetake
                            }, o.createElement("div", {
                                className: d.default.retakeIcon
                            }, o.createElement(w.default, {
                                name: "return"
                            })), g.default.t(1186)), s = this.props.chat ? o.createElement(S.default, {
                                ref: this.setRefCaptionInput,
                                chat: this.props.chat,
                                maxLength: c.default.MAX_CAPTION_LENGTH,
                                multiline: !0,
                                onEnter: this.onSend,
                                onChange: this.onCaptionChange,
                                placeholder: g.default.t(198),
                                showRemaining: !0,
                                spellCheck: !0,
                                supportsEmoji: !0,
                                value: this.state.caption
                            }) : null;
                            break;
                        default:
                            __LOG__(2)(R(), this.state.state)
                    }
                    var m = this.props.caption ? o.createElement(O.default, {
                        transitionName: "media-caption",
                        className: d.default.caption
                    }, s) : null;
                    return o.createElement(h.default, {
                        key: "attach-capture-modal",
                        theme: this.props.theme
                    }, o.createElement(f.default, {
                        title: g.default.t(1316),
                        type: f.DRAWER_HEADER_TYPE.OFFSET,
                        onCancel: this.props.onBack
                    }, t), o.createElement(p.default, {
                        overflow: "hidden"
                    }, o.createElement("div", {
                        className: d.default.container
                    }, i, o.createElement("div", {
                        className: d.default.body
                    }, o.createElement(O.default, {
                        transitionName: "capture",
                        className: d.default.videoContainer
                    }, a))), o.createElement("div", {
                        className: d.default.footer
                    }, m, o.createElement(O.default, {
                        transitionName: "pop_delay"
                    }, e))))
                }
            }
            G.defaultProps = {
                caption: !1
            };
            var H = (0, P.default)(G);
            t.default = class extends H {
                constructor(...e) {
                    super(...e), this.loadNewStream = e => {
                        this.getComponent().loadNewStream(e)
                    }
                }
            }
        },
        65434: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(2167)),
                o = i(a(47519)),
                d = a(90973),
                u = i(a(17957)),
                c = i(a(20642));
            class h extends n.Component {
                constructor(e) {
                    super(e)
                }
                render() {
                    return n.createElement("div", {
                        className: (0, r.default)(o.default.container)
                    }, n.createElement(d.FlexRow, {
                        align: "start",
                        justify: "start",
                        wrap: "wrap"
                    }, this.props.categories.map((e => n.createElement(l.default, {
                        "aria-label": u.default.t(28),
                        key: e.id.toString(),
                        className: o.default.chip,
                        onClick: () => this.props.onRemoveItem(e.id),
                        label: e.localized_display_name,
                        postfixIcon: "round-x-inv"
                    })))))
                }
            }
            var p = (0, c.default)(h);
            t.default = p
        },
        55086: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(60417)),
                n = s(a(2784)),
                l = i(a(44572)),
                o = i(a(96066)),
                d = i(a(7470)),
                u = i(a(51317)),
                c = i(a(23069)),
                h = i(a(58701)),
                p = i(a(73023)),
                f = s(a(71311)),
                m = a(20485),
                v = i(a(22004)),
                _ = i(a(38147)),
                E = i(a(6660)),
                g = i(a(44343)),
                C = i(a(17957)),
                S = i(a(81610)),
                I = i(a(46821)),
                y = i(a(11498)),
                M = i(a(82631)),
                T = i(a(67134));
            class P extends n.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        searchText: ""
                    }, this.setSearch = e => {
                        this.search = e
                    }, this.setRefList = e => {
                        this.refList = e
                    }, this.flatListController = new v.default, this.onSearch = e => {
                        this.searchText = e, this._onSearch(e)
                    }, this._onSearch = this.props.debounce((e => {
                        this.setState({
                            searchText: e
                        })
                    }), 100), this.onFocusList = e => {
                        this.refList && (e.preventDefault(), e.stopPropagation(), _.default.shouldIndicateFocus(), this.refList && this.refList.focusFirst())
                    }, this.onSelectFirst = e => {
                        e.preventDefault(), e.stopPropagation();
                        var t = this.frequentContacts[0];
                        if (t) return _.default.shouldIndicateFocus(), void this.props.onClick(e, t);
                        var a = this.getFilteredContacts(this.searchText)[0];
                        a && (_.default.shouldIndicateFocus(), this.props.onClick(e, a))
                    }, this.onFocusSearch = () => {
                        _.default.shouldIndicateFocus(), E.default.focus(this.search)
                    }
                }
                componentDidMount() {
                    E.default.focus(this.search)
                }
                getFilteredContacts(e) {
                    var t = e;
                    if (d.default.ensureSorted(), !(t = "string" == typeof t ? t : this.state.searchText)) return d.default.getFilteredContacts();
                    var a = d.default.getFilteredContacts().concat(d.default.filter((e => e.name && !e.isMe && !e.isPSA && !e.isWAContact)));
                    t = C.default.accentFold(t);
                    var s = (0, I.default)(t);
                    return a.filter((function(e) {
                        return e.searchMatch(t, s)
                    }))
                }
                calculateFrequentContacts() {
                    var {
                        searchText: e
                    } = this.state;
                    if (e) return [];
                    var t = d.default.frequentContacts("message");
                    return (0, r.default)(t)
                }
                render() {
                    var e, t = null,
                        a = this.getFilteredContacts();
                    if (this.frequentContacts = this.calculateFrequentContacts(), e = 0 === a.length ? this.state.searchText ? (0, m.SearchWithKeyword)(this.state.searchText) : (0, m.SearchWithoutKeyword)() : n.createElement(c.default, {
                            ref: this.setRefList,
                            contacts: a,
                            flatListController: this.flatListController,
                            frequentContacts: this.frequentContacts,
                            onClick: this.props.onClick,
                            onFocusSearch: this.onFocusSearch,
                            showPersonGroupDivisionHeader: !!this.state.searchText
                        }), !this.state.searchText) {
                        var s = n.createElement(y.default, null, n.createElement(M.default, {
                            name: "new-group",
                            directional: !0
                        }));
                        t = n.createElement("div", {
                            "data-list-scroll-offset": !0
                        }, n.createElement("div", {
                            className: u.default.newGroupButton
                        }, n.createElement(o.default, {
                            image: s,
                            primary: C.default.t(1660),
                            onClick: this.props.onNewGroup
                        }), n.createElement(l.default, null)))
                    }
                    var i = {
                        down: this.onFocusList
                    };
                    return n.createElement(h.default, {
                        key: "contact-modal"
                    }, n.createElement(f.default, {
                        title: this.props.title,
                        type: f.DRAWER_HEADER_TYPE.LARGE,
                        onBack: this.props.onBack
                    }), n.createElement(g.default, {
                        handlers: i
                    }, n.createElement(S.default, {
                        ref: this.setSearch,
                        onSearch: this.onSearch,
                        onEnter: this.onSelectFirst,
                        placeholder: C.default.t(1200)
                    })), n.createElement(p.default, {
                        flatListControllers: [this.flatListController]
                    }, t, e))
                }
            }
            var L = (0, T.default)(P);
            t.default = L
        },
        23591: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(23109)),
                l = s(a(79711)),
                o = s(a(50935)),
                d = s(a(26583)),
                u = s(a(82034)),
                c = s(a(58701)),
                h = s(a(73023)),
                p = i(a(71311)),
                f = s(a(77875)),
                m = i(a(96452)),
                v = a(75459),
                _ = s(a(98294)),
                E = a(13414),
                g = s(a(19712)),
                C = s(a(17957)),
                S = s(a(20642)),
                I = a(97526),
                y = s(a(58885)),
                M = s(a(92313)),
                T = s(a(57950)),
                P = s(a(16981)),
                L = s(a(72259)),
                b = s(a(72424)),
                w = s(a(2825)),
                N = s(a(40207)),
                O = s(a(82631)),
                D = i(a(75074)),
                R = s(a(58355));
            class k extends r.Component {
                constructor(...e) {
                    super(...e), this.setRefScrollable = e => {
                        this.refScrollable = e
                    }, this.state = {
                        msgInfo: void 0,
                        unimplemented: !1
                    }, this.wrapper = null, this.isMsgVisible = (e, t = !1) => e === this.props.msg.id && (!!t || this.getMsgComponent()), this.onClose = () => {
                        this.props.uim.uie.requestDismiss()
                    }
                }
                componentDidMount() {
                    var e;
                    M.default.find(this.props.msg.id).checkpoint(this.props.rejectOnUnmount()).then((e => {
                        this.setState({
                            msgInfo: e
                        }), this.props.listeners.add(e.played, "add remove", (() => {
                            this.forceUpdate()
                        })), this.props.listeners.add(e.read, "add remove", (() => {
                            this.forceUpdate()
                        })), this.props.listeners.add(e.delivery, "add remove", (() => {
                            this.forceUpdate()
                        }))
                    })).catchType(m.Unmount, (() => {})).catch((() => {
                        this.setState({
                            unimplemented: !0
                        }), l.default.openToast(r.createElement(D.default, {
                            msg: C.default.t(962),
                            id: (0, D.genId)("msg_info_failed")
                        }))
                    }));
                    var t = null === (e = this.refScrollable) || void 0 === e ? void 0 : e.container;
                    this.props.msg.type === o.default.MSG_TYPE.IMAGE && t && (t.scrollTop = t.scrollHeight), this.props.listeners.add(this.props.msg, "remove", ((e, t) => {
                        t === y.default && this.props.uim.uie.requestDismiss()
                    }))
                }
                getMsgComponent() {
                    var e = this.wrapper;
                    if (e) return e.getMsgComponentRef()
                }
                render() {
                    var e, t, a, {
                            msg: s
                        } = this.props,
                        {
                            msgInfo: i,
                            unimplemented: l
                        } = this.state;
                    if (i) {
                        var m, _, S, y, M = [],
                            L = s.type === o.default.MSG_TYPE.PTT;
                        (L || s.isViewOnce) && (t = C.default.t(931), S = (_ = i.played.head()) && _.t, y = r.createElement("span", {
                            className: u.default.icon
                        }, r.createElement(O.default, {
                            name: L ? "status-ptt" : "view-once-viewed",
                            className: u.default.statusBlue
                        })), M.push(r.createElement(d.default, {
                            title: L ? C.default.t(926) : C.default.t(932),
                            t: S,
                            icon: y,
                            key: "played"
                        }))), S = (_ = i.read.head()) && _.t, y = r.createElement("span", {
                            className: u.default.icon
                        }, r.createElement(O.default, {
                            name: "status-dblcheck",
                            className: u.default.ack
                        })), t = null !== (m = t) && void 0 !== m ? m : C.default.t(928), M.push(r.createElement(d.default, {
                            title: t,
                            t: S,
                            icon: y,
                            key: "read"
                        })), S = (_ = i.delivery.head()) && _.t, y = r.createElement("span", {
                            className: u.default.icon
                        }, r.createElement(O.default, {
                            name: "status-dblcheck"
                        })), M.push(r.createElement(d.default, {
                            title: C.default.t(924),
                            t: S,
                            icon: y,
                            key: "delivery"
                        })), !b.default.hfmStringChanges && b.default.frequentlyForwardedMessages && s.numTimesForwarded > 0 && !s.isFrequentlyForwarded && M.push(r.createElement(T.default, {
                            key: "forward",
                            msg: s
                        })), e = r.createElement(f.default, {
                            theme: "padding"
                        }, M)
                    }
                    i || l || (a = r.createElement("div", {
                        className: u.default.spinner,
                        key: "spinner"
                    }, r.createElement(w.default, {
                        size: 50,
                        stroke: 4
                    })));
                    var N = null;
                    return s.labels && s.labels.length && (0, v.canDisplayLabel)() && (N = r.createElement(f.default, {
                        theme: "padding"
                    }, r.createElement(g.default, {
                        labels: s.labels
                    }))), r.createElement(c.default, {
                        key: "message-info-modal",
                        theme: "striped"
                    }, r.createElement(p.default, {
                        title: C.default.t(923),
                        type: p.DRAWER_HEADER_TYPE.SMALL,
                        onCancel: this.onClose
                    }), r.createElement(P.default, {
                        ref: this.setRefScrollable,
                        chatPreference: n.default.assertGet("defaultPreference")
                    }, r.createElement(R.default, {
                        msg: s,
                        ref: (0, E.GetRef)((e => {
                            this.wrapper = e
                        })),
                        displayType: o.default.DISP_TYPE.MSG_INFO,
                        isMsgVisible: this.isMsgVisible,
                        position: I.MsgPosition.END,
                        onProductClick: this.props.onProductClick
                    })), r.createElement(h.default, null, N, r.createElement("div", {
                        className: u.default.body
                    }, a, e)))
                }
            }
            k.CONCERNS = {
                msg: ["id", "star", "type", "isGif", "isViewOnce", "labels", "numTimesForwarded", "isFrequentlyForwarded"]
            };
            var A = (0, _.default)((0, L.default)((0, S.default)((0, N.default)(k, k.CONCERNS))));
            t.default = A
        },
        70482: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(9386)),
                o = s(a(50935)),
                d = s(a(18120)),
                u = s(a(17957)),
                c = a(40263);
            class h extends r.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        description: "",
                        includeDeviceInfo: !0,
                        isSending: !1
                    }, this.onCancel = () => {
                        this.props.onCancel && this.props.onCancel(), n.default.closeModal()
                    }, this.onDescriptionChange = e => {
                        this.setState({
                            description: e,
                            descriptionError: this.validateDescription(e) ? void 0 : this.state.descriptionError
                        })
                    }, this._onIncludeDeviceInfoChange = () => {
                        this.setState({
                            includeDeviceInfo: !this.state.includeDeviceInfo
                        })
                    }, this.validateDescription = e => e.length >= o.default.CONTACT_US_MIN_DESC_LENGTH, this.stopPropagation = e => {
                        e.stopPropagation()
                    }
                }
                componentWillUnmount() {
                    var e, t;
                    !0 === (null === (e = this._sendRequest) || void 0 === e ? void 0 : e.isPending()) && (null === (t = this._sendRequest) || void 0 === t || t.cancel())
                }
                render() {
                    var {
                        isSending: e
                    } = this.state, t = {
                        enter: this.stopPropagation
                    };
                    return e && (t.esc = this.stopPropagation), d.default.supportsFeature(d.default.F.MD_BACKEND), r.createElement(l.default, {
                        okText: u.default.t(1680),
                        onOK: () => n.default.closeModal(),
                        title: u.default.t(1304)
                    }, r.createElement(c.TextParagraph, {
                        theme: "plain"
                    }, u.default.t(1305)))
                }
            }
            t.default = h
        },
        34815: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = i(a(21403)),
                d = i(a(19899)),
                u = i(a(79711)),
                c = i(a(6636)),
                h = i(a(17957)),
                p = i(a(85059)),
                f = i(a(40207)),
                m = a(64658),
                v = a(40263);

            function _(e) {
                return n.createElement("div", {
                    className: (0, r.default)(c.default.section, {
                        [c.default.disabled]: e.disabled
                    })
                }, n.createElement("div", {
                    "data-a8n": l.default.key(e.a8nText),
                    className: c.default.control
                }, n.createElement(o.default, {
                    id: e.id,
                    onChange: e.onChange,
                    checked: e.checked,
                    disabled: e.disabled
                })), n.createElement("label", {
                    className: c.default.label,
                    htmlFor: e.id
                }, e.children))
            }
            class E extends n.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        notifications: p.default.getGlobalNotifications(),
                        sounds: p.default.getGlobalSounds(),
                        previews: p.default.getGlobalPreviews(),
                        collapseMuted: p.default.getCollapseMuted()
                    }, this._onSounds = () => {
                        var e = !this.state.sounds;
                        this.setState({
                            sounds: e
                        }), p.default.setGlobalSounds(e)
                    }, this.onNotifications = () => {
                        var e = !this.state.notifications;
                        this.setState({
                            notifications: e
                        }), p.default.setGlobalNotifications(e)
                    }, this._onPreviews = () => {
                        var e = !this.state.previews;
                        this.setState({
                            previews: e
                        }), p.default.setGlobalPreviews(e)
                    }, this._onCollapseMuted = () => {
                        var e = !this.state.collapseMuted;
                        this.setState({
                            collapseMuted: e
                        }), p.default.setCollapseMuted(e)
                    }, this.onClose = () => {
                        u.default.closeModal()
                    }, this._onMuteDesktopNotifications = () => {
                        u.default.muteAll((0, m.unproxy)(this.props.mute), !this.props.mute.isMuted)
                    }
                }
                render() {
                    var e = [];
                    window.Notification && (e.push(n.createElement(_, {
                        key: 0,
                        a8nText: "option-desktop-notifications",
                        id: "desktop-notifications",
                        checked: this.state.notifications,
                        onChange: this.onNotifications
                    }, h.default.t(1085))), e.push(n.createElement(_, {
                        key: 1,
                        a8nText: "options-msg-previews",
                        disabled: !this.state.notifications,
                        id: "msg-previews",
                        checked: this.state.previews,
                        onChange: this._onPreviews
                    }, h.default.t(1086), n.createElement(v.TextDiv, {
                        theme: "muted"
                    }, h.default.t(1087)))));
                    var t, a = this.props.mute.expiration,
                        s = this.props.mute.isMuted,
                        i = h.default.t(1331);
                    if (s && null != a) {
                        var r = d.default.untilStr(a);
                        t = n.createElement(v.TextDiv, {
                            theme: "muted"
                        }, r)
                    }
                    return n.createElement("div", {
                        className: c.default.container
                    }, n.createElement(_, {
                        a8nText: "option-sounds",
                        id: "sounds",
                        checked: this.state.sounds,
                        onChange: this._onSounds
                    }, h.default.t(1088)), e, undefined, n.createElement(_, {
                        a8nText: "option-mute-desktop-notifications",
                        id: "mute-desktop-notifications",
                        checked: s,
                        onChange: this._onMuteDesktopNotifications
                    }, i, t))
                }
            }
            E.CONCERNS = {
                mute: ["isMuted", "expiration"]
            };
            var g = (0, f.default)(E, E.CONCERNS);
            t.default = g
        },
        48535: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                return r.createElement("div", {
                    key: "container",
                    className: n.default.dropOverlay
                }, r.createElement("div", {
                    className: n.default.dropOverlayOutline
                }, l.default.t(561)))
            };
            var r = i(a(2784)),
                n = s(a(39194)),
                l = s(a(17957))
        },
        89364: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.Component = t.RETRY_OPTIONS = void 0;
            var r = i(a(45455)),
                n = s(a(2784)),
                l = i(a(58701)),
                o = i(a(73023)),
                d = i(a(71311)),
                u = i(a(61286)),
                c = i(a(11285)),
                h = i(a(35387)),
                p = i(a(17957)),
                f = i(a(20642)),
                m = i(a(68332)),
                v = i(a(31762)),
                _ = i(a(88352)),
                E = i(a(5680)),
                g = i(a(94461)),
                C = i(a(82631)),
                S = a(63836),
                I = i(a(74185)),
                y = i(a(74824)),
                M = {
                    NONE: "none",
                    RETAKE: "retake",
                    RESTART: "restart"
                };
            t.RETRY_OPTIONS = M;
            class T extends n.Component {
                constructor(e) {
                    super(e), this._onDoneEditing = () => {
                        var e = this.state.editedMedia;
                        this.saveCanvas(), this._refProfileCropTool && this._refProfileCropTool.getComponent().crop().then((({
                            thumb: t,
                            full: a
                        }) => {
                            this.props.onFinished(t, a), e.cleanUp()
                        }))
                    }, this._onObjectLoad = e => {
                        if (e && e instanceof HTMLElement) {
                            var t = {};
                            !this.state.editorSize || this.state.editorSize.width === e.clientWidth && this.state.editorSize.height === e.clientHeight || (t.editorSize = {
                                width: e.clientWidth,
                                height: e.clientHeight
                            }), this.state.loaded || (t.loaded = !0), (0, r.default)(t) || this.setState(t)
                        }
                    }, this.setRefMediaEditCanvas = e => {
                        this.mediaEditCanvas = e
                    }, this._setRefProfileCropTool = e => {
                        this._refProfileCropTool = e
                    }, this.drawCanvas = (e, t) => {
                        this.mediaEditCanvas && this.mediaEditCanvas.drawCanvas(e, t)
                    }, this.saveCanvas = () => {
                        this.mediaEditCanvas && this.mediaEditCanvas.saveCanvas()
                    }, this.updateCanvasSize = (e, t) => {
                        this.mediaEditCanvas && this.mediaEditCanvas.updateCanvasSize(e, t)
                    }, this.onCanvasInitialized = () => {
                        this.forceUpdate()
                    }, this.state = {
                        doneEditing: !1,
                        loaded: !1,
                        editorSize: {
                            width: 500,
                            height: 361
                        },
                        editedMedia: new c.default(e.img)
                    }, this.mediaEditController = new v.default
                }
                componentDidMount() {
                    this.props.listeners.add(this.mediaEditController, "change:isInitialized", this.onCanvasInitialized)
                }
                render() {
                    var e, {
                            attributionUrl: t,
                            onRetake: a,
                            retryText: s
                        } = this.props,
                        i = this.state.loaded ? n.createElement("div", {
                            className: u.default.btnSend,
                            key: "btn-send"
                        }, n.createElement(g.default, {
                            large: !0,
                            onClick: this._onDoneEditing
                        }, n.createElement(C.default, {
                            name: "checkmark-large"
                        }))) : null;
                    this.mediaEditController.isInitialized && (e = n.createElement(E.default, {
                        editedMedia: this.state.editedMedia,
                        stage: this.mediaEditController.stage,
                        cropOverlay: this.mediaEditController.cropOverlay,
                        mediaContainer: this.mediaEditController.mediaContainer,
                        drawCanvas: this.drawCanvas,
                        ref: this._setRefProfileCropTool
                    }));
                    var r, c = n.createElement(m.default, {
                        className: u.default.mediaElement,
                        editedMedia: this.state.editedMedia,
                        mediaEditController: this.mediaEditController,
                        fitType: "cover",
                        ref: this.setRefMediaEditCanvas
                    });
                    if (a) {
                        var f;
                        switch (s) {
                            case M.NONE:
                                f = null;
                                break;
                            case M.RETAKE:
                                f = p.default.t(1186);
                                break;
                            case M.RESTART:
                            default:
                                f = p.default.t(1189)
                        }
                        r = n.createElement("button", {
                            className: u.default.retake,
                            onClick: a
                        }, n.createElement("div", {
                            className: u.default.retakeIcon
                        }, n.createElement(C.default, {
                            name: "return"
                        })), f)
                    }
                    var v = t ? n.createElement("div", {
                            className: u.default.attribution
                        }, n.createElement(h.default, {
                            className: u.default.attributionLink,
                            href: t
                        }, I.default.hostname(t)), n.createElement("span", null, p.default.t(791), " ", n.createElement(h.default, {
                            href: (0, S.getTosUrl)()
                        }, p.default.t(797)))) : null,
                        T = n.createElement("div", {
                            className: u.default.footer
                        }, n.createElement(y.default, {
                            transitionName: "btn"
                        }, i), v),
                        P = this.props.imageSize ? this.props.imageSize : {
                            width: 500,
                            height: 361
                        };
                    return n.createElement(l.default, {
                        key: "attach-edit-modal",
                        theme: "edit"
                    }, n.createElement(d.default, {
                        title: p.default.t(216),
                        type: "offset",
                        onCancel: this.props.onCancel
                    }, r), n.createElement(o.default, {
                        overflow: "hidden"
                    }, n.createElement("div", {
                        className: u.default.mediaBody
                    }, e, n.createElement("div", {
                        className: u.default.containerBackground
                    }, n.createElement(y.default, {
                        transitionName: "capture"
                    }, n.createElement(_.default, {
                        type: "cover",
                        size: P,
                        onObjectLoad: this._onObjectLoad
                    }, c)))), T))
                }
            }
            var P = T;
            t.Component = P;
            var L = (0, f.default)(T);
            t.default = L
        },
        3570: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function({
                frequentlyForwardedCount: e,
                totalCount: t
            }) {
                var a = r.createElement("span", {
                    className: d.default.text
                }, 1 === e && 1 === t ? u.default.t(674) : u.default.t(673), " ", r.createElement(l.default, {
                    href: (0, o.getFrequentlyForwardedFaqUrl)()
                }, u.default.t(825)));
                return r.createElement("div", {
                    className: d.default.wrapper
                }, r.createElement("div", {
                    className: d.default.icon
                }, r.createElement(c.default, {
                    name: "highly-forwarded"
                })), r.createElement(n.default, {
                    theme: "plain",
                    primary: a,
                    idle: !0
                }))
            };
            var r = i(a(2784)),
                n = s(a(96066)),
                l = s(a(35387)),
                o = a(95585),
                d = s(a(55845)),
                u = s(a(17957)),
                c = s(a(82631))
        },
        7388: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(91460),
                n = i(a(2784)),
                l = s(a(96066)),
                o = s(a(79711)),
                d = s(a(98004)),
                u = i(a(46478)),
                c = s(a(58701)),
                h = s(a(73023)),
                p = s(a(6162)),
                f = i(a(71311)),
                m = s(a(91581)),
                v = a(20485),
                _ = a(19741),
                E = i(a(96452)),
                g = a(55600),
                C = s(a(9051)),
                S = s(a(93138)),
                I = s(a(17957)),
                y = s(a(72259)),
                M = a(66615),
                T = s(a(41745)),
                P = s(a(54525)),
                L = s(a(40207)),
                b = s(a(82631)),
                w = i(a(75074)),
                N = "group-invite-link-anchor",
                O = 0,
                D = 1,
                R = 2;
            class k extends n.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        state: O
                    }, this._getErrorMessageFromStatusCode = e => {
                        switch (e) {
                            case 401:
                                return I.default.t(723);
                            case 403:
                                return I.default.t(724);
                            case 404:
                                return I.default.t(725);
                            default:
                                return I.default.t(726)
                        }
                    }, this._handleLoadingErrorStatusCode = e => {
                        var t = this._getErrorMessageFromStatusCode(e);
                        this.props.onBack(), o.default.openToast(n.createElement(w.default, {
                            msg: t,
                            id: (0, w.genId)()
                        }))
                    }, this._handleRevokeGroupInvite = () => {
                        o.default.openModal(n.createElement(S.default, {
                            pushTransition: "none",
                            popTransition: "none",
                            chat: this.props.chat,
                            onConfirm: this._handleConfirmRevokeGroupInvite
                        }), {
                            transition: "modal-flow"
                        })
                    }, this._handleRevokingErrorStatusCode = e => {
                        var t = this._getErrorMessageFromStatusCode(e);
                        this.props.onBack(), o.default.openToast(n.createElement(w.default, {
                            msg: t,
                            id: (0, w.genId)()
                        }))
                    }, this._handleConfirmRevokeGroupInvite = () => {
                        this.setState({
                            state: D
                        });
                        var e = (0, g.revokeGroupInvite)(this.props.groupMetadata);
                        (0, r.delayMs)(500).then((() => e)).checkpoint(this.props.rejectOnUnmount()).then((() => {
                            o.default.openToast(n.createElement(w.default, {
                                msg: I.default.t(729),
                                id: (0, w.genId)()
                            })), this.setState({
                                state: R
                            })
                        })).catchType(_.ServerStatusCodeError, (e => {
                            this._handleRevokingErrorStatusCode(e.statusCode)
                        })).catchType(E.Unmount, (() => {}))
                    }, this._handleSendGroupInviteLink = () => {
                        o.default.openModal(n.createElement(T.default, {
                            chat: this.props.chat
                        }), {
                            transition: "modal-flow"
                        })
                    }, this.handleClickGroupInviteLinkCapture = e => {
                        e.preventDefault(), e.stopPropagation()
                    }, this._renderDrawerBody = () => {
                        var e, t = this.props.groupMetadata;
                        if (this.state.state === O) e = n.createElement(v.LoadingWithText, {
                            text: I.default.t(716)
                        });
                        else if (this.state.state === D) e = n.createElement(v.LoadingWithText, {
                            text: I.default.t(728, {
                                groupName: this.props.chat.contact.name
                            })
                        });
                        else {
                            var a = t.groupInviteLink,
                                s = null;
                            document.queryCommandSupported("copy") && (s = n.createElement(d.default, {
                                elementId: N
                            }));
                            var i = n.createElement(u.default, {
                                    id: this.props.chat.id,
                                    size: 82,
                                    quality: u.DETAIL_IMAGE_QUALITY.HIGH
                                }),
                                r = n.createElement("span", {
                                    className: C.default.linkContainer
                                }, n.createElement(M.SelectableLink, {
                                    id: N,
                                    href: a,
                                    selectable: !0
                                }, a));
                            e = n.createElement(h.default, null, n.createElement(l.default, {
                                image: i,
                                primary: n.createElement(m.default, {
                                    text: this.props.chat.contact.name,
                                    direction: "auto"
                                }),
                                theme: "identity",
                                secondary: r
                            }), n.createElement("div", {
                                className: C.default.descContainer
                            }, I.default.t(721)), n.createElement(P.default, {
                                onClick: this._handleSendGroupInviteLink
                            }), s, n.createElement(p.default, {
                                a8nText: "li-revoke-link",
                                icon: n.createElement(b.default, {
                                    name: "revoke",
                                    className: C.default.icon
                                }),
                                onClick: this._handleRevokeGroupInvite
                            }, I.default.t(718)))
                        }
                        return e
                    }
                }
                componentDidMount() {
                    (0, g.queryGroupInviteCode)(this.props.groupMetadata).checkpoint(this.props.rejectOnUnmount()).then((() => {
                        this.setState({
                            state: R
                        })
                    })).catchType(_.ServerStatusCodeError, (e => {
                        this._handleLoadingErrorStatusCode(e.statusCode)
                    })).catchType(E.Unmount, (() => {}))
                }
                render() {
                    return n.createElement(c.default, null, n.createElement(f.default, {
                        title: I.default.t(720),
                        onBack: this.props.onBack,
                        type: f.DRAWER_HEADER_TYPE.SMALL
                    }), this._renderDrawerBody())
                }
            }
            k.CONCERNS = {
                groupMetadata: ["inviteCode", "groupInviteLink"]
            };
            var A = (0, y.default)((0, L.default)(k, k.CONCERNS));
            t.default = A
        },
        42878: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(9386)),
                o = s(a(7123)),
                d = s(a(17957));
            class u extends r.Component {
                constructor(...e) {
                    super(...e), this._handleCancel = () => {
                        n.default.closeModal()
                    }, this._handleOK = () => {
                        this.props.onConfirm(), n.default.closeModal()
                    }
                }
                render() {
                    return r.createElement(l.default, {
                        title: d.default.t(718),
                        onOK: this._handleOK,
                        okText: d.default.t(718),
                        onCancel: this._handleCancel,
                        cancelText: d.default.t(1518)
                    }, r.createElement("div", {
                        className: o.default.confirmationText
                    }, d.default.t(727, {
                        groupName: this.props.chat.contact.name
                    })))
                }
            }
            t.default = u
        },
        3784: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = i(a(23109)),
                d = i(a(79711)),
                u = i(a(50935)),
                c = i(a(58701)),
                h = i(a(73023)),
                p = s(a(71311)),
                f = i(a(77875)),
                m = s(a(96452)),
                v = s(a(35598)),
                _ = i(a(22004)),
                E = a(75459),
                g = i(a(35327)),
                C = i(a(62420)),
                S = i(a(52754)),
                I = a(21212),
                y = i(a(98294)),
                M = a(13414),
                T = i(a(19712)),
                P = i(a(17957)),
                L = i(a(20642)),
                b = a(97526),
                w = i(a(58885)),
                N = i(a(92313)),
                O = i(a(57950)),
                D = i(a(16981)),
                R = i(a(61941)),
                k = i(a(72259)),
                A = i(a(51908)),
                x = i(a(72424)),
                U = i(a(2825)),
                F = i(a(40207)),
                B = i(a(82631)),
                V = a(40263),
                G = s(a(75074)),
                H = i(a(58355));

            function j() {
                var e = (0, r.default)(["Invalid SECTION for group message info section header"]);
                return j = function() {
                    return e
                }, e
            }
            class W extends n.Component {
                constructor(...e) {
                    super(...e), this.flatListController = new _.default, this.setRefScrollable = e => {
                        this.refScrollable = e
                    }, this.state = {
                        msgInfo: void 0,
                        unimplemented: !1
                    }, this.wrapper = null, this.isMsgVisible = (e, t = !1) => e === this.props.msg.id && (!!t || this.getMsgComponent()), this.onClose = () => {
                        this.props.uim.uie.requestDismiss()
                    }, this._getHeaderAtSection = e => {
                        var t, a;
                        switch (e) {
                            case I.SECTIONS.PLAYED_HEADER:
                                a = n.createElement(B.default, {
                                    name: "status-ptt",
                                    className: C.default.statusBlue
                                }), t = P.default.t(927);
                                break;
                            case I.SECTIONS.READ_HEADER:
                                a = n.createElement(B.default, {
                                    name: "status-dblcheck",
                                    className: C.default.ack
                                }), t = P.default.t(929);
                                break;
                            case I.SECTIONS.DELIVERED_HEADER:
                                a = n.createElement(B.default, {
                                    name: "status-dblcheck"
                                }), t = P.default.t(925);
                                break;
                            case I.SECTIONS.VIEWED_HEADER:
                                a = n.createElement(B.default, {
                                    name: "view-once-viewed",
                                    className: C.default.statusBlue
                                }), t = P.default.t(933);
                                break;
                            default:
                                return __LOG__(4, void 0, new Error)(j()), null
                        }
                        return a = n.createElement("div", {
                            className: C.default.titleIcon
                        }, a), n.createElement("div", {
                            "data-a8n": l.default.key("msg-info-title"),
                            className: C.default.title
                        }, n.createElement(A.default, {
                            side: a,
                            ellipsify: !0
                        }, n.createElement(V.TextSpan, {
                            theme: "section-title"
                        }, t)))
                    }, this._getFooterAtSection = e => {
                        var t = (0, R.default)(this.state.msgInfo, "this.state.msgInfo");
                        return n.createElement(S.default, {
                            key: e,
                            section: e,
                            msgInfo: t
                        })
                    }, this.renderItem = e => "row" === e.kind ? this._getInfoCell(e.participant) : e.type === I.SECTIONS.FORWARD_COUNT ? this._getForwardCount() : e.type === I.SECTIONS.PLAYED_HEADER || e.type === I.SECTIONS.READ_HEADER || e.type === I.SECTIONS.DELIVERED_HEADER || e.type === I.SECTIONS.VIEWED_HEADER ? this._getHeaderAtSection(e.type) : this._getFooterAtSection(e.type)
                }
                componentDidMount() {
                    var e;
                    N.default.find(this.props.msg.id).checkpoint(this.props.rejectOnUnmount()).then((e => {
                        this.setState({
                            msgInfo: e
                        }), this.props.listeners.add(e.played, "add remove", (() => {
                            this.forceUpdate()
                        })), this.props.listeners.add(e.read, "add remove", (() => {
                            this.forceUpdate()
                        })), this.props.listeners.add(e.delivery, "add remove", (() => {
                            this.forceUpdate()
                        }))
                    })).catchType(m.Unmount, (() => {})).catch((() => {
                        this.setState({
                            unimplemented: !0
                        }), d.default.openToast(n.createElement(G.default, {
                            msg: P.default.t(962),
                            id: (0, G.genId)("msg_info_failed")
                        }))
                    }));
                    var t = null === (e = this.refScrollable) || void 0 === e ? void 0 : e.container;
                    this.props.msg.type === u.default.MSG_TYPE.IMAGE && t && (t.scrollTop = t.scrollHeight), this.props.listeners.add(this.props.msg, "remove", ((e, t) => {
                        t === w.default && this.props.uim.uie.requestDismiss()
                    }))
                }
                getAnimateEnterClass(e) {
                    return "animate-enter".concat(-1 === e ? "" : e)
                }
                getMsgComponent() {
                    var e = this.wrapper;
                    if (e) return e.getMsgComponentRef()
                }
                _getInfoCell(e) {
                    return n.createElement(g.default, {
                        msgInfoParticipant: e,
                        contact: e.contact,
                        key: e.id.toString()
                    })
                }
                _getForwardCount() {
                    return x.default.hfmStringChanges ? null : n.createElement("div", {
                        className: C.default.forwardCount
                    }, n.createElement(O.default, {
                        msg: this.props.msg
                    }))
                }
                getData() {
                    var {
                        msg: e
                    } = this.props, {
                        msgInfo: t
                    } = this.state, a = [], s = e.type === u.default.MSG_TYPE.PTT;
                    if (t && (s || e.isViewOnce)) {
                        var i = s ? I.SECTIONS.PLAYED_HEADER : I.SECTIONS.VIEWED_HEADER;
                        a.push({
                            kind: "section",
                            type: i,
                            itemKey: i,
                            height: 50
                        }), a.push(...t.played.map((e => ({
                            participant: e,
                            kind: "row",
                            itemKey: e.id.toString(),
                            height: v.DEFAULT_ITEM_HEIGHT
                        })))), t.playedRemaining > 0 && (i = s ? I.SECTIONS.PLAYED_FOOTER : I.SECTIONS.VIEWED_FOOTER, a.push({
                            kind: "section",
                            type: i,
                            itemKey: i,
                            height: 50
                        }))
                    }
                    return t && (t.read.length > 0 || t.playedRemaining > 0) && (a.push({
                        kind: "section",
                        type: I.SECTIONS.READ_HEADER,
                        itemKey: I.SECTIONS.READ_HEADER,
                        height: 50
                    }), a.push(...t.read.map((e => ({
                        participant: e,
                        kind: "row",
                        itemKey: e.id.toString(),
                        height: v.DEFAULT_ITEM_HEIGHT
                    })))), t.readRemaining > 0 && a.push({
                        kind: "section",
                        type: I.SECTIONS.READ_FOOTER,
                        itemKey: I.SECTIONS.READ_FOOTER,
                        height: 50
                    })), t && (t.delivery.length > 0 || t.deliveryRemaining > 0) && (a.push({
                        kind: "section",
                        type: I.SECTIONS.DELIVERED_HEADER,
                        itemKey: I.SECTIONS.DELIVERED_HEADER,
                        height: 50
                    }), a.push(...t.delivery.map((e => ({
                        participant: e,
                        kind: "row",
                        itemKey: e.id.toString(),
                        height: v.DEFAULT_ITEM_HEIGHT
                    })))), t.deliveryRemaining > 0 && a.push({
                        kind: "section",
                        type: I.SECTIONS.DELIVERED_FOOTER,
                        itemKey: I.SECTIONS.DELIVERED_FOOTER,
                        height: 50
                    })), x.default.frequentlyForwardedMessages && e.numTimesForwarded > 0 && !e.isFrequentlyForwarded && a.push({
                        kind: "section",
                        type: I.SECTIONS.FORWARD_COUNT,
                        itemKey: I.SECTIONS.FORWARD_COUNT,
                        height: 60
                    }), a
                }
                render() {
                    var e, {
                            msg: t
                        } = this.props,
                        {
                            msgInfo: a,
                            unimplemented: s
                        } = this.state;
                    a || s || (e = n.createElement("div", {
                        className: C.default.spinner,
                        key: "spinner"
                    }, n.createElement(U.default, {
                        size: 50,
                        stroke: 4
                    })));
                    var i = this.getData(),
                        r = i.length ? n.createElement(v.default, {
                            flatListController: this.flatListController,
                            direction: "vertical",
                            forceConsistentRenderCount: !1,
                            data: i,
                            renderItem: this.renderItem
                        }) : null,
                        l = null;
                    return t.labels && t.labels.length && (0, E.canDisplayLabel)() && (l = n.createElement(f.default, {
                        theme: "padding"
                    }, n.createElement(T.default, {
                        labels: t.labels
                    }))), n.createElement(c.default, {
                        key: "message-info-modal",
                        theme: "striped"
                    }, n.createElement(p.default, {
                        title: P.default.t(923),
                        type: p.DRAWER_HEADER_TYPE.SMALL,
                        onCancel: this.onClose
                    }), n.createElement(D.default, {
                        ref: this.setRefScrollable,
                        chatPreference: o.default.assertGet("defaultPreference")
                    }, n.createElement(H.default, {
                        msg: t,
                        ref: (0, M.GetRef)((e => {
                            this.wrapper = e
                        })),
                        displayType: u.default.DISP_TYPE.MSG_INFO,
                        isMsgVisible: this.isMsgVisible,
                        position: b.MsgPosition.END,
                        onProductClick: this.props.onProductClick
                    })), n.createElement(h.default, {
                        flatListControllers: [this.flatListController]
                    }, l, e, n.createElement("div", {
                        className: C.default.list
                    }, r)))
                }
            }
            W.CONCERNS = {
                msg: ["id", "star", "type", "isGif", "isViewOnce", "labels", "numTimesForwarded", "isFrequentlyForwarded"]
            };
            var K = (0, y.default)((0, k.default)((0, L.default)((0, F.default)(W, W.CONCERNS))));
            t.default = K
        },
        52754: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = i(a(62420)),
                d = a(21212),
                u = i(a(17957)),
                c = i(a(40207)),
                h = a(40263);

            function p() {
                var e = (0, r.default)(["Invalid SECTION for group message info section footer"]);
                return p = function() {
                    return e
                }, e
            }
            class f extends n.Component {
                render() {
                    var e, t, a;
                    switch (this.props.section) {
                        case d.SECTIONS.PLAYED_FOOTER:
                        case d.SECTIONS.VIEWED_FOOTER:
                            e = this.props.msgInfo.playedRemaining, t = this.props.msgInfo.playedRemaining;
                            break;
                        case d.SECTIONS.READ_FOOTER:
                            e = this.props.msgInfo.readRemaining, t = this.props.msgInfo.readRemaining;
                            break;
                        case d.SECTIONS.DELIVERED_FOOTER:
                            e = this.props.msgInfo.deliveryRemaining, t = this.props.msgInfo.deliveryRemaining;
                            break;
                        default:
                            return __LOG__(4, void 0, new Error)(p()), null
                    }
                    a = null != e && 0 !== e ? {
                        count: e,
                        _plural: t
                    } : {
                        _plural: t
                    };
                    var s = u.default.t(930, a);
                    return n.createElement("div", {
                        "data-a8n": l.default.key("msg-info-remaining"),
                        className: o.default.footer
                    }, n.createElement(h.TextSpan, {
                        theme: "muted"
                    }, s))
                }
            }
            f.CONCERNS = {
                msgInfo: ["playedRemaining", "readRemaining", "deliveryRemaining"]
            };
            var m = (0, c.default)(f, f.CONCERNS);
            t.default = m
        },
        21212: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SECTIONS = void 0;
            var s = a(28103).Mirrored(["DELIVERED_FOOTER", "DELIVERED_HEADER", "FORWARD_COUNT", "PLAYED_FOOTER", "PLAYED_HEADER", "READ_FOOTER", "READ_HEADER", "VIEWED_FOOTER", "VIEWED_HEADER"]);
            t.SECTIONS = s
        },
        17402: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(96066)),
                l = s(a(50935)),
                o = s(a(46478)),
                d = s(a(58701)),
                u = s(a(73023)),
                c = i(a(71311)),
                h = s(a(91581)),
                p = s(a(93601)),
                f = s(a(57739)),
                m = s(a(17957)),
                v = s(a(41967)),
                _ = s(a(84845)),
                E = s(a(15118)),
                g = s(a(72259)),
                C = s(a(94461)),
                S = s(a(82631)),
                I = s(a(52100)),
                y = s(a(74824));
            class M extends r.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        isBusy: !1,
                        inviteComment: m.default.t(748)
                    }, this.setRefParticipantList = e => {
                        this.refParticipantList = e
                    }, this.onClose = () => {
                        var {
                            onClose: e
                        } = this.props;
                        e()
                    }, this._getGroupThumbBase64 = () => {
                        var {
                            gid: e
                        } = this.props, t = E.default.get(e);
                        return new Promise((e => {
                            t && t.img ? (0, p.default)(t.img).then((t => {
                                if (t.ok) return t.blob();
                                e(void 0)
                            })).then((t => {
                                if (t) {
                                    var a = new FileReader;
                                    a.onloadend = function() {
                                        var t = a.result;
                                        if (null != t) {
                                            var s = t.toString().split(",")[1];
                                            e(s)
                                        } else e(void 0)
                                    }, a.readAsDataURL(t)
                                }
                            })).catch((() => e(void 0))) : e(void 0)
                        }))
                    }, this.onSend = () => {
                        var {
                            onSend: e
                        } = this.props, {
                            inviteComment: t
                        } = this.state;
                        this._getGroupThumbBase64().then((a => {
                            e(t, a)
                        }))
                    }, this._onInviteCommentChange = e => {
                        this.setState({
                            inviteComment: e
                        })
                    }, this.setRefEmojiInput = e => {
                        this.refEmojiInput = e
                    }
                }
                render() {
                    var e = r.createElement(C.default, {
                            a8nText: "group-participants-btn",
                            large: !0,
                            onClick: this.onSend
                        }, r.createElement(S.default, {
                            name: "send",
                            directional: !0
                        })),
                        t = r.createElement(o.default, {
                            id: this.props.gid
                        }),
                        a = r.createElement(h.default, {
                            text: this.props.subject
                        });
                    return r.createElement(v.default, {
                        type: "invite"
                    }, r.createElement(d.default, {
                        theme: "invite"
                    }, r.createElement(c.default, {
                        type: c.DRAWER_HEADER_TYPE.POPUP,
                        title: m.default.t(757),
                        onCancel: this.onClose
                    }), r.createElement(u.default, null, r.createElement("div", {
                        className: f.default.search
                    }, r.createElement("div", {
                        "data-list-scroll-container": !0
                    }, r.createElement(_.default, {
                        ref: this.setRefParticipantList,
                        theme: "list-names",
                        contacts: this.props.participants.map((e => e.contact))
                    }))), r.createElement("div", {
                        className: f.default.commentInput
                    }, r.createElement(I.default, {
                        a8n: "groups-v4-invite-add-comment-input",
                        ref: this.setRefEmojiInput,
                        value: this.state.inviteComment,
                        showRemaining: !0,
                        maxLength: l.default.MAX_CAPTION_LENGTH,
                        onChange: this._onInviteCommentChange,
                        theme: "v4-invite-caption",
                        supportsEmoji: !0
                    })), r.createElement(y.default, {
                        transitionName: "btn",
                        className: f.default.onSendInvite
                    }, e), r.createElement("div", {
                        className: f.default.groupInfo
                    }, r.createElement(n.default, {
                        idle: !0,
                        image: t,
                        primary: a,
                        secondary: m.default.t(752),
                        theme: "group_v4_invite"
                    })))))
                }
            }
            var T = (0, g.default)(M);
            t.default = T
        },
        54123: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(54073)),
                n = i(a(90882)),
                l = i(a(16760)),
                o = a(91460),
                d = s(a(2784)),
                u = s(a(13886)),
                c = a(20485),
                h = i(a(17957)),
                p = i(a(12002)),
                f = i(a(46821)),
                m = i(a(73664));
            class v extends d.Component {
                getElement() {
                    this._refEl
                }
                constructor(e) {
                    super(e), this._setRefEl = e => {
                        this._refEl = e
                    }, this.onSelect = (e, t) => {
                        if (t instanceof u.Mode) {
                            var a = t.props.chat;
                            !0 === this.props.filter(a) && this.props.onGroup(t.props.chat)
                        }
                    }, this.onSearch = (0, r.default)((e => {
                        this.setState({
                            searchText: e
                        })
                    }), 100), this.renderItem = e => {
                        var t, a, {
                                onGroup: s,
                                filter: i
                            } = this.props,
                            r = i(e.chat),
                            n = "boolean" != typeof r;
                        return n && (t = r, a = "group-modal"), d.createElement(u.default, {
                            chat: e.chat,
                            contact: e.chat.contact,
                            mode: u.Mode.INFO,
                            active: this.selection,
                            secondary: t,
                            noContext: !0,
                            theme: a,
                            onClick: n ? void 0 : s.bind(null, e.chat)
                        })
                    }, this.selection = new m.default, this.state = {
                        loading: !0,
                        searchText: void 0
                    }
                }
                componentDidMount() {
                    var {
                        chats: e
                    } = this.props;
                    (0, o.delayMs)(300).then((() => Promise.all((0, l.default)((0, n.default)(e, (e => e.groupMetadata.stale)), (e => a(99922).default.update(e.groupMetadata.id).catch((() => {}))))))).then((() => this.setState({
                        loading: !1
                    })))
                }
                getData() {
                    var {
                        chats: e,
                        filter: t
                    } = this.props, {
                        loading: a,
                        searchText: s
                    } = this.state;
                    if (a) return [];
                    var i = h.default.accentFold(s),
                        r = (0, f.default)(i),
                        n = e.filter((e => t(e) && (!i || i && e.contact.searchMatch(i, r))));
                    return this.selection.init(n.filter((e => !0 === t(e))).map((e => e.id))), n.map((e => ({
                        chat: e,
                        itemKey: e.id.toString()
                    })))
                }
                render() {
                    var {
                        onCancel: e
                    } = this.props, {
                        loading: t
                    } = this.state, a = t ? d.createElement(c.Loading, null) : d.createElement(c.SearchGroups, null);
                    return d.createElement(p.default, {
                        title: h.default.t(1639),
                        data: this.getData(),
                        renderItem: this.renderItem,
                        emptyState: a,
                        selection: this.selection,
                        onCancel: e,
                        onSearch: this.onSearch,
                        onSelect: this.onSelect,
                        onRef: this._setRefEl,
                        searchPlaceholder: h.default.t(1203)
                    })
                }
            }
            t.default = v, v.defaultProps = {
                filter: function() {
                    return !0
                }
            }
        },
        83848: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(98150)),
                l = i(a(86634)),
                o = s(a(79711)),
                d = s(a(20620)),
                u = s(a(58701)),
                c = s(a(73023)),
                h = s(a(6162)),
                p = i(a(71311)),
                f = a(35387),
                m = a(95585),
                v = s(a(18120)),
                _ = s(a(43143)),
                E = s(a(17957)),
                g = s(a(65829)),
                C = a(69421),
                S = s(a(40210)),
                I = s(a(40773)),
                y = a(63836),
                M = s(a(77626)),
                T = s(a(95062)),
                P = {
                    id: "animated-doodle",
                    selectors: [".".concat(_.default.animation)],
                    low: {
                        default: n.default
                    },
                    high: {
                        default: n.default
                    }
                };
            class L extends r.Component {
                constructor(...e) {
                    super(...e), this.openTime = -1, this._actionsTaken = !1, this._onTOS = () => {
                        this._actionsTaken = !0, (0, f.openExternalLink)((0, y.getTosUrl)())
                    }, this._onHelpCenter = () => {
                        (0, f.openExternalLink)((0, m.getFaqUrl)()), this._logSessionEvent(S.default.CONTACT_US_EXIT_STATE.FAQ)
                    }, this._onContactUs = () => {
                        o.default.openModal(v.default.supportsFeature(v.default.F.SUPPORT) ? r.createElement(d.default, {
                            onCancel: this.onContactUsCancel
                        }) : r.createElement(I.default, {
                            onCancel: this.onContactUsCancel,
                            onSend: this.onContactUsSend
                        }))
                    }, this._onLicenses = () => {
                        o.default.openModal(r.createElement(g.default, {
                            onOk: this._onLicensesOk
                        }))
                    }, this.onContactUsCancel = () => {
                        this._logSessionEvent(S.default.CONTACT_US_EXIT_STATE.PROBLEM_DESCRIPTION)
                    }, this.onContactUsSend = e => {
                        this._logSessionEvent(S.default.CONTACT_US_EXIT_STATE.EMAIL_SEND, e)
                    }, this._onLicensesOk = () => {}
                }
                componentDidMount() {
                    this.openTime = performance.now(), l.default.loadAsset(P, l.LOAD_PRIORITY.HELP_ANIMATED_DOODLE)
                }
                componentWillUnmount() {
                    this._actionsTaken || this._logSessionEvent(S.default.CONTACT_US_EXIT_STATE.CANCELLED)
                }
                _logSessionEvent(e, t) {
                    (0, C.logSessionEvent)(e, this.openTime, t), this._actionsTaken = !0
                }
                render() {
                    var e;
                    return M.default.isElectron && (e = r.createElement(h.default, {
                        a8nText: "li-licenses",
                        onClick: this._onLicenses
                    }, E.default.t(826))), r.createElement(u.default, null, r.createElement(p.default, {
                        a8n: "drawer-title-help",
                        title: E.default.t(784),
                        onBack: this.props.onClose,
                        type: p.DRAWER_HEADER_TYPE.LARGE
                    }), r.createElement(c.default, null, r.createElement("div", {
                        className: _.default.animation
                    }), r.createElement(T.default, {
                        className: _.default.versionInfo
                    }), r.createElement(h.default, {
                        a8nText: "li-faq",
                        onClick: this._onHelpCenter
                    }, E.default.t(1746)), r.createElement(h.default, {
                        a8nText: "li-contact-us",
                        onClick: this._onContactUs
                    }, E.default.t(1250)), e, r.createElement(h.default, {
                        a8nText: "li-tos",
                        onClick: this._onTOS
                    }, E.default.t(1324)), undefined, undefined))
                }
            }
            t.default = L
        },
        18775: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.Component = void 0;
            var r = i(a(19976)),
                n = i(a(22487)),
                l = i(a(16760)),
                o = i(a(87622)),
                d = s(a(2784)),
                u = s(a(57005)),
                c = i(a(79711)),
                h = i(a(50935)),
                p = i(a(58701)),
                f = i(a(73023)),
                m = s(a(71311)),
                v = a(20485),
                _ = s(a(96452)),
                E = i(a(93601)),
                g = i(a(38147)),
                C = i(a(6660)),
                S = i(a(44343)),
                I = i(a(83994)),
                y = i(a(17957)),
                M = i(a(81610)),
                T = i(a(72259)),
                P = i(a(86169)),
                L = i(a(67134)),
                b = s(a(75074)),
                w = i(a(77626)),
                N = a(86145),
                O = i(a(76022));

            function D() {
                var e = (0, r.default)(["Image search failed"]);
                return D = function() {
                    return e
                }, e
            }

            function R() {
                var e = (0, r.default)(["Image search failed"]);
                return R = function() {
                    return e
                }, e
            }
            class k extends d.Component {
                constructor(e) {
                    super(e), this.setRefSearch = e => {
                        this.refSearch = e
                    }, this._setRefSearchHotkeys = e => {
                        this._refSearchHotkeys = e
                    }, this._setRefGallery = e => {
                        this._refGallery = e
                    }, this._search = (e, t) => {
                        this._hasPendingSearch = !1;
                        var a = u.search(e, t).cancellable().then((t => {
                            a === this._searchPromise && (this._addSearchResults(e, t), this.setState({
                                isSearching: !1
                            }))
                        })).catchType(Promise.CancellationError, (() => {})).catch((() => {
                            __LOG__(3, !0)(R()), c.default.openToast(d.createElement(b.default, {
                                msg: y.default.t(792),
                                id: (0, b.genId)()
                            })), a === this._searchPromise && this.setState({
                                isSearching: !1
                            })
                        })).finally((() => {
                            a === this._searchPromise && (this._searchPromise = null)
                        }));
                        this._searchPromise = a, this.setState({
                            isSearching: !0
                        })
                    }, this._handleUserInput = e => {
                        var t = (e || "").trim();
                        if (!t) return this._cancelSearch(), void this._resetState();
                        (0, N.numCodepoints)(t) < h.default.FTS_MIN_CHARS || t !== this.state.query && (this._cancelSearch(), this._resetState(), this._requestSearch(t))
                    }, this._handleRequestMoreImages = () => {
                        this._hasPendingSearch || this._searchPromise || !this.state.totalEstimatedMatches || this.state.nextOffset >= this.state.totalEstimatedMatches || this._requestSearch(this.state.query, this.state.nextOffset)
                    }, this._handleImageClick = e => {
                        var t = this.state.imageData[e];
                        if (t) {
                            var a = t.contentUrl;
                            (w.default.isElectron ? (0, P.default)((() => (0, E.default)(a))).then((e => {
                                if (200 !== e.status) throw new _.ServerStatusError(null, a, e.status);
                                return e.blob()
                            })) : O.default.downloadImage(a)).checkpoint(this.props.rejectOnUnmount()).then((e => {
                                if (!(e instanceof Blob)) throw new _.ImageError("Server did not respond with image bytes", a);
                                this.props.onImageSelected(e, t.hostPageUrl)
                            })).catchType(_.Unmount, (() => {})).catch((() => {
                                __LOG__(3, !0)(D()), c.default.openToast(d.createElement(b.default, {
                                    msg: y.default.t(789),
                                    id: (0, b.genId)()
                                }))
                            }))
                        }
                    }, this._focusSearch = () => {
                        g.default.shouldIndicateFocus(), C.default.focus(this.refSearch)
                    }, this._focusGallery = e => {
                        e.repeat || this._refGallery && this.refSearch && this.refSearch.cursorIsAtEnd() && (e.preventDefault(), e.stopPropagation(), g.default.shouldIndicateFocus(), null != this._refGallery && C.default.focus(this._refGallery))
                    }, this._handleSearchFocus = () => {
                        g.default.maybeIndicateFocus(this._refSearchHotkeys)
                    }, this.state = {
                        imageData: {},
                        isSearching: !1,
                        nextOffset: 0,
                        query: "",
                        thumbnails: [],
                        totalEstimatedMatches: 0
                    }, this._hasPendingSearch = !1, this._searchPromise = null, this._debouncedSearch = this.props.debounce(this._search, 750)
                }
                componentWillUnmount() {
                    this._cancelSearch()
                }
                _requestSearch(e, t = 0) {
                    this._hasPendingSearch = !0, this._debouncedSearch(e, t)
                }
                _cancelSearch() {
                    this._hasPendingSearch && (this._debouncedSearch.cancel(), this._hasPendingSearch = !1), this._searchPromise && this._searchPromise.cancel()
                }
                _resetState() {
                    this.setState({
                        imageData: {},
                        isSearching: !1,
                        nextOffset: 0,
                        query: "",
                        thumbnails: [],
                        totalEstimatedMatches: 0
                    })
                }
                _addSearchResults(e, t) {
                    this.setState((a => {
                        var s = (0, o.default)(t.value, (e => null == e ? void 0 : e.thumbnailUrl)),
                            i = (0, l.default)(t.value, (e => ({
                                id: e.imageId,
                                name: e.name,
                                thumbUrl: e.thumbnailUrl
                            }))),
                            r = t.value.length,
                            d = {};
                        return a.query === e ? (d.nextOffset = t.nextOffset ? t.nextOffset : a.nextOffset + r, d.thumbnails = (0, n.default)(a.thumbnails, i), d.totalEstimatedMatches = t.totalEstimatedMatches, d.imageData = Object.assign(s, a.imageData)) : (d.imageData = s, d.nextOffset = t.nextOffset ? t.nextOffset : r, d.query = e, d.thumbnails = i, d.totalEstimatedMatches = t.totalEstimatedMatches), d
                    }))
                }
                render() {
                    var e, t = m.DRAWER_HEADER_TYPE.POPUP,
                        a = {
                            down: this._focusGallery
                        };
                    return e = 0 === this.state.thumbnails.length ? this.state.isSearching ? d.createElement(v.SearchingImages, null) : this.state.query ? d.createElement(v.ImageSearchEmpty, null) : d.createElement(v.BeforeImageSearch, null) : d.createElement(I.default, {
                        ref: this._setRefGallery,
                        canLoadMore: this.state.nextOffset < this.state.totalEstimatedMatches,
                        isLoadingMore: this.state.isSearching,
                        thumbnails: this.state.thumbnails,
                        onFocusPrev: this._focusSearch,
                        onImageClick: this._handleImageClick,
                        onRequestMoreImages: this._handleRequestMoreImages
                    }), d.createElement(p.default, null, d.createElement(m.default, {
                        title: y.default.t(796),
                        type: t,
                        onBack: this.props.onBack,
                        onCancel: this.props.onCancel
                    }), d.createElement(f.default, null, d.createElement(S.default, {
                        onRef: this._setRefSearchHotkeys,
                        handlers: a,
                        onFocus: this._handleSearchFocus
                    }, d.createElement(M.default, {
                        ref: this.setRefSearch,
                        placeholder: y.default.t(793),
                        onSearch: this._handleUserInput,
                        loading: this.state.isSearching
                    })), e))
                }
            }
            var A = k;
            t.Component = A;
            var x = (0, L.default)((0, T.default)(k));
            t.default = x
        },
        37350: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(58701)),
                o = i(a(73023)),
                d = s(a(71311)),
                u = i(a(17957)),
                c = a(51905),
                h = s(a(23539)),
                p = i(a(74885)),
                f = i(a(2825)),
                m = i(a(82631));
            class v extends n.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        hover: !1
                    }, this.onClick = () => {
                        this.props.onUpdateColor({
                            id: this.props.labelId,
                            color: this.props.colorInt
                        }, h.LABEL_PROPERTIES.COLOR), this.props.onBack()
                    }, this._disableHover = () => {
                        this.state.hover && this.setState({
                            hover: !1
                        })
                    }, this._enableHover = () => {
                        this.state.hover || this.setState({
                            hover: !0
                        })
                    }
                }
                render() {
                    var e = this.props.isSelected ? n.createElement(m.default, {
                            name: "checkmark-medium"
                        }) : null,
                        t = (0, r.default)(p.default.wallpaperColorCanvas, {
                            [p.default.canvasHover]: this.state.hover,
                            [p.default.canvasActive]: this.props.isSelected
                        });
                    return n.createElement("span", {
                        className: t,
                        style: {
                            backgroundColor: (0, c.intColorToHex)(this.props.colorInt)
                        },
                        onMouseOver: this._enableHover,
                        onMouseEnter: this._enableHover,
                        onMouseLeave: this._disableHover,
                        onClick: this.onClick
                    }, e)
                }
            }
            class _ extends n.Component {
                render() {
                    for (var {
                            currentColor: e,
                            colors: t
                        } = this.props, a = t.map((t => n.createElement(v, {
                            onUpdateColor: this.props.onUpdateColor,
                            colorInt: t,
                            onBack: this.props.onBack,
                            labelId: this.props.labelId,
                            isSelected: e === t,
                            key: t
                        }))), s = 0; s < 2; s++) a.push(n.createElement("div", {
                        key: "emptyEl" + s,
                        className: p.default.wallpaperColorEmpty
                    }));
                    return a
                }
            }
            class E extends n.Component {
                constructor() {
                    super(), this._getColorPromise = null, this.state = {
                        colors: h.default.labelColorPalette && h.default.labelColorPalette.colors
                    }
                }
                componentWillUnmount() {
                    this._getColorPromise && this._getColorPromise.cancel()
                }
                render() {
                    var e = n.createElement(f.default, {
                        stroke: 6,
                        size: 24
                    });
                    return this.state.colors ? e = n.createElement(_, {
                        labelId: this.props.labelId,
                        onBack: this.props.onClose,
                        onUpdateColor: this.props.onUpdateColor,
                        colors: this.state.colors,
                        currentColor: this.props.currentColor
                    }) : (this._getColorPromise = h.default.getLabelColorPalette(), this._getColorPromise.cancellable().then((e => {
                        this.setState({
                            colors: e
                        })
                    }))), n.createElement(l.default, null, n.createElement(d.default, {
                        theme: this.state.colors ? void 0 : "center-content",
                        title: u.default.t(813),
                        onBack: this.props.onClose,
                        type: d.DRAWER_HEADER_TYPE.LARGE
                    }), n.createElement(o.default, null, n.createElement("div", {
                        className: p.default.container
                    }, e)))
                }
            }
            t.default = E
        },
        86895: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(9386)),
                o = s(a(58701)),
                d = s(a(73023)),
                u = i(a(71311)),
                c = a(75459),
                h = s(a(17957)),
                p = s(a(80281)),
                f = a(74282),
                m = s(a(20642)),
                v = s(a(40210)),
                _ = s(a(51956)),
                E = s(a(96996)),
                g = s(a(42913)),
                C = s(a(94461)),
                S = s(a(82631));
            class I extends r.PureComponent {
                constructor() {
                    super(), this.onMultiSelect = () => {
                        var e = this.multiSelection.getSelected().length;
                        this.setState({
                            selectedCount: e
                        })
                    }, this.shouldScrollIntoViewAndSelect = () => ({
                        shouldScrollIntoView: !0,
                        shouldSelect: !1
                    }), this.onDeleteLabel = e => {
                        n.default.closeModal(), this.multiSelection.unsetAll(), this.props.onDeleteLabel(e)
                    }, this._confirmDeleteSelectedLabels = () => {
                        var e = this.multiSelection.getSelected();
                        (0, f.logLabelOperationEvent)(v.default.LABEL_OPERATIONS.VIEW, e.length, v.default.LABEL_TARGETS.DELETE_LABEL_DIALOG), n.default.openModal(r.createElement(l.default, {
                            okText: h.default.t(1810),
                            cancelText: h.default.t(1675),
                            onCancel: () => {
                                (0, f.logLabelOperationEvent)(v.default.LABEL_OPERATIONS.CLICK_NEGATIVE, 1, v.default.LABEL_TARGETS.DELETE_LABEL_DIALOG), n.default.closeModal()
                            },
                            onOK: () => {
                                (0, f.logLabelOperationEvent)(v.default.LABEL_OPERATIONS.CLICK_POSITIVE, 1, v.default.LABEL_TARGETS.DELETE_LABEL_DIALOG), this.onDeleteLabel(e)
                            }
                        }, h.default.t(528, {
                            _plural: e.length
                        })))
                    }, this.onCancelSelection = () => {
                        this.multiSelection.unsetAll(), this.setState({
                            selectedCount: 0
                        })
                    }, this.multiSelection = new g.default([], (e => e.id)), this.state = {
                        selectedCount: 0
                    }
                }
                componentDidMount() {
                    (0, f.logLabelOperationEvent)(v.default.LABEL_OPERATIONS.VIEW, void 0, v.default.LABEL_TARGETS.LABELS_SCREEN)
                }
                render() {
                    var {
                        selectedCount: e
                    } = this.state, t = null;
                    t = e > 0 ? r.createElement(_.default, {
                        selectedModels: this.multiSelection,
                        onCancel: this.onCancelSelection,
                        onDelete: this._confirmDeleteSelectedLabels,
                        theme: "drawer-header"
                    }) : r.createElement(u.default, {
                        title: h.default.t(823),
                        onBack: this.props.onClose,
                        type: u.DRAWER_HEADER_TYPE.LARGE
                    });
                    var a = (0, c.canEditLabel)() && r.createElement("div", {
                        className: p.default.addLabelBtContainer
                    }, r.createElement(C.default, {
                        large: !0,
                        onClick: this.props.openAddLabel
                    }, r.createElement(S.default, {
                        name: "plus-large"
                    })));
                    return r.createElement(o.default, {
                        theme: "settings"
                    }, t, r.createElement(d.default, null, r.createElement(E.default, {
                        shouldScrollIntoViewAndSelect: this.shouldScrollIntoViewAndSelect,
                        selectedLabels: this.multiSelection,
                        renderContext: "label-list",
                        onMultiSelect: this.onMultiSelect,
                        onLabelClick: this.props.onLabelClick
                    })), a)
                }
            }
            var y = (0, m.default)(I);
            t.default = y
        },
        37972: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            t.Z = void 0;
            var r = i(a(2784)),
                n = s(a(662)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = s(a(58701)),
                u = s(a(73023)),
                c = i(a(71311)),
                h = s(a(14457)),
                p = s(a(71201)),
                f = a(75459),
                m = s(a(17957)),
                v = s(a(23539)),
                _ = a(74282),
                E = s(a(49984)),
                g = s(a(20642)),
                C = a(80898),
                S = s(a(40210)),
                I = s(a(51956)),
                y = s(a(27e3)),
                M = s(a(42913)),
                T = s(a(2734)),
                P = s(a(82631));

            function L({
                openColorPicker: e,
                openEditLabel: t
            }) {
                return (0, f.canEditLabel)() ? r.createElement(C.MenuBarItem, {
                    a8nText: "starred-menu",
                    icon: r.createElement(P.default, {
                        name: "menu"
                    }),
                    title: m.default.t(915)
                }, r.createElement(h.default, {
                    type: "dropdown_menu",
                    flipOnRTL: !0,
                    key: "labelChooseColor",
                    dirX: "LEFT"
                }, r.createElement(p.default, {
                    a8n: "menu-item",
                    action: e
                }, m.default.t(813)), r.createElement(p.default, {
                    a8n: "menu-item",
                    action: t
                }, m.default.t(566)))) : null
            }
            class b extends r.PureComponent {
                constructor() {
                    super(), this._openColorPicker = () => {
                        var {
                            labelId: e
                        } = this.props, t = v.default.assertGet(e);
                        this.props.openLabelColorDrawer(this.props.labelId, t.color)
                    }, this._openEditLabel = () => {
                        this.props.onEditLabel && this.props.onEditLabel(this.props.labelId)
                    }, this.onCancelLabelSelection = () => {
                        this.multiSelection.unsetAll()
                    }, this.onRemoveLabel = () => {
                        var e = this.multiSelection.getSelected(),
                            {
                                onRemoveLabel: t,
                                labelId: a
                            } = this.props;
                        if (t) {
                            var s = v.default.assertGet(a);
                            (0, _.logLabelOperationEvent)(S.default.LABEL_OPERATIONS.VIEW, e.length, S.default.LABEL_TARGETS.BULK_UNLABEL_DIALOG), l.default.openModal(r.createElement(o.default, {
                                title: m.default.t(1159, {
                                    count: e.length,
                                    labelName: s.name,
                                    _plural: e.length
                                }),
                                okText: m.default.t(1680),
                                cancelText: m.default.t(1518),
                                onCancel: this._closeModal,
                                onOK: this._onRemoveLabelConfirmed.bind(null, a, e)
                            }))
                        }
                    }, this._closeModal = () => {
                        var e = this.multiSelection.getSelected();
                        (0, _.logLabelOperationEvent)(S.default.LABEL_OPERATIONS.CLICK_NEGATIVE, e.length, S.default.LABEL_TARGETS.BULK_UNLABEL_DIALOG), l.default.closeModal()
                    }, this._onRemoveLabelConfirmed = (e, t) => {
                        l.default.closeModal(), this.onCancelLabelSelection(), this.props.onRemoveLabel(e, t), (0, _.logLabelOperationEvent)(S.default.LABEL_OPERATIONS.CLICK_POSITIVE, t.length, S.default.LABEL_TARGETS.BULK_UNLABEL_DIALOG)
                    }, this.multiSelection = new M.default([], (e => e.id.toString()))
                }
                componentDidMount() {
                    this.props.listeners.add(this.multiSelection, "all", (() => this.forceUpdate())), (0, _.logLabelOperationEvent)(S.default.LABEL_OPERATIONS.VIEW, void 0, S.default.LABEL_TARGETS.LABEL_DETAILS_SCREEN)
                }
                _hasMixedSelection(e) {
                    for (var t, a, s = 0; s < e.length; s++) {
                        if (e[s] instanceof y.default ? a = !0 : t = !0, t && a) return !0
                    }
                    return !1
                }
                render() {
                    var e = this.multiSelection.getSelected(),
                        t = this._hasMixedSelection(e),
                        a = this.multiSelection.getSelected().length > 0 ? r.createElement(I.default, {
                            labelEditEnabled: !t,
                            onRemoveLabel: this.onRemoveLabel,
                            selectedModels: this.multiSelection,
                            onCancel: this.onCancelLabelSelection,
                            theme: "drawer-header"
                        }) : r.createElement(c.default, {
                            onBack: this.props.onClose,
                            menu: r.createElement(L, {
                                openColorPicker: this._openColorPicker,
                                openEditLabel: this._openEditLabel
                            }),
                            type: c.DRAWER_HEADER_TYPE.LABELS
                        }, r.createElement(E.default, {
                            labels: [this.props.labelId],
                            renderAsCircle: !0,
                            showName: !0,
                            theme: "drawer-title"
                        }));
                    return r.createElement(d.default, {
                        theme: "settings"
                    }, a, r.createElement(u.default, null, r.createElement(n.default, {
                        hideMultiSelectBar: !0,
                        multiSelection: this.multiSelection,
                        labelFilter: this.props.labelId,
                        settings: T.default,
                        selectable: !0
                    })))
                }
            }
            var w = (0, g.default)(b);
            t.Z = w
        },
        43865: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(9386)),
                o = s(a(17957)),
                d = s(a(72952)),
                u = a(41967),
                c = s(a(2825)),
                h = a(40263);
            class p extends r.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        licensesText: void 0
                    }, this.onOk = () => {
                        this.props.onOk && this.props.onOk(), n.default.closeModal()
                    }
                }
                componentDidMount() {}
                render() {
                    var e, t;
                    return this.state.licensesText || (e = r.createElement("div", {
                        className: d.default.spinner,
                        key: "spinner"
                    }, r.createElement(c.default, {
                        size: 50,
                        stroke: 4
                    }))), this.state.licensesText && (t = r.createElement("div", {
                        className: d.default.textContainer
                    }, this.state.licensesText)), r.createElement(l.default, {
                        okText: o.default.t(1680),
                        onOK: this.onOk,
                        type: u.FlexModalType
                    }, r.createElement("div", {
                        className: d.default.container
                    }, r.createElement(h.TextSpan, {
                        theme: "popup-title"
                    }, o.default.t(826)), t, e))
                }
            }
            t.default = p
        },
        49003: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.ID_SEPARATOR = void 0;
            var i = s(a(21941)),
                r = a(69763);
            t.ID_SEPARATOR = ",";
            t.default = class {
                constructor(...e) {
                    this.participants = new i.default, e.forEach((e => this.add(e)))
                }
                get id() {
                    return this.participants.map((({
                        id: e
                    }) => e.toString())).join(",")
                }
                get center() {
                    var e = this.participants.map((({
                            lat: e
                        }) => e)),
                        t = this.participants.map((({
                            lng: e
                        }) => e));
                    return {
                        lat: (Math.min(...e) + Math.max(...e)) / 2,
                        lng: (Math.min(...t) + Math.max(...t)) / 2
                    }
                }
                get lat() {
                    return this.center.lat
                }
                get lng() {
                    return this.center.lng
                }
                get length() {
                    return this.participants.length
                }
                get northeast() {
                    var e = this.participants.map((({
                            lat: e
                        }) => e)),
                        t = this.participants.map((({
                            lng: e
                        }) => e));
                    return {
                        lat: Math.max(...e),
                        lng: Math.max(...t)
                    }
                }
                get southwest() {
                    var e = this.participants.map((({
                            lat: e
                        }) => e)),
                        t = this.participants.map((({
                            lng: e
                        }) => e));
                    return {
                        lat: Math.min(...e),
                        lng: Math.min(...t)
                    }
                }
                add(e) {
                    this.participants.add(e)
                }
                hasSingleParticipant() {
                    return 1 === this.length
                }
                fits(e, t, a) {
                    var {
                        lat: s,
                        lng: i
                    } = this.center, {
                        lat: n,
                        lng: l
                    } = e, o = (0, r.getMetersBetweenLatLngs)(s, i, s, l), d = (0, r.getMetersBetweenLatLngs)(s, i, n, i), u = (0, r.getMetersPerPixel)(s, t);
                    return o / u <= a && d / u <= a
                }
            }
        },
        29053: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(63895)),
                l = s(a(46478)),
                o = s(a(35598)),
                d = s(a(63097)),
                u = s(a(22004)),
                c = s(a(17957)),
                h = s(a(60949)),
                p = s(a(82631)),
                f = s(a(58660));
            class m extends r.Component {
                constructor(...e) {
                    super(...e), this.flatListController = new u.default, this.renderListItem = e => {
                        var {
                            participant: t
                        } = e, a = t.isMe ? r.createElement("div", {
                            className: n.default.time
                        }, r.createElement(f.default, {
                            participant: t
                        })) : null;
                        return r.createElement("div", {
                            className: n.default.item,
                            onClick: () => this.props.onParticipantSelected(t.contact.id.toString())
                        }, r.createElement("div", {
                            className: n.default.left
                        }, r.createElement(l.default, {
                            id: t.contact.id,
                            size: 28
                        })), r.createElement("div", {
                            className: n.default.right
                        }, r.createElement("div", {
                            className: n.default.name
                        }, r.createElement(h.default, {
                            contact: t.contact,
                            titlify: !0,
                            ellipsify: !0,
                            you: !0
                        })), a))
                    }
                }
                getListData() {
                    return this.props.participants.map((e => ({
                        itemKey: e.id.toString(),
                        participant: e
                    })))
                }
                render() {
                    return r.createElement("div", {
                        className: n.default.container
                    }, r.createElement("div", {
                        className: n.default.header
                    }, r.createElement("div", {
                        className: n.default.left
                    }, r.createElement("span", {
                        className: n.default.close,
                        onClick: this.props.onClearSelected
                    }, r.createElement(p.default, {
                        name: "x"
                    }))), r.createElement("div", {
                        className: n.default.right
                    }, c.default.t(832, {
                        count: this.props.participants.length,
                        _plural: this.props.participants.length
                    }))), r.createElement(d.default, {
                        className: n.default.list,
                        flatListControllers: [this.flatListController]
                    }, r.createElement(o.default, {
                        data: this.getListData(),
                        flatListController: this.flatListController,
                        direction: "vertical",
                        defaultItemHeight: 48,
                        renderItem: this.renderListItem
                    })))
                }
            }
            t.default = m
        },
        37244: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t, a, s) {
                var i = new Map;
                if (!e.length) return i;
                for (var l = e.filter((e => e !== a)).sort(((e, t) => e.lat - t.lat)), o = function(e) {
                        var a = l[e],
                            o = void 0;
                        if (i.forEach((e => {
                                !o && e.fits(a, t, s) && (o = e)
                            })), o) {
                            var d = o,
                                u = o.id;
                            i.delete(u), d.add(a)
                        } else o = new r.default(a);
                        i.set((0, n.default)(o, "clusterToAdd").id, (0, n.default)(o, "clusterToAdd"))
                    }, d = 0; d < l.length; d++) o(d);
                if (a && e.length !== l.length) {
                    var u = new r.default(a);
                    i.set(u.id, u)
                }
                return i
            }, t.participantInCluster = function(e, t) {
                return e.split(r.ID_SEPARATOR).includes(t.toString())
            }, t.singleParticipantClusterId = function(e) {
                return !e.includes(r.ID_SEPARATOR)
            }, t.findClusterForParticipant = function(e, t) {
                var a, s = e.values();
                for (;
                    (a = s.next()) && !a.done;) {
                    var i = a.value;
                    if (i.participants.get(t)) return i
                }
                return null
            };
            var r = i(a(49003)),
                n = s(a(61941))
        },
        29065: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getSmallestElapsedTime = a, t.isStale = function(e) {
                return a(e) >= 600
            }, t.MARKER_SIZE = t.AVATAR_SIZE = t.PIN_SIZE = t.GLOW_SIZE = t.IMAGE_BORDER_SIZE = t.IMAGE_SIZE = t.STALE_THRESHOLD = void 0;
            t.STALE_THRESHOLD = 600;
            t.IMAGE_SIZE = 40;
            t.IMAGE_BORDER_SIZE = 2;
            t.GLOW_SIZE = 4;
            t.PIN_SIZE = 4;
            t.AVATAR_SIZE = 44;

            function a(e) {
                var t = e.participants.map((e => e.elapsedTime()));
                return Math.min(...t)
            }
            t.MARKER_SIZE = 52
        },
        89926: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(19899)),
                l = s(a(58701)),
                o = s(a(73023)),
                d = i(a(71311)),
                u = s(a(98294)),
                c = s(a(98397)),
                h = s(a(17957)),
                p = s(a(20642)),
                f = s(a(37721)),
                m = a(54933),
                v = s(a(15803)),
                _ = s(a(99911)),
                E = s(a(40207)),
                g = s(a(82631));
            class C extends r.PureComponent {
                constructor(e) {
                    super(e), this.onClose = () => {
                        this.props.onClose ? this.props.onClose() : this.props.uim.uie.requestDismiss()
                    }, this.onRoadmapSelected = () => {
                        this.setState({
                            mapType: m.MapType.ROADMAP
                        })
                    }, this.onSatelliteSelected = () => {
                        this.setState({
                            mapType: m.MapType.SATELLITE
                        })
                    }, this.onTerrainSelected = () => {
                        this.setState({
                            mapType: m.MapType.TERRAIN
                        })
                    }, this.onTrafficToggled = () => {
                        this.setState((e => ({
                            showTraffic: !e.showTraffic
                        })))
                    }, this.onMarkerSelected = e => {
                        this.setState({
                            markerSelected: e
                        })
                    }, this.state = {
                        mapType: m.MapType.ROADMAP,
                        showTraffic: !1,
                        markerSelected: !1,
                        online: _.default.online
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(_.default, "change:online", (() => {
                        this.setState({
                            online: _.default.online
                        })
                    }))
                }
                render() {
                    var e, t, a, s, i = r.createElement(v.default, {
                            onRoadmapSelected: this.onRoadmapSelected,
                            onSatelliteSelected: this.onSatelliteSelected,
                            onTerrainSelected: this.onTerrainSelected,
                            onTrafficToggled: this.onTrafficToggled,
                            showTraffic: this.state.showTraffic
                        }),
                        {
                            finalLat: u,
                            finalLng: p,
                            finalTimeOffset: m,
                            lat: _,
                            lng: E,
                            senderObj: C,
                            t: S
                        } = this.props.msg,
                        {
                            mapType: I,
                            showTraffic: y,
                            markerSelected: M,
                            online: T
                        } = this.state;
                    return void 0 === u || void 0 === p || void 0 === m ? (e = _, t = E, a = S) : (e = u, t = p, a = S + m), s = T ? r.createElement("div", {
                        className: c.default.wrapper
                    }, r.createElement(f.default, {
                        contact: C,
                        lat: e,
                        lng: t,
                        mapType: I,
                        showTraffic: y,
                        markerSelected: M,
                        onMarkerSelected: this.onMarkerSelected
                    }), r.createElement("div", {
                        className: c.default.notification
                    }, r.createElement("div", {
                        className: c.default.ended
                    }, h.default.t(833)), r.createElement("div", {
                        className: c.default.lastUpdated
                    }, n.default.liveLocationLastUpdatedStr(a)))) : r.createElement("div", {
                        className: c.default.offline
                    }, r.createElement("div", null, r.createElement("div", {
                        className: c.default.circle
                    }, r.createElement(g.default, {
                        name: "live-location-disconnected"
                    })), r.createElement("div", {
                        className: c.default.text
                    }, h.default.t(880)))), r.createElement(l.default, null, r.createElement(d.default, {
                        title: h.default.t(834),
                        type: d.DRAWER_HEADER_TYPE.SMALL,
                        menu: i,
                        onCancel: this.onClose
                    }), r.createElement(o.default, null, s))
                }
            }
            C.CONCERNS = {
                msg: ["finalLat", "finalLng", "finalTimeOffset", "lat", "lng", "senderObj", "t"]
            };
            var S = (0, u.default)((0, p.default)((0, E.default)(C, C.CONCERNS)));
            t.default = S
        },
        37721: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(39329),
                n = i(a(2784)),
                l = a(60238),
                o = a(54933),
                d = s(a(66357));
            class u extends n.Component {
                constructor(e) {
                    super(e), this.setMap = e => this.map = e, this.mapOnClick = () => {
                        this.dismissMarkerTimer.debounceAndCap(50, 100)
                    }, this.markerOnClick = () => {
                        this.dismissMarkerTimer.isScheduled() && this.dismissMarkerTimer.cancel(), this.props.onMarkerSelected(!0)
                    }, this.getPixelPositionOffset = (e, t) => ({
                        x: -e / 2,
                        y: -t
                    }), this.dismissMarkerTimer = new r.ShiftTimer((() => {
                        this.props.markerSelected && this.props.onMarkerSelected(!1)
                    }))
                }
                componentWillUnmount() {
                    this.dismissMarkerTimer.isScheduled() && this.dismissMarkerTimer.cancel()
                }
                getMapPaneName() {
                    return l.OverlayView.OVERLAY_MOUSE_TARGET
                }
                getMarkers() {
                    var {
                        lat: e,
                        lng: t,
                        contact: a,
                        markerSelected: s
                    } = this.props;
                    return n.createElement(d.default, {
                        marker: {
                            isLive: !1,
                            contact: a,
                            lat: e,
                            lng: t,
                            selected: s,
                            onClick: e => this.markerOnClick(e)
                        }
                    })
                }
                getTrafficLayer() {
                    return this.props.showTraffic ? n.createElement(l.TrafficLayer, {
                        autoRefresh: !0
                    }) : null
                }
                render() {
                    var {
                        lat: e,
                        lng: t
                    } = this.props;
                    return n.createElement(l.GoogleMap, {
                        ref: this.setMap,
                        defaultCenter: {
                            lat: e,
                            lng: t
                        },
                        defaultOptions: this.props.getMapOptions(),
                        defaultZoom: o.INITIAL_ZOOM,
                        mapTypeId: this.props.mapType,
                        onClick: this.mapOnClick
                    }, this.getMarkers(), this.getTrafficLayer())
                }
            }
            var c = (0, o.withConfig)((0, l.withScriptjs)((0, l.withGoogleMap)(u)));
            t.default = c
        },
        97264: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(45455)),
                n = i(a(12436)),
                l = i(a(72779)),
                o = s(a(2784)),
                d = i(a(29053)),
                u = s(a(37244)),
                c = i(a(79711)),
                h = a(29065),
                p = i(a(58701)),
                f = i(a(73023)),
                m = s(a(71311)),
                v = i(a(98294)),
                _ = i(a(96673)),
                E = i(a(17957)),
                g = i(a(20642)),
                C = i(a(10979)),
                S = i(a(42842)),
                I = a(54933),
                y = i(a(15803)),
                M = i(a(99911)),
                T = i(a(6625)),
                P = i(a(39391)),
                L = i(a(40207)),
                b = a(64658),
                w = i(a(82631)),
                N = i(a(67134)),
                O = s(a(75074)),
                D = i(a(68384)),
                R = a(75637),
                k = ["click", "mousedown", "mousemove", "scroll"],
                A = "ACTIVE",
                x = "INACTIVE",
                U = "OFFLINE";
            class F extends o.PureComponent {
                constructor(e) {
                    super(e), this._onParticipantAdd = () => {
                        var {
                            zoomLevel: e,
                            selectedParticipantId: t
                        } = this.state;
                        this._updateMinZoomClusters(), this.setState({
                            clusters: this._getClusters(e, t)
                        })
                    }, this.onParticipantRemove = e => {
                        var {
                            selectedClusterId: t,
                            selectedParticipantId: a,
                            zoomLevel: s
                        } = this.state;
                        this._updateMinZoomClusters();
                        var i = t,
                            r = a;
                        t && (0, u.participantInCluster)(t, e.id) && (i = null), D.default.equals(a, e.id) && (r = null), this.setState({
                            selectedClusterId: i,
                            selectedParticipantId: r,
                            clusters: this._getClusters(s, r)
                        })
                    }, this._onParticipantDisable = e => {
                        if (!e.isMe) {
                            var t = e.contact.formattedName;
                            c.default.openToast(o.createElement(O.default, {
                                msg: E.default.t(857, {
                                    name: t
                                }),
                                id: (0, O.genId)()
                            }))
                        }
                    }, this.onLocationChanged = () => {
                        var {
                            zoomLevel: e,
                            selectedParticipantId: t
                        } = this.state;
                        this._updateMinZoomClusters(), this.setState({
                            clusters: this._getClusters(e, t)
                        })
                    }, this.onIdle = () => {
                        var {
                            liveLocation: e
                        } = this.props.chat;
                        e && (e.stopViewingMap(), this.setState({
                            status: x
                        }))
                    }, this.onActivity = (0, n.default)((() => {
                        this._removeIdleTimeout(), this._addIdleTimeout()
                    }), 250), this._onRefresh = () => {
                        var {
                            liveLocation: e
                        } = this.props.chat;
                        e && (e.startViewingMap(), this.setState({
                            status: A
                        }))
                    }, this.onClose = () => {
                        this.props.onClose ? this.props.onClose() : this.props.uim.uie.requestDismiss()
                    }, this.onMarkerSelected = e => {
                        e ? (0, u.singleParticipantClusterId)(e) ? this.onParticipantSelected(e) : this._onClusterSelected(e) : this.onClearSelected()
                    }, this.onClearSelected = () => {
                        var {
                            selectedParticipantId: e,
                            selectedClusterId: t,
                            zoomLevel: a
                        } = this.state;
                        (e || t) && this.setState({
                            selectedParticipantId: null,
                            selectedClusterId: null,
                            clusters: this._getClusters(a)
                        })
                    }, this._onClusterSelected = e => {
                        this.state.selectedClusterId !== e && this.setState({
                            selectedParticipantId: null,
                            selectedClusterId: e
                        })
                    }, this.onParticipantSelected = e => {
                        var {
                            selectedParticipantId: t,
                            zoomLevel: a
                        } = this.state, s = (0, R.createWid)(e);
                        D.default.equals(t, s) || this.setState({
                            selectedParticipantId: s,
                            selectedClusterId: null,
                            clusters: this._getClusters(a, s)
                        })
                    }, this.onStopSharing = e => {
                        e.preventDefault(), e.stopPropagation();
                        var {
                            chat: t
                        } = this.props;
                        c.default.openModal(o.createElement(C.default, {
                            chat: t
                        }))
                    }, this.onRoadmapSelected = () => {
                        this.setState({
                            mapType: I.MapType.ROADMAP
                        })
                    }, this.onSatelliteSelected = () => {
                        this.setState({
                            mapType: I.MapType.SATELLITE
                        })
                    }, this.onTerrainSelected = () => {
                        this.setState({
                            mapType: I.MapType.TERRAIN
                        })
                    }, this.onTrafficToggled = () => {
                        this.setState((e => ({
                            showTraffic: !e.showTraffic
                        })))
                    }, this._onBackToCenter = () => {
                        this.setState({
                            selectedParticipantId: null,
                            selectedClusterId: null,
                            atCenter: !0,
                            clusters: this._getClusters(this.state.zoomLevel)
                        })
                    }, this.onMapMoved = (e, t) => {
                        this.setState((a => {
                            var s = {};
                            if (a.zoomLevel !== e) {
                                var i = this._getClusters(e, a.selectedParticipantId);
                                Object.assign(s, {
                                    zoomLevel: e,
                                    clusters: i
                                })
                            }
                            return this._hasValidParticipants() && a.atCenter !== t && Object.assign(s, {
                                atCenter: t
                            }), (0, r.default)(s) ? null : s
                        }))
                    }, this._updateMinZoomClusters(), this.state = {
                        clusters: this._getClusters(I.INITIAL_ZOOM),
                        selectedClusterId: null,
                        selectedParticipantId: null,
                        mapType: I.MapType.ROADMAP,
                        showTraffic: !1,
                        zoomLevel: I.INITIAL_ZOOM,
                        atCenter: !0,
                        status: M.default.online ? A : U
                    }
                }
                componentDidMount() {
                    this._listenToModelChange(), this._listenToNetworkChange(), this._startCheckingForIdle();
                    var {
                        liveLocation: e
                    } = this.props.chat;
                    e && (e.startViewingMap(), this._addParticipantListeners(e))
                }
                componentWillUnmount() {
                    this.onActivity.cancel();
                    var {
                        liveLocation: e
                    } = this.props.chat;
                    e && e.stopViewingMap()
                }
                _addParticipantListeners(e) {
                    this.props.listeners.add(e.participants, "add", this._onParticipantAdd), this.props.listeners.add(e.participants, "remove", this.onParticipantRemove), this.props.listeners.add(e.participants, "change:disabled", this._onParticipantDisable), this.props.listeners.add(e.participants, "change:valid", this.onLocationChanged)
                }
                _removeParticipantListeners(e) {
                    this.props.listeners.remove(e.participants, "add", this._onParticipantAdd), this.props.listeners.remove(e.participants, "remove", this.onParticipantRemove), this.props.listeners.remove(e.participants, "change:disabled", this._onParticipantDisable), this.props.listeners.remove(e.participants, "change:valid", this.onLocationChanged)
                }
                _listenToModelChange() {
                    var {
                        chat: e
                    } = this.props;
                    this.props.listeners.add((0, b.unproxy)(e), "change:liveLocation", (() => {
                        var {
                            liveLocation: t
                        } = e;
                        t && (this._removeParticipantListeners(t), this._addParticipantListeners(t));
                        var {
                            zoomLevel: a
                        } = this.state;
                        this.setState({
                            clusters: this._getClusters(a)
                        })
                    }))
                }
                _listenToNetworkChange() {
                    this.props.listeners.add(M.default, "change:online", (() => {
                        M.default.online || this._stopCheckingForIdle(), this.setState({
                            status: M.default.online ? A : U
                        })
                    }))
                }
                _startCheckingForIdle() {
                    this._addIdleTimeout(), this._addActivityListeners()
                }
                _stopCheckingForIdle() {
                    this._removeIdleTimeout(), this._removeActivityListeners()
                }
                _addIdleTimeout() {
                    this._idleTimeoutId = this.props.setTimeout(this.onIdle, 18e4)
                }
                _removeIdleTimeout() {
                    null != this._idleTimeoutId && this.props.clearTimeout(this._idleTimeoutId), this._idleTimeoutId = null
                }
                _addActivityListeners() {
                    k.forEach((e => {
                        this.props.listeners.add(document, e, this.onActivity)
                    }))
                }
                _removeActivityListeners() {
                    k.forEach((e => {
                        this.props.listeners.remove(document, e, this.onActivity)
                    }))
                }
                _updateMinZoomClusters() {
                    var e = this.getParticipants(),
                        t = e ? e.validLocations() : [];
                    this._minZoomClusters = (0, u.default)(t, I.MIN_ZOOM, null, h.MARKER_SIZE)
                }
                getParticipants() {
                    var {
                        liveLocation: e
                    } = this.props.chat;
                    return e ? e.participants : null
                }
                _hasValidParticipants() {
                    var e = this.getParticipants();
                    return !!e && !!e.validLocations().length
                }
                _getOpenFromCluster() {
                    var e = this.getParticipants();
                    if (!e || 0 === e.length) return null;
                    var {
                        openFrom: t
                    } = this.props, a = null;
                    if (t) a = t;
                    else {
                        var s = e.at(0);
                        s && (a = s.id)
                    }
                    return a ? (0, u.findClusterForParticipant)(this._minZoomClusters, a) : null
                }
                _getClusters(e, t) {
                    var a = this.getParticipants(),
                        s = null,
                        i = [];
                    a && (t && (s = a.get(t)), i = a.validLocations());
                    var r = i,
                        n = [];
                    if (this._minZoomClusters.size > 1) {
                        var l = this._getOpenFromCluster();
                        if (l) {
                            var o = l.participants;
                            r = o.validLocations(), n = i.filter((({
                                id: e
                            }) => !o.get(e)))
                        }
                    }
                    return {
                        primary: (0, u.default)(r, e, s, h.MARKER_SIZE),
                        secondary: (0, u.default)(n, e, s, h.MARKER_SIZE)
                    }
                }
                _getList() {
                    var e, {
                            clusters: t,
                            selectedClusterId: a
                        } = this.state,
                        s = this.getParticipants();
                    if (s && s.length) {
                        if (a) {
                            var i = t.primary.get(a) || t.secondary.get(a);
                            if (i) {
                                var r = i.participants;
                                e = o.createElement(d.default, {
                                    participants: r,
                                    onParticipantSelected: this.onParticipantSelected,
                                    onClearSelected: this.onClearSelected
                                })
                            }
                        }
                        e || (e = o.createElement(T.default, {
                            participants: s,
                            onParticipantSelected: this.onParticipantSelected,
                            onStopSharing: this.onStopSharing
                        }))
                    }
                    return e
                }
                render() {
                    var e, t;
                    this.props.isFirstLevel ? e = this.onClose : t = this.onClose;
                    var a, s, {
                            selectedParticipantId: i,
                            selectedClusterId: r,
                            mapType: n,
                            showTraffic: d,
                            atCenter: u,
                            status: c
                        } = this.state,
                        h = c === A ? o.createElement(y.default, {
                            onRoadmapSelected: this.onRoadmapSelected,
                            onSatelliteSelected: this.onSatelliteSelected,
                            onTerrainSelected: this.onTerrainSelected,
                            onTrafficToggled: this.onTrafficToggled,
                            showTraffic: d
                        }) : null;
                    if (c === A || c === x) {
                        var v = i && i.toString() || r;
                        a = o.createElement("div", {
                            className: _.default.wrapper
                        }, o.createElement("div", {
                            className: (0, l.default)(_.default.backToCenter, {
                                [_.default.visible]: !u
                            }),
                            onClick: this._onBackToCenter
                        }, o.createElement(w.default, {
                            name: "return"
                        })), o.createElement(S.default, {
                            clusters: this.state.clusters.primary,
                            secondaryClusters: this.state.clusters.secondary,
                            selectedMarkerId: v,
                            openFrom: this.props.openFrom,
                            mapType: n,
                            showTraffic: d,
                            atCenter: u,
                            onMarkerSelected: this.onMarkerSelected,
                            onClearSelected: this.onClearSelected,
                            onLocationChanged: this.onLocationChanged,
                            onMapMoved: this.onMapMoved
                        }), this._getList())
                    }
                    if (c === x || c === U) {
                        var g = c === x,
                            C = g ? "live-location-refresh" : "live-location-disconnected",
                            I = g ? E.default.t(845) : E.default.t(880);
                        s = o.createElement(P.default, {
                            inactive: g,
                            svgName: C,
                            text: I,
                            onClick: g ? this._onRefresh : void 0
                        })
                    }
                    return o.createElement(p.default, null, o.createElement(m.default, {
                        title: E.default.t(858),
                        type: m.DRAWER_HEADER_TYPE.SMALL,
                        menu: h,
                        onBack: t,
                        onCancel: e
                    }), o.createElement(f.default, null, a, s))
                }
            }
            F.CONCERNS = {
                chat: ["id", "liveLocation"]
            };
            var B = (0, v.default)((0, N.default)((0, g.default)((0, L.default)(F, F.CONCERNS))));
            t.default = B
        },
        42842: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(54073)),
                n = a(39329),
                l = s(a(2784)),
                o = a(60238),
                d = a(54933),
                u = i(a(66357)),
                c = a(69763),
                h = 1e-4;
            class p extends l.Component {
                constructor(e) {
                    super(e), this.setMap = e => this.map = e, this.onLocationChanged = e => {
                        var {
                            clusters: t,
                            atCenter: a,
                            selectedMarkerId: s
                        } = this.props;
                        if (this.props.onLocationChanged(), !s && a) this._viewAllClusters();
                        else if (s && s === e) {
                            var i = t.get(s);
                            i && this._viewSingleCluster(i)
                        }
                    }, this.onIdle = (0, r.default)((() => {
                        var e = this.map;
                        if (e) {
                            var t = e.getZoom();
                            if (this._zoomingToAllClusters) {
                                this._defaultZoomLevel = t, this._zoomingToAllClusters = !1;
                                var a = this._zoomHistory;
                                if (a.prev.preZoom === a.curr.postZoom && a.prev.postZoom === a.curr.preZoom) return
                            }
                            this.props.onMapMoved(t, this.atCenter())
                        }
                    }), 100), this.onDragStart = () => {
                        var e = this.map;
                        if (e) {
                            var t = e.getZoom();
                            this.props.onMapMoved(t, !1)
                        }
                    }, this.onResize = (0, r.default)((() => {
                        this._setMapLatLngDiff()
                    }), 250), this.mapOnClick = () => {
                        this.dismissMarkerTimer.debounceAndCap(50, 100)
                    }, this.markerOnClick = (e, t) => {
                        this.dismissMarkerTimer.isScheduled() && this.dismissMarkerTimer.cancel(), this.props.onMarkerSelected(t)
                    }, this.dismissMarkerTimer = new n.ShiftTimer((() => {
                        this.props.selectedMarkerId && this.props.onClearSelected()
                    })), this._defaultLatDiff = this._defaultLngDiff = .01, this._defaultZoomLevel = -1, this._zoomingToAllClusters = !1, this._zoomHistory = {
                        prev: {
                            preZoom: -1,
                            postZoom: -1
                        },
                        curr: {
                            preZoom: -1,
                            postZoom: -1
                        }
                    }
                }
                componentWillUnmount() {
                    this.onIdle.cancel(), this.onResize.cancel(), window.removeEventListener("resize", this.onResize), this.dismissMarkerTimer.isScheduled() && this.dismissMarkerTimer.cancel()
                }
                componentDidMount() {
                    window.addEventListener("resize", this.onResize), this._setMapLatLngDiff(), this._viewAllClusters()
                }
                componentDidUpdate(e) {
                    var {
                        clusters: t,
                        secondaryClusters: a,
                        selectedMarkerId: s,
                        atCenter: i
                    } = this.props, {
                        selectedMarkerId: r
                    } = e;
                    if (this._setMapLatLngDiff(), t.size && (!r || s || i))
                        if (s && r !== s) {
                            var n = t.get(s) || a.get(s);
                            n && this._viewSingleCluster(n)
                        } else !s && i && this._viewAllClusters()
                }
                _viewAllClusters() {
                    var {
                        clusters: e
                    } = this.props;
                    0 === e.size || this.atCenter() || (this._zoomToFitAllClusters(e), this._centerAllClusters(e))
                }
                _viewSingleCluster(e) {
                    this._zoomToFitSingleCluster(e), this._centerSingleCluster(e)
                }
                _zoomToFitAllClusters(e) {
                    var t = this.map;
                    if (t) {
                        this._zoomingToAllClusters = !0, this._zoomHistory.prev.preZoom = this._zoomHistory.curr.preZoom, this._zoomHistory.curr.preZoom = t.getZoom();
                        var a = this.getBounds(e),
                            s = e.entries().next();
                        if (1 !== e.size || s.done) this._boundsTooSmall(a) ? t.fitBounds(this._getDefaultBounds(a.getCenter())) : t.fitBounds(a);
                        else {
                            var [, i] = s.value;
                            this._zoomToFitSingleCluster(i, !1)
                        }
                        this._zoomHistory.prev.postZoom = this._zoomHistory.curr.postZoom, this._zoomHistory.curr.postZoom = t.getZoom()
                    }
                }
                _zoomToFitSingleCluster(e, t = !0) {
                    var a = this.map;
                    if (a && (!t || !this._boundsTooSmall(a.getBounds()))) {
                        var s = e.northeast,
                            i = e.southwest,
                            r = new google.maps.LatLng(s.lat, s.lng),
                            n = new google.maps.LatLng(i.lat, i.lng),
                            l = new google.maps.LatLngBounds(n, r);
                        this._boundsTooSmall(l) ? a.fitBounds(this._getDefaultBounds(l.getCenter())) : a.fitBounds(l)
                    }
                }
                _centerAllClusters(e) {
                    var t = this.getBounds(e).getCenter();
                    this._centerMap(t)
                }
                _centerSingleCluster(e) {
                    var t = new google.maps.LatLng(e.center);
                    this._centerMap(t)
                }
                _centerMap(e) {
                    var t = this.map;
                    t && (t.getCenter().equals(e) || t.panTo(e))
                }
                _getInitialCenter() {
                    return this.getBounds(this.props.clusters).getCenter()
                }
                getBounds(e) {
                    var t = new google.maps.LatLngBounds;
                    return e.forEach((e => {
                        t.extend({
                            lat: e.lat,
                            lng: e.lng
                        })
                    })), t
                }
                _boundsTooSmall(e) {
                    var t = e.getNorthEast(),
                        a = e.getSouthWest(),
                        s = t.lat() - a.lat(),
                        i = t.lng() - a.lng(),
                        r = Math.abs(s) < this._defaultLatDiff,
                        n = Math.abs(i) < this._defaultLngDiff;
                    return r || n
                }
                _getDefaultBounds(e) {
                    var t = new google.maps.LatLng(e.lat() - this._defaultLatDiff / 2, e.lng() - this._defaultLngDiff / 2),
                        a = new google.maps.LatLng(e.lat() + this._defaultLatDiff / 2, e.lng() + this._defaultLngDiff / 2);
                    return new google.maps.LatLngBounds(t, a)
                }
                atCenter() {
                    var e = this.map;
                    if (!e) return !0;
                    var t = e.getCenter(),
                        a = this._getInitialCenter(),
                        s = t.lat() - a.lat(),
                        i = t.lng() - a.lng();
                    return Math.abs(s) < h && Math.abs(i) < h && this._defaultZoomLevel === e.getZoom()
                }
                _setMapLatLngDiff() {
                    var e = this.map;
                    if (e) {
                        var t = e.getCenter(),
                            a = e.getDiv(),
                            s = (0, c.getMetersPerPixel)(t.lat(), d.INITIAL_ZOOM),
                            i = a.offsetWidth * s,
                            r = a.offsetHeight * s;
                        this._defaultLatDiff = (0, c.getLatDiff)(r), this._defaultLngDiff = (0, c.getLngDiff)(i, t.lat())
                    }
                }
                getMarkers() {
                    var {
                        clusters: e,
                        secondaryClusters: t,
                        selectedMarkerId: a
                    } = this.props, s = [], i = (e, t) => {
                        s.push(l.createElement(u.default, {
                            key: t,
                            marker: {
                                isLive: !0,
                                cluster: e,
                                onLocationChanged: () => this.onLocationChanged(t),
                                selected: a === t,
                                onClick: e => this.markerOnClick(e, t)
                            }
                        }))
                    };
                    return e.forEach(i), t.forEach(i), s
                }
                getTrafficLayer() {
                    return this.props.showTraffic ? l.createElement(o.TrafficLayer, {
                        autoRefresh: !0
                    }) : null
                }
                render() {
                    return l.createElement(o.GoogleMap, {
                        ref: this.setMap,
                        defaultCenter: this._getInitialCenter(),
                        defaultOptions: this.props.getMapOptions(),
                        defaultZoom: d.INITIAL_ZOOM,
                        mapTypeId: this.props.mapType,
                        onClick: this.mapOnClick,
                        onDragStart: this.onDragStart,
                        onIdle: this.onIdle
                    }, this.getMarkers(), this.getTrafficLayer())
                }
            }
            var f = (0, d.withConfig)((0, o.withScriptjs)((0, o.withGoogleMap)(p)));
            t.default = f
        },
        54933: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.withConfig = function(e) {
                return class extends l.Component {
                    constructor(...e) {
                        super(...e), this.state = {
                            authFailed: !0 === window.gm_authFailed
                        }, this._onAuthFailed = () => {
                            window.gm_authFailed = !0, this.setState({
                                authFailed: !0
                            });
                            var e = this._getUrl(),
                                t = String(u.default.googleMapsDoNotAuth),
                                a = String(u.default.googleMapsKeyless);
                            __LOG__(4, void 0, new Error, !0)(p(), e, "web", t, a), SEND_LOGS("google-map-auth-failed")
                        }
                    }
                    componentDidMount() {
                        window.gm_authFailure = this._onAuthFailed
                    }
                    componentWillUnmount() {
                        window.gm_authFailure = void 0
                    }
                    _getUrl() {
                        var e = {
                            client: "gme-whatsappinc",
                            v: "3",
                            libraries: "geometry,drawing,places",
                            t: Math.floor(Date.now() / 864e5)
                        };
                        return h.default.build("https://maps.googleapis.com/maps/api/js", e)
                    }
                    getMapOptions() {
                        return {
                            clickableIcons: !1,
                            fullscreenControl: !1,
                            keyboardShortcuts: !1,
                            mapTypeControl: !1,
                            minZoom: 3,
                            streetViewControl: !1,
                            zoomControl: !0,
                            zoomControlOptions: {
                                position: google.maps.ControlPosition.TOP_RIGHT
                            }
                        }
                    }
                    render() {
                        if (this.state.authFailed) return l.createElement("div", {
                            className: d.default.authFailed
                        }, o.default.t(704));
                        var t = this._getUrl(),
                            a = l.createElement("div", {
                                className: d.default.loading
                            }, l.createElement(c.default, {
                                color: "highlight"
                            })),
                            s = l.createElement("div", {
                                className: d.default.container
                            }),
                            i = l.createElement("div", {
                                className: d.default.map
                            });
                        return l.createElement(e, (0, r.default)({
                            googleMapURL: t,
                            loadingElement: a,
                            containerElement: s,
                            mapElement: i,
                            getMapOptions: this.getMapOptions
                        }, this.props))
                    }
                }
            }, t.MIN_ZOOM = t.INITIAL_ZOOM = t.MapType = void 0;
            var r = i(a(58527)),
                n = i(a(19976)),
                l = s(a(2784)),
                o = i(a(17957)),
                d = i(a(38388)),
                u = i(a(72424)),
                c = i(a(2825)),
                h = i(a(74185));

            function p() {
                var e = (0, n.default)(["url: ", "\ntarget: ", "\nprops; ", " & ", ""], ["url: ", "\\ntarget: ", "\\nprops; ", " & ", ""]);
                return p = function() {
                    return e
                }, e
            }
            var f = a(28103)({
                ROADMAP: "roadmap",
                SATELLITE: "satellite",
                TERRAIN: "terrain"
            });
            t.MapType = f;
            t.INITIAL_ZOOM = 15;
            t.MIN_ZOOM = 3
        },
        66357: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = a(60238),
                o = i(a(92569)),
                d = a(29065),
                u = i(a(20642)),
                c = i(a(87397)),
                h = i(a(98373)),
                p = i(a(67134)),
                f = i(a(5179));
            class m extends n.Component {
                constructor(e) {
                    super(e), this._setOverlay = e => {
                        this.overlay = e
                    }, this.onLocationChanged = () => {
                        this.props.marker.isLive && this.props.marker.onLocationChanged()
                    }, this._onLastUpdatedTimeChanged = () => {
                        if (this.props.marker.isLive) {
                            null != this.timeoutId && (this.props.clearTimeout(this.timeoutId), this.timeoutId = null);
                            var e = (0, d.isStale)(this.props.marker.cluster);
                            this.state.stale !== e && this.setState({
                                stale: e
                            }), e || this._setStaleTimeout()
                        }
                    }, this._getPixelPositionOffset = (e, t) => ({
                        x: -e / 2,
                        y: -t
                    }), this.state = {
                        stale: !e.marker.isLive || (0, d.isStale)(e.marker.cluster)
                    }
                }
                componentDidMount() {
                    if (this.props.marker.isLive) {
                        var {
                            cluster: e
                        } = this.props.marker;
                        (0, d.isStale)(e) || this._setStaleTimeout(), e.participants.forEach((e => {
                            this.props.listeners.add(e, "change:lat change:lng", this.onLocationChanged), this.props.listeners.add(e, "change:lastUpdated", this._onLastUpdatedTimeChanged)
                        }))
                    }
                }
                _setStaleTimeout() {
                    if (this.props.marker.isLive) {
                        var {
                            cluster: e
                        } = this.props.marker, t = d.STALE_THRESHOLD - (0, d.getSmallestElapsedTime)(e);
                        t <= 0 || (this.timeoutId = this.props.setTimeout((() => this.setState({
                            stale: !0
                        })), 1e3 * t))
                    }
                }
                _getMapPaneName() {
                    return this.props.marker.onClick ? l.OverlayView.OVERLAY_MOUSE_TARGET : l.OverlayView.OVERLAY_LAYER
                }
                render() {
                    var e, t, a, s, {
                            onClick: i,
                            selected: u
                        } = this.props.marker,
                        {
                            stale: p
                        } = this.state;
                    if (this.props.marker.isLive) {
                        var {
                            cluster: m
                        } = this.props.marker;
                        e = m.lat, t = m.lng, a = m.participants.map((({
                            id: e
                        }) => e))
                    } else e = this.props.marker.lat, t = this.props.marker.lng, a = [this.props.marker.contact.id];
                    if (u) {
                        var v, _, E;
                        if (this.props.marker.isLive) {
                            var {
                                cluster: g
                            } = this.props.marker, C = g.participants, S = g.hasSingleParticipant() ? C.at(0) : null;
                            S && (v = S.id, _ = S.accuracy, E = S.isMe)
                        } else {
                            var {
                                contact: I
                            } = this.props.marker;
                            v = I.id, E = I.isMe
                        }
                        v && (s = n.createElement(h.default, {
                            id: v,
                            lat: e,
                            lng: t,
                            accuracy: _,
                            isMe: E || !1,
                            markerSize: d.MARKER_SIZE
                        }))
                    }
                    return n.createElement(l.OverlayView, {
                        ref: this._setOverlay,
                        position: {
                            lat: e,
                            lng: t
                        },
                        mapPaneName: this._getMapPaneName(),
                        getPixelPositionOffset: this._getPixelPositionOffset
                    }, n.createElement(f.default.Provider, {
                        value: this.context
                    }, n.createElement("div", {
                        className: (0, r.default)(c.default.container, {
                            [c.default.selected]: u
                        }),
                        onClick: i
                    }, s, n.createElement("div", {
                        className: (0, r.default)(c.default.glow, {
                            [c.default.stale]: p,
                            [c.default.expired]: !this.props.marker.isLive
                        }),
                        style: {
                            height: d.AVATAR_SIZE,
                            width: d.AVATAR_SIZE,
                            padding: d.GLOW_SIZE
                        }
                    }, n.createElement("div", null, n.createElement(o.default, {
                        ids: a,
                        size: d.IMAGE_SIZE,
                        border: !0,
                        showCount: !0
                    }))), n.createElement("div", {
                        className: (0, r.default)(c.default.pin, {
                            [c.default.selected]: u
                        }),
                        style: {
                            height: d.PIN_SIZE,
                            width: d.PIN_SIZE,
                            marginLeft: (d.MARKER_SIZE - d.PIN_SIZE) / 2
                        }
                    }))))
                }
            }
            m.contextType = f.default;
            var v = (0, p.default)((0, u.default)(m));
            t.default = v
        },
        15803: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return r.createElement(d.MenuBarItem, {
                    a8nText: "live-location-map-menu",
                    icon: r.createElement(u.default, {
                        name: "menu"
                    }),
                    title: o.default.t(915)
                }, r.createElement(n.default, {
                    type: "dropdown_menu",
                    flipOnRTL: !0,
                    dirX: n.DirX.LEFT,
                    dirY: n.DirY.BOTTOM
                }, r.createElement(l.default, {
                    a8n: "mi-roadmap-view menu-item",
                    action: e.onRoadmapSelected
                }, o.default.t(840)), r.createElement(l.default, {
                    a8n: "mi-satellite-view menu-item",
                    action: e.onSatelliteSelected
                }, o.default.t(841)), r.createElement(l.default, {
                    a8n: "mi-terrain-view menu-item",
                    action: e.onTerrainSelected
                }, o.default.t(842)), r.createElement(l.default, {
                    a8n: "mi-traffic menu-item",
                    action: e.onTrafficToggled
                }, e.showTraffic ? o.default.t(843) : o.default.t(844))))
            };
            var r = i(a(2784)),
                n = i(a(14457)),
                l = s(a(71201)),
                o = s(a(17957)),
                d = a(80898),
                u = s(a(82631))
        },
        6625: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(65219)),
                l = s(a(35598)),
                o = s(a(63097)),
                d = s(a(22004)),
                u = s(a(17957)),
                c = s(a(18156)),
                h = s(a(58660));
            class p extends r.Component {
                constructor(...e) {
                    super(...e), this.flatListController = new d.default, this.renderListItem = e => {
                        var {
                            participant: t
                        } = e, a = t.valid ? r.createElement(h.default, {
                            participant: t
                        }) : u.default.t(866), s = t.valid ? () => this.props.onParticipantSelected(t.contact.id.toString()) : null, i = t.isMe ? r.createElement("div", {
                            onClick: this.props.onStopSharing,
                            className: c.default.stopSharingButton
                        }, u.default.t(856)) : null;
                        return r.createElement(n.default, {
                            contact: t.contact,
                            secondary: a,
                            onClick: s,
                            detail: i
                        })
                    }
                }
                getListData() {
                    return this.props.participants.map((e => ({
                        itemKey: e.id.toString(),
                        contentKey: e.valid ? "valid" : "invalid",
                        participant: e
                    })))
                }
                render() {
                    var e = this.getListData();
                    return r.createElement(o.default, {
                        className: c.default.list,
                        flatListControllers: [this.flatListController]
                    }, r.createElement(l.default, {
                        data: e,
                        renderItem: this.renderListItem,
                        flatListController: this.flatListController,
                        direction: "vertical"
                    }))
                }
            }
            var f = p;
            t.default = f
        },
        98373: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(43334)),
                o = i(a(79711)),
                d = i(a(53388)),
                u = i(a(7470)),
                c = i(a(71201)),
                h = a(35387),
                p = i(a(17957)),
                f = a(65935),
                m = i(a(60949)),
                v = i(a(34356)),
                _ = i(a(82631)),
                E = i(a(17693)),
                g = i(a(63498));
            class C extends n.Component {
                constructor(e) {
                    super(e), this.mouseEnter = () => {
                        this.state.hover || this.setState({
                            hover: !0
                        })
                    }, this.mouseLeave = () => {
                        this.state.hover && this.setState({
                            hover: !1
                        })
                    }, this._onDirection = () => {
                        var {
                            lat: e,
                            lng: t
                        } = this.props;
                        (0, h.openExternalLink)((0, f.getDirectionUrl)(e, t))
                    }, this.onMessage = () => {
                        var {
                            id: e
                        } = this.props;
                        l.default.find(e).then((e => {
                            e.active && o.default.existsDrawerRight((e => {
                                e && 2 === d.default.column && o.default.closeDrawerRight()
                            })), o.default.openChatFromUnread(e).then((t => {
                                t && o.default.focusChatTextInput(e)
                            }))
                        }))
                    }, this._onContextOpen = e => {
                        var t = e && e.target;
                        this.setState({
                            contextMenu: {
                                menu: this._getContextMenu(),
                                anchor: t
                            }
                        })
                    }, this.onContextClose = () => {
                        this.setState({
                            contextMenu: !1
                        })
                    }, this.state = {
                        hover: !1,
                        contextMenu: !1
                    }
                }
                _getContextMenu() {
                    var e = [];
                    return e.push(n.createElement(c.default, {
                        key: "direction",
                        a8n: "get-directions",
                        action: this._onDirection
                    }, p.default.t(679))), e.push(n.createElement(c.default, {
                        key: "message",
                        a8n: "send-message",
                        action: this.onMessage
                    }, p.default.t(916))), e
                }
                render() {
                    var {
                        id: e,
                        accuracy: t,
                        isMe: a,
                        markerSize: s
                    } = this.props, i = u.default.assertGet(e), l = {
                        transform: "translateX(calc(-50% + ".concat(s / 2, "px))")
                    }, o = n.createElement("div", {
                        className: v.default.name
                    }, n.createElement(m.default, {
                        ellipsify: !0,
                        you: !0,
                        contact: i
                    })), d = null != t ? n.createElement("div", {
                        className: v.default.status
                    }, p.default.t(831, {
                        accuracy: t,
                        _plural: t
                    })) : null, c = a ? null : n.createElement("div", {
                        onClick: this._onContextOpen,
                        className: v.default.menuButton
                    }, n.createElement(_.default, {
                        name: "down"
                    })), h = n.createElement("div", {
                        className: v.default.triangle
                    }), f = !a && this.state.contextMenu ? n.createElement(E.default, {
                        displayName: "LiveLocationPopupContextMenu",
                        escapable: !0,
                        popable: !0,
                        requestDismiss: this.onContextClose
                    }, n.createElement(g.default, {
                        contextMenu: this.state.contextMenu
                    })) : null;
                    return n.createElement("div", {
                        className: (0, r.default)(v.default.container, {
                            [v.default.twoLines]: !!d
                        }),
                        style: l
                    }, n.createElement("div", {
                        className: v.default.popup,
                        onMouseOver: this.mouseEnter,
                        onMouseEnter: this.mouseEnter,
                        onMouseDown: this.mouseLeave,
                        onMouseUp: this.mouseEnter,
                        onMouseLeave: this.mouseLeave
                    }, o, d, c), h, f)
                }
            }
            t.default = C
        },
        39391: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return r.createElement("div", {
                    className: e.inactive ? n.default.inactive : n.default.offline,
                    onClick: e.onClick
                }, r.createElement("div", null, r.createElement("div", {
                    className: n.default.circle
                }, r.createElement(l.default, {
                    name: e.svgName
                })), r.createElement("div", {
                    className: n.default.text
                }, e.text)))
            };
            var r = i(a(2784)),
                n = s(a(96673)),
                l = s(a(82631))
        },
        58660: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(17957)),
                l = s(a(20642)),
                o = s(a(67134));
            class d extends r.Component {
                constructor(e) {
                    super(e), this.onUpdate = e => {
                        this.setState({
                            timestampText: this._getTimestampText(e)
                        })
                    }, this.state = {
                        timestampText: this._getTimestampText(e.participant)
                    }
                }
                componentDidMount() {
                    var {
                        participant: e
                    } = this.props;
                    e.isMe ? this.props.listeners.add(e, "change:expiration", this.onUpdate) : this.props.listeners.add(e, "change:lastUpdated", this.onUpdate);
                    var t = this.getTime(e);
                    this._setTimeoutForNextMinute(t)
                }
                componentDidUpdate(e) {
                    var {
                        participant: t
                    } = this.props, {
                        participant: a
                    } = e;
                    if (t.expiration !== a.expiration && t.lastUpdated !== a.lastUpdated) {
                        null != this.timeoutId && this.props.clearTimeout(this.timeoutId), null != this._intervalId && this.props.clearInterval(this._intervalId);
                        var s = this.getTime(t);
                        this._setTimeoutForNextMinute(s)
                    }
                }
                _getTimestampText(e) {
                    return e.isMe ? this._remainingTimeText(e.remainingTime()) : this._elapsedTimeText(e.elapsedTime())
                }
                getTime(e) {
                    return e.isMe ? e.remainingTime() : e.elapsedTime()
                }
                _setTimeoutForNextMinute(e) {
                    this.timeoutId = this.props.setTimeout((() => {
                        this.setState({
                            timestampText: this._getTimestampText(this.props.participant)
                        }), this._setIntervalForEveryMinute()
                    }), e % 60 * 1e3)
                }
                _setIntervalForEveryMinute() {
                    this._intervalId = this.props.setInterval((() => {
                        this.setState({
                            timestampText: this._getTimestampText(this.props.participant)
                        })
                    }), 6e4)
                }
                _elapsedTimeText(e) {
                    var {
                        hours: t,
                        minutes: a
                    } = this._toHoursAndMinutes(e);
                    return t > 0 ? a > 0 ? n.default.t(860, {
                        hours: t,
                        minutes: a
                    }) : n.default.t(859, {
                        hours: t,
                        _plural: t
                    }) : a > 0 ? n.default.t(862, {
                        minutes: a,
                        _plural: a
                    }) : n.default.t(861)
                }
                _remainingTimeText(e) {
                    var {
                        hours: t,
                        minutes: a
                    } = this._toHoursAndMinutes(e, !0);
                    return t > 0 ? a > 0 ? n.default.t(847, {
                        hours: t,
                        minutes: a
                    }) : n.default.t(846, {
                        hours: t,
                        _plural: t
                    }) : n.default.t(848, {
                        minutes: a,
                        _plural: a
                    })
                }
                _toHoursAndMinutes(e, t = !1) {
                    var a = e;
                    t && (a += 59);
                    var s = a % 3600;
                    return {
                        hours: Math.floor(a / 3600),
                        minutes: Math.floor(s / 60)
                    }
                }
                render() {
                    return r.createElement("span", null, this.state.timestampText)
                }
            }
            var u = (0, l.default)((0, o.default)(d));
            t.default = u
        },
        69763: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getMetersBetweenLatLngs = function(e, t, i, r) {
                var n = s(i - e),
                    l = s(r - t),
                    o = Math.sin(n / 2) * Math.sin(n / 2) + Math.cos(s(e)) * Math.cos(s(i)) * Math.sin(l / 2) * Math.sin(l / 2),
                    d = 2 * Math.atan2(Math.sqrt(o), Math.sqrt(1 - o));
                return a * d
            }, t.getMetersPerPixel = function(e, t) {
                var a = Math.cos(e * Math.PI / 180),
                    s = 1 / Math.pow(2, t);
                return 156543.03392 * a * s
            }, t.getLatDiff = function(e) {
                return i(e / a)
            }, t.getLngDiff = function(e, t) {
                var r = a * Math.cos(s(t));
                return i(e / r)
            };
            var a = 6371e3;

            function s(e) {
                return e * (Math.PI / 180)
            }

            function i(e) {
                return e * (180 / Math.PI)
            }
        },
        75198: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(34519)),
                n = s(a(2784)),
                l = i(a(64)),
                o = i(a(58701)),
                d = i(a(73023)),
                u = s(a(71311)),
                c = a(75459),
                h = i(a(17957)),
                p = i(a(23539)),
                f = a(74282),
                m = i(a(20642)),
                v = i(a(71617)),
                _ = i(a(40210)),
                E = s(a(41967)),
                g = i(a(96996)),
                C = i(a(42913)),
                S = a(64658),
                I = i(a(82631)),
                y = 0,
                M = 1,
                T = 2;
            class P extends n.Component {
                constructor(e) {
                    super(e), this.selectedLabels = new C.default([], (e => e.id)), this._changeSet = new Set, this.onMultiSelect = e => {
                        e && (this._initialLabelState[e] === T ? this._changeSet.add("{labelId}_changed") : this._changeSet.has(e) ? this._changeSet.delete(e) : this._changeSet.add(e), this.forceUpdate())
                    }, this._constructLabelCountMap = () => {
                        var e = {},
                            {
                                modelsToUpdate: t
                            } = this.props;
                        return t.forEach((t => {
                            var a = (0, S.unproxy)(t);
                            a.labels && a.labels.forEach((t => {
                                e[t] = e[t] ? ++e[t] : 1
                            }))
                        })), e
                    }, this._onUpdateLabelsOK = () => {
                        (0, f.logLabelOperationEvent)(_.default.LABEL_OPERATIONS.CLICK_POSITIVE, this.props.modelsToUpdate.length, _.default.LABEL_TARGETS.LABEL_COMBINED_DIALOG);
                        var e = this.selectedLabels.list,
                            t = this.selectedLabels.selected,
                            a = e.map(((e, a) => ({
                                id: e.id,
                                type: t[a] ? "add" : "remove"
                            })));
                        p.default.addOrRemoveLabels(a, this.props.modelsToUpdate), this.props.onLabelUpdateComplete && this.props.onLabelUpdateComplete()
                    };
                    var {
                        modelsToUpdate: t
                    } = this.props, a = this._constructLabelCountMap();
                    this._initialLabelState = (0, r.default)(a, (e => e === t.length ? M : e > 0 ? T : y))
                }
                render() {
                    var e = n.createElement(l.default, {
                            a8nText: "popup-controls-ok",
                            type: "primary",
                            disabled: 0 === this._changeSet.size,
                            onClick: this._onUpdateLabelsOK,
                            key: 1
                        }, h.default.t(1198)),
                        t = n.createElement(l.default, {
                            a8nText: "popup-controls-cancel",
                            type: "plain",
                            onClick: this.props.onCancel,
                            key: 0
                        }, h.default.t(1518)),
                        a = (0, c.canEditLabel)() && n.createElement("div", {
                            className: v.default.newLabelBtn
                        }, n.createElement(l.default, {
                            a8nText: "popup-controls-cancel",
                            type: "simplified",
                            onClick: this.props.onAddNewLabel,
                            key: 2
                        }, n.createElement(I.default, {
                            name: "plus-large",
                            className: v.default.plus,
                            display: "inline"
                        }), h.default.t(210)));
                    return n.createElement(E.default, {
                        type: E.TowerModalType
                    }, n.createElement(o.default, {
                        key: "mange_label_modal",
                        theme: "labels"
                    }, n.createElement(u.default, {
                        title: h.default.t(815),
                        type: u.DRAWER_HEADER_TYPE.POPUP,
                        onCancel: this.props.onCancel
                    }), n.createElement(d.default, {
                        "data-list-scroll-container": !0,
                        theme: "padding"
                    }, n.createElement(g.default, {
                        shouldScrollIntoViewAndSelect: this.props.shouldScrollIntoViewAndSelect,
                        initialLabelState: this._initialLabelState,
                        selectedLabels: this.selectedLabels,
                        renderContext: "label-selection",
                        onLabelClick: this.props.onLabelClick,
                        onMultiSelect: this.onMultiSelect
                    })), a, n.createElement("div", {
                        className: v.default.actionBtns
                    }, t, e)))
                }
            }
            var L = (0, m.default)(P);
            t.default = L
        },
        68332: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(37426),
                n = i(a(2784)),
                l = s(a(79693)),
                o = s(a(88352)),
                d = s(a(27104));
            class u extends n.Component {
                constructor(e) {
                    super(e), this._initCanvas = () => {
                        var e = this.props.editedMedia.originalImage;
                        e.complete ? this.onImageLoad() : e.onload = this.onImageLoad
                    }, this.onImageLoad = () => {
                        var e = this.props.editedMedia.editData;
                        this.props.editedMedia.editedImage = null;
                        var t = this.props.editedMedia.originalImage;
                        if (e.width || e.height || (e.width = t.naturalWidth, e.height = t.naturalHeight), !e.baseItem) {
                            var a = new r.Easel.Bitmap(t);
                            e.baseItem = a
                        }
                        this.drawCanvas(!0)
                    }, this._maybeInitStage = e => {
                        var t;
                        return this.state.stage ? t = this.state.stage : (t = new r.Easel.Stage(e)).enableMouseOver(), this.props.mediaEditController.stage = t, t
                    }, this.drawCanvas = (e, t) => {
                        if (this._refStaticCanvas && this._refStaticCanvas.refCanvas) {
                            var a = this._refStaticCanvas.refCanvas;
                            t && this.props.mediaPickerStatsLogger && this.props.mediaPickerStatsLogger.logChange(this.props.activeMediaId || -1, t);
                            var s = this.props.editedMedia,
                                i = s.editData,
                                r = this._maybeInitStage(a);
                            e && (a.width = i.width, a.height = i.height), r.removeAllChildren(), null != i.baseItem && r.addChild(i.baseItem), i.items && r.addChild(...i.items);
                            var n = s.originalImage.naturalWidth,
                                l = s.originalImage.naturalHeight;
                            r.regX = n / 2, r.regY = l / 2, r.rotation = i.rotation, i.width && i.height && (r.x = i.width / 2 + i.scale * i.offsetX, r.y = i.height / 2 + i.scale * i.offsetY), r.scaleX = i.scale, r.scaleY = i.scale, r.update(), this.setState({
                                canvasSize: {
                                    width: a.width,
                                    height: a.height
                                },
                                stage: r
                            })
                        }
                    }, this.saveCanvas = () => {
                        this.drawCanvas(!0);
                        var e = this._refStaticCanvas && this._refStaticCanvas.refCanvas;
                        e && this.props.editedMedia.saveEditsFromCanvas(e)
                    }, this.clearStage = e => {
                        e && (e.children.forEach((e => {
                            e.removeAllEventListeners()
                        })), e.removeAllEventListeners(), e.removeAllChildren(), e.enableMouseOver(0), e.clear())
                    }, this._setRefStaticCanvas = e => {
                        this._refStaticCanvas = e
                    }, this._setRefMediaContainer = e => {
                        this._refMediaContainer = e
                    }, this._setRefCropOverlay = e => {
                        this._refCropOverlay = e
                    }, this.updateCanvasSize = (e, t) => {
                        this.setState({
                            canvasSize: {
                                width: e,
                                height: t
                            }
                        })
                    }, this.state = {
                        canvasSize: {
                            height: 1,
                            width: 1
                        },
                        stage: null,
                        mediaContainer: null
                    }
                }
                componentDidMount() {
                    this._initCanvas(), this.setState({
                        mediaContainer: this._refMediaContainer
                    }), this.cropOverlay = new r.Easel.Stage(this._refCropOverlay), this.cropOverlay.autoClear = !1, this.cropOverlay.enableMouseOver(), this._refMediaContainer && (this.props.mediaEditController.mediaContainer = this._refMediaContainer), this.props.mediaEditController.cropOverlay = this.cropOverlay
                }
                componentWillUnmount() {
                    var e = this.props.editedMedia.originalImage;
                    e.complete || (e.onload = void 0), this.saveCanvas(), this.clearStage(this.state.stage), this.clearStage(this.cropOverlay)
                }
                render() {
                    var e = n.createElement("canvas", {
                        ref: this._setRefCropOverlay,
                        className: l.default.cropOverlay
                    });
                    return n.createElement("div", {
                        className: this.props.className,
                        ref: this._setRefMediaContainer
                    }, n.createElement(o.default, {
                        type: this.props.fitType || "scaleDown",
                        size: this.state.canvasSize
                    }, e, n.createElement(d.default, {
                        ref: this._setRefStaticCanvas,
                        className: l.default.mediaViewerImg
                    })))
                }
            }
            t.default = u
        },
        31762: (e, t, a) => {
            "use strict";
            var s = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(a(61247));
            class r extends i.default {
                constructor(...e) {
                    super(...e), this.stage = (0, i.prop)(), this.cropOverlay = (0, i.prop)(), this.mediaContainer = (0, i.prop)(), this.isInitialized = (0, i.derived)(this._isInitialized, ["stage", "cropOverlay", "mediaContainer"])
                }
                _isInitialized() {
                    return !!this.stage && !!this.cropOverlay && !!this.mediaContainer
                }
                clearStage(e) {
                    e && (e.children.forEach((e => {
                        e.removeAllEventListeners()
                    })), e.removeAllEventListeners(), e.removeAllChildren(), e.clear())
                }
            }
            var n = (0, i.defineModel)(r);
            t.default = n
        },
        91846: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(25291)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = a(23751),
                d = i(a(58701)),
                u = i(a(73023)),
                c = s(a(71311)),
                h = i(a(63430)),
                p = i(a(17957)),
                f = i(a(12980)),
                m = i(a(91853)),
                v = i(a(96183)),
                _ = i(a(94461)),
                E = i(a(82631)),
                g = i(a(52100)),
                C = i(a(74824));
            class S extends n.Component {
                constructor(e) {
                    super(e), this.onImageSet = (e, t) => {
                        this.setState({
                            thumb: e,
                            full: t
                        })
                    }, this.onContinue = () => {
                        var e = (0, h.default)(this.state.text.trim());
                        (0, o.createGroup)(e, this.state.thumb, this.state.full, this.props.participants, this.state.dogfoodingGroupsInternalOnly), this.props.onContinue()
                    }, this.onSubjectChange = e => {
                        this.setState({
                            text: e
                        })
                    }, this.setRefEmojiInput = e => {
                        this.refEmojiInput = e
                    }, this._onDogfoodingGroupChange = () => {
                        var e = !this.state.dogfoodingGroupsInternalOnly;
                        this.setState({
                            dogfoodingGroupsInternalOnly: e
                        })
                    }, this.state = {
                        text: e.subject || "",
                        thumb: e.thumb,
                        full: e.full,
                        dogfoodingGroupsInternalOnly: !1
                    }
                }
                componentDidMount() {
                    this.refEmojiInput && this.refEmojiInput.restoreFocus()
                }
                render() {
                    var e = this.state.text.trim().length > 0,
                        t = e ? n.createElement("div", {
                            className: f.default.nextButton
                        }, n.createElement(_.default, {
                            a8nText: "create-group-btn",
                            onClick: (0, r.default)(this.onContinue)
                        }, n.createElement(E.default, {
                            name: "checkmark-medium"
                        }))) : null;
                    return n.createElement(d.default, null, n.createElement(c.default, {
                        title: p.default.t(1055),
                        type: c.DRAWER_HEADER_TYPE.LARGE,
                        onBack: this.props.onBack
                    }), n.createElement(u.default, null, n.createElement("div", {
                        className: f.default.section
                    }, n.createElement(m.default, {
                        type: v.default.GROUP,
                        attachToChat: !1,
                        startImage: this.state.full,
                        onImageSet: this.onImageSet
                    })), n.createElement("div", {
                        "data-a8n": l.default.key("group-subject"),
                        className: f.default.section
                    }, n.createElement(g.default, {
                        ref: this.setRefEmojiInput,
                        value: this.state.text,
                        maxLength: 25,
                        showRemaining: !0,
                        onChange: this.onSubjectChange,
                        placeholder: p.default.t(747),
                        onEnter: e ? (0, r.default)(this.onContinue) : () => {},
                        supportsEmoji: !0
                    })), null, n.createElement(C.default, {
                        transitionName: "btn"
                    }, t)))
                }
            }
            t.default = S
        },
        8180: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(90882)),
                n = i(a(45455)),
                l = i(a(17335)),
                o = i(a(72779)),
                d = s(a(2784)),
                u = i(a(32960)),
                c = a(43322),
                h = i(a(79711)),
                p = i(a(9386)),
                f = i(a(7470)),
                m = i(a(23069)),
                v = i(a(58701)),
                _ = i(a(73023)),
                E = s(a(71311)),
                g = a(20485),
                C = s(a(96452)),
                S = i(a(63097)),
                I = i(a(22004)),
                y = i(a(38147)),
                M = i(a(6660)),
                T = i(a(44343)),
                P = i(a(17957)),
                L = i(a(70365)),
                b = i(a(46821)),
                w = i(a(84845)),
                N = i(a(72259)),
                O = i(a(94461)),
                D = a(66615),
                R = i(a(72424)),
                k = i(a(2825)),
                A = i(a(82631)),
                x = s(a(75074)),
                U = i(a(74824)),
                F = (0, x.genId)("max_participant_toast");
            class B extends d.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        searchText: "",
                        participants: this.props.participants,
                        shouldFocus: !0,
                        isBusy: !1
                    }, this.flatListController = new I.default, this.setRefParticipantList = e => {
                        this.refParticipantList = e
                    }, this.setRefList = e => {
                        this.refList = e
                    }, this.onKeyDown = e => {
                        if ("Backspace" === e.key && !this.state.searchText && !(0, n.default)(this.state.participants)) {
                            e.preventDefault();
                            var t = this.state.participants;
                            this.setState({
                                participants: t.slice(0, t.length - 1),
                                shouldFocus: !0
                            })
                        }
                    }, this.onInput = e => {
                        this.setState({
                            searchText: e.target.value
                        })
                    }, this.onReset = () => {
                        this.setState({
                            searchText: "",
                            shouldFocus: !0
                        })
                    }, this.focus = () => {
                        M.default.focus(this.refInput)
                    }, this.onBack = () => {
                        this.props.onBack()
                    }, this.onContinue = () => {
                        this.props.onContinue(this.state.participants)
                    }, this.onDelete = (e, t) => {
                        var a = (0, r.default)(this.state.participants, (e => !e.id.equals(t.id)));
                        this.setState({
                            participants: a,
                            shouldFocus: !a.length
                        })
                    }, this.onContactClick = (e, t) => {
                        this.state.participants.find((e => e.id.equals(t.id))) ? this._removeContact(t) : t.isBlocked() ? h.default.openModal(d.createElement(p.default, {
                            title: P.default.t(201),
                            onOK: () => {
                                this._unblockAndAddContact(t), h.default.closeModal()
                            },
                            onCancel: () => h.default.closeModal(),
                            okText: P.default.t(1810),
                            cancelText: P.default.t(1675)
                        }, P.default.t(199))) : this.addContact(t)
                    }, this.onFocusList = e => {
                        this.refList && (e.preventDefault(), e.stopPropagation(), y.default.shouldIndicateFocus(), this.refList && this.refList.focusFirst())
                    }, this._onFocusParticipants = e => {
                        e.repeat || this.refInput && 0 !== this.refInput.selectionStart || this.refParticipantList && (e.preventDefault(), e.stopPropagation(), T.default.flashFocus = 0, this.refParticipantList && this.refParticipantList.focusLast())
                    }, this.onSelectFirst = e => {
                        e.preventDefault(), e.stopPropagation();
                        var t = this.getFilteredContacts()[0];
                        t && this.onContactClick(e, t)
                    }, this.onFocusSearch = () => {
                        y.default.shouldIndicateFocus(), M.default.focus(this.refInput)
                    }, this.setRefInput = e => {
                        this.refInput = e
                    }, this._setRefSizer = e => {
                        this._refSizer = e
                    }
                }
                componentDidMount() {
                    this.focus()
                }
                componentDidUpdate() {
                    this._adjustInput()
                }
                getFilteredContacts() {
                    var e = (0, l.default)(f.default.getFilteredContacts(), this.state.participants),
                        t = this.state.searchText;
                    if (!t) return e;
                    t = P.default.accentFold(t);
                    var a = (0, b.default)(t);
                    return e.filter((e => e.searchMatch(t, a)))
                }
                _adjustInput() {
                    if (this.refInput) {
                        var e, t = this.refInput.offsetParent.offsetWidth - 10,
                            a = this._refSizer.offsetWidth,
                            s = a > t ? t : a;
                        this.refInput.style.width = s + "px", e = t - this.refInput.offsetLeft - s > 0 ? t - this.refInput.offsetLeft : t, this.refInput.style.width = e + "px", this.state.shouldFocus && this.focus()
                    }
                }
                addContact(e) {
                    var t = this.state.participants;
                    if (t.length >= R.default.maxParticipants) {
                        var a = P.default.t(90, {
                            max: R.default.maxParticipants
                        });
                        h.default.openToast(d.createElement(x.default, {
                            msg: a,
                            id: F
                        }))
                    } else this.setState({
                        participants: t.concat(e),
                        searchText: "",
                        shouldFocus: !0
                    })
                }
                _removeContact(e) {
                    var t = this.state.participants;
                    this.setState({
                        participants: (0, r.default)(t, (t => !e.id.equals(t.id))),
                        shouldFocus: !0
                    })
                }
                _unblockAndAddContact(e) {
                    this.setState({
                        isBusy: !0
                    }), (0, c.unblockContact)(e).checkpoint(this.props.rejectOnUnmount()).then((() => {
                        this.addContact(e), this.setState({
                            isBusy: !1
                        })
                    })).catchType(C.Unmount, (() => {})).catch((() => {
                        this.setState({
                            isBusy: !1
                        })
                    }))
                }
                render() {
                    var e;
                    this.state.isBusy ? e = d.createElement("div", {
                        className: L.default.spinner
                    }, d.createElement(k.default, {
                        stroke: 6,
                        size: 24
                    })) : this.state.participants && this.state.participants.length && (e = d.createElement(O.default, {
                        a8nText: "group-participants-btn",
                        onClick: this.onContinue
                    }, d.createElement(A.default, {
                        name: "arrow-forward",
                        directional: !0
                    })));
                    var t = this.state.participants && this.state.participants.length ? " " : P.default.t(734),
                        a = {
                            down: this.onFocusList,
                            enter: this.state.searchText ? this.onSelectFirst : this.state.participants && this.state.participants.length ? this.onContinue : () => {},
                            up: this._onFocusParticipants
                        };
                    a[P.default.LR("left", "right")] = this._onFocusParticipants;
                    var s, i = this.getFilteredContacts();
                    return s = 0 === i.length ? d.createElement(g.SearchContacts, null) : d.createElement(m.default, {
                        ref: this.setRefList,
                        flatListController: this.flatListController,
                        contacts: i,
                        onClick: this.onContactClick,
                        onFocusSearch: this.onFocusSearch,
                        showPersonGroupDivisionHeader: !1
                    }), d.createElement(v.default, null, d.createElement(E.default, {
                        title: P.default.t(208),
                        type: E.DRAWER_HEADER_TYPE.LARGE,
                        onBack: this.onBack
                    }), d.createElement(_.default, null, d.createElement("div", {
                        className: L.default.search
                    }, d.createElement("div", null, d.createElement(T.default, {
                        handlers: a,
                        className: L.default.inputLine
                    }, d.createElement("div", {
                        "data-list-scroll-container": !0
                    }, d.createElement(w.default, {
                        ref: this.setRefParticipantList,
                        theme: "list-names",
                        contacts: this.state.participants,
                        onDelete: this.onDelete,
                        onFocusSearch: this.onFocusSearch
                    })), d.createElement("input", {
                        "data-a8n": u.default.key("inputarea"),
                        className: (0, o.default)(L.default.inputarea, D.SELECTABLE_INPUT_CSS_CLASS),
                        ref: this.setRefInput,
                        placeholder: t,
                        onKeyDown: this.onKeyDown,
                        onChange: this.onInput,
                        value: this.state.searchText,
                        type: "text"
                    }), d.createElement("span", {
                        className: L.default.inputareaSizer,
                        ref: this._setRefSizer
                    }, this.state.searchText)))), d.createElement(S.default, {
                        className: L.default.contacts,
                        flatListControllers: [this.flatListController]
                    }, s), d.createElement(U.default, {
                        transitionName: "btn",
                        className: L.default.drawerSection
                    }, e)))
                }
            }
            B.defaultProps = {
                participants: []
            };
            var V = (0, N.default)(B);
            t.default = V
        },
        64907: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(34815)),
                n = i(a(58701)),
                l = i(a(73023)),
                o = s(a(71311)),
                d = i(a(17957)),
                u = i(a(85059)),
                c = s(a(2784));
            t.default = e => c.createElement(n.default, null, c.createElement(o.default, {
                a8n: "drawer-title-notifications",
                title: d.default.t(1073),
                onBack: e.onClose,
                type: o.DRAWER_HEADER_TYPE.LARGE
            }), c.createElement(l.default, null, c.createElement(r.default, {
                key: "notifications",
                mute: u.default.globalMute()
            })))
        },
        89254: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = i(a(65468)),
                d = i(a(66585)),
                u = a(66181),
                c = i(a(79711)),
                h = i(a(9386)),
                p = i(a(52737)),
                f = i(a(50935)),
                m = i(a(58701)),
                v = i(a(73023)),
                _ = s(a(71311)),
                E = i(a(77875)),
                g = i(a(87451)),
                C = i(a(63430)),
                S = s(a(96452)),
                I = a(95595),
                y = a(75459),
                M = i(a(98294)),
                T = i(a(12155)),
                P = i(a(17957)),
                L = i(a(40210)),
                b = i(a(91853)),
                w = i(a(96183)),
                N = i(a(55043)),
                O = i(a(81315)),
                D = a(75613),
                R = i(a(72259)),
                k = a(10467),
                A = i(a(40207)),
                x = a(96911),
                U = a(40263),
                F = i(a(52100)),
                B = i(a(3111));

            function V() {
                var e = (0, r.default)(["ProfileDrawer: failed to set/delete profile image"]);
                return V = function() {
                    return e
                }, e
            }
            class G extends n.Component {
                constructor(e) {
                    super(e), this.onBack = () => {
                        this.props.onClose ? this.props.onClose() : this.props.uim.uie.requestDismiss()
                    }, this._validateStatus = e => !!(e || "").trim(), this._onStatusBegin = () => {
                        this._isEditingStatus = !0
                    }, this._onSetStatusError = () => {
                        c.default.openModal(n.createElement(h.default, {
                            onOK: () => c.default.closeModal(),
                            okText: P.default.t(1680)
                        }, P.default.t(189)))
                    }, this._onSetStatus = () => {
                        if (null != this.state.status) {
                            this._isEditingStatus = !1;
                            var e = this.props.status.status,
                                t = (0, C.default)(this.state.status);
                            if (t === e) return this.setState({
                                status: t
                            });
                            this.setState({
                                pendingStatus: !0
                            }), (0, x.setMyStatus)((0, C.default)(this.state.status)).checkpoint(this.props.rejectOnUnmount()).then((() => {
                                this.setState({
                                    pendingStatus: !1
                                })
                            })).catchType(S.Unmount, (() => {}))
                        } else this._onCancelStatus()
                    }, this.onStatusChange = e => {
                        this.setState({
                            status: e
                        })
                    }, this._onCancelStatus = () => {
                        this._isEditingStatus = !1, this.setState({
                            status: this.props.status.status
                        })
                    }, this._onPushnameBegin = () => {
                        this._isEditingPushname = !0
                    }, this._validatePushname = () => {
                        var e, {
                            pushname: t
                        } = this.state;
                        return (t = (t || "").trim()) ? /[\u2714\u2705\u2611]/g.test(t) && (e = P.default.t(184)) : e = P.default.t(181), !e || (this._onSetPushnameError(e), !1)
                    }, this._onSetPushname = () => {
                        if (this._isEditingPushname = !1, p.default.canSetMyPushname()) {
                            var {
                                pushname: e
                            } = this.state;
                            if ((e = (0, C.default)((e || "").trim())) === this.props.conn.pushname) return this.setState({
                                pushname: e
                            });
                            this.setState({
                                pendingPushname: !0
                            }), (0, k.setPushname)(e).checkpoint(this.props.rejectOnUnmount()).then((() => {
                                this.setState({
                                    pendingPushname: !1
                                })
                            })).catchType(S.Unmount, (() => {}))
                        }
                    }, this._onSetPushnameError = e => {
                        c.default.openModal(n.createElement(h.default, {
                            onOK: () => c.default.closeModal(),
                            okText: P.default.t(1680)
                        }, e))
                    }, this._onPushnameChange = e => {
                        this.setState({
                            pushname: e
                        })
                    }, this._onCancelPushname = () => {
                        this._isEditingPushname = !1, this.setState({
                            pushname: this.props.conn.pushname
                        })
                    }, this.onImageSet = (e, t) => {
                        var a = this.props.profilePicThumb;
                        this.setState({
                            pendingPhoto: !0
                        }), (e && t ? (0, D.setProfilePic)(a, e, t) : (0, D.deleteProfilePic)(a)).checkpoint(this.props.rejectOnUnmount()).catchType(S.Unmount, (() => {})).catchType(S.ActionError, (() => {
                            __LOG__(3)(V())
                        })).finally((() => {
                            this.setState({
                                pendingPhoto: !1
                            })
                        }))
                    }, this.state = {
                        pushname: e.conn.pushname,
                        status: e.status.status,
                        pendingPushname: !1,
                        pendingStatus: !1,
                        pendingPhoto: !1,
                        catalog: null
                    }
                }
                componentDidMount() {
                    p.default.isSMB && (0, y.canEditBizProfile)() && o.default.find((0, I.getMeUser)()).then((e => {
                        this.setState({
                            catalog: e
                        })
                    })).catch((() => {}))
                }
                renderProductCatalogSection() {
                    return n.createElement(d.default, {
                        catalog: this.state.catalog,
                        entryPoint: L.default.CATALOG_ENTRY_POINT.CATALOG_ENTRY_POINT_SETTINGS,
                        onProductDetail: u.openCatalogManagementFlow,
                        onProductCatalog: () => (0, u.openCatalogManagementFlow)(),
                        productsToShow: 3,
                        sessionId: (new N.default).toString(),
                        catalogEntryLabel: null == this.state.catalog ? P.default.t(202) : P.default.t(1407),
                        showProductPlaceholders: !0,
                        seeMoreOverlay: !0
                    })
                }
                _renderAboutInput() {
                    var {
                        status: e
                    } = this.props, t = this._isEditingStatus || this.state.pendingStatus ? this.state.status : e.status;
                    return n.createElement(F.default, {
                        a8n: "col-main-profile-input",
                        value: t,
                        editable: !0,
                        pending: this.state.pendingStatus,
                        showRemaining: !0,
                        validate: this._validateStatus,
                        maxLength: f.default.MAX_STATUS_LENGTH,
                        onBeginEdit: this._onStatusBegin,
                        onChange: this.onStatusChange,
                        onSave: this._onSetStatus,
                        onError: this._onSetStatusError,
                        onCancel: this._onCancelStatus,
                        theme: "text-input",
                        supportsEmoji: !0,
                        lockable: !0,
                        lowProfile: !0
                    })
                }
                _renderStandardEditSection() {
                    var {
                        conn: e
                    } = this.props, t = this._isEditingPushname || this.state.pendingPushname ? this.state.pushname : e.pushname, a = p.default.isSMB ? P.default.t(353) : P.default.t(1153), s = n.createElement(E.default, {
                        a8nText: "col-main-profile",
                        title: P.default.t(1759),
                        theme: "padding"
                    }, this._renderAboutInput());
                    return n.createElement(n.Fragment, null, n.createElement(E.default, {
                        a8nText: "col-main-profile",
                        title: P.default.t(1152),
                        theme: "padding"
                    }, n.createElement(F.default, {
                        a8n: "col-main-profile-input",
                        value: t,
                        editable: p.default.canSetMyPushname(),
                        pending: this.state.pendingPushname,
                        showRemaining: !0,
                        validate: this._validatePushname,
                        maxLength: f.default.MAX_PUSHNAME_LENGTH,
                        onBeginEdit: this._onPushnameBegin,
                        onChange: this._onPushnameChange,
                        onSave: this._onSetPushname,
                        onCancel: this._onCancelPushname,
                        supportsEmoji: !0,
                        lockable: !0,
                        lowProfile: !0
                    })), n.createElement("div", {
                        "data-a8n": l.default.key("pushname-description"),
                        className: O.default.nameWrapper
                    }, n.createElement(U.TextSpan, {
                        theme: "muted"
                    }, a)), s)
                }
                _renderSection(e) {
                    return n.createElement(T.default, e)
                }
                _renderAboutSection() {
                    var e = this._renderSection({
                            icon: "info",
                            content: this._renderAboutInput()
                        }),
                        t = this._renderSection({
                            icon: "call-phone",
                            iconClass: O.default.phoneIcon,
                            content: n.createElement("div", null, n.createElement("div", {
                                className: O.default.phoneField
                            }, (0, B.default)((0, I.assertGetMe)())), n.createElement("div", {
                                className: O.default.infoText
                            }, P.default.t(373)))
                        });
                    return n.createElement(E.default, {
                        title: P.default.t(363),
                        theme: "refresh"
                    }, e, t)
                }
                _renderEditBizProfileEditSection() {
                    return n.createElement("div", null, n.createElement(g.default, null), this.renderProductCatalogSection(), this._renderAboutSection())
                }
                render() {
                    var {
                        profilePicThumb: e
                    } = this.props, t = (0, y.canEditBizProfile)() ? this._renderEditBizProfileEditSection() : this._renderStandardEditSection(), a = P.default.t(907), s = !e.canSet() && !e.canDelete();
                    return n.createElement(m.default, null, n.createElement(_.default, {
                        a8n: "drawer-title-profile",
                        title: a,
                        onBack: this.onBack,
                        type: _.DRAWER_HEADER_TYPE.LARGE
                    }), n.createElement(v.default, null, n.createElement("div", {
                        className: O.default.photoPickerWrapper
                    }, n.createElement(b.default, {
                        type: w.default.PROFILE,
                        id: e.id,
                        attachToChat: !1,
                        pending: this.state.pendingPhoto,
                        startImage: e.imgFull,
                        readOnly: s,
                        onImageSet: this.onImageSet
                    })), t))
                }
            }
            G.CONCERNS = {
                profilePicThumb: ["imgFull", "id"],
                status: ["status"],
                conn: ["pushname"]
            };
            var H = (0, M.default)((0, R.default)((0, A.default)(G, G.CONCERNS)));
            t.default = H
        },
        29192: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(96066)),
                l = s(a(52737)),
                o = i(a(46478)),
                d = s(a(58701)),
                u = s(a(73023)),
                c = s(a(6162)),
                h = i(a(71311)),
                p = s(a(91581)),
                f = a(95595),
                m = s(a(17957)),
                v = s(a(58914)),
                _ = s(a(82631));
            class E extends r.PureComponent {
                render() {
                    var e, t = r.createElement(v.default, {
                            id: this.props.profileId
                        }),
                        a = r.createElement(o.default, {
                            id: (0, f.getMaybeMeUser)(),
                            size: 82,
                            quality: o.DETAIL_IMAGE_QUALITY.HIGH
                        }),
                        s = r.createElement(p.default, {
                            text: l.default.pushname,
                            ellipsify: !0,
                            titlify: !0
                        });
                    return e = r.createElement(c.default, {
                        a8nText: "li-keyboard-shortcuts",
                        icon: r.createElement(_.default, {
                            name: "settings-keyboard"
                        }),
                        onClick: this.props.onKeyboardShortcuts
                    }, m.default.t(811)), r.createElement(d.default, {
                        theme: "settings"
                    }, r.createElement(h.default, {
                        title: m.default.t(1261),
                        onBack: this.props.onClose,
                        type: h.DRAWER_HEADER_TYPE.LARGE
                    }), r.createElement(u.default, null, r.createElement(n.default, {
                        onClick: this.props.onProfile,
                        image: a,
                        primary: s,
                        theme: "identity",
                        secondary: t
                    }), r.createElement(c.default, {
                        a8nText: "li-notifications",
                        icon: r.createElement(_.default, {
                            name: "settings-notifications"
                        }),
                        onClick: this.props.onNotifications
                    }, m.default.t(905)), undefined, r.createElement(c.default, {
                        icon: r.createElement(_.default, {
                            name: "settings-theme"
                        }),
                        onClick: this.props.onThemeSettings
                    }, m.default.t(912)), r.createElement(c.default, {
                        icon: r.createElement(_.default, {
                            name: "settings-wallpaper"
                        }),
                        onClick: this.props.onWallpaper
                    }, m.default.t(913)), r.createElement(c.default, {
                        a8nText: "li-blocked",
                        icon: r.createElement(_.default, {
                            name: "settings-blocked"
                        }),
                        onClick: this.props.onBlocked
                    }, m.default.t(899)), undefined, e, r.createElement(c.default, {
                        a8nText: "li-help",
                        icon: r.createElement(_.default, {
                            name: "settings-help"
                        }),
                        onClick: this.props.onHelp
                    }, m.default.t(901)), undefined, undefined, undefined, undefined, undefined))
                }
            }
            t.default = E
        },
        46156: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = i(a(12436)),
                l = s(a(2784)),
                o = i(a(79711)),
                d = i(a(50935)),
                u = i(a(58701)),
                c = i(a(73023)),
                h = s(a(71311)),
                p = a(20485),
                f = s(a(96452)),
                m = i(a(6660)),
                v = i(a(98294)),
                _ = i(a(44343)),
                E = i(a(17957)),
                g = i(a(20642)),
                C = a(80898),
                S = i(a(72259)),
                I = i(a(36533)),
                y = i(a(73664)),
                M = i(a(2825)),
                T = i(a(53200)),
                P = i(a(46983)),
                L = i(a(85454)),
                b = i(a(82631)),
                w = i(a(74824));

            function N() {
                var e = (0, r.default)(["StarredDrawer:loadEarlierMsgs failed\n", ""], ["StarredDrawer:loadEarlierMsgs failed\\n", ""]);
                return N = function() {
                    return e
                }, e
            }
            class O extends l.Component {
                constructor(e) {
                    super(e), this._msgRefs = {}, this._setRefHotKeys = e => {
                        this._refHotKeys = e
                    }, this._refScrollContainer = l.createRef(), this._getInitialState = () => {
                        var {
                            starredMsgs: e
                        } = this.props;
                        return {
                            cursor: I.default.create({
                                msgCollection: e,
                                type: d.default.RENDER_CURSOR.STARRED_DRAWER
                            }).loadAfter(e, {
                                count: d.default.MSG_PRELOAD_THRESHOLD
                            })
                        }
                    }, this._handleStarChange = () => {
                        this._initSelectionObjects(), this.forceUpdate()
                    }, this._initSelectionObjects = () => {
                        var e = this.props.starredMsgs.toArray();
                        this._currSelection.init(e, !0), this._activeSelection.init(e)
                    }, this.setRefMsgComponent = (e, t) => {
                        t ? this._msgRefs[e.id.toString()] = t : delete this._msgRefs[e.id.toString()]
                    }, this.loadEarlierMsgs = () => {
                        var e = this.state.cursor,
                            t = this.props.chat && this.props.chat.id,
                            {
                                starredMsgs: a
                            } = this.props,
                            s = a.models;
                        if (e.getEnd(a) < s.length) this.setState({
                            cursor: e.loadAfter(a)
                        });
                        else {
                            if (a.isSynced) return;
                            this.props.starredMsgs.sync(t).checkpoint(this.props.rejectOnUnmount()).then((() => {
                                e.hasAfter(a) && this.setState({
                                    cursor: e.loadAfter(a)
                                })
                            })).catchType(f.Unmount, (() => {})).catch((e => {
                                __LOG__(2)(N(), e)
                            }))
                        }
                    }, this.onClose = () => {
                        this.props.onClose ? this.props.onClose() : this.props.uim.uie.requestDismiss()
                    }, this.focus = () => {
                        this._refHotKeys && m.default.focus(this._refHotKeys)
                    }, this.onFocusGain = e => {
                        this._refHotKeys && ((e ? e.target : document.activeElement) === this._refHotKeys && (this._currSelection.index < 0 ? this._currSelection.setFirst(!0) : this._currSelection.reset(!1)))
                    }, this._onNextMsg = e => {
                        e && (e.preventDefault(), e.stopPropagation());
                        var t = this._currSelection.next();
                        this._currSelection.index !== t && this._currSelection.setNext(!0)
                    }, this._onPrevMsg = e => {
                        e && (e.stopPropagation(), e.preventDefault()), this._currSelection.prev() > -1 && this._currSelection.setPrev(!0)
                    }, this.onScroll = e => {
                        this.handleScroll(e.currentTarget)
                    }, this._handleScroll = e => {
                        this.updateMsgListInfo(),
                            function(e) {
                                return e.scrollTop + d.default.SCROLL_FUDGE > e.scrollHeight - e.clientHeight
                            }(e) && this.loadEarlierMsgs()
                    }, this._selectMsg = e => {
                        this._currSelection.setVal(e), this._activeSelection.setVal(e), o.default.openChatAt(e.chat, e.chat.getSearchContext(e)), o.default.focusShowMsg(e.id)
                    }, this._getMsgList = () => {
                        var e = this.state.cursor,
                            {
                                starredMsgs: t
                            } = this.props,
                            a = t.toArray(),
                            s = t.isSynced ? e.getEnd(t) : Math.min(e.getEnd(t), a.length);
                        return a = a.slice(e.getStart(t), s), this.length = a.length, a
                    }, this.getMsgVisibility = e => {
                        if (!e) return d.default.VISIBILITY.BELOW;
                        var t = this._refScrollContainer.current;
                        if (t) {
                            var a = t.previousSibling;
                            if (a && a instanceof HTMLElement) {
                                var s = a.clientHeight,
                                    i = t.scrollTop + s,
                                    r = i + t.clientHeight,
                                    n = e.getContainerElement();
                                return n ? n.offsetTop + n.clientHeight <= i ? d.default.VISIBILITY.ABOVE : n.offsetTop >= r ? d.default.VISIBILITY.BELOW : d.default.VISIBILITY.VISIBLE : d.default.VISIBILITY.BELOW
                            }
                        }
                    }, this.isMsgVisible = (e, t = !1) => !!this._msgListInfo.visibleMsgs[e.toString()] && (!!t || this.getMsgComponent(e)), this.getMsgComponent = e => {
                        var t = this._msgRefs[e.toString()];
                        if (t) {
                            var a = t.getWrapperRef();
                            return a && "function" == typeof a.getMsgComponentRef ? a.getMsgComponentRef() : void 0
                        }
                    }, this._updateMsgListInfo = () => {
                        for (var e = this._getMsgList(), t = {}, a = 0, s = this.length - 1; a < s;) {
                            var i = Math.floor((a + s) / 2),
                                r = this._msgRefs[e[i].id.toString()];
                            this.getMsgVisibility(r) === d.default.VISIBILITY.ABOVE ? a = i + 1 : s = i
                        }
                        for (var n = a; n < e.length; n++) {
                            var l = this._msgRefs[e[n].id.toString()];
                            if (this.getMsgVisibility(l) !== d.default.VISIBILITY.VISIBLE) break;
                            t[e[n].id.toString()] = !0
                        }
                        this.pauseHiddenGifs(this._msgListInfo.visibleMsgs, t), this._msgListInfo.visibleMsgs = t
                    }, this.pauseHiddenGifs = (e, t) => {
                        for (var a in e)
                            if (!t[a]) {
                                var s = this.props.starredMsgs.get(a);
                                if (s && s.isGif) {
                                    var i = this.getMsgComponent(a);
                                    i && i.playCount && i.pause()
                                }
                            }
                    }, this.handleScroll = (0, n.default)(this._handleScroll, 100), this.updateMsgListInfo = (0, n.default)(this._updateMsgListInfo, 100), this._msgListInfo = {
                        visibleMsgs: {}
                    }, this.state = this._getInitialState(), this._currSelection = new y.default([], (e => e.id.toString())), this._activeSelection = new y.default([], (e => e.id.toString())), this._initSelectionObjects()
                }
                componentDidMount() {
                    this.focus(), this.props.listeners.add(window, "resize", this.updateMsgListInfo), !this.props.starredMsgs.isSynced && this.props.starredMsgs.length < d.default.PAGE_SIZE && this.props.listeners.uiIdle(this.loadEarlierMsgs), this.props.listeners.add(this.props.starredMsgs, "reset sync", (() => {
                        this._initSelectionObjects(), this.forceUpdate()
                    })), this.props.listeners.add(this.props.starredMsgs, "add remove", this._handleStarChange), this.onFocusGain(), this.props.listeners.add(this.props.starredMsgs, "reset", (() => {
                        this._msgListInfo = {
                            visibleMsgs: {}
                        }, this.setState(this._getInitialState()), this.loadEarlierMsgs()
                    }))
                }
                componentWillUnmount() {
                    this.handleScroll.cancel(), this.updateMsgListInfo.cancel()
                }
                componentDidUpdate() {
                    this.updateMsgListInfo()
                }
                render() {
                    var e, t, a = this._getMsgList(),
                        s = this.state.cursor,
                        {
                            starredMsgs: i
                        } = this.props,
                        r = this.props.chat || null;
                    if (t = i.isSynced && s.getEnd(i) >= a.length ? null : this.props.starredMsgs.syncPromise ? l.createElement("div", {
                            className: T.default.more,
                            title: E.default.t(867)
                        }, l.createElement(M.default, {
                            stroke: 6,
                            size: 24
                        })) : l.createElement("div", {
                            className: T.default.more
                        }, l.createElement("div", {
                            title: E.default.t(864),
                            onClick: this.loadEarlierMsgs
                        }, l.createElement(b.default, {
                            name: "refresh"
                        }))), a.length > 0) {
                        var n = a.map((e => {
                            var t = e.type === d.default.MSG_TYPE.IMAGE || e.type === d.default.MSG_TYPE.VIDEO || e.type === d.default.MSG_TYPE.AUDIO;
                            return l.createElement(L.default, {
                                key: e.id.toString(),
                                ref: t => {
                                    this.setRefMsgComponent(e, t)
                                },
                                msg: e,
                                isMsgVisible: t ? this.isMsgVisible : () => {},
                                currSelection: this._currSelection,
                                activeSelection: this._activeSelection,
                                onClickMsg: this._selectMsg
                            })
                        }));
                        e = l.createElement(w.default, {
                            transitionName: "slide"
                        }, n)
                    } else this.props.starredMsgs.isSynced ? e = l.createElement(p.StarredMsgs, null) : (e = l.createElement(p.Loading, null), t = null);
                    var o = {
                            down: this._onNextMsg,
                            up: this._onPrevMsg
                        },
                        f = a.length > 0 ? l.createElement(C.MenuBarItem, {
                            a8nText: "starred-menu",
                            icon: l.createElement(b.default, {
                                name: "menu"
                            }),
                            title: E.default.t(915)
                        }, l.createElement(P.default, {
                            chat: r,
                            msgs: a
                        })) : null;
                    return l.createElement(u.default, {
                        theme: "gallery"
                    }, l.createElement(_.default, {
                        className: T.default.hotKeyWraper,
                        handlers: o,
                        onFocus: this.onFocusGain,
                        "data-tab": d.default.TAB_ORDERS.CHAT_STARRED_DRAWER,
                        onRef: this._setRefHotKeys
                    }, l.createElement(h.default, {
                        title: E.default.t(1271),
                        onBack: this.onClose,
                        type: h.DRAWER_HEADER_TYPE.LARGE,
                        menu: f
                    }), l.createElement(c.default, {
                        onScroll: this.onScroll,
                        ref: this._refScrollContainer
                    }, e, t)))
                }
            }
            var D = (0, v.default)((0, S.default)((0, g.default)(O)));
            t.default = D
        },
        46983: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(14457)),
                o = s(a(71201)),
                d = s(a(17957)),
                u = s(a(18931));
            class c extends r.Component {
                constructor(...e) {
                    super(...e), this.sendUnstarAll = () => {
                        n.default.openModal(r.createElement(u.default, {
                            msgs: this.props.msgs,
                            chat: this.props.chat
                        }))
                    }
                }
                getElement() {
                    return this._refDropdown
                }
                render() {
                    var {
                        msgs: e
                    } = this.props;
                    return r.createElement(l.default, {
                        onRef: e => {
                            this._refDropdown = e
                        },
                        type: "dropdown_menu",
                        flipOnRTL: !0,
                        key: "StarredDrawerHeader",
                        dirX: "LEFT"
                    }, r.createElement(o.default, {
                        a8n: "mi-unstar-all menu-item",
                        action: this.sendUnstarAll,
                        disabled: 0 === e.length
                    }, d.default.t(1344)))
                }
            }
            t.default = c
        },
        27104: (e, t, a) => {
            "use strict";
            var s = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(a(2784));
            class r extends i.Component {
                constructor(...e) {
                    super(...e), this._setRefCanvas = e => {
                        this.refCanvas = e
                    }
                }
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return i.createElement("canvas", {
                        className: this.props.className,
                        ref: this._setRefCanvas
                    })
                }
            }
            t.default = r
        },
        24190: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(43334)),
                l = s(a(79711)),
                o = s(a(64357)),
                d = a(14457),
                u = s(a(99003)),
                c = s(a(82512)),
                h = a(40789),
                p = s(a(63430)),
                f = a(13414),
                m = s(a(17957)),
                v = s(a(72259)),
                _ = s(a(93456)),
                E = a(37960),
                g = s(a(35912)),
                C = s(a(82631)),
                S = i(a(75074)),
                I = s(a(17693)),
                y = s(a(63498)),
                M = s(a(74824));
            class T extends r.Component {
                constructor() {
                    super(...arguments), this.emojiInputComponent = (0, u.default)(), this._refEmojiPanel = r.createRef(), this.isSkinTonePickerOpen = !1, this.onSend = e => {
                        if (e.preventDefault(), this.inputLine) {
                            var t = this.inputLine.value.trim();
                            if (t.length) {
                                var a = (0, S.genId)();
                                n.default.find(this.props.msg.sender).then((e => (l.default.openToast(r.createElement(S.default, {
                                    msg: m.default.t(1283),
                                    id: a
                                })), (0, E.sendTextMsgToChat)(e, (0, p.default)(t), {
                                    quotedMsg: this.props.msg
                                })))).then((() => {
                                    this.props.onSend()
                                })).catchType(o.default, (() => {
                                    var {
                                        chat: e
                                    } = this.state;
                                    e && l.default.openToast(r.createElement(S.default, {
                                        msg: m.default.t(1520, {
                                            contact: e.contact.formattedName
                                        }),
                                        id: a
                                    }))
                                })), this.inputLine && this.inputLine.reset(), this._emojiPickerClose(), this.props.dismissReply()
                            }
                        }
                    }, this.onFocus = () => {
                        this.setState({
                            focused: !0
                        })
                    }, this.onBlur = () => {
                        this.isSkinTonePickerOpen || document.activeElement === document.body && this.setState({
                            focused: !1
                        })
                    }, this.onSkinTonePicker = e => {
                        this.isSkinTonePickerOpen = e
                    }, this.isFocused = () => this.state.focused, this.onEmojiPicker = e => {
                        e && (e.preventDefault(), e.stopPropagation());
                        var t = r.createElement(c.default, {
                            ref: this._refEmojiPanel,
                            onEmoji: this.onEmoji,
                            onFocusNext: this.restoreFocus,
                            onFocusPrev: this.restoreFocus
                        });
                        this.setState({
                            emojiPicker: {
                                menu: t,
                                dirY: d.DirY.TOP,
                                type: "emoji_picker",
                                anchor: e.target
                            }
                        })
                    }, this.onEmoji = e => {
                        this.inputLine && this.inputLine.replaceSelection(e)
                    }, this.restoreFocus = () => {
                        this.inputLine && this.inputLine.focus()
                    }, this._restoreEmojiPickerFocus = () => {
                        var e;
                        null === (e = this._refEmojiPanel.current) || void 0 === e || e.restoreFocus()
                    }, this._emojiPickerClose = () => {
                        this.setState({
                            emojiPicker: void 0
                        })
                    }, this.state = {
                        replyCaption: "",
                        focused: !1,
                        emojiPicker: void 0,
                        chat: void 0
                    }, n.default.find(this.props.msg.sender).checkpoint(this.props.rejectOnUnmount()).then((e => {
                        this.setState({
                            chat: e
                        })
                    }))
                }
                componentDidUpdate(e, t) {
                    this._shouldPausePlayback(t) && !this._shouldPausePlayback(this.state) ? this.props.play() : !this._shouldPausePlayback(t) && this._shouldPausePlayback(this.state) && this.props.pause()
                }
                _shouldPausePlayback(e) {
                    return Boolean(e.emojiPicker) || e.focused
                }
                isPaused() {
                    return this._shouldPausePlayback(this.state)
                }
                render() {
                    var e, t, a;
                    this.state.emojiPicker && (e = r.createElement(I.default, {
                        displayName: "EmojiPicker",
                        escapable: !0,
                        popable: !0,
                        requestDismiss: this._emojiPickerClose,
                        requestFocus: this._restoreEmojiPickerFocus
                    }, r.createElement(y.default, {
                        contextMenu: this.state.emojiPicker
                    })), t = r.createElement(I.default, {
                        displayName: "EmojiPicker",
                        escapable: !0,
                        requestFocus: this._restoreEmojiPickerFocus
                    }, r.createElement("div", null, e)));
                    var {
                        chat: s
                    } = this.state;
                    s && this.state.focused && !this.state.emojiPicker && (a = r.createElement(I.default, {
                        displayName: "StatusV3Reply",
                        escapable: !0,
                        requestDismiss: this.props.dismissReply
                    }, r.createElement("div", {
                        className: g.default.popupPanel
                    }, r.createElement(_.default, {
                        msg: this.props.msg.safe(),
                        theme: "statusV3",
                        key: this.props.msg.id.toString(),
                        chat: s
                    }))));
                    var i = this.emojiInputComponent;
                    return r.createElement("div", {
                        className: g.default.container
                    }, r.createElement(M.default, {
                        transitionName: "status-v3-quoted-msg",
                        transitionAppear: !0
                    }, a), r.createElement("div", {
                        className: g.default.wrapper
                    }, r.createElement("button", {
                        className: g.default.emojiIcon,
                        onClick: this.onEmojiPicker
                    }, r.createElement(C.default, {
                        name: "smiley"
                    })), r.createElement("div", {
                        className: g.default.lineWrapper
                    }, r.createElement(i.EmojiSuggestions, {
                        theme: h.ThemeOptions.EMOJI_INPUT,
                        onSkinTonePicker: this.onSkinTonePicker
                    }), r.createElement(i, {
                        ref: (0, f.GetRef)((e => {
                            this.inputLine = e
                        })),
                        theme: "status-reply",
                        spellCheck: !0,
                        onFocus: this.onFocus,
                        onBlur: this.onBlur,
                        onEnter: this.onSend,
                        placeholder: m.default.t(1334),
                        editable: !0,
                        multiline: !0
                    })), r.createElement("button", {
                        className: g.default.sendIcon,
                        onClick: this.onSend
                    }, r.createElement(C.default, {
                        name: "send",
                        directional: !0
                    })), t))
                }
            }
            var P = (0, v.default)(T);
            t.default = P
        },
        65530: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(32960)),
                l = s(a(19899)),
                o = s(a(7470)),
                d = s(a(46478)),
                u = a(20485),
                c = i(a(35598)),
                h = s(a(63097)),
                p = s(a(22004)),
                f = a(95595),
                m = s(a(18120)),
                v = s(a(17957)),
                _ = s(a(20642)),
                E = s(a(61941)),
                g = s(a(93683)),
                C = s(a(57185)),
                S = s(a(93866)),
                I = s(a(26907)),
                y = s(a(82631)),
                M = "SEC_UNREAD",
                T = "SEC_READ",
                P = "SEC_MUTED",
                L = "ROW_STATUS";
            class b extends r.Component {
                constructor() {
                    super(...arguments), this.flatListController = new p.default, this.onStatusChange = () => {
                        var e = this._getUnreadStatusList(),
                            t = this._getReadStatusList(),
                            a = [...e, ...t].filter((e => e.contact.statusMute));
                        this.setState({
                            unreadStatusList: e.filter((e => !e.contact.statusMute)),
                            readStatusList: t.filter((e => !e.contact.statusMute)),
                            mutedStatusList: a,
                            myStatus: C.default.getMyStatus()
                        })
                    }, this._onContactMuteChange = () => {
                        var e = this._getUnreadStatusList(),
                            t = this._getReadStatusList(),
                            a = [...e, ...t].filter((e => e.contact.statusMute));
                        this.setState({
                            unreadStatusList: e.filter((e => !e.contact.statusMute)),
                            readStatusList: t.filter((e => !e.contact.statusMute)),
                            mutedStatusList: a,
                            myStatus: C.default.getMyStatus()
                        })
                    }, this._toggleMuted = () => {
                        this.setState((e => ({
                            isMutedExpanded: !e.isMutedExpanded
                        })))
                    }, this.renderItem = e => {
                        switch (e.type) {
                            case M:
                                return r.createElement("div", {
                                    className: S.default.listSectionSep
                                }, r.createElement("hr", null), r.createElement("div", {
                                    className: S.default.listSectionText
                                }, r.createElement("span", null, v.default.t(1282))));
                            case T:
                                return r.createElement("div", {
                                    className: S.default.listSectionSep
                                }, r.createElement("hr", null), r.createElement("div", {
                                    className: S.default.listSectionText
                                }, r.createElement("span", null, v.default.t(1288))));
                            case P:
                                return r.createElement("div", {
                                    className: S.default.listSectionSep
                                }, r.createElement("hr", null), r.createElement("div", {
                                    className: S.default.listSectionText
                                }, r.createElement("span", null, v.default.t(1278)), r.createElement("button", {
                                    className: S.default.listSectionAction,
                                    onClick: this._toggleMuted
                                }, e.expanded ? v.default.t(1275) : v.default.t(1276))));
                            case L:
                                return r.createElement(g.default, {
                                    statusV3: e.status,
                                    onClick: () => this.props.onOpenStatus(e.status, void 0, e.index),
                                    contact: e.status.contact
                                });
                            default:
                                throw new c.UnknownDataError(e)
                        }
                    };
                    var e = this._getUnreadStatusList(),
                        t = this._getReadStatusList(),
                        a = [...e, ...t].filter((e => e.contact.statusMute));
                    this.state = {
                        unreadStatusList: e.filter((e => !e.contact.statusMute)),
                        readStatusList: t.filter((e => !e.contact.statusMute)),
                        mutedStatusList: a,
                        myStatus: C.default.getMyStatus(),
                        isMutedExpanded: !1
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(C.default, "add remove bulk_add sort change:msgsChanged change:hasUnread", this.onStatusChange), this.props.listeners.add(o.default, "change:statusMute", this._onContactMuteChange), this.props.listeners.add(C.default, "sync", (() => {
                        this.forceUpdate()
                    }))
                }
                _getUnreadStatusList() {
                    return C.default.getUnexpired(!0)
                }
                _getReadStatusList() {
                    return C.default.getUnexpired(!1)
                }
                getData() {
                    var {
                        unreadStatusList: e,
                        readStatusList: t,
                        mutedStatusList: a
                    } = this.state, s = [];
                    return e.length > 0 && (s.push({
                        type: M,
                        itemKey: "section-unread",
                        height: 48
                    }), s.push(...e.map(((e, t) => ({
                        type: L,
                        itemKey: e.id.toString(),
                        height: 64,
                        status: e,
                        index: t
                    }))))), t.length > 0 && (s.push({
                        type: T,
                        itemKey: "section-read",
                        height: 48
                    }), s.push(...t.map(((e, t) => ({
                        type: L,
                        itemKey: e.id.toString(),
                        height: 64,
                        status: e,
                        index: t
                    }))))), a.length > 0 && (s.push({
                        type: P,
                        itemKey: "section-muted",
                        height: 48,
                        expanded: this.state.isMutedExpanded
                    }), this.state.isMutedExpanded && s.push(...a.map(((e, t) => ({
                        type: L,
                        itemKey: e.id.toString(),
                        height: 64,
                        status: e,
                        index: t
                    }))))), s
                }
                render() {
                    var e, t = this.getData();
                    return e = C.default.hasSynced() && t.length > 0 ? r.createElement(c.default, {
                        className: "statusList",
                        itemEnterAnimationsEnabled: !0,
                        flatListController: this.flatListController,
                        direction: "vertical",
                        data: t,
                        renderItem: this.renderItem
                    }) : r.createElement(u.ListStatus, null), r.createElement("div", {
                        className: S.default.listPanel
                    }, r.createElement(w, {
                        statusV3: this.state.myStatus,
                        onOpenStatus: this.props.onOpenStatus
                    }), r.createElement(h.default, {
                        className: S.default.listBody,
                        flatListControllers: [this.flatListController]
                    }, e))
                }
            }
            class w extends r.Component {
                render() {
                    var e, t, a, s = this.props.statusV3;
                    s && (a = s.msgs);
                    var i, o, u, c, h = () => {
                        var e = s && s.msgs;
                        s && e && e.length && this.props.onOpenStatus(s, e.head(), 0)
                    };
                    if (s && a && a.length) {
                        e = r.createElement(I.default, {
                            statusV3: s,
                            contact: s.contact,
                            onClick: h
                        });
                        var p = (0, E.default)(a.last(), "myMsgs.last()").t;
                        t = r.createElement("span", {
                            className: S.default.secondaryHeaderText
                        }, l.default.relativeDateAndTimeStr(p)), o = {
                            cursor: "pointer"
                        }, i = h
                    } else e = r.createElement(d.default, {
                        id: (0, f.getMaybeMeUser)(),
                        theme: "status_v3",
                        size: 40
                    }), t = r.createElement("span", {
                        "data-a8n": n.default.key("status-no-updates"),
                        className: S.default.secondaryHeaderText
                    }, v.default.t(1280));
                    m.default.supportsFeature(m.default.F.STATUS_V3_UI_SENDING) && (u = r.createElement(y.default, {
                        name: "menu"
                    }), c = r.createElement(y.default, {
                        name: "status-v3-create"
                    }));
                    var _ = r.createElement("span", {
                        "data-a8n": n.default.key("my-status"),
                        className: S.default.primaryHeaderText
                    }, v.default.t(1279));
                    return r.createElement("div", {
                        className: S.default.panelHeader,
                        style: o,
                        onClick: i
                    }, r.createElement("div", {
                        className: S.default.headerButtonsPrimary
                    }, e), r.createElement("div", {
                        className: S.default.headerText
                    }, _, t), r.createElement("div", {
                        className: S.default.headerButtonsSecondary
                    }, c, u))
                }
            }
            var N = (0, _.default)(b);
            t.default = N
        },
        40618: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(79711)),
                o = i(a(20642)),
                d = i(a(57185)),
                u = i(a(65530)),
                c = i(a(41837)),
                h = i(a(80703)),
                p = i(a(82631));
            class f extends n.Component {
                constructor(e) {
                    super(e), this._onStatusAddRemove = () => {
                        this.setState({
                            status: d.default.getMyStatus()
                        })
                    }, this.state = {
                        status: d.default.getMyStatus()
                    }
                }
                shouldComponentUpdate(e, t) {
                    return t.status !== this.state.status
                }
                componentDidMount() {
                    var {
                        sessionId: e,
                        listeners: t
                    } = this.props;
                    t.add(d.default, "add remove", this._onStatusAddRemove), t.add(l.default, "dismiss_status_v3_viewer", (() => {
                        this.props.closeStatusViewer(!0)
                    })), null != e && d.default.logMetrics({
                        type: "session",
                        sessionId: e
                    })
                }
                render() {
                    var {
                        onOpenStatus: e
                    } = this.props, t = (0, r.default)(c.default.v3_x, {});
                    return n.createElement("div", {
                        className: c.default.modalBackground,
                        "data-animate-status-v3-modal-background": !0
                    }, n.createElement("div", {
                        className: c.default.mainWrapper
                    }, n.createElement(u.default, {
                        onOpenStatus: e
                    }), n.createElement(h.default, {
                        status: this.state.status,
                        onOpenStatus: e
                    }), n.createElement("button", {
                        className: t,
                        onClick: () => this.props.closeStatusViewer(!0)
                    }, n.createElement(p.default, {
                        name: "x-viewer"
                    }))))
                }
            }
            var m = (0, o.default)(f);
            t.default = m
        },
        80703: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = i(a(19899)),
                d = i(a(50935)),
                u = a(19741),
                c = s(a(96452)),
                h = i(a(18120)),
                p = i(a(17957)),
                f = i(a(20642)),
                m = i(a(92313)),
                v = i(a(72259)),
                _ = i(a(2825)),
                E = i(a(95578)),
                g = a(21504),
                C = i(a(82631));

            function S() {
                var e = (0, r.default)(["error while loading all out status: ", ""]);
                return S = function() {
                    return e
                }, e
            }
            class I extends n.Component {
                render() {
                    var e, t, a = n.createElement(M, {
                        statusV3: this.props.status,
                        onOpenStatus: this.props.onOpenStatus
                    });
                    return h.default.supportsFeature(h.default.F.STATUS_V3_UI_SENDING) && (e = n.createElement("div", {
                        className: E.default.updateWrapper
                    }, n.createElement("div", {
                        className: E.default.updateTitle
                    }, p.default.t(1285)), n.createElement("div", {
                        className: E.default.uploadButtons
                    }, n.createElement("div", {
                        className: E.default.buttonContainer
                    }, n.createElement(C.default, {
                        name: "status-v3-upload",
                        className: E.default.buttonIcon
                    }), p.default.t(1286)), n.createElement("div", {
                        className: E.default.buttonContainer
                    }, n.createElement(C.default, {
                        name: "status-v3-camera",
                        className: E.default.buttonIcon
                    }), p.default.t(1274)))), t = n.createElement("hr", null)), n.createElement("div", {
                        className: E.default.outStatusPanel
                    }, e, t, a)
                }
            }
            class y extends n.Component {
                constructor(...e) {
                    super(...e), this.rerender = () => {
                        this.forceUpdate()
                    }
                }
                componentDidMount() {
                    var {
                        statusV3: e,
                        listeners: t
                    } = this.props;
                    e && (t.add(e, "change:msgsChanged", this.rerender), e.loadMore(e.totalCount).catch((e => {
                        __LOG__(3)(S(), String(e))
                    })))
                }
                componentDidUpdate(e) {
                    var {
                        listeners: t,
                        statusV3: a
                    } = this.props, {
                        statusV3: s
                    } = e;
                    s !== a && (s && t.remove(s, "change:msgsChanged", this.rerender), a && t.add(a, "change:msgsChanged", this.rerender))
                }
                render() {
                    var e = this.props.statusV3;
                    if (e && e.msgs.length > 0) {
                        var t = e.msgs.map((t => n.createElement(P, {
                            key: t.id.toString(),
                            msg: t,
                            status: e,
                            onOpenStatus: this.props.onOpenStatus
                        })));
                        return n.createElement("div", {
                            className: E.default.viewWrapper
                        }, n.createElement("div", {
                            className: E.default.viewTitle
                        }, p.default.t(1287)), n.createElement("div", {
                            className: E.default.viewUpdates
                        }, t))
                    }
                    return n.createElement("div", {
                        className: E.default.viewWrapper
                    }, n.createElement("div", {
                        className: E.default.placeholderIcon
                    }, n.createElement(C.default, {
                        name: "status-v3-placeholder"
                    })), n.createElement("div", {
                        "data-a8n": l.default.key("status-placeholder"),
                        className: E.default.placeholderText
                    }, p.default.t(1281)))
                }
            }
            var M = (0, f.default)(y);
            class T extends n.Component {
                constructor() {
                    super(...arguments), this.state = {}
                }
                componentDidMount() {
                    m.default.find(this.props.msg.id).checkpoint(this.props.rejectOnUnmount()).then((e => {
                        this.props.listeners.add(e.read, "add remove", (() => {
                            this.setState({
                                seenCount: e.read.length
                            })
                        })), this.setState({
                            seenCount: e.read.length
                        })
                    })).catchType(c.Unmount, (() => {})).catchType(u.EphemeralDrop, (() => {}))
                }
                render() {
                    var e, t, a, {
                            msg: s,
                            status: i
                        } = this.props,
                        r = s.mediaData;
                    if (r && r.preview) e = {
                        backgroundImage: "url(".concat(r.preview.url(), ")")
                    };
                    else if (s.type === d.default.MSG_TYPE.CHAT) {
                        e = {
                            backgroundColor: s.statusV3TextBg
                        }
                    }
                    return s.type === d.default.MSG_TYPE.CHAT && (t = n.createElement(g.StatusV3Text, {
                        msg: s,
                        theme: "status-panel"
                    })), a = void 0 !== this.state.seenCount ? n.createElement(n.Fragment, null, n.createElement(C.default, {
                        name: "status-v3-seen",
                        className: E.default.iconSeen
                    }), n.createElement("div", {
                        className: E.default.seenCount
                    }, this.state.seenCount)) : n.createElement(_.default, {
                        stroke: 3,
                        size: 12
                    }), n.createElement("div", {
                        className: E.default.outDetail
                    }, n.createElement("div", {
                        className: E.default.statusImage,
                        style: e,
                        onClickCapture: e => {
                            this.props.onOpenStatus(i, s), e.preventDefault(), e.stopPropagation()
                        }
                    }, t), n.createElement("div", {
                        className: E.default.seen
                    }, a), n.createElement("div", {
                        className: E.default.timestamp
                    }, o.default.relativeDateAndTimeStr(s.t)))
                }
            }
            var P = (0, v.default)((0, f.default)(T)),
                L = I;
            t.default = L
        },
        21504: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.StatusV3Text = t.default = void 0;
            var r = i(a(19976)),
                n = i(a(54073)),
                l = i(a(72779)),
                o = s(a(2784)),
                d = i(a(43596)),
                u = i(a(43334)),
                c = i(a(19899)),
                h = i(a(79711)),
                p = i(a(50935)),
                f = i(a(46478)),
                m = i(a(91581)),
                v = s(a(96452)),
                _ = i(a(6660)),
                E = i(a(59159)),
                g = a(13414),
                C = i(a(44343)),
                S = i(a(53632)),
                I = a(62902),
                y = i(a(17957)),
                M = i(a(20642)),
                T = i(a(8603)),
                P = i(a(19125)),
                L = i(a(40210)),
                b = i(a(88352)),
                w = i(a(72259)),
                N = i(a(2825)),
                O = i(a(40207)),
                D = i(a(24190)),
                R = a(794),
                k = i(a(98475)),
                A = i(a(3839)),
                x = i(a(17693)),
                U = a(86145),
                F = i(a(81853));

            function B() {
                var e = (0, r.default)(["Invalid status v3 image type: ", ""]);
                return B = function() {
                    return e
                }, e
            }
            class V extends o.Component {
                constructor() {
                    super(...arguments), this._refProgressBar = o.createRef(), this._refProgressBarComponent = o.createRef(), this._refMeasuringProfile = o.createRef(), this._refWrapper = o.createRef(), this.componentWillUnmount = () => {
                        if (this._playbackController.removeListeners(), null != this.props.sessionId) {
                            var e = Math.round(this._playbackController.duration || 0);
                            this._statusViewEvent.webcStatusPlaybackT = e;
                            var t = this._playStartTime;
                            null != t && (this._statusViewEvent.webcStatusViewT += Math.round(window.performance.now() - t), this._playStartTime = void 0), this._statusViewEvent.commit()
                        }
                    }, this._onWindowResize = () => {
                        var e = this._refMeasuringProfile && this._refMeasuringProfile.current,
                            t = this._refProgressBar && this._refProgressBar.current;
                        if (e && t) {
                            var a = e.getBoundingClientRect(),
                                s = t.getBoundingClientRect();
                            !y.default.isRTL() && a.right > s.left - 5 || y.default.isRTL() && a.left < s.right + 5 ? this.setState({
                                narrow: !0
                            }) : this.setState({
                                narrow: !1
                            })
                        }
                    }, this._onTab = e => {
                        (e && (e.stopPropagation(), e.preventDefault()), this.props.statusV3.contact.isMe) || (this.composeBox.isFocused() ? this.dismissReply() : this._startReply())
                    }, this.onWindowGainedFocus = () => {
                        this._windowFocused = !0, this.play()
                    }, this.onWindowLostFocus = () => {
                        this._windowFocused = !1, this.pause()
                    }, this._onClickProfile = () => {
                        var e = this.props.statusV3.contact.id;
                        u.default.find(e).then((e => h.default.openChatBottom(e))).then((() => {
                            this.props.closeStatusViewer(!0)
                        }))
                    }, this.play = () => {
                        var e = this.props.mediaData;
                        if (e) {
                            if (e.mediaStage !== T.default.STAGE.RESOLVED) return;
                            this._statusViewEvent.webcStatusLoadT || (this._statusViewEvent.markWebcStatusLoadT(), this._statusViewEvent.webcStatusLoaded = !0)
                        }
                        var t = this.composeBox;
                        t && t.isPaused() || this._windowFocused && (this._playStartTime = window.performance.now(), this._playbackController.resume())
                    }, this.pause = () => {
                        var e = this.props.mediaData;
                        if (!e || e.mediaStage === T.default.STAGE.RESOLVED) {
                            var t = this._playStartTime;
                            null != t && (this._statusViewEvent.webcStatusViewT += Math.round(window.performance.now() - t), this._playStartTime = void 0), this._playbackController.pause()
                        }
                    }, this.onMouseDown = () => {
                        this.pause()
                    }, this.onMouseUp = () => {
                        this.play()
                    }, this.dismissReply = () => {
                        var e = this._refWrapper && this._refWrapper.current;
                        e && _.default.focus(e)
                    }, this._startReply = () => {
                        this.composeBox.restoreFocus()
                    }, this.onSend = () => {
                        this._statusViewEvent.webcStatusReplyCount++
                    }, this.state = {
                        chat: void 0,
                        narrow: !1
                    }, this._windowFocused = !0, this._playbackController = (0, R.setupStatusV3Controller)(this.props.mediaData, this.props.msg), this._statusViewEvent = new L.default.WebcStatusView({
                        webcStatusLoaded: !1,
                        webcStatusReplyCount: 0,
                        webcStatusViewT: 0
                    })
                }
                componentDidMount() {
                    var {
                        statusV3: e,
                        msg: t,
                        mediaData: a,
                        msgIdx: s,
                        sessionId: i
                    } = this.props;
                    if (null != i) {
                        var r;
                        r = e.contact.isMe ? L.default.WEBC_STATUS_ROW_SECTION.MY : e.contact.statusMute ? L.default.WEBC_STATUS_ROW_SECTION.MUTED : e.hasUnread ? L.default.WEBC_STATUS_ROW_SECTION.RECENT : L.default.WEBC_STATUS_ROW_SECTION.VIEWED;
                        var l, o = this.props.rowIdx || 0,
                            d = e.msgs.length - 1 - s < e.unreadCount;
                        a ? l = a.isGif ? L.default.WEBC_STATUS_MEDIA_TYPE.GIF : "video" === a.type ? L.default.WEBC_STATUS_MEDIA_TYPE.VIDEO : L.default.WEBC_STATUS_MEDIA_TYPE.IMAGE : (l = t.getLinks().length ? L.default.WEBC_STATUS_MEDIA_TYPE.URL : L.default.WEBC_STATUS_MEDIA_TYPE.TEXT, this._statusViewEvent.markWebcStatusLoadT(), this._statusViewEvent.webcStatusLoaded = !0), this._statusViewEvent.webcStatusSessionId = i, this._statusViewEvent.webcStatusRowSection = r, this._statusViewEvent.webcStatusRowIndex = o, this._statusViewEvent.webcStatusMediaType = l, this._statusViewEvent.webcStatusUnread = d
                    }
                    this._refProgressBarComponent && this._refProgressBarComponent.current && this._playbackController.addListeners(((e, t) => {
                        var a = this._refProgressBarComponent && this._refProgressBarComponent.current;
                        a && a.onStart(e, t)
                    }), (() => {
                        var e = this._refProgressBarComponent && this._refProgressBarComponent.current;
                        e && e.onPause()
                    }), (() => {
                        var e = this._refProgressBarComponent && this._refProgressBarComponent.current;
                        e && e.onEnded().checkpoint(this.props.rejectOnUnmount()).then((() => {
                            this.props.onNext()
                        })).catchType(v.Unmount, (() => {}))
                    })), a ? (this.play(), a && a.mediaStage === T.default.STAGE.RESOLVED && this.props.markRead(this.props.statusV3, this.props.msg)) : (this.props.msg.type, p.default.MSG_TYPE.CHAT, this.play(), this.props.markRead(this.props.statusV3, this.props.msg));
                    var u = this._refWrapper && this._refWrapper.current;
                    u && u.focus();
                    var c = this.props.listeners;
                    c.add(window, "focus", this.onWindowGainedFocus), c.add(window, "blur", this.onWindowLostFocus), c.add(window, "resize", (0, n.default)(this._onWindowResize)), this._onWindowResize()
                }
                render() {
                    var e, t, {
                        msg: a,
                        mediaData: s,
                        statusV3: i
                    } = this.props;
                    if (s && s.preview) e = {
                        backgroundImage: "url(".concat(s.preview.url(), ")")
                    };
                    else if (a.type === p.default.MSG_TYPE.CHAT) {
                        e = {
                            backgroundColor: a.statusV3TextBg
                        }
                    }
                    if (s) switch (s.type) {
                        case T.default.TYPE.IMAGE:
                            t = o.createElement(H, {
                                msg: a,
                                statusV3: i,
                                mediaData: s,
                                markRead: this.props.markRead,
                                play: this.play,
                                pause: this.pause,
                                onMouseDown: this.onMouseDown,
                                onMouseUp: this.onMouseUp
                            });
                            break;
                        case T.default.TYPE.VIDEO:
                            t = o.createElement(W, {
                                msg: a,
                                statusV3: i,
                                mediaData: s,
                                markRead: this.props.markRead,
                                play: this.play,
                                pause: this.pause,
                                playbackController: this._playbackController,
                                onMouseDown: this.onMouseDown,
                                onMouseUp: this.onMouseUp
                            });
                            break;
                        default:
                            __LOG__(3)(B(), s.type)
                    } else t = a.type === p.default.MSG_TYPE.CHAT ? o.createElement(K, {
                        msg: a,
                        onMouseDown: this.onMouseDown,
                        onMouseUp: this.onMouseUp
                    }) : o.createElement(z, {
                        onMouseDown: this.onMouseDown,
                        onMouseUp: this.onMouseUp
                    });
                    var r, n = o.createElement("div", {
                        ref: this._refProgressBar
                    }, o.createElement(A.default, {
                        ref: this._refProgressBarComponent,
                        current: this.props.msgIdx,
                        total: this.props.totalMsgs,
                        onClick: this.props.onClickProgressBar
                    }));
                    a.type !== p.default.MSG_TYPE.CHAT && (r = o.createElement("div", {
                        className: k.default.captionBackdrop
                    }, o.createElement(m.default, {
                        className: k.default.mediaCaption,
                        text: a.caption,
                        formatters: I.Configuration.StatusV3Caption()
                    })));
                    var d, u, h = (0, l.default)(k.default.profile, {
                            [k.default.nonClickProfile]: a.isSentByMe,
                            [k.default.profileNarrow]: this.state.narrow
                        }),
                        v = (0, l.default)(k.default.profile, k.default.measuringProfile, {}),
                        _ = o.createElement("div", {
                            className: h,
                            onClick: a.isSentByMe ? null : this._onClickProfile
                        }, o.createElement("div", {
                            className: k.default.playerAvatar
                        }, o.createElement(f.default, {
                            id: i.contact.id,
                            theme: "status_v3",
                            size: 40
                        })), o.createElement("div", {
                            className: k.default.msgInfo
                        }, o.createElement(m.default, {
                            className: k.default.msgInfoName,
                            text: i.contact.formattedName
                        }), o.createElement("div", {
                            className: k.default.timestamp
                        }, c.default.relativeDateAndTimeStr(a.t)))),
                        E = o.createElement("div", {
                            ref: this._refMeasuringProfile,
                            className: v
                        }, o.createElement("div", {
                            className: k.default.playerAvatar
                        }, o.createElement(f.default, {
                            id: i.contact.id,
                            theme: "status_v3",
                            size: 40
                        })), o.createElement("div", {
                            className: k.default.msgInfo
                        }, o.createElement(m.default, {
                            className: k.default.msgInfoName,
                            text: i.contact.formattedName
                        }), o.createElement("div", {
                            className: k.default.timestamp
                        }, c.default.relativeDateAndTimeStr(a.t)))),
                        S = {
                            tab: this._onTab,
                            "shift+tab": this._onTab
                        },
                        y = e => e.stopPropagation();
                    s && (d = o.createElement(q, {
                        mediaData: s
                    }));
                    var M = this.props.statusV3.contact;
                    M.isMe || M.isPSA || (u = o.createElement(C.default, {
                        handlers: {
                            left: y,
                            right: y
                        }
                    }, o.createElement(D.default, {
                        msg: this.props.msg,
                        dismissReply: this.dismissReply,
                        onSend: this.onSend,
                        pause: this.pause,
                        play: this.play,
                        ref: (0, g.GetRef)((e => {
                            this.composeBox = e
                        }))
                    })));
                    var P, L = (0, l.default)(k.default.playerBackground, {
                            [k.default.media]: s
                        }),
                        b = (0, l.default)(k.default.progressBackdrop, {
                            [k.default.progressBarBackdropNarrow]: this.state.narrow
                        });
                    return a.type !== p.default.MSG_TYPE.CHAT && (P = o.createElement("div", {
                        className: b
                    })), o.createElement(x.default, {
                        displayName: "StatusV3Player",
                        escapable: !0,
                        requestDismiss: e => {
                            e || this.props.closeStatusViewer()
                        },
                        requestFocus: this.dismissReply
                    }, o.createElement(C.default, {
                        handlers: S
                    }, o.createElement("div", {
                        className: k.default.playerWrapper,
                        key: a.id.toString(),
                        tabIndex: -1,
                        ref: this._refWrapper
                    }, E, _, P, n, r, o.createElement("div", {
                        className: L,
                        style: e
                    }), t, d, u)))
                }
            }
            class G extends o.PureComponent {
                constructor(...e) {
                    super(...e), this._renderImage = e => {
                        var {
                            msg: t,
                            mediaData: a
                        } = this.props, s = (0, l.default)(k.default.playerContent, k.default.v3Image);
                        return o.createElement("div", {
                            className: s,
                            onMouseDown: this.props.onMouseDown,
                            onMouseUp: this.props.onMouseUp,
                            onDragEnd: this.props.onMouseUp
                        }, o.createElement(b.default, {
                            type: "contain",
                            size: {
                                width: a.fullWidth,
                                height: a.fullHeight
                            }
                        }, o.createElement("div", {
                            className: k.default.mediaViewer
                        }, o.createElement(S.default, {
                            src: e,
                            disableContextMenu: !0
                        }), t && t.interactiveAnnotations && t.interactiveAnnotations.length > 0 && o.createElement(d.default, {
                            annotations: t.interactiveAnnotations,
                            onTooltipDisplay: this.props.onMouseDown,
                            onTooltipDismiss: this.props.onMouseUp
                        }))))
                    }, this._renderPreviewImage = () => {
                        var {
                            mediaData: e
                        } = this.props, t = (0, l.default)(k.default.playerContent, k.default.v3Image, k.default.loading);
                        return o.createElement("div", {
                            className: t,
                            onMouseDown: this.props.onMouseDown,
                            onMouseUp: this.props.onMouseUp
                        }, o.createElement(b.default, {
                            type: "contain",
                            size: {
                                width: e.aspectRatio,
                                height: 1
                            }
                        }, o.createElement(S.default, {
                            src: e.preview && e.preview.url()
                        })))
                    }, this._downloadMedia = () => this.props.msg.downloadMedia({
                        downloadEvenIfExpensive: !0,
                        rmrReason: L.default.WEBC_RMR_REASON_CODE.STATUS_V3,
                        isUserInitiated: !0
                    })
                }
                componentDidMount() {
                    this.props.mediaData.mediaStage !== T.default.STAGE.RESOLVED && this.props.msg.downloadMedia({
                        downloadEvenIfExpensive: !0,
                        rmrReason: L.default.WEBC_RMR_REASON_CODE.STATUS_V3,
                        isUserInitiated: !0
                    })
                }
                componentDidUpdate() {
                    this.props.play();
                    var e = this.props.mediaData;
                    e && e.mediaStage === T.default.STAGE.RESOLVED && this.props.markRead(this.props.statusV3, this.props.msg)
                }
                componentWillUnmount() {
                    this.props.pause()
                }
                render() {
                    return o.createElement(P.default, {
                        mediaData: this.props.mediaData,
                        placeholderRenderer: this._renderPreviewImage,
                        downloadMedia: this._downloadMedia,
                        renderProgressively: !0
                    }, this._renderImage)
                }
            }
            G.CONCERNS = {
                mediaData: ["mediaStage", "renderableUrl", "preview", "fullWidth", "fullHeight", "aspectRatio"]
            };
            var H = (0, O.default)(G, G.CONCERNS);
            class j extends o.PureComponent {
                constructor(...e) {
                    super(...e), this.refVideo = o.createRef(), this.setRefVideo = e => {
                        this.refVideo = e, this.props.playbackController.setVideo(this.refVideo.current)
                    }
                }
                componentDidMount() {
                    var e = this.props.mediaData;
                    e.streamable || e.isStreamable() || this.props.msg.downloadMedia({
                        downloadEvenIfExpensive: !0,
                        rmrReason: L.default.WEBC_RMR_REASON_CODE.STATUS_V3,
                        isUserInitiated: !0
                    })
                }
                componentDidUpdate() {
                    this.props.play();
                    var e = this.props.mediaData;
                    e && e.mediaStage === T.default.STAGE.RESOLVED && this.props.markRead(this.props.statusV3, this.props.msg)
                }
                componentWillUnmount() {
                    this.props.pause()
                }
                render() {
                    var {
                        msg: e,
                        mediaData: t,
                        onMouseDown: a,
                        onMouseUp: s
                    } = this.props, i = t.mediaStage !== T.default.STAGE.RESOLVED, r = (0, l.default)(k.default.playerContent, k.default.v3Video, {
                        loading: i
                    }), n = t.preview ? t.preview.url() : void 0;
                    return o.createElement("div", {
                        className: r,
                        onMouseDown: a,
                        onMouseUp: s
                    }, o.createElement(b.default, {
                        type: "contain",
                        size: {
                            width: t.fullWidth,
                            height: t.fullHeight
                        }
                    }, o.createElement("div", {
                        className: k.default.mediaViewer
                    }, o.createElement(F.default, {
                        msg: e,
                        mediaData: t,
                        autoPlay: !0,
                        refVideo: this.setRefVideo,
                        poster: n,
                        disableContextMenu: !0
                    }, y.default.t(1392)), e && e.interactiveAnnotations && e.interactiveAnnotations.length > 0 && o.createElement(d.default, {
                        annotations: e.interactiveAnnotations,
                        onTooltipDisplay: this.props.onMouseDown,
                        onTooltipDismiss: this.props.onMouseUp
                    }))))
                }
            }
            j.CONCERNS = {
                mediaData: ["preview", "mediaStage", "fullWidth", "fullHeight", "streamable"]
            };
            var W = (0, O.default)(j, j.CONCERNS);
            class K extends o.PureComponent {
                componentDidMount() {
                    E.default.load(this.props.msg.font).catch((() => {}))
                }
                render() {
                    var e, t, a = (0, U.numCodepoints)(this.props.msg.body),
                        s = {
                            [k.default["font_".concat(this.props.msg.font)]]: !0
                        };
                    return a <= 60 ? (e = (0, l.default)(k.default.text, k.default.textLarge, s), t = I.Configuration.StatusV3Text({
                        links: this.props.msg.getLinks()
                    })) : a <= 240 ? (e = (0, l.default)(k.default.text, k.default.textMedium, s), t = I.Configuration.StatusV3Text({
                        links: this.props.msg.getLinks()
                    })) : e = (0, l.default)(k.default.text, k.default.textSmall, s), o.createElement("div", {
                        className: (0, l.default)(k.default.playerContent, {
                            [k.default.statusPanelPlayerContent]: "status-panel" === this.props.theme,
                            [k.default.statusThumbnailPlayerContent]: "status-thumbnail" === this.props.theme,
                            [k.default.textThumbnailPlayerContent]: "text-thumb" === this.props.theme
                        }),
                        onMouseDown: this.props.onMouseDown,
                        onMouseUp: this.props.onMouseUp
                    }, o.createElement("div", {
                        className: e
                    }, o.createElement(m.default, {
                        text: this.props.msg.body,
                        formatters: t
                    })))
                }
            }
            t.StatusV3Text = K;
            class z extends o.PureComponent {
                render() {
                    return o.createElement("div", {
                        className: k.default.playerContent,
                        onMouseDown: this.props.onMouseDown,
                        onMouseUp: this.props.onMouseUp
                    }, o.createElement("div", {
                        className: k.default.unknown
                    }, y.default.t(1284)))
                }
            }
            class Y extends o.Component {
                render() {
                    var {
                        mediaData: e
                    } = this.props;
                    return e.mediaStage !== T.default.STAGE.RESOLVED ? o.createElement("div", {
                        className: k.default.mediaStateControls
                    }, o.createElement("button", {
                        className: "icon-media-disabled"
                    }, o.createElement(N.default, {
                        size: 50,
                        stroke: 4,
                        color: "white"
                    }))) : null
                }
            }
            Y.CONCERNS = {
                mediaData: ["mediaStage"]
            };
            var q = (0, O.default)(Y, Y.CONCERNS),
                Z = (0, w.default)((0, M.default)(V));
            t.default = Z
        },
        6901: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = i(a(72779)),
                l = a(91460),
                o = s(a(2784)),
                d = i(a(79711)),
                u = i(a(50935)),
                c = a(19741),
                h = s(a(96452)),
                p = i(a(59159)),
                f = i(a(44343)),
                m = i(a(17957)),
                v = i(a(8603)),
                _ = i(a(40210)),
                E = i(a(72259)),
                g = i(a(2825)),
                C = i(a(21504)),
                S = s(a(75449)),
                I = i(a(38157)),
                y = i(a(82631)),
                M = s(a(75074)),
                T = i(a(74824));

            function P() {
                var e = (0, r.default)(["Invalid iterator while loading first unread msg"]);
                return P = function() {
                    return e
                }, e
            }

            function L() {
                var e = (0, r.default)(["Invalid iterator while loading first unread msg"]);
                return L = function() {
                    return e
                }, e
            }

            function b() {
                var e = (0, r.default)(["Invalid iterator while loading first unread msg"]);
                return b = function() {
                    return e
                }, e
            }

            function w() {
                var e = (0, r.default)(["No more status v3 while preloading next status"]);
                return w = function() {
                    return e
                }, e
            }

            function N() {
                var e = (0, r.default)(["Invalid iterator while getting next status msg"]);
                return N = function() {
                    return e
                }, e
            }

            function O() {
                var e = (0, r.default)(["No more status v3 while preloading next status"]);
                return O = function() {
                    return e
                }, e
            }

            function D() {
                var e = (0, r.default)(["Invalid iterator while getting previous status msg"]);
                return D = function() {
                    return e
                }, e
            }

            function R() {
                var e = (0, r.default)(["No more status v3 while preloading next status"]);
                return R = function() {
                    return e
                }, e
            }

            function k() {
                var e = (0, r.default)(["Error finding next status while preloading next status"]);
                return k = function() {
                    return e
                }, e
            }

            function A() {
                var e = (0, r.default)(["Invalid iterator while preloading next status"]);
                return A = function() {
                    return e
                }, e
            }

            function x() {
                var e = (0, r.default)(["No more status v3 while preloading next status"]);
                return x = function() {
                    return e
                }, e
            }

            function U() {
                var e = (0, r.default)(["Invalid iterator while getting next status msg"]);
                return U = function() {
                    return e
                }, e
            }
            class F extends o.Component {
                constructor() {
                    super(...arguments), this.onClickProgressBar = e => {
                        var t = this.state.iterator;
                        if ((!t || e !== t.msgIdx) && t) {
                            var a = this._statusV3Snapshot.statusAt(t, e);
                            a.isFulfilled() || this.setState({
                                loading: !0
                            }), a.checkpoint(this.props.rejectOnUnmount()).then((e => {
                                this.setState({
                                    iterator: e
                                })
                            })).catchType(h.Unmount, (() => {})).catchType(c.EphemeralDrop, (() => {})).catchType(S.InvalidStatusV3Iterator, (() => {
                                __LOG__(3)(U())
                            })).catchType(S.StatusV3LoadingError, (() => {
                                __LOG__(3)(x())
                            })).finally((() => {
                                this.setState({
                                    loading: !1
                                })
                            }))
                        }
                    }, this._preloadNextStatus = () => {
                        var e = this.state.iterator;
                        e && this._statusV3Snapshot.hasNext(e) && this._statusV3Snapshot.getNext(e).checkpoint(this.props.rejectOnUnmount()).then((e => {
                            var t = this._statusV3Snapshot.statuses[e.statusIdx].msgs[e.msgIdx];
                            if (!t) throw new S.StatusV3MsgNotFound;
                            if (t.type === u.default.MSG_TYPE.CHAT) p.default.load(t.font).catch((() => {}));
                            else {
                                var a = t.mediaData;
                                a && a.mediaStage !== v.default.STAGE.RESOLVED && t.downloadMedia({
                                    downloadEvenIfExpensive: !0,
                                    rmrReason: _.default.WEBC_RMR_REASON_CODE.STATUS_V3,
                                    isUserInitiated: !1
                                })
                            }
                        })).catchType(h.Unmount, (() => {})).catchType(c.EphemeralDrop, (() => {})).catchType(S.InvalidStatusV3Iterator, (() => {
                            __LOG__(3)(A())
                        })).catchType(S.StatusV3MsgNotFound, (() => {
                            __LOG__(3)(k())
                        })).catchType(S.StatusV3LoadingError, (() => {
                            __LOG__(3)(R())
                        }))
                    }, this.onPrev = () => {
                        var e = this.state.iterator;
                        if (e && this._statusV3Snapshot.hasPrev(e)) {
                            var t = e.statusIdx;
                            this._statusV3Snapshot.getPrev(e).checkpoint(this.props.rejectOnUnmount()).then((e => {
                                e.statusIdx === t ? this.setState({
                                    iterator: e
                                }) : (this.setState({
                                    transitioning: !0
                                }), (0, l.delayMs)(200).checkpoint(this.props.rejectOnUnmount()).then((() => {
                                    this.setState({
                                        iterator: e,
                                        transitioning: !1
                                    })
                                })).catchType(h.Unmount, (() => {})))
                            })).catchType(h.Unmount, (() => {})).catchType(c.EphemeralDrop, (() => {})).catchType(S.InvalidStatusV3Iterator, (() => {
                                __LOG__(3)(D())
                            })).catchType(S.StatusV3LoadingError, (() => {
                                __LOG__(3)(O())
                            }))
                        }
                    }, this.onNext = () => {
                        var e = this.state.iterator;
                        if (e && this._statusV3Snapshot.hasNext(e)) {
                            var t = e.statusIdx,
                                a = this._statusV3Snapshot.getNext(e);
                            a.isFulfilled() || this.setState({
                                loading: !0
                            }), a.checkpoint(this.props.rejectOnUnmount()).then((e => {
                                e.statusIdx === t ? this.setState({
                                    iterator: e
                                }) : (this.setState({
                                    transitioning: !0,
                                    loading: !1
                                }), (0, l.delayMs)(200).checkpoint(this.props.rejectOnUnmount()).then((() => {
                                    this.setState({
                                        iterator: e,
                                        transitioning: !1
                                    })
                                })).catchType(h.Unmount, (() => {})))
                            })).catchType(h.Unmount, (() => {})).catchType(c.EphemeralDrop, (() => {})).catchType(S.InvalidStatusV3Iterator, (() => {
                                __LOG__(3)(N()), this.closeStatusViewer()
                            })).catchType(S.StatusV3LoadingError, (() => {
                                __LOG__(3)(w())
                            })).finally((() => {
                                this.setState({
                                    loading: !1
                                })
                            }))
                        } else this.closeStatusViewer()
                    }, this.markRead = (e, t) => {
                        if (t) {
                            var a = e.unreadCount,
                                s = e.totalCount;
                            e.msgs.getModelsArray().findIndex((e => e === t)) >= s - a && e.sendReadStatus(t.id, t.author);
                            var i = this._statusV3Snapshot.statuses.find((t => t.statusV3 === e));
                            i && i.readMsgKeys.push(t.id.toString())
                        }
                    }, this.closeStatusViewer = e => {
                        this.setState({
                            transitioning: !0
                        }), (0, l.delayMs)(200).checkpoint(this.props.rejectOnUnmount()).then((() => {
                            this.props.closeStatusViewer(e)
                        })).catchType(h.Unmount, (() => {}))
                    };
                    var e = this.props.initialStatusV3;
                    if (this.props.quotedMsgKey) {
                        this.state = {};
                        var t = this.props.quotedMsgKey;
                        if (-1 !== e.msgs.getModelsArray().findIndex((e => e.id.toString() === t.toString()))) this._statusV3Snapshot = new S.default(e, t), this._statusV3Snapshot.getFirstUnread(e, !0, t).checkpoint(this.props.rejectOnUnmount()).then((e => {
                            this.setState({
                                iterator: e,
                                loading: !1
                            })
                        })).catchType(h.Unmount, (() => {})).catchType(c.EphemeralDrop, (() => {})).catchType(S.InvalidStatusV3Iterator, (() => {
                            __LOG__(3)(L()), d.default.openToast(o.createElement(M.default, {
                                msg: m.default.t(1277),
                                id: (0, M.genId)()
                            })), this.props.closeStatusViewer()
                        }));
                        else this.state = {
                            loading: !0
                        }, e.loadMore(e.totalCount).then((() => {
                            (this.setState({
                                loading: !1
                            }), -1 !== e.msgs.getModelsArray().findIndex((e => e.id.toString() === t.toString()))) ? (this._statusV3Snapshot = new S.default(e, t), this._statusV3Snapshot.getFirstUnread(e, !0, t).checkpoint(this.props.rejectOnUnmount()).then((e => {
                                this.setState({
                                    iterator: e,
                                    loading: !1
                                })
                            })).catchType(h.Unmount, (() => {})).catchType(c.EphemeralDrop, (() => {})).catchType(S.InvalidStatusV3Iterator, (() => {
                                __LOG__(3)(P()), d.default.openToast(o.createElement(M.default, {
                                    msg: m.default.t(1277),
                                    id: (0, M.genId)()
                                })), this.props.closeStatusViewer()
                            }))) : (this.props.onMsgNotFound && this.props.onMsgNotFound(), d.default.openToast(o.createElement(M.default, {
                                msg: m.default.t(1277),
                                id: (0, M.genId)()
                            })), this.props.closeStatusViewer())
                        })).catch((() => {
                            d.default.openToast(o.createElement(M.default, {
                                msg: m.default.t(1277),
                                id: (0, M.genId)()
                            })), this.props.closeStatusViewer()
                        })).finally((() => {
                            this.setState({
                                loading: !1
                            })
                        }))
                    } else {
                        var a = this.props.initialStatusMsg;
                        this._statusV3Snapshot = new S.default(e);
                        var s = this._statusV3Snapshot.getFirstUnread(e, !0, a && a.id);
                        s.isFulfilled() ? this.state = {} : this.state = {
                            loading: !0
                        }, s.checkpoint(this.props.rejectOnUnmount()).then((e => {
                            this.setState({
                                iterator: e,
                                loading: !1
                            })
                        })).catchType(h.Unmount, (() => {})).catchType(c.EphemeralDrop, (() => {})).catchType(S.InvalidStatusV3Iterator, (() => {
                            __LOG__(3)(b()), d.default.openToast(o.createElement(M.default, {
                                msg: m.default.t(1277),
                                id: (0, M.genId)()
                            })), this.props.closeStatusViewer()
                        }))
                    }
                }
                componentDidMount() {
                    this._preloadNextStatus()
                }
                componentDidUpdate() {
                    this._preloadNextStatus()
                }
                render() {
                    var e, t, a, s, i, r, l, d, u = this.state.iterator;
                    u && (r = (i = this._statusV3Snapshot).statuses[u.statusIdx], l = r.statusV3, d = r.msgs[u.msgIdx], i.hasPrev(u) && (a = o.createElement("div", {
                        className: I.default.chevronLeft
                    }, o.createElement(y.default, {
                        name: "chevron-left"
                    })), s = o.createElement("div", {
                        className: I.default.chevronLeftBg,
                        onClick: this.onPrev
                    })), i.hasNext(u) && (e = o.createElement("div", {
                        className: I.default.chevronRight
                    }, o.createElement(y.default, {
                        name: "chevron-right"
                    })), t = o.createElement("div", {
                        className: I.default.chevronRightBg,
                        onClick: () => {
                            this.onNext(), this.markRead(l, d)
                        }
                    })));
                    var c, h = {
                        left: this.onPrev,
                        right: this.onNext
                    };
                    !this.state.transitioning && !this.state.loading && d && u && r && l && (c = o.createElement("div", {
                        className: I.default.playerContainer,
                        key: d.id
                    }, o.createElement(C.default, {
                        key: d.id,
                        statusV3: l,
                        msg: d,
                        mediaData: d.mediaData,
                        msgIdx: u.msgIdx,
                        totalMsgs: r.totalCount,
                        markRead: this.markRead,
                        closeStatusViewer: this.closeStatusViewer,
                        onClickProgressBar: this.onClickProgressBar,
                        onNext: this.onNext,
                        onPrev: this.onPrev,
                        sessionId: this.props.sessionId,
                        rowIdx: this.props.rowIdx
                    })));
                    var p, m = (0, n.default)(I.default.v3X, {}),
                        v = o.createElement("button", {
                            className: m,
                            onClick: () => this.props.closeStatusViewer(!0)
                        }, o.createElement(y.default, {
                            name: "x-viewer"
                        })),
                        _ = (0, n.default)(I.default.backIcon, {}),
                        E = o.createElement("button", {
                            className: _,
                            onClick: () => this.props.closeStatusViewer()
                        }, o.createElement(y.default, {
                            name: "back",
                            directional: !0
                        }));
                    return this.state.loading && (p = o.createElement("div", {
                        className: I.default.mediaStateControls
                    }, o.createElement("button", null, o.createElement(g.default, {
                        size: 50,
                        stroke: 4,
                        color: "white"
                    })))), o.createElement(f.default, {
                        handlers: h
                    }, o.createElement("div", {
                        className: I.default.viewer,
                        "data-animate-status-v3-viewer": !0
                    }, v, E, s, a, t, e, p, o.createElement(T.default, {
                        transitionName: "status-v3-player",
                        transitionAppear: !0
                    }, c)))
                }
            }
            var B = (0, E.default)(F);
            t.default = B
        },
        93869: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(79711)),
                l = s(a(9386)),
                o = s(a(17957)),
                d = s(a(31003)),
                u = s(a(94984)),
                c = s(a(2220));
            class h extends r.PureComponent {
                constructor(...e) {
                    super(...e), this.state = {
                        theme: "system"
                    }, this._handleThemeChange = e => {
                        var t, a = null == e || null === (t = e.target) || void 0 === t ? void 0 : t.value;
                        "light" !== a && "dark" !== a && "system" !== a || this.setState({
                            theme: a
                        })
                    }, this._handleOk = () => {
                        var {
                            theme: e
                        } = this.state;
                        "system" === e ? (this.context.setSystemThemeMode(!0), this.context.setTheme(u.default.currentTheme)) : (this.context.setSystemThemeMode(!1), this.context.setTheme(e)), n.default.closeModal()
                    }, this._handleCancel = () => {
                        n.default.closeModal()
                    }
                }
                componentDidMount() {
                    this.setState({
                        theme: this.context.systemThemeMode ? "system" : this.context.theme
                    })
                }
                render() {
                    var {
                        theme: e
                    } = this.state;
                    return r.createElement(l.default, {
                        title: o.default.t(1327),
                        onOK: this._handleOk,
                        onCancel: this._handleCancel
                    }, r.createElement("form", null, r.createElement("ol", null, r.createElement("li", {
                        key: "light"
                    }, r.createElement("label", {
                        className: d.default.label
                    }, r.createElement("input", {
                        type: "radio",
                        name: "theme",
                        value: "light",
                        className: d.default.input,
                        checked: "light" === e,
                        onChange: this._handleThemeChange
                    }), o.default.t(1326))), r.createElement("li", {
                        key: "dark"
                    }, r.createElement("label", {
                        className: d.default.label
                    }, r.createElement("input", {
                        type: "radio",
                        name: "theme",
                        value: "dark",
                        className: d.default.input,
                        checked: "dark" === e,
                        onChange: this._handleThemeChange
                    }), o.default.t(1325))), r.createElement("li", {
                        key: "system"
                    }, r.createElement("label", {
                        className: d.default.label
                    }, r.createElement("input", {
                        type: "radio",
                        name: "theme",
                        value: "system",
                        className: d.default.input,
                        checked: "system" === e,
                        onChange: this._handleThemeChange
                    }), o.default.t(1328))))))
                }
            }
            t.default = h, h.contextType = c.default
        },
        18931: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(43334)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = s(a(91581)),
                u = s(a(17957));
            class c extends r.Component {
                constructor(...e) {
                    super(...e), this.onCancel = () => {
                        l.default.closeModal()
                    }, this._onUnstar = () => {
                        var e = this.props.chat,
                            t = this.props.msgs;
                        e && e.pendingAction++, n.default.unstarAllMessages(t, e).finally((() => {
                            e && e.pendingAction--
                        })), l.default.closeModal()
                    }
                }
                render() {
                    return r.createElement(o.default, {
                        onOK: this._onUnstar,
                        okText: u.default.t(1345),
                        onCancel: this.onCancel
                    }, r.createElement("div", null, r.createElement(d.default, {
                        text: u.default.t(1346)
                    })))
                }
            }
            t.default = c
        },
        44031: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = a(46774),
                l = s(a(58701)),
                o = s(a(73023)),
                d = i(a(71311)),
                u = s(a(91581)),
                c = s(a(44343)),
                h = s(a(17957)),
                p = i(a(41967)),
                f = s(a(94461)),
                m = s(a(82631)),
                v = s(a(27611)),
                _ = s(a(91735)),
                E = a(84990);
            class g extends r.Component {
                render() {
                    var e, {
                        contactList: t,
                        onSend: a,
                        onBack: s,
                        chat: i
                    } = this.props;
                    switch (i.kind) {
                        case n.CHAT_KIND.CHAT:
                            e = h.default.t(499, {
                                chat: i.title(),
                                count: h.default.n(t.length),
                                _plural: t.length
                            });
                            break;
                        case n.CHAT_KIND.GROUP:
                            e = h.default.t(500, {
                                chat: i.title(),
                                count: h.default.n(t.length),
                                _plural: t.length
                            });
                            break;
                        case n.CHAT_KIND.BROADCAST:
                            e = h.default.t(498, {
                                chat: i.title(),
                                count: h.default.n(t.length),
                                _plural: t.length
                            })
                    }
                    var _ = e ? r.createElement(u.default, {
                        text: e,
                        direction: "auto",
                        titlify: !0,
                        ellipsify: !0
                    }) : null;
                    return r.createElement(p.default, {
                        type: p.BoxModalType
                    }, r.createElement(l.default, null, r.createElement(d.default, {
                        type: d.DRAWER_HEADER_TYPE.POPUP,
                        onBack: s
                    }, _), r.createElement(o.default, null, r.createElement(c.default, null, r.createElement("div", {
                        className: v.default.body
                    }, t.map(((e, t) => this._renderVcard((0, E.vcardFromContactModel)(e), t.toString())))))), r.createElement("div", {
                        className: v.default.btnContainer
                    }, r.createElement("div", {
                        className: v.default.btnPosition
                    }, r.createElement(f.default, {
                        large: !0,
                        onClick: a
                    }, r.createElement(m.default, {
                        name: "send",
                        directional: !0
                    }))))))
                }
                _renderVcard(e, t) {
                    var a = (0, E.parseVcard)(e.vcard);
                    return a ? r.createElement("div", {
                        key: t,
                        className: v.default.vcardWrapper
                    }, r.createElement(_.default, {
                        parsedVcard: a,
                        thumbnail: (0, E.vcardThumbnail)(a)
                    })) : null
                }
            }
            t.default = g
        },
        2663: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(32960)),
                o = i(a(23109)),
                d = i(a(21403)),
                u = i(a(79711)),
                c = i(a(50935)),
                h = i(a(58701)),
                p = i(a(73023)),
                f = s(a(71311)),
                m = i(a(17957)),
                v = i(a(72424)),
                _ = i(a(40207)),
                E = a(40263),
                g = i(a(2220)),
                C = s(a(75074)),
                S = a(80084),
                I = i(a(98370));
            class y extends n.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        hover: !1
                    }, this.onClick = () => {
                        var e = this._encodeColor(),
                            t = o.default.get("defaultPreference");
                        t && e !== t.wallpaperColor && (t.set("wallpaperColor", e), u.default.openToast(n.createElement(C.default, {
                            msg: m.default.t(1495),
                            id: (0, C.genId)()
                        })))
                    }, this.onMouseOver = () => {
                        this.state.hover || (this.setState({
                            hover: !0
                        }), o.default.trigger("wallpaper_color_preview", this._encodeColor()))
                    }, this.onMouseEnter = () => {
                        this.state.hover || (this.setState({
                            hover: !0
                        }), o.default.trigger("wallpaper_color_preview", this._encodeColor()))
                    }, this.onMouseLeave = () => {
                        this.state.hover && (this.setState({
                            hover: !1
                        }), o.default.trigger("wallpaper_color_preview"))
                    }, this._encodeColor = () => {
                        var {
                            colorHex: e,
                            isDefault: t
                        } = this.props;
                        return t ? c.default.DEFAULT_CHAT_WALLPAPER : e
                    }
                }
                render() {
                    var e = this.props.isDefault ? n.createElement("span", {
                            className: I.default.wallpaperDefaultTitle,
                            "data-a8n": l.default.key("wallpaper-default-title")
                        }, m.default.t(522)) : null,
                        t = (0, r.default)(I.default.wallpaperColorCanvas, {
                            [I.default.canvasHover]: this.state.hover,
                            [I.default.canvasActive]: this.props.isSelected,
                            [I.default.canvasDefault]: this.props.isDefault
                        });
                    return n.createElement("span", {
                        className: t,
                        style: {
                            backgroundColor: this.props.colorHex
                        },
                        onMouseOver: this.onMouseOver,
                        onMouseEnter: this.onMouseEnter,
                        onMouseLeave: this.onMouseLeave,
                        onClick: this.onClick,
                        title: this.props.isDefault ? m.default.t(522) : null
                    }, e)
                }
            }
            class M extends n.Component {
                constructor(...e) {
                    super(...e), this._onWallpaperDoodleChange = () => {
                        var {
                            chatPreference: e
                        } = this.props;
                        if (e) {
                            var t = !e.showDoodle;
                            e.set("showDoodle", t), u.default.openToast(n.createElement(C.default, {
                                msg: t ? m.default.t(1496) : m.default.t(1497),
                                id: (0, C.genId)()
                            }))
                        }
                    }
                }
                render() {
                    var e, {
                            chatPreference: t,
                            colors: a
                        } = this.props,
                        s = t && t.wallpaperColor,
                        i = t && t.showDoodle,
                        r = a.map((e => n.createElement(y, {
                            colorHex: e,
                            isSelected: s === e,
                            isDefault: !1,
                            key: e
                        }))),
                        l = n.createElement(y, {
                            isSelected: s === c.default.DEFAULT_CHAT_WALLPAPER,
                            isDefault: !0,
                            key: c.default.DEFAULT_CHAT_WALLPAPER
                        });
                    r.unshift(l);
                    for (var o = 0; o < 2; o++) r.push(n.createElement("div", {
                        key: "emptyEl" + o,
                        className: I.default.wallpaperColorEmpty
                    }));
                    return v.default.wallpapersV2 && (e = n.createElement("div", {
                        className: I.default.wallpaperApplyDoodle
                    }, n.createElement(d.default, {
                        onChange: this._onWallpaperDoodleChange,
                        checked: !!i
                    }), n.createElement(E.TextSpan, {
                        className: I.default.checkboxLabel,
                        theme: "small"
                    }, m.default.t(1494)))), n.createElement(n.Fragment, null, e, n.createElement("div", {
                        className: I.default.wallpaperColorGrid
                    }, r))
                }
            }
            M.CONCERNS = {
                chatPreference: ["wallpaperColor", "showDoodle"]
            };
            var T = (0, _.default)(M, M.CONCERNS);
            class P extends n.Component {
                componentWillUnmount() {
                    o.default.trigger("wallpaper_color_preview"), v.default.wallpapersV2 && o.default.trigger("wallpaper_drawer_close")
                }
                componentDidMount() {
                    v.default.wallpapersV2 && o.default.trigger("wallpaper_drawer_open")
                }
                render() {
                    return n.createElement(h.default, null, n.createElement(f.default, {
                        title: m.default.t(1498),
                        onBack: this.props.onClose,
                        type: f.DRAWER_HEADER_TYPE.LARGE
                    }), n.createElement(p.default, null, n.createElement(T, {
                        colors: (0, S.getWallpaperColors)(this.context.theme),
                        chatPreference: o.default.get("defaultPreference")
                    })))
                }
            }
            t.default = P, P.contextType = g.default
        },
        6099: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(19899)),
                l = s(a(79711)),
                o = s(a(9386)),
                d = i(a(37356)),
                u = s(a(58701)),
                c = s(a(73023)),
                h = i(a(71311)),
                p = a(19741),
                f = s(a(12522)),
                m = s(a(22004)),
                v = s(a(17957)),
                _ = s(a(46937)),
                E = s(a(58670)),
                g = s(a(96116)),
                C = a(40263);
            class S extends r.Component {
                constructor(e) {
                    super(e), this._orderFlatListController = new m.default, this.state = {
                        isLoading: !0,
                        fetchState: "PENDING",
                        order: null
                    }
                }
                componentDidMount() {
                    var {
                        orderId: e,
                        token: t,
                        sellerJid: a
                    } = this.props;
                    _.default.findOrder(e, a, t).then((e => {
                        this.setState({
                            fetchState: "SUCCESS",
                            isLoading: !1,
                            order: e
                        })
                    })).catchType(p.E404, (() => {
                        this._showNotFoundErrorToast(), this.setState({
                            fetchState: "ERROR",
                            isLoading: !1
                        })
                    })).catch((() => {
                        this.setState({
                            fetchState: "ERROR",
                            isLoading: !1
                        })
                    }))
                }
                _getDrawerContent() {
                    var {
                        sellerJid: e,
                        sessionId: t
                    } = this.props, {
                        fetchState: a,
                        order: s
                    } = this.state;
                    if (this.state.isLoading || null == s) return r.createElement(f.default, {
                        fetchState: a
                    });
                    var i = "";
                    i = s.products.length > 0 ? v.default.t(814, {
                        count: s.totalItemCount || 0,
                        _plural: s.totalItemCount || 0
                    }) : v.default.t(1096);
                    var l = r.createElement(C.TextDiv, {
                            theme: "title"
                        }, i),
                        o = null;
                    o = null != s.total && 0 !== s.total ? v.default.t(1093, {
                        subtotal: d.format(s.currency, s.total)
                    }) : v.default.t(1089);
                    var u = r.createElement(C.TextDiv, {
                            theme: "muted-small"
                        }, o),
                        c = null;
                    if (null != s.createdAt) {
                        var h = n.default.timeStr(s.createdAt);
                        c = r.createElement(C.TextSpan, {
                            theme: "muted-small"
                        }, "".concat(h))
                    }
                    return r.createElement(r.Fragment, null, r.createElement(f.default, {
                        fetchState: a
                    }), r.createElement("div", {
                        className: E.default.info
                    }, l, u), r.createElement(g.default, {
                        flatListController: this._orderFlatListController,
                        onProductDetail: this.props.onProductDetail,
                        order: s,
                        sellerJid: e,
                        sessionId: t
                    }), r.createElement("div", {
                        className: E.default.date
                    }, c))
                }
                _showNotFoundErrorToast() {
                    l.default.openModal(r.createElement(o.default, {
                        onOK: () => {
                            l.default.closeModal()
                        },
                        okText: v.default.t(1680)
                    }, v.default.t(1090)))
                }
                onClose() {
                    l.default.closeDrawerRight()
                }
                render() {
                    var {
                        userIsCartOwner: e
                    } = this.props;
                    return r.createElement(u.default, {
                        theme: "striped",
                        onDrop: this.onClose
                    }, r.createElement(h.default, {
                        title: e ? v.default.t(409) : v.default.t(408),
                        type: h.DRAWER_HEADER_TYPE.SMALL,
                        onBack: this.onClose
                    }), r.createElement(c.default, {
                        flatListControllers: [this._orderFlatListController]
                    }, this._getDrawerContent()))
                }
            }
            t.default = S
        },
        96116: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    order: t,
                    onProductDetail: a,
                    sellerJid: s,
                    sessionId: i
                } = e;
                return r.createElement(o.default, {
                    flatListControllers: [e.flatListController]
                }, r.createElement(l.default, {
                    flatListController: e.flatListController,
                    direction: "vertical",
                    forceConsistentRenderCount: !1,
                    data: (c = t.orderItemCollection.toArray(), (0, d.logOrderListImpression)({
                        catalogSessionId: i,
                        orderId: t.id,
                        productCount: c.length,
                        catalogOwnerJid: s
                    }), c.map((e => ({
                        itemKey: e.id.toString(),
                        product: e
                    })))),
                    renderItem: t => {
                        var {
                            order: s,
                            sellerJid: i,
                            sessionId: n
                        } = e, {
                            product: l
                        } = t, o = {
                            productId: l.id,
                            businessOwnerJid: i
                        };
                        return r.createElement(u.default, {
                            product: l,
                            onClick: () => {
                                (0, d.logOrderListItemClick)({
                                    catalogSessionId: n,
                                    orderId: s.id,
                                    catalogOwnerJid: i
                                }), a(o, n)
                            }
                        })
                    },
                    defaultItemHeight: n.default.PRODUCT_LIST_ITEM_HEIGHT
                }));
                var c
            };
            var r = i(a(2784)),
                n = s(a(50935)),
                l = s(a(35598)),
                o = s(a(63097)),
                d = a(63865),
                u = s(a(84933))
        },
        84933: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    product: t,
                    onClick: a
                } = e, s = r.createElement(o.default, {
                    text: t.name,
                    ellipsify: !0,
                    titlify: !0
                }), i = r.createElement(c.default, {
                    mediaData: t.mediaData,
                    theme: "list"
                }), p = d.default.t(1094, {
                    quantity: t.quantity.toString()
                }), f = null;
                t.quantity && (f = r.createElement(h.TextSpan, {
                    className: u.default.quantity
                }, p));
                var m = null;
                m = t.price && 0 !== t.price ? l.format(t.currency, t.price) : d.default.t(401);
                var v = r.createElement(h.TextSpan, {
                        className: u.default.price
                    }, m),
                    _ = null;
                null != f && (_ = r.createElement("span", {
                    className: u.default.separator
                }, "•"));
                var E = r.createElement("div", null, v, _, f);
                return r.createElement(n.default, {
                    key: t.id.toString(),
                    image: i,
                    customImage: !0,
                    primary: s,
                    secondary: E,
                    theme: "order-product",
                    onClick: a
                })
            };
            var r = i(a(2784)),
                n = s(a(96066)),
                l = i(a(37356)),
                o = s(a(91581)),
                d = s(a(17957)),
                u = s(a(98524)),
                c = s(a(92209)),
                h = a(40263)
        },
        65995: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.EditProductDrawer = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = a(57050),
                o = i(a(64)),
                d = i(a(21403)),
                u = i(a(79711)),
                c = a(8430),
                h = s(a(37356)),
                p = i(a(48535)),
                f = i(a(58701)),
                m = i(a(73023)),
                v = s(a(71311)),
                _ = i(a(72227)),
                E = a(19741),
                g = a(95595),
                C = i(a(98294)),
                S = i(a(17957)),
                I = i(a(20642)),
                y = a(83974),
                M = s(a(37163)),
                T = a(8125),
                P = i(a(67864)),
                L = i(a(72259)),
                b = i(a(72424)),
                w = i(a(2825)),
                N = i(a(40207)),
                O = i(a(52100)),
                D = s(a(75074)),
                R = i(a(74185));
            class k extends n.Component {
                constructor(e) {
                    var t;
                    super(e), this._imagePanelRef = n.createRef(), this._onNameChange = e => {
                        this.setState({
                            name: e,
                            nameError: "" === e ? S.default.t(644) : "",
                            isModified: !0
                        })
                    }, this.getServerPrice = e => parseInt(parseFloat(e).toFixed(2).toString().replace(/\.|,/g, ""), 10), this._onPriceChange = e => {
                        var t = h.valueFromString(this.state.currency, e),
                            a = "";
                        "" === e || h.validatePriceString(this.state.currency, e, M.MIN_PRICE, M.MAX_PRICE) || (a = S.default.t(645)), this.setState({
                            priceAmount1000: "" === e ? null : t,
                            priceStr: "".concat(e),
                            priceError: a,
                            isModified: !0
                        })
                    }, this.onDescriptionChange = e => {
                        this.setState({
                            description: e,
                            isModified: !0
                        })
                    }, this._onUrlChange = e => {
                        var t = "";
                        "" === e || R.default.isValid(e) || (t = S.default.t(650)), this.setState({
                            url: e,
                            urlError: t,
                            isModified: !0
                        })
                    }, this._onUrlBlur = () => {
                        var {
                            url: e
                        } = this.state;
                        "" === e || R.default.isHttps(e) || R.default.isHttp(e) || this.setState({
                            url: "https://".concat(e)
                        })
                    }, this._onRetailerIdChange = e => {
                        this.setState({
                            retailerId: e,
                            retailerIdError: "",
                            isModified: !0
                        })
                    }, this._onHiddenChange = () => {
                        this.setState({
                            isHidden: !this.state.isHidden
                        })
                    }, this._getProductChanges = () => {
                        var {
                            product: e
                        } = this.props, {
                            name: t,
                            priceAmount1000: a,
                            currency: s,
                            description: i,
                            url: r,
                            retailerId: n,
                            isHidden: l
                        } = this.state;
                        return new M.default({
                            id: e.id,
                            priceAmount1000: a,
                            currency: s,
                            description: i || "",
                            imageCdnUrl: e.imageCdnUrl,
                            additionalImageCdnUrl: e.additionalImageCdnUrl,
                            name: t,
                            retailerId: n,
                            url: r,
                            isHidden: l
                        })
                    }, this._onSaveItem = () => {
                        var e, {
                                catalog: t,
                                product: a,
                                newProduct: s,
                                sessionId: i
                            } = this.props,
                            r = this._getProductChanges();
                        (s ? (0, y.logAddProductClick)(i) : (0, y.logEditProductClick)(a, i), this.setState({
                            isUpdating: !0
                        }), s || this.state.isModified) ? null === (e = this._imagePanelRef.current) || void 0 === e || e.component.uploadImages().then((e => {
                            r.imageCdnUrl = e[0], r.additionalImageCdnUrl = e.slice(1), (s ? t.addProduct : t.editProduct).call(t, r).then(this._handleEditSuccess).catchType(E.CatalogEditServerError, this._handleEditError).finally((() => {
                                this.setState({
                                    isUpdating: !1
                                })
                            }))
                        })).catch((e => {
                            throw this.setState({
                                isUpdating: !1
                            }), e
                        })): (0, T.productVisibilitySet)([{
                            productId: a.id.toString(),
                            isHidden: r.isHidden
                        }]).then((() => {
                            a.isHidden = r.isHidden, this._handleEditSuccess(a)
                        })).catchType(E.CatalogEditServerError, this._handleEditError).finally((() => {
                            this.setState({
                                isUpdating: !1
                            })
                        }))
                    }, this._handleEditError = e => {
                        this.props.newProduct ? (0, y.logAddProductFailed)(this.props.sessionId) : (0, y.logEditProductFailed)(this.props.product, this.props.sessionId, e.statusCode), null != e.reason && ("duplicate" === e.reason.media && this.setState({
                            imageError: S.default.t(640)
                        }), "duplicate" !== e.reason.retailer_id && "duplicate" !== e.reason["retailer-id"] || this.setState({
                            retailerIdError: S.default.t(641)
                        })), u.default.openToast(n.createElement(D.default, {
                            msg: S.default.t(437),
                            id: (0, D.genId)("catalog_save_item_failed")
                        }))
                    }, this._handleEditSuccess = e => {
                        var {
                            catalog: t,
                            onEditSuccess: a,
                            newProduct: s,
                            onCreate: i
                        } = this.props;
                        t.productCollection.add(e, {
                            merge: !0
                        }), this.props.newProduct ? (0, y.logAddProductSuccess)(this.props.sessionId) : (0, y.logEditProductSuccess)(this.props.product, this.props.sessionId), u.default.openToast(n.createElement(D.default, {
                            msg: S.default.t(428),
                            id: (0, D.genId)("catalog_item_saved")
                        })), a(e), null != s && i && i()
                    }, this._onDeleteItem = () => {
                        var {
                            catalog: e,
                            product: t,
                            sessionId: a,
                            onDelete: s
                        } = this.props;
                        (0, l.handleProductDelete)(e, t, a).then((e => {
                            e && (u.default.closeDrawerMid(), s && s())
                        }))
                    }, this._onImageChange = e => {
                        var t = "";
                        0 === e.length && (t = S.default.t(643)), this.setState({
                            imageError: t,
                            hasImages: e.length > 0,
                            isModified: !0
                        })
                    }, this.onDrop = e => {
                        var t;
                        null === (t = this._imagePanelRef.current) || void 0 === t || t.component.onFilePick(e)
                    }, this.onDragChange = e => {
                        this.setState({
                            isDragging: e
                        })
                    };
                    var {
                        product: a
                    } = this.props, s = null == a.priceAmount1000 ? null : a.priceAmount1000, i = "";
                    if (null != s && null != a.currency) {
                        var r = h.formatToParts(a.currency, s);
                        i = "".concat(r.integer).concat(r.decimal)
                    }
                    this.state = {
                        name: a.name || "",
                        priceAmount1000: s,
                        description: a.description || "",
                        url: a.url || "",
                        retailerId: a.retailerId || "",
                        priceStr: i,
                        currency: a.currency || h.currencyForCountryShortcode((0, c.getCountryShortcodeByPhone)(null === (t = (0, g.getMaybeMeUser)()) || void 0 === t ? void 0 : t.user)),
                        isUpdating: !1,
                        nameError: "",
                        priceError: "",
                        urlError: "",
                        retailerIdError: "",
                        imageError: "",
                        hasImages: !!a.imageCdnUrl,
                        isDragging: !1,
                        isHidden: a.isHidden,
                        isModified: !1
                    }
                }
                componentDidMount() {
                    var {
                        listeners: e,
                        product: t
                    } = this.props;
                    e.add(t, "change:isHidden", (() => {
                        this.setState({
                            isHidden: this.props.product.isHidden
                        })
                    }))
                }
                isValid() {
                    var {
                        name: e,
                        nameError: t,
                        priceError: a,
                        urlError: s,
                        retailerIdError: i,
                        imageError: r,
                        hasImages: n
                    } = this.state;
                    return "" !== e && !1 !== n && t + a + s + i + r === ""
                }
                render() {
                    var {
                        product: e,
                        onBack: t,
                        onCancel: a,
                        newProduct: s
                    } = this.props, {
                        isUpdating: i,
                        isDragging: l,
                        currency: u,
                        nameError: c,
                        priceError: E,
                        urlError: g,
                        retailerIdError: C,
                        imageError: I
                    } = this.state, y = n.createElement(o.default, {
                        type: "primary",
                        onClick: this._onSaveItem,
                        disabled: !this.isValid(),
                        a8nText: "product-edit-drawer-save-button"
                    }, s ? S.default.t(215) : S.default.t(1198)), T = n.createElement("div", {
                        className: _.default.drawerHeader
                    }, n.createElement("div", null, s ? S.default.t(439) : S.default.t(440)), n.createElement("div", {
                        className: _.default.drawerHeaderButtonContainer
                    }, y)), L = s ? null : n.createElement("div", {
                        className: _.default.deleteButtonContainer
                    }, n.createElement(o.default, {
                        type: "warning",
                        onClick: this._onDeleteItem,
                        a8nText: "product-edit-drawer-delete-button"
                    }, S.default.t(527))), N = (0, r.default)(_.default.productWrapper, {
                        [_.default.isSending]: i
                    }), D = l ? n.createElement(p.default, null) : null, R = i ? n.createElement("div", {
                        className: _.default.spinner
                    }, n.createElement(w.default, {
                        size: 50,
                        stroke: 3
                    })) : null, k = b.default.webCatalogProductsOnOff && n.createElement("div", null, n.createElement(d.default, {
                        id: "product-hidden-check",
                        onChange: this._onHiddenChange,
                        checked: this.state.isHidden,
                        disabled: !1
                    }), n.createElement("label", {
                        className: _.default.hiddenLabel,
                        htmlFor: "product-hidden-check"
                    }, S.default.t(425)), n.createElement("div", {
                        className: _.default.hiddenDescr
                    }, S.default.t(424)));
                    return n.createElement(f.default, {
                        key: "catalog-link-drawer",
                        theme: "catalog",
                        onDrop: this.onDrop,
                        onDragChange: this.onDragChange
                    }, D, n.createElement(v.default, {
                        a8n: "catalog-link-title",
                        title: T,
                        type: v.DRAWER_HEADER_TYPE.SMALL,
                        onBack: t,
                        onCancel: a
                    }), n.createElement(m.default, null, n.createElement("div", {
                        className: N
                    }, R, n.createElement(P.default, {
                        product: e,
                        maxImageCount: M.MAX_PRODUCT_IMAGES,
                        onChange: this._onImageChange,
                        ref: this._imagePanelRef,
                        error: I
                    }), n.createElement(O.default, {
                        a8n: "product-edit-drawer-name-input",
                        value: this.state.name,
                        placeholder: S.default.t(819),
                        onChange: this._onNameChange,
                        theme: "small",
                        customStyleThemes: ["desaturated"],
                        maxLength: 150,
                        error: c
                    }), n.createElement(O.default, {
                        a8n: "product-edit-drawer-price-input",
                        value: this.state.priceStr,
                        placeholder: S.default.t(820, {
                            currencySymbol: h.formatToParts(u, 0).symbol
                        }),
                        onChange: this._onPriceChange,
                        theme: "small",
                        maxLength: 30,
                        customStyleThemes: ["desaturated"],
                        error: E
                    }), n.createElement(O.default, {
                        a8n: "product-edit-drawer-description-input",
                        value: this.state.description,
                        placeholder: S.default.t(817),
                        onChange: this.onDescriptionChange,
                        theme: "small",
                        maxLength: 5e3,
                        customStyleThemes: ["desaturated"],
                        multiline: !0
                    }), n.createElement(O.default, {
                        a8n: "product-edit-drawer-link-input",
                        value: this.state.url,
                        placeholder: S.default.t(818),
                        onChange: this._onUrlChange,
                        onBlur: this._onUrlBlur,
                        theme: "small",
                        customStyleThemes: ["desaturated"],
                        maxLength: 75,
                        error: g,
                        managed: !0
                    }), n.createElement(O.default, {
                        a8n: "product-edit-drawer-retailer-id-input",
                        value: this.state.retailerId,
                        placeholder: S.default.t(816),
                        onChange: this._onRetailerIdChange,
                        theme: "small",
                        customStyleThemes: ["desaturated"],
                        maxLength: 100,
                        error: C
                    }), k, L)))
                }
            }
            t.EditProductDrawer = k, k.CONCERNS = {
                product: ["id", "additionalImageCdnUrl", "name", "priceAmount1000", "description", "productImageCollection", "reviewStatus", "url", "imageCdnUrl", "retailerId", "currency", "isHidden"]
            };
            var A = (0, C.default)((0, L.default)((0, N.default)((0, I.default)(k), k.CONCERNS)));
            t.default = A
        },
        68617: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    onBack: t,
                    onAddProductClick: a,
                    onCatalogAlreadyCreated: s,
                    sessionId: i
                } = e, [y, M] = n.useState(!1), T = n.createElement("div", {
                    className: E.default.placeholderIcon
                }), P = '<a href="'.concat(u.default.FB_LEGAL_TERMS_URL, '" target="_blank">').concat(v.default.t(652), "</a>"), L = '<a href="'.concat(u.default.FB_COMMERCE_POLICY_URL, '" target="_blank">').concat(v.default.t(651), "</a>"), b = '<a href="'.concat(u.default.WA_COMMERCE_POLICY_URL, '" target="_blank">').concat(v.default.t(1818), "</a>"), w = v.default.t(419, {
                    fb_product_link: P,
                    fb_commerce_link: L,
                    wa_commerce_policy_link: b
                }), N = (0, r.default)({
                    [E.default.isLoading]: y
                }), O = y ? n.createElement("div", {
                    className: E.default.spinner
                }, n.createElement(C.default, {
                    size: 50,
                    stroke: 3
                })) : null, D = y ? n.createElement(l.default, {
                    onClick: () => {},
                    theme: "default",
                    idle: !!y
                }) : n.createElement(l.default, {
                    onClick: function() {
                        M(!0), (0, _.logCreateProductCatalogClick)(i), (0, g.createCatalog)().then((() => {
                            (0, _.logCreateProductCatalogSuccess)(i), a(i)
                        })).catchType(m.ServerStatusCodeError, (e => {
                            (0, _.logCreateProductCatalogFailed)(i, e.statusCode), d.default.openToast(n.createElement(I.default, {
                                msg: v.default.t(639),
                                id: (0, I.genId)("err_catalog_already_created")
                            })), s(i)
                        })).finally((() => {
                            M(!1)
                        }))
                    },
                    theme: "default",
                    idle: !1
                });
                return n.createElement(c.default, {
                    key: "catalog-link-drawer"
                }, n.createElement(p.default, {
                    title: v.default.t(1123),
                    type: p.DRAWER_HEADER_TYPE.LARGE,
                    onBack: t
                }), n.createElement(h.default, {
                    className: N
                }, n.createElement(f.default, {
                    theme: "padding-small",
                    animation: !1
                }, O, n.createElement(S.TextDiv, {
                    theme: "title"
                }, v.default.t(413)), D, n.createElement(S.TextDiv, {
                    theme: "plain"
                }, n.createElement("div", {
                    dangerouslySetInnerHTML: {
                        __html: w
                    }
                })), n.createElement("div", {
                    className: E.default.placeholderContainer
                }, n.createElement(o.default, {
                    theme: "add-item-placeholder",
                    image: T,
                    customImage: !0,
                    className: E.default.addItemPlaceholder,
                    primary: "",
                    secondary: "",
                    idle: !0
                }), n.createElement("div", {
                    className: E.default.divider
                }), n.createElement(o.default, {
                    theme: "add-item-placeholder",
                    image: T,
                    customImage: !0,
                    className: E.default.addItemPlaceholder,
                    primary: "",
                    secondary: "",
                    idle: !0
                }), n.createElement("div", {
                    className: E.default.divider
                })))))
            };
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(71334)),
                o = i(a(96066)),
                d = i(a(79711)),
                u = i(a(50935)),
                c = i(a(58701)),
                h = i(a(73023)),
                p = s(a(71311)),
                f = i(a(77875)),
                m = a(19741),
                v = i(a(17957)),
                _ = a(83974),
                E = i(a(70168)),
                g = a(8125),
                C = i(a(2825)),
                S = a(40263),
                I = s(a(75074))
        },
        49306: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.ProductInfoDrawer = void 0;
            var r = i(a(2784)),
                n = s(a(64)),
                l = s(a(58701)),
                o = s(a(73023)),
                d = i(a(71311)),
                u = s(a(77875)),
                c = s(a(89286)),
                h = a(95595),
                p = s(a(98294)),
                f = s(a(17957)),
                m = a(83974),
                v = a(93649),
                _ = a(38350),
                E = s(a(56935)),
                g = s(a(7109)),
                C = s(a(96506)),
                S = s(a(83514)),
                I = s(a(79026)),
                y = s(a(72424)),
                M = s(a(40207)),
                T = s(a(76019)),
                P = a(40263);
            class L extends r.Component {
                constructor(e) {
                    super(e), this.onEditProduct = () => {
                        var {
                            product: e,
                            sessionId: t
                        } = this.props;
                        this.props.onEditProduct && this.props.onEditProduct(e, t)
                    }, this.onShareProduct = () => {
                        var {
                            product: e,
                            sessionId: t
                        } = this.props;
                        this.props.onShareProduct && this.props.onShareProduct(e, t)
                    }, this.onSendChat = () => {
                        this.props.onCancel(), (0, v.sendProductToChat)(this.props.product, this.props.catalog), (0, m.logProductMessageBusinessClick)(this.props.product, this.props.sessionId)
                    }, this.state = {
                        isLoading: !0
                    }
                }
                componentDidMount() {
                    var {
                        catalog: e,
                        product: t
                    } = this.props;
                    e.pullProduct(t.id.toString()).finally((() => {
                        this.setState({
                            isLoading: !1
                        })
                    })), (0, m.logProductDetailView)({
                        product: t,
                        catalogSessionId: this.props.sessionId
                    })
                }
                render() {
                    var {
                        product: e,
                        sessionId: t,
                        onCancel: a
                    } = this.props, s = (0, h.getMaybeMeUser)(), i = T.default.get(s), p = r.createElement(P.TextDiv, {
                        theme: "muted",
                        className: g.default.businessInfoTitle
                    }, f.default.t(352)), m = e.reviewStatus !== _.PRODUCT_REVIEW_STATUS.APPROVED || e.isHidden && y.default.webCatalogProductsOnOff, v = r.createElement("div", null, r.createElement("div", {
                        className: g.default.buttonSeparator
                    }, r.createElement(n.default, {
                        type: "strong",
                        onClick: this.onEditProduct
                    }, f.default.t(563))), r.createElement(n.default, {
                        type: "strong-primary",
                        onClick: this.onShareProduct,
                        disabled: m
                    }, f.default.t(1747))), M = r.createElement("div", {
                        className: g.default.drawerHeader
                    }, r.createElement("div", {
                        className: g.default.productName
                    }, e.name), r.createElement("div", {
                        className: g.default.drawerHeaderButtonContainer
                    }, v)), L = i ? r.createElement(u.default, {
                        title: p,
                        theme: "no-padding"
                    }, r.createElement(I.default, {
                        status: i
                    })) : null, b = this.state.isLoading ? r.createElement(c.default, null) : r.createElement(r.Fragment, null, r.createElement(S.default, {
                        product: e,
                        isAvailable: !0,
                        fetching: !1,
                        sessionId: t
                    }), r.createElement(C.default, {
                        product: e,
                        sessionId: t
                    }), r.createElement(E.default, {
                        product: e,
                        onSendChat: this.onSendChat,
                        isAvailable: !0,
                        sessionId: t
                    }));
                    return r.createElement(l.default, {
                        key: "catalog-link-drawer",
                        theme: "catalog"
                    }, r.createElement(d.default, {
                        a8n: "catalog-product-title",
                        title: M,
                        type: d.DRAWER_HEADER_TYPE.SMALL,
                        onCancel: a
                    }), r.createElement(o.default, null, r.createElement(u.default, {
                        theme: "center-column-fixed-width"
                    }, b), r.createElement("div", {
                        className: g.default.productWrapper
                    }, L)))
                }
            }
            t.ProductInfoDrawer = L, L.CONCERNS = {
                product: ["id", "catalogWid", "name", "priceAmount1000", "description", "productImageCollection", "reviewStatus", "url", "canAppeal", "imageCdnUrl", "retailerId", "currency", "isHidden"]
            };
            var b = (0, p.default)((0, M.default)(L, L.CONCERNS));
            t.default = b
        },
        96506: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    product: t,
                    sessionId: a
                } = e;

                function s() {
                    l.default.openModal(r.createElement(n.default, {
                        product: t,
                        sessionId: a
                    }))
                }
                var i = '<a href="'.concat(o.default.WA_COMMERCE_POLICY_URL, '" target="_blank">').concat(d.default.t(825), "</a>");
                if (t.reviewStatus === u.PRODUCT_REVIEW_STATUS.APPROVED) return t.isHidden && h.default.webCatalogProductsOnOff ? r.createElement("div", {
                    className: c.default.hiddenProductInfoContainer
                }, r.createElement("div", {
                    className: c.default.hiddenProductInfoIcon
                }, r.createElement(p.default, {
                    name: "hide"
                })), r.createElement("div", {
                    className: c.default.hiddenProductInfoText
                }, r.createElement(f.TextDiv, null, d.default.t(1126)))) : null;
                if (t.reviewStatus === u.PRODUCT_REVIEW_STATUS.REJECTED) {
                    if (!0 === t.canAppeal) {
                        var m = "".concat(d.default.t(426, {
                                learn_more_link: i
                            })),
                            v = r.createElement("div", {
                                dangerouslySetInnerHTML: {
                                    __html: m
                                }
                            }),
                            _ = '<span class="'.concat(c.default.appealLink, '">').concat(d.default.t(427), "</span>"),
                            E = "".concat(d.default.t(420, {
                                request_review_link: _
                            })),
                            g = r.createElement("div", {
                                dangerouslySetInnerHTML: {
                                    __html: E
                                }
                            });
                        return r.createElement("div", {
                            className: c.default.statusAlert,
                            "data-a8n": "product-appeal-rejected-initial-review"
                        }, v, r.createElement(f.TextDiv, {
                            className: c.default.appealText
                        }, r.createElement("div", {
                            onClick: s,
                            onKeyPress: s,
                            role: "button",
                            tabIndex: "0",
                            "data-a8n": "product-appeal-button"
                        }, g)))
                    }
                    var C = "".concat(d.default.t(422, {
                            learn_more_link: i
                        })),
                        S = r.createElement("div", {
                            dangerouslySetInnerHTML: {
                                __html: C
                            }
                        });
                    return r.createElement("div", {
                        className: c.default.statusAlert,
                        "data-a8n": "product-appeal-rejected-final"
                    }, S)
                }
                if (t.reviewStatus === u.PRODUCT_REVIEW_STATUS.NO_REVIEW || t.reviewStatus === u.PRODUCT_REVIEW_STATUS.OUTDATED) {
                    var I = t.isHidden && h.default.webCatalogProductsOnOff ? "".concat(d.default.t(435, {
                        learn_more_link: i
                    })) : "".concat(d.default.t(434, {
                        learn_more_link: i
                    }));
                    return r.createElement("div", {
                        className: c.default.statusAlert,
                        "data-a8n": "product-appeal-pending-initial-review"
                    }, r.createElement("div", {
                        dangerouslySetInnerHTML: {
                            __html: I
                        }
                    }))
                }
                if (!1 === t.canAppeal) {
                    var y = d.default.t(421);
                    return r.createElement("div", {
                        className: c.default.statusAlert,
                        "data-a8n": "product-appeal-pending-appeal"
                    }, y)
                }
                return null
            };
            var r = i(a(2784)),
                n = s(a(94180)),
                l = s(a(79711)),
                o = s(a(50935)),
                d = s(a(17957)),
                u = a(38350),
                c = s(a(56300)),
                h = s(a(72424)),
                p = s(a(82631)),
                f = a(40263)
        },
        79026: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(96066)),
                l = s(a(52737)),
                o = s(a(46478)),
                d = a(95595),
                u = s(a(98294)),
                c = s(a(40207));
            class h extends r.Component {
                constructor(e) {
                    super(e)
                }
                render() {
                    var {
                        status: e
                    } = this.props;
                    return r.createElement(n.default, {
                        image: r.createElement(o.default, {
                            id: (0, d.getMaybeMeUser)()
                        }),
                        primary: l.default.pushname,
                        secondary: e.status,
                        idle: !0
                    })
                }
            }
            h.CONCERNS = {
                status: ["status"]
            };
            var p = (0, u.default)((0, c.default)(h, h.CONCERNS));
            t.default = p
        },
        67864: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(26360)),
                l = s(a(79711)),
                o = s(a(50935)),
                d = a(555),
                u = i(a(96452)),
                c = s(a(17957)),
                h = a(28278),
                p = s(a(8603)),
                f = a(27e3),
                m = s(a(25012)),
                v = s(a(81001)),
                _ = s(a(92209)),
                E = s(a(72259)),
                g = s(a(82631)),
                C = i(a(75074)),
                S = s(a(74824));
            class I extends r.Component {
                constructor(e) {
                    super(e), this.onAddFileClick = () => {
                        this.refInput && this.refInput.click()
                    }, this.onFilePick = e => {
                        (0, d.getFiles)(e, o.default.IMAGE_MIMES).then((e => {
                            var t = this.props.maxImageCount - this.state.images.length;
                            e.length > t && l.default.openToast(r.createElement(C.default, {
                                msg: c.default.t(885),
                                duration: 6e3,
                                action: {
                                    onAction: () => {},
                                    actionText: c.default.t(705),
                                    dismiss: !0,
                                    theme: "success"
                                },
                                id: (0, C.genId)()
                            })), e.slice(0, this.props.maxImageCount - this.state.images.length).map((e => ({
                                file: e,
                                filename: e.name,
                                mimetype: e.type,
                                type: f.TYPE.PRODUCT
                            }))).map((e => {
                                var t, a = new n.default({
                                    file: Promise.resolve(e)
                                });
                                return null === (t = a.processPromise) || void 0 === t ? void 0 : t.then((() => {
                                    this._appendImage(a)
                                }))
                            }))
                        })).checkpoint(this.props.rejectOnUnmount()).catchType(u.Unmount, (() => {})), e.target && e.target.value && (e.target.value = "")
                    }, this.uploadImages = () => {
                        var e = this.state.images.filter((e => null == e.url)).map((e => (0, h.uploadProductImage)(e.mediaData.mediaBlob, e.mediaData.filehash).then((t => {
                            e.url = t
                        }))));
                        return Promise.all(e).then((() => this.state.images.map((e => e.url || ""))))
                    }, this.setRefInput = e => {
                        this.refInput = e
                    };
                    var t = e.product.productImageCollection.filter((e => !e.old)).map((e => ({
                        url: e.mediaUrl,
                        mediaData: e.mediaData
                    })));
                    this.state = {
                        images: t
                    }
                }
                _appendImage(e) {
                    e.mediaPrep.waitForPrep().then((t => {
                        if (this._validateImage(t)) {
                            t.mediaStage = p.default.STAGE.RESOLVED, t.renderableUrl = e.fullPreview;
                            var a = t.mediaBlob;
                            !a || a instanceof m.default || m.default.createFromData(a, a.type).then((e => {
                                t.mediaBlob = e
                            })), this.setState({
                                images: [...this.state.images, {
                                    url: null,
                                    mediaData: t
                                }]
                            }), this.props.onChange && this.props.onChange(this.state.images)
                        }
                    }))
                }
                _validateImage(e) {
                    return !(this.state.images.filter((t => t.mediaData.filehash === e.filehash)).length > 0) || (l.default.openToast(r.createElement(C.default, {
                        id: (0, C.genId)(),
                        msg: c.default.t(640)
                    })), !1)
                }
                _deleteImage(e) {
                    var t = this.state.images.filter((t => t !== e));
                    this.setState({
                        images: t
                    }), this.props.onChange && this.props.onChange(t)
                }
                _renderTiles() {
                    return this.state.images.filter((e => e.mediaData)).map((e => r.createElement("div", {
                        key: e.mediaData.filehash,
                        className: v.default.imageTile
                    }, r.createElement("div", {
                        className: v.default.btnDelete,
                        onClick: () => this._deleteImage(e),
                        role: "button"
                    }, r.createElement(g.default, {
                        className: v.default.deleteIcon,
                        name: "x-alt"
                    })), r.createElement(_.default, {
                        mediaData: e.mediaData,
                        className: v.default.imageThumb
                    }))))
                }
                _renderAddImageButton() {
                    return this.state.images.length < this.props.maxImageCount ? r.createElement("div", {
                        className: v.default.btnAddContainer,
                        onClick: this.onAddFileClick,
                        role: "button"
                    }, r.createElement("div", {
                        className: v.default.btnAdd
                    }, r.createElement(g.default, {
                        name: "camera"
                    }), r.createElement("div", {
                        className: v.default.btnAddText
                    }, c.default.t(412)))) : null
                }
                _renderFileInput() {
                    return r.createElement("input", {
                        ref: this.setRefInput,
                        type: "file",
                        accept: o.default.IMAGE_MIMES,
                        style: {
                            display: "none"
                        },
                        onChange: this.onFilePick,
                        multiple: !0
                    })
                }
                renderErrorMessage() {
                    return r.createElement("div", {
                        className: v.default.errorMessage
                    }, this.props.error)
                }
                render() {
                    return r.createElement("div", {
                        className: v.default.panel
                    }, r.createElement("div", {
                        className: v.default.tileContainer
                    }, r.createElement(S.default, {
                        transitionAppear: !0,
                        transitionName: "thumb-scale-flex"
                    }, this._renderTiles(), this._renderAddImageButton()), this._renderFileInput()), this.renderErrorMessage())
                }
            }
            var y = (0, E.default)(I);
            t.default = y
        },
        78492: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.ProductMessageListDrawer = void 0;
            var r = i(a(12436)),
                n = s(a(2784)),
                l = i(a(99601)),
                o = i(a(8227)),
                d = i(a(50935)),
                u = i(a(58701)),
                c = i(a(73023)),
                h = s(a(71311)),
                p = s(a(96452)),
                f = a(47884),
                m = i(a(12522)),
                v = i(a(22004)),
                _ = i(a(89286)),
                E = i(a(17957)),
                g = i(a(20642)),
                C = a(49080),
                S = a(80898),
                I = i(a(90567)),
                y = i(a(72259)),
                M = i(a(40207)),
                T = a(11419);
            class P extends n.Component {
                constructor(e) {
                    super(e), this._catalogFlatListController = new v.default, this._handleScroll = e => {
                        this.state.loadingMore || e.scrollTop + d.default.SCROLL_FUDGE > e.scrollHeight - e.clientHeight && this._loadMoreProduct()
                    }, this.handleScroll = (0, r.default)(this._handleScroll, 100), this._loadMoreProduct = () => {
                        var {
                            productListId: e
                        } = this.props, {
                            stopLoading: t,
                            loadedProducts: a
                        } = this.state;
                        if (!t) {
                            var s = I.default.assertGet(e).productCollection.getProductModels().length;
                            this.setState({
                                loadingMore: !0,
                                loadedProducts: s
                            }), I.default.update(e).checkpoint(this.props.rejectOnUnmount()).then((e => {
                                this.setState({
                                    loadingMore: !1
                                }), (Array.isArray(e) ? e[0] : e).productCollection.getProductModels().length === a && this.setState({
                                    stopLoading: !0
                                }), s * d.default.PRODUCT_LIST_ITEM_HEIGHT < window.innerHeight && this._loadMoreProduct()
                            })).catchType(p.Unmount, (() => {})).catch((() => {
                                this.setState({
                                    loadingMore: !1,
                                    stopLoading: !0
                                })
                            }))
                        }
                    }, this.onScroll = e => {
                        this.handleScroll(e.currentTarget), this.props.setScrollOffset && this.props.setScrollOffset(e.currentTarget.scrollTop)
                    }, this._onCartChange = () => {
                        var e = this.state.cart.itemCount;
                        this.state.cartCount !== e && this.setState({
                            cartCount: e
                        })
                    }, this._onCartClick = () => {
                        var {
                            contact: e,
                            sessionId: t,
                            onCartClick: a
                        } = this.props;
                        a && a(e.id.toString(), t)
                    };
                    var t = I.default.get(this.props.productListId),
                        a = l.default.findCart(this.props.contact.id.toString());
                    this.state = {
                        loadingMore: !1,
                        loadedProducts: 0,
                        stopLoading: !1,
                        productMessageList: t,
                        cart: a,
                        cartCount: a.itemCount,
                        productMessageListFetchState: t ? "SUCCESS" : "NONE"
                    }
                }
                componentDidMount() {
                    var {
                        listeners: e
                    } = this.props;
                    e.add(this.state.cart, "all", this._onCartChange), this.state.productMessageList ? this._loadMoreProduct() : this._findProductMessageList()
                }
                _findProductMessageList() {
                    return I.default.find(this.props.productListId).checkpoint(this.props.rejectOnUnmount()).then((e => {
                        this.setState({
                            productMessageList: e,
                            productMessageListFetchState: "SUCCESS"
                        }), this._loadMoreProduct()
                    })).catch((e => {
                        (0, f.parseErrorState)(e, (e => this.setState({
                            productMessageListFetchState: e
                        })))
                    }))
                }
                _getDrawerContent() {
                    var {
                        productMessageList: e
                    } = this.state;
                    return e ? n.createElement(n.Fragment, null, n.createElement("div", null, this.state.loadingMore && n.createElement(_.default, null))) : n.createElement(m.default, {
                        fetchState: this.state.productMessageListFetchState
                    })
                }
                _getCartIcon() {
                    var {
                        onCartClick: e,
                        sessionId: t,
                        contact: a
                    } = this.props;
                    if (e) {
                        var s = this.state.cartCount,
                            i = (0, T.isNumber)(s) && s > 0 ? s.toString() : void 0,
                            r = (0, C.getOnCartClickWithLog)(this._onCartClick, a.id.toString(), t);
                        return n.createElement(S.MenuBarItem, {
                            a8nText: "menu-bar-cart-link",
                            icon: n.createElement(o.default, {
                                theme: "inherit-color"
                            }),
                            text: i,
                            title: E.default.t(398),
                            onClick: r
                        })
                    }
                    return null
                }
                render() {
                    return n.createElement(u.default, {
                        theme: "products",
                        onDrop: this.props.onBack
                    }, n.createElement(h.default, {
                        title: E.default.t(1123),
                        type: h.DRAWER_HEADER_TYPE.SMALL,
                        onBack: this.props.onBack,
                        menu: this._getCartIcon()
                    }), n.createElement(c.default, {
                        onScroll: this.onScroll,
                        flatListControllers: [this._catalogFlatListController],
                        scrollOffset: this.props.scrollOffset
                    }, this._getDrawerContent()))
                }
            }
            t.ProductMessageListDrawer = P, P.CONCERNS = {
                contact: ["id"]
            };
            var L = (0, y.default)((0, g.default)((0, M.default)(P, P.CONCERNS)));
            t.default = L
        },
        5231: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(65468)),
                l = s(a(17957)),
                o = s(a(61941)),
                d = i(a(51079)),
                u = s(a(78636)),
                c = (e, t) => {
                    var [a, s] = r.useState(!1), [i, c] = r.useState([]), h = r.createElement(u.default, {
                        disabled: !a,
                        onClick: () => {
                            var t, a = (0, o.default)(null === (t = i[0]) || void 0 === t ? void 0 : t.catalogWid, "products[0]?.catalogWid"),
                                s = (0, o.default)(n.default.get(a), "CatalogCollection.get(catalogWid)");
                            e.onShare(s)
                        }
                    });
                    return r.createElement(d.default, {
                        ref: t,
                        title: l.default.t(1259),
                        onCancel: e.onCancel,
                        onConfirm: e.onConfirm,
                        listType: d.ListType.PRODUCT_SELECT_MODAL,
                        enableSearchBox: !1,
                        customHeader: h,
                        onSelectionChanged: (e, t, a) => {
                            s(0 === a.length)
                        },
                        onDataLoaded: e => {
                            var t = e;
                            c(t), s(t.length > 0)
                        }
                    })
                },
                h = r.forwardRef(c);
            t.default = h
        },
        78636: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = e.disabled ? d.default.disabled : "",
                    a = e.disabled ? null : e.onClick,
                    s = r.createElement("span", {
                        className: d.default.title
                    }, l.default.t(1120)),
                    i = r.createElement(o.default, {
                        theme: "compact",
                        disabled: e.disabled
                    }, r.createElement(u.default, {
                        name: "catalog"
                    }));
                return r.createElement(n.default, {
                    image: i,
                    onClick: a,
                    primary: s,
                    theme: "list-button-compact",
                    className: t
                })
            };
            var r = i(a(2784)),
                n = s(a(96066)),
                l = s(a(17957)),
                o = s(a(11498)),
                d = s(a(70919)),
                u = s(a(82631))
        },
        93683: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(72779)),
                n = s(a(2784)),
                l = i(a(73549)),
                o = i(a(19899)),
                d = i(a(40207)),
                u = i(a(40392)),
                c = i(a(26907));
            class h extends n.PureComponent {
                render() {
                    var {
                        statusV3: e,
                        contact: t
                    } = this.props, a = (0, r.default)({
                        [u.default.dimmed]: t.statusMute
                    }), s = o.default.relativeDateAndTimeStr(e.t);
                    return n.createElement(l.default, {
                        className: a,
                        key: e.id.toString(),
                        customImage: !0,
                        theme: "status-list",
                        image: n.createElement(c.default, {
                            statusV3: e,
                            contact: t,
                            onClick: this.props.onClick
                        }),
                        primary: t.formattedName,
                        secondary: s,
                        onClick: this.props.onClick,
                        contextEnabled: () => !1
                    })
                }
            }
            h.CONCERNS = {
                statusV3: ["id", "t", "hasUnread", "unreadCount", "totalCount", "contact"],
                contact: ["formattedName", "statusMute"]
            };
            var p = (0, d.default)(h, h.CONCERNS);
            t.default = p
        },
        32457: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(58527)),
                n = s(a(2784)),
                l = i(a(40207)),
                o = i(a(47861));
            class d extends n.PureComponent {
                _genCircle(e) {
                    var t = 100 + this.props.stroke;
                    return n.createElement("circle", (0, r.default)({
                        cx: t / 2,
                        cy: t / 2,
                        r: 50,
                        fill: "none",
                        strokeLinecap: "round",
                        strokeWidth: this.props.stroke
                    }, e))
                }
                _genDasharray(e, t, a, s) {
                    for (var i = "", r = 0; r < e; r++) i += r === e - 1 ? "".concat(t, " ").concat(a - e * (s + t) + s, " ") : "".concat(t, " ").concat(s, " ");
                    return i
                }
                render() {
                    var {
                        statusV3: e,
                        stroke: t,
                        size: a
                    } = this.props, s = 100 + t, i = "0 0 ".concat(s, " ").concat(s), r = e.totalCount, l = 10, d = 50 * Math.PI * 2;
                    d - 10 * r < 1 && (l = d / r / 1.2);
                    var u, c, h = (d - l * r) / r,
                        p = d / 4 - l / 2,
                        f = e.contact.isMe ? 0 : e.unreadCount,
                        m = r - f;
                    if (f) {
                        var v, _ = p + r * (l + h);
                        1 !== r && (v = this._genDasharray(f, h, d, l)), u = this._genCircle({
                            strokeDashoffset: _,
                            strokeDasharray: v,
                            className: o.default.unread
                        })
                    }
                    if (m) {
                        var E, g = p + m * (l + h);
                        1 !== r && (E = this._genDasharray(m, h, d, l)), c = this._genCircle({
                            strokeDashoffset: g,
                            strokeDasharray: E,
                            className: o.default.read
                        })
                    }
                    return n.createElement("svg", {
                        className: o.default.ring,
                        width: a,
                        height: a,
                        viewBox: i
                    }, u, c)
                }
            }
            d.CONCERNS = {
                statusV3: ["unreadCount", "totalCount", "contact"]
            }, d.defaultProps = {
                size: 48,
                stroke: 4
            };
            var u = (0, l.default)(d, d.CONCERNS);
            t.default = u
        },
        794: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setupStatusV3Controller = function(e, t) {
                if (e) {
                    if (e.type === l.default.TYPE.IMAGE) {
                        var a = 4500;
                        return (0, r.default)(t.caption) || (a += 2e3 * Math.min(t.caption.length / 150, 1)), new c(a)
                    }
                    return e.type === l.default.TYPE.VIDEO ? t.isGif ? new p : new o.default : new c(3e3)
                }
                if (t.type === n.default.MSG_TYPE.CHAT) {
                    var s = 2e3 + 60 * Math.min(t.body.length, 1e3);
                    return new c(s)
                }
                return new c(3e3)
            }, t.StatusV3GifController = t.StatusV3CountdownController = void 0;
            var i = s(a(19976)),
                r = s(a(45455)),
                n = s(a(50935)),
                l = s(a(8603)),
                o = s(a(60717));

            function d() {
                var e = (0, i.default)(["Timer stop called on stopped timer"]);
                return d = function() {
                    return e
                }, e
            }

            function u() {
                var e = (0, i.default)(["Duplicate timer start"]);
                return u = function() {
                    return e
                }, e
            }
            class c {
                constructor(e) {
                    this.addListeners = (e, t, a) => {
                        this._onStart = e, this._onPause = t, this._onEnded = a
                    }, this.removeListeners = () => {
                        this._onStart = void 0, this._onPause = void 0, this._onEnded = void 0
                    }, this.play = () => {
                        if (this._timer) __LOG__(2)(u());
                        else {
                            this._timer = setTimeout(this._onTimeup, this._timeout), this._start = (new Date).getTime();
                            var e = this._onStart;
                            e && e(this._timeout, this._duration)
                        }
                    }, this.stop = () => {
                        if (this._timer) {
                            clearTimeout(this._timer), this._timer = null;
                            var e = (new Date).getTime();
                            this._timeout -= e - this._start;
                            var t = this._onPause;
                            t && t()
                        } else __LOG__(2)(d())
                    }, this.resume = () => {
                        this.play()
                    }, this.pause = () => {
                        this.stop()
                    }, this._onTimeup = () => {
                        var e = this._onEnded;
                        e && e()
                    }, this._duration = e, this._timeout = this._duration, this._start = 0
                }
                get duration() {
                    return this._duration
                }
            }
            t.StatusV3CountdownController = c;
            var h = 6e3;
            class p {
                constructor() {
                    this.removeListeners = () => {
                        this._onStart = void 0, this._onPause = void 0, this._onEnded = void 0, this._videoController.removeListeners(), this._countdownController.removeListeners()
                    }, this.setVideo = (e, t) => {
                        this._video !== e && (this._video = e, null != t && (this._duration = t), this._videoController.setVideo(e))
                    }, this._onVideoStartHandler = () => {
                        var e = this._video;
                        if (null != e) {
                            var t = this._onStart,
                                a = e.duration || this._duration,
                                s = Math.max(3 * a * 1e3, h);
                            t && t(s - 1e3 * a * this._playCounter - 1e3 * e.currentTime, s)
                        }
                    }, this._onVideoPauseHandler = () => {
                        var e = this._onPause;
                        e && e()
                    }, this._onVideoEndedHandler = () => {
                        var e = this._video;
                        if (null != e) {
                            this._playCounter++;
                            var t = this._onEnded;
                            3 === this._playCounter && (this._videoEnded = !0, this._timerEnded && t && t()), e.currentTime = 0, this._videoEnded && this._timerEnded || setTimeout((() => {
                                this._videoController.play()
                            }), 0)
                        }
                    }, this._onTimerEndedHandler = () => {
                        var e = this._onEnded;
                        this._timerEnded = !0, e && this._videoEnded && e()
                    }, this.play = () => {
                        this._videoController.play(), this._countdownController.play()
                    }, this.stop = () => {
                        this._videoController.stop(), this._countdownController.stop()
                    }, this.resume = () => {
                        this._videoController.resume(), this._countdownController.resume()
                    }, this.pause = () => {
                        this._videoController.pause(), this._countdownController.pause()
                    }, this._playCounter = 0, this._timerEnded = !1, this._videoEnded = !1, this._videoController = new o.default, this._countdownController = new c(h), this._videoController.addListeners(this._onVideoStartHandler, this._onVideoPauseHandler, this._onVideoEndedHandler), this._countdownController.addListeners(void 0, void 0, this._onTimerEndedHandler)
                }
                addListeners(e, t, a) {
                    this._onStart = e, this._onPause = t, this._onEnded = a
                }
                get duration() {
                    return Math.max(3 * (this._video && this._video.duration || this._duration) * 1e3, h)
                }
            }
            t.StatusV3GifController = p
        },
        3839: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(19976)),
                n = i(a(72779)),
                l = s(a(2784)),
                o = i(a(72424)),
                d = i(a(8177)),
                u = i(a(91378));

            function c() {
                var e = (0, r.default)(["Assertion failed!"]);
                return c = function() {
                    return e
                }, e
            }

            function h() {
                var e = (0, r.default)(["Current index: ", ", total count: ", ""]);
                return h = function() {
                    return e
                }, e
            }
            class p extends l.Component {
                constructor() {
                    super(...arguments), this._setRefBar = e => {
                        this._refBar = e
                    }, this.onClick = e => {
                        this.props.onClick && this.props.onClick(e)
                    }, this.onStart = (e, t) => {
                        if (this._refBar) {
                            var a = 1e3 * o.default.statusVideoMaxDuration,
                                s = Math.min(e, a),
                                i = Math.min(t, a),
                                r = "-".concat(s / i * 100, "%");
                            (0, u.default)(this._refBar, "stop"), this._barAnimation = (0, u.default)(this._refBar, {
                                translateX: ["0%", r]
                            }, {
                                duration: s,
                                easing: "linear"
                            })
                        }
                    }, this.onPause = () => {
                        this._refBar && (0, u.default)(this._refBar, "stop")
                    }, this.onEnded = () => this._barAnimation ? this._barAnimation : Promise.resolve(), __LOG__(2)(h(), this.props.current, this.props.total), this.props.current >= 0 && this.props.current < this.props.total || (__LOG__(4, void 0, new Error, !0)(c()), SEND_LOGS("bad current status v3 index"))
                }
                render() {
                    for (var e = this, t = [], a = "".concat(100 / this.props.total, "%"), s = function(s) {
                            var i = (0, n.default)(d.default.foreground, {
                                    [d.default.filled]: s < e.props.current,
                                    [d.default.empty]: s > e.props.current,
                                    [d.default.active]: s === e.props.current
                                }),
                                r = l.createElement("div", {
                                    className: d.default.wrapper,
                                    style: {
                                        width: a
                                    },
                                    key: s,
                                    onClick: () => e.onClick(s)
                                }, l.createElement("div", {
                                    className: d.default.bg
                                }), l.createElement("div", {
                                    className: d.default.mask
                                }, l.createElement("div", {
                                    className: i,
                                    ref: s === e.props.current ? e._setRefBar : () => {}
                                })));
                            t.push(r)
                        }, i = 0; i < this.props.total; ++i) s(i);
                    return l.createElement("div", {
                        className: d.default.container
                    }, t)
                }
            }
            t.default = p
        },
        75449: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.StatusV3MsgNotFound = t.StatusV3LoadingError = t.InvalidStatusV3Iterator = void 0;
            var r = i(a(19976)),
                n = i(a(22487)),
                l = i(a(75652)),
                o = i(a(16760)),
                d = a(91460),
                u = a(29351),
                c = i(a(57185)),
                h = s(a(82885));

            function p() {
                var e = (0, r.default)(["error while loading more status msgs: ", ""]);
                return p = function() {
                    return e
                }, e
            }

            function f() {
                var e = (0, r.default)(["error while loading more status msgs: ", ""]);
                return f = function() {
                    return e
                }, e
            }

            function m() {
                var e = (0, r.default)(["Loaded ", " messages with total count ", ", but noEarlierMsgs set"]);
                return m = function() {
                    return e
                }, e
            }

            function v() {
                var e = (0, r.default)(["error while getting first unread status: ", ""]);
                return v = function() {
                    return e
                }, e
            }

            function _() {
                var e = (0, r.default)(["Total count: ", ", unread count: ", ", msgs length: ", ""]);
                return _ = function() {
                    return e
                }, e
            }
            class E extends((0, u.customError)("InvalidStatusV3Iterator")) {}
            t.InvalidStatusV3Iterator = E;
            class g extends((0, u.customError)("StatusV3LoadingError")) {}
            t.StatusV3LoadingError = g;
            class C extends((0, u.customError)("StatusV3MsgNotFound")) {}
            t.StatusV3MsgNotFound = C;
            t.default = class {
                constructor(e, t) {
                    if (this._printInfo = () => {
                            this.statuses.forEach((e => {
                                __LOG__(2)(_(), e.totalCount, e.unreadCount, e.msgs.length)
                            }))
                        }, this.getFirstUnread = (e, t, a) => {
                            var s = this.statuses.findIndex((t => t.statusV3 === e));
                            if (-1 !== s) {
                                var i, r = this.statuses[s],
                                    n = r.readMsgKeys;
                                return a ? (i = r.msgs ? r.msgs.findIndex((e => a && e.id.toString() === a.toString())) : -1) >= 0 ? Promise.resolve({
                                    msgIdx: i,
                                    statusIdx: s
                                }) : Promise.reject(new E) : -1 === (i = r.msgs ? r.msgs.findIndex((e => !n.includes(e.id.toString()))) : -1) && e.msgs.msgLoadState.noEarlierMsgs ? (i = t ? 0 : r.msgs.length - 1, Promise.resolve({
                                    msgIdx: i,
                                    statusIdx: s
                                })) : -1 !== i ? Promise.resolve({
                                    msgIdx: i,
                                    statusIdx: s
                                }) : 0 === r.unreadCount && t && r.msgs.length > 0 ? Promise.resolve({
                                    msgIdx: 0,
                                    statusIdx: s
                                }) : this._fetchMore(e).then((() => this.getFirstUnread(e, t, a))).catch((e => (__LOG__(3)(v(), String(e)), Promise.reject(new E))))
                            }
                            return Promise.reject(new E)
                        }, this.hasNext = e => {
                            var t = this.statuses[e.statusIdx];
                            return e.msgIdx + 1 < t.totalCount || e.statusIdx + 1 < this.statuses.length
                        }, this.getNext = e => {
                            var t = this.statuses[e.statusIdx],
                                a = t.statusV3;
                            if (e.msgIdx + 1 < t.totalCount && e.msgIdx + 1 < t.msgs.length) return Promise.resolve({
                                msgIdx: e.msgIdx + 1,
                                statusIdx: e.statusIdx
                            });
                            if (e.msgIdx + 1 < t.totalCount) return a.msgs.msgLoadState.noEarlierMsgs ? (__LOG__(3)(m(), t.msgs.length, t.totalCount), Promise.reject(new E)) : this._fetchMore(a).then((() => this.getNext(e))).catch((t => {
                                if (__LOG__(3)(f(), String(t)), e.statusIdx + 1 < this.statuses.length) {
                                    var a = this.statuses[e.statusIdx + 1].statusV3;
                                    return this.getFirstUnread(a, !0)
                                }
                                return Promise.reject(new E)
                            }));
                            if (e.statusIdx + 1 < this.statuses.length) {
                                var s = this.statuses[e.statusIdx + 1].statusV3;
                                return this.getFirstUnread(s, !0)
                            }
                            return Promise.reject(new E)
                        }, this.hasPrev = e => e.msgIdx > 0 || e.statusIdx > 0, this.getPrev = e => {
                            if (e.msgIdx > 0) return Promise.resolve({
                                msgIdx: e.msgIdx - 1,
                                statusIdx: e.statusIdx
                            });
                            if (e.statusIdx > 0) {
                                var t = this.statuses[e.statusIdx - 1].statusV3;
                                return this.getFirstUnread(t, !1)
                            }
                            return Promise.reject(new E)
                        }, this.statusAt = (e, t) => {
                            var a = this.statuses[e.statusIdx],
                                s = a.statusV3;
                            return t < a.msgs.length ? Promise.resolve({
                                msgIdx: t,
                                statusIdx: e.statusIdx
                            }) : s.msgs.msgLoadState.noEarlierMsgs ? Promise.reject(new E) : this._fetchMore(s).then((() => this.statusAt(e, t))).catch((e => (__LOG__(3)(p(), String(e)), Promise.reject(new E))))
                        }, this._fetchMore = e => Promise.loop(((t, a, s) => {
                            var i = (0, d.delayMs)(h.expBackoff(s, 12e4, 1e3, .1));
                            return e.loadMore().then((() => {
                                var a = this.statuses.findIndex((t => t.statusV3 === e));
                                if (-1 !== a) {
                                    var r = this.statuses[a],
                                        d = r.totalCount,
                                        u = r.unreadCount,
                                        c = e.msgs.getModelsArray().slice(0, d),
                                        h = c.slice(0, d - u),
                                        p = (0, o.default)(h, (e => e.id.toString()));
                                    r.msgs = c, r.readMsgKeys = (0, l.default)((0, n.default)(r.readMsgKeys, p)), t(!0)
                                } else {
                                    if (!(s >= 4)) return i;
                                    t(!1)
                                }
                            })).catch((() => {
                                if (!(s >= 4)) return i;
                                t(!1)
                            }))
                        })).then((e => {
                            if (!e) throw new g
                        })), t) {
                        var a = e.msgs.getModelsArray().find((e => t && e.id.toString() === t.toString()));
                        if (!a) throw new C;
                        this.statuses = [{
                            statusV3: e,
                            totalCount: 1,
                            unreadCount: 0,
                            msgs: [a],
                            readMsgKeys: [a.id.toString()]
                        }]
                    } else if (e.unreadCount > 0 && !e.contact.isMe && !e.contact.statusMute) {
                        var s = c.default.getUnexpired(!0),
                            i = [];
                        s.forEach((e => {
                            if (!e.contact.statusMute) {
                                var t = e.msgs.getModelsArray(),
                                    a = e.totalCount - e.unreadCount,
                                    s = t.slice(0, a),
                                    r = (0, o.default)(s, (e => e.id.toString()));
                                i.push({
                                    statusV3: e,
                                    totalCount: e.totalCount,
                                    unreadCount: e.unreadCount,
                                    msgs: t,
                                    readMsgKeys: r
                                })
                            }
                        })), this.statuses = i
                    } else {
                        var r = e.msgs.getModelsArray(),
                            u = e.totalCount - e.unreadCount,
                            S = r.slice(0, u),
                            I = (0, o.default)(S, (e => e.id.toString())),
                            y = [{
                                statusV3: e,
                                totalCount: e.totalCount,
                                unreadCount: e.unreadCount,
                                msgs: r,
                                readMsgKeys: I
                            }];
                        this.statuses = y
                    }
                    this._printInfo()
                }
            }
        },
        26907: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(a(2784)),
                n = s(a(72779)),
                l = s(a(50935)),
                o = s(a(40686)),
                d = s(a(40207)),
                u = s(a(32457)),
                c = a(21504),
                h = s(a(29340));
            class p extends r.PureComponent {
                render() {
                    var e, {
                            statusV3: t,
                            contact: a
                        } = this.props,
                        s = t.lastStatus,
                        i = null,
                        d = h.default.statusImage;
                    return i = s ? s.type === l.default.MSG_TYPE.CHAT ? r.createElement(f, {
                        msg: s
                    }) : r.createElement(o.default, {
                        containerClassName: (0, n.default)(h.default.thumbContainer, h.default.statusImageFallbackBackground),
                        childClassName: d,
                        msg: s,
                        shouldRenderEmptyThumbnail: !0
                    }) : r.createElement("div", {
                        className: (0, n.default)(d, h.default.statusImageFallbackBackground)
                    }), a.statusMute || (e = r.createElement(u.default, {
                        statusV3: t
                    })), r.createElement("div", {
                        className: h.default.container,
                        role: this.props.role || "",
                        onClickCapture: e => {
                            this.props.onClick && this.props.onClick(), e.stopPropagation(), e.preventDefault()
                        }
                    }, e, i)
                }
            }
            p.CONCERNS = {
                statusV3: ["lastStatus"],
                contact: ["statusMute"]
            };
            class f extends r.PureComponent {
                render() {
                    var {
                        msg: e
                    } = this.props, t = e.statusV3TextBg;
                    return r.createElement("div", {
                        className: h.default.statusImage,
                        style: {
                            backgroundColor: t
                        }
                    }, r.createElement("div", {
                        className: h.default.textThumb
                    }, r.createElement(c.StatusV3Text, {
                        msg: e,
                        theme: "status-thumbnail"
                    })))
                }
            }
            var m = (0, d.default)(p, p.CONCERNS);
            t.default = m
        },
        60717: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(a(72424));

            function r(e) {
                return Math.min(e, i.default.statusVideoMaxDuration)
            }
            var n = class {
                constructor() {
                    this.addListeners = (e, t, a) => {
                        this._onStart = e, this._onPause = t, this._onEnded = a
                    }, this.setVideo = e => {
                        this._video !== e && (this._unsetVideo(), this._video = e, null != e && (e.addEventListener("playing", this._onPlayingHandler), e.addEventListener("pause", this._onPauseHandler), e.addEventListener("ended", this._onEndedHandler), e.addEventListener("timeupdate", this._onTimeUpdate)))
                    }, this._unsetVideo = () => {
                        var e = this._video;
                        e && (this.stop(), e.removeEventListener("playing", this._onPlayingHandler), e.removeEventListener("pause", this._onPauseHandler), e.removeEventListener("ended", this._onEndedHandler), e.removeEventListener("timeupdate", this._onTimeUpdate))
                    }, this.play = () => {
                        this._video && this._video.play()
                    }, this.pause = () => {
                        this._video && !this._video.paused && this._video.pause()
                    }, this.resume = () => {
                        this._video && this._video.play()
                    }, this.stop = () => {
                        this._video && !this._video.paused && this._video.pause()
                    }, this._onPlayingHandler = () => {
                        var e = this._video;
                        if (null != e) {
                            var t = this._onStart;
                            if (t) {
                                var a = r(e.duration);
                                t(1e3 * (a - e.currentTime), 1e3 * a)
                            }
                        }
                    }, this._onPauseHandler = () => {
                        var e = this._onPause;
                        e && e()
                    }, this._onEndedHandler = () => {
                        var e = this._onEnded;
                        e && e()
                    }, this._onTimeUpdate = () => {
                        var e, t = null === (e = this._video) || void 0 === e ? void 0 : e.currentTime;
                        if (null != t && t >= i.default.statusVideoMaxDuration) {
                            this.stop(), this._onEndedHandler();
                            var a = this._video;
                            a && (a.removeEventListener("timeupdate", this._onTimeUpdate), a.removeEventListener("ended", this._onEndedHandler))
                        }
                    }, this.removeListeners = () => {
                        this.stop(), this._onStart = void 0, this._onPause = void 0, this._onEnded = void 0
                    }
                }
                get duration() {
                    return null == this._video ? 0 : 1e3 * r(this._video.duration)
                }
            };
            t.default = n
        },
        57005: (e, t, a) => {
            "use strict";
            var s = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.search = function(e, t, a = 30) {
                var s = {
                        q: e,
                        SafeSearch: "Strict",
                        appid: "D41D8CD98F00B204E9800998ECF8427E4F4A7492",
                        mkt: c[n.default.getLocale()] || c.en,
                        size: u,
                        aspect: d,
                        count: a,
                        offset: t
                    },
                    i = l.default.build("https://www.bingapis.com/api/v6/images/search", s);
                return o.default.get(i, o.default.RESP_TYPE.JSON).then((t => {
                    if (!t.response.hasOwnProperty("_type")) throw new r.InvalidServerResponseError(i, status, "Not a valid Bing response: ".concat(JSON.stringify(t.response)));
                    if ("ErrorResponse" === t.response._type) {
                        var a = t.response;
                        throw new r.BingServerError(e, t.status, a)
                    }
                    if ("Images" !== t.response._type) throw new r.InvalidServerResponseError(i, status, "Did not receive an image search response, " + "potentially malformed query ".concat(JSON.stringify(t.response)));
                    return t.response
                }))
            };
            var r = i(a(96452)),
                n = s(a(17957)),
                l = s(a(74185)),
                o = s(a(69835)),
                d = "Square",
                u = "Medium",
                c = {
                    ar: "ar-SA",
                    da: "da-DK",
                    de: "de-DE",
                    en: "en-US",
                    es: "es-US",
                    fi: "fi-FI",
                    fr: "fr-FR",
                    it: "it-IT",
                    ko: "ko-KR",
                    nl: "nl-NL",
                    pl: "pl-PL",
                    "pt-BR": "pt-BR",
                    ru: "ru-RU",
                    sv: "sv-SE",
                    tr: "tr-TR",
                    "zh-CN": "zh-CN",
                    "zh-TW": "zh-TW",
                    "zh-HK": "zh-HK"
                }
        },
        59159: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(a(70417)),
                r = a(28703),
                n = a(33293),
                l = {};
            l[r.ExtendedTextMessageFontType.SERIF] = {
                google: {
                    families: ["Roboto"]
                }
            }, l[r.ExtendedTextMessageFontType.SANS_SERIF] = {
                google: {
                    families: ["Droid Serif"]
                }
            }, l[r.ExtendedTextMessageFontType.NORICAN_REGULAR] = {
                google: {
                    families: ["Norican"]
                }
            }, l[r.ExtendedTextMessageFontType.BRYNDAN_WRITE] = {
                custom: {
                    families: ["Bryndan-Write"]
                }
            }, l[r.ExtendedTextMessageFontType.OSWALD_HEAVY] = {
                google: {
                    families: ["Oswald:bold"]
                }
            };
            var o = {};
            o[r.ExtendedTextMessageFontType.BRYNDAN_WRITE] = '@font-face {font-family:"Bryndan-Write"; src:url("'.concat(n, '") format("truetype");}');
            var d = new class {
                constructor() {
                    this.loadedFonts = {}, this.loadingPromise = {}
                }
                load(e) {
                    if (this.loadedFonts[e]) return Promise.resolve();
                    if (this.loadingPromise[e]) return this.loadingPromise[e];
                    var t = l[e],
                        a = o[e],
                        s = (a ? new Promise(((e, t) => {
                            var s = document.createElement("style");
                            s.appendChild(document.createTextNode(a)), s.onload = e, s.onerror = t, document.head && document.head.appendChild(s)
                        })) : Promise.resolve()).then((() => new Promise(((a, s) => {
                            var r = (0, i.default)((0, i.default)({}, t), {}, {
                                active: () => {
                                    this.loadedFonts[e] = !0, a()
                                },
                                inactive: () => {
                                    this.loadingPromise[e] = void 0, s("Failed to load font: " + e)
                                }
                            });
                            WebFont.load(r)
                        }))));
                    return this.loadingPromise[e] = s, s
                }
                loadAllFonts() {
                    return Promise.all(Array.from(r.ExtendedTextMessageFontType.members()).map((e => this.load(e))))
                }
            };
            t.default = d
        },
        15059: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return (0, i.default)(e, r)
            };
            var i = s(a(99686)),
                r = e => null == e
        },
        86169: (e, t, a) => {
            "use strict";
            var s = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return Promise.loop((function(t, a, s) {
                    var i = (0, n.delayMs)(l.expBackoff(s, 6e4, void 0, .1));
                    return (d.default.state === d.STATE.CONNECTED ? Promise.resolve() : (0, o.default)(d.default, "change:state", (0, r.default)({
                        state: d.STATE.CONNECTED
                    }))).then((() => e())).then((e => {
                        if (e.status >= 500 && e.status < 600) return i;
                        t(e)
                    })).catch((() => i))
                }))
            };
            var r = i(a(45126)),
                n = a(91460),
                l = s(a(82885)),
                o = i(a(17744)),
                d = s(a(12767))
        },
        63836: (e, t, a) => {
            "use strict";
            var s = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getTosUrl = function() {
                return "".concat(r, "?lg=").concat(i.default.getLocale())
            }, t.TOS_BASE_URL = void 0;
            var i = s(a(17957)),
                r = "https://www.whatsapp.com/legal/";
            t.TOS_BASE_URL = r
        },
        52567: (e, t, a) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.validateURL = t.validateEmail = t.EMAIL_REGEX = void 0;
            var s = a(74185),
                i = new RegExp(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/);
            t.EMAIL_REGEX = i;
            t.validateEmail = e => !e || i.test(e);
            t.validateURL = e => !e || s.URL_REGEX.test(e)
        },
        98150: (e, t, a) => {
            e.exports = a.p + "img/animated-doodle_600127bdb5f7627ede5cd4ef320f55b0.png"
        },
        33293: (e, t, a) => {
            e.exports = a.p + "bryndan_write_20e48b2ec8c64b2a1ceb5b28d9bcc9d0.ttf"
        },
        90245: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                editMain: "vjKv2",
                dayMain: "_15mES",
                timeWrapper: "dguG_",
                hoursAnd: "_3dPdV",
                hoursMain: "_2NSEj",
                dayCheckbox: "_1Aerz",
                dayInfo: "_2x2dz",
                dayInfoText: "_1KeFW"
            }
        },
        7899: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                editMain: "_3Qb6s",
                list: "_2si2K",
                rowMain: "_26RZv",
                rowCheckbox: "NJmYi",
                rowLabel: "_3OhaG",
                disabled: "jUzEE",
                loadingSpinner: "VQPkV",
                searchBackground: "_12X4T"
            }
        },
        37533: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                businessHoursDayColumn: "_25R4l",
                businessHoursTimeColumn: "AeuSd",
                businessHoursSection: "_2vxS9",
                businessHoursTime: "_2Q3U2",
                addAnotherWebsite: "_29WX8",
                businessMap: "_2BBxS",
                mapOverlay: "_3anF1",
                overlayHint: "_3mc7J",
                infoText: "_1l-wf",
                verifiedNameIcon: "_2iRAs"
            }
        },
        55561: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                loadingSpinner: "_3_LJF"
            }
        },
        90809: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                editPencil: "_1biL_",
                section: "_3QTDK",
                smallMargin: "_27tBZ",
                noMargin: "_2ZYRM",
                sectionPrimaryIcon: "_2sLc3",
                fieldPrimaryIcon: "_1WFhm",
                sectionMain: "_1OjMK",
                sectionContainerMain: "_24N7r",
                sectionEditIcon: "_1eZDQ",
                sectionEmptyText: "_1HLYu",
                hidden: "_161F8"
            }
        },
        60259: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                info: "_1k5TZ",
                footer: "_2OYeg",
                emptyCartContainer: "_17Y1T",
                emptyCardHeader: "_24A2t",
                emptyCardText: "Btu3u",
                btnSend: "_1-wPf",
                cartMessage: "_2i_Nv"
            }
        },
        53270: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                price: "_9FX4I",
                actions: "_14mQB",
                deleteIcon: "_3b98f",
                cartListItem: "_2vZhq"
            }
        },
        41163: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                select: "_1BLB1"
            }
        },
        60075: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                deleteIcon: "txTZq"
            }
        },
        19822: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                title: "_2rWf8"
            }
        },
        48102: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                notifyName: "_3DxUF"
            }
        },
        87620: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                title: "_1cm8S",
                text: "H8Vqa",
                icon: "_2xOjk"
            }
        },
        21009: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                header: "_3LFqd"
            }
        },
        53999: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "S4Hn7",
                border: "_q8lV",
                square: "_2EGHe",
                avatar: "OsBqD",
                count: "_28NYS",
                two: "_3WQB6",
                first: "gdAG9",
                second: "_3d3oA",
                three: "_2BRRW",
                third: "_1FrNI",
                four: "_3PjHn",
                fourth: "f5wLF"
            }
        },
        89306: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                overlay: "_2qsE7",
                icon: "_27U5d",
                text: "nmH4D"
            }
        },
        66650: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_1uUXN",
                hasPrefixIcon: "_3cM62",
                hasPostfixIcon: "_32ha8",
                content: "qaJse",
                icon: "_2Zc1j",
                prefixIcon: "_2VCWi",
                paddedIcon: "n6QZF"
            }
        },
        64002: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                imageGallery: "_1U5md",
                imageGalleryList: "l_VtG",
                imageGalleryItem: "_12qtg",
                imageGalleryItemSpacer: "R73_m",
                imageGalleryItemImage: "_1mRcT",
                imageGalleryItemOverlay: "sc7G4",
                selected: "_1WBa-",
                imageGalleryFooter: "XaD1V",
                focusAnimation: "jUylA",
                focusAnimationKeyframes: "_1pZl3"
            }
        },
        79674: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                inputEmoji: "_3PaJo",
                wrapper: "UQ0S6",
                textInput: "_1cBR9",
                labelText: "vEql6",
                clearInput: "_1Ca_b",
                float: "vQLTL",
                textActive: "hRqfV",
                suggestionsPositioner: "_1C_wE",
                suggestionsContainer: "_5HL_Q",
                charCounter: "_2C6I2",
                inputControls: "_1826U",
                charCounterWithClearBtn: "_1SUJo",
                spacer: "_1EvFF",
                noPlaceholder: "SXaKj",
                buttonContainer: "_25gwF",
                active: "_2Gqfb"
            }
        },
        48695: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_3C7q_",
                body: "_3s7bs"
            }
        },
        7116: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                tabContainer: "_3uRNC",
                tab: "_3g5ZC",
                selected: "bKpUF"
            }
        },
        19518: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                versionInfo: "_3MrMz"
            }
        },
        73621: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                scaler: "_25_O8",
                scalerButton: "_34hCK"
            }
        },
        4085: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                inputContainer: "rOjs5",
                label: "_4KvgT",
                input: "oNgw4"
            }
        },
        97152: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                body: "_3S8qa",
                thumbs: "_1npKH",
                thumbsContainer: "pQbUf",
                btnSend: "_3v5V7",
                captionInput: "_2HlOc",
                mediaBody: "_3Z2cz",
                invalidContainer: "_1IS2b",
                invalidMedia: "_3L9FV",
                mediaWarning: "_2Pu3O",
                btnAdd: "_2kxXx",
                btnAddDisabled: "wt2bU",
                btnAddText: "_24DMK"
            }
        },
        73366: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                thumb: "aaQbT",
                active: "sykWe",
                body: "_1kkeT",
                btnDelete: "_2n1pq",
                bodyDoc: "_2SOPo"
            }
        },
        59335: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_1Ot8E",
                media: "_3hfOk"
            }
        },
        11793: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_3FgGf",
                preview: "_3MOdd",
                img: "_3NgNl"
            }
        },
        32001: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_2RZHc",
                media: "_192t1",
                document: "_3S28f",
                text: "_2mXNP",
                icon: "_1eZJL"
            }
        },
        12621: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_2Uakc",
                media: "gK8jz",
                img: "_2ycmW",
                audio: "_3yz78",
                videoContainer: "_2buDw",
                spinner: "_1psbh",
                video: "_1knJe",
                staticPreview: "dElcV"
            }
        },
        96757: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_3hHCK",
                preview: "_2NxJM",
                caption: "_1ajXw",
                img: "ln7Rp"
            }
        },
        30933: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                btnViewOnce: "_3wOTT",
                btnViewOnceActive: "sqgW8"
            }
        },
        32661: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                text: "_35A8s"
            }
        },
        31377: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                list: "_17KD8",
                hint: "G8Tyt",
                button: "_2okK_"
            }
        },
        83764: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_2SRbM",
                body: "_2FNzl",
                footer: "w-vaO",
                retakeBtn: "_1Fduz",
                retakeIcon: "_2VWr5",
                caption: "reBXK",
                videoContainer: "_3E2el",
                video: "_3htkI",
                btn: "x49XD",
                videoInactive: "t2y9M",
                btnSend: "_2-E7N",
                image: "_31rMI",
                snapshot: "hTWcE"
            }
        },
        47519: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_2SmtJ",
                chip: "_1QPI1"
            }
        },
        51317: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                newGroupButton: "_3kJ-9"
            }
        },
        82034: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                icon: "_5eRqW",
                body: "_25W8i",
                spinner: "_1guTW",
                ack: "_38ck1",
                statusBlue: "_1uFsX"
            }
        },
        6636: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "AO2h_",
                section: "maTUh",
                control: "_3yUUP",
                label: "_2xvW5",
                disabled: "_11L21"
            }
        },
        39194: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                dropOverlay: "Tn0mt",
                dropOverlayOutline: "_2xF5H"
            }
        },
        61286: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                btnSend: "_2F3ww",
                attributionLink: "_1Tyjj",
                mediaBody: "_165NN",
                attribution: "J4mRu",
                footer: "_1y7hs",
                containerBackground: "_3v45H",
                retake: "K-69C",
                retakeIcon: "_2iesF",
                mediaElementBase: "_1ExaQ",
                mediaElement: "_2AByG _1ExaQ"
            }
        },
        55845: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                wrapper: "RdOJd",
                icon: "_33196",
                text: "z4TEC"
            }
        },
        9051: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                linkContainer: "_3D4f-",
                descContainer: "_3rfWy",
                icon: "_2kvi3"
            }
        },
        7123: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                confirmationText: "_39ZbM"
            }
        },
        62420: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                title: "_2Gjk9",
                titleIcon: "cERCv",
                ack: "_2pE7P",
                statusBlue: "_1_MqV",
                forwardCount: "_2H_oO",
                spinner: "_28srV",
                list: "_17F1I",
                footer: "_1Fp2h"
            }
        },
        57739: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                commentInput: "_3pEjS",
                search: "_33dbE",
                groupInfo: "_3R9Y4",
                onSendInvite: "Quczp"
            }
        },
        43143: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                animation: "Hjxnk",
                "play-ltr": "_15z4K",
                playLtr: "_15z4K",
                "play-rtl": "_3anLU",
                playRtl: "_3anLU",
                versionInfo: "_3qfsf"
            }
        },
        74885: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_332Wn",
                wallpaperColorCanvas: "_11i-f",
                wallpaperColorEmpty: "lELMX",
                canvasActive: "aolM7",
                canvasHover: "_6zJ_L"
            }
        },
        80281: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                addLabelBtContainer: "_1QowE"
            }
        },
        72952: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "Fmeis",
                textContainer: "_1seX1",
                spinner: "ALHQF"
            }
        },
        63895: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_289ov",
                list: "_2rGcd",
                header: "YoHdU",
                item: "_3M5f0",
                right: "WqzM1",
                left: "_2d2vs",
                close: "_2LhUr",
                name: "RPbwq",
                time: "_1ZJ7K"
            }
        },
        98397: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                wrapper: "SuQHQ",
                offline: "_1jxad",
                circle: "_28wdD",
                text: "_2P6-6",
                notification: "NW1Lh",
                ended: "_2HzF3",
                lastUpdated: "_2j4iJ"
            }
        },
        96673: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                wrapper: "_1BLuT",
                inactive: "KbVXN",
                offline: "AOZ0E",
                circle: "D1DwJ",
                text: "_3R3RZ",
                backToCenter: "WEsA4",
                visible: "_1z67b"
            }
        },
        38388: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_2DorF",
                map: "_21r-h",
                authFailed: "Duwfq",
                loading: "_1bABc"
            }
        },
        87397: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_1JiqF",
                selected: "xqVmU",
                glow: "_14zjN",
                stale: "_2v4P0",
                expired: "_2imMT",
                pin: "_3F_cn"
            }
        },
        18156: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                list: "_24dlt",
                stopSharingButton: "_16OFg"
            }
        },
        34356: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                popup: "_3FN-E",
                container: "X6oDG",
                twoLines: "Q3WnW",
                name: "_3ukcg",
                status: "DILT-",
                menuButton: "_2UAfE",
                triangle: "_1EQJ7"
            }
        },
        71617: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                actionBtns: "_3uAdi",
                newLabelBtn: "_1oClF",
                plus: "_1Y2uH"
            }
        },
        79693: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                mediaViewerImg: "_22uMp",
                cropOverlay: "_1iJB8"
            }
        },
        12980: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                nextButton: "-h5qP",
                section: "_3VPFA",
                label: "NEPQf",
                control: "_3Ro22"
            }
        },
        70365: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                spinner: "_1h0YE",
                search: "_3tEPr",
                inputarea: "_38sK8",
                inputLine: "_3G4NF",
                contacts: "_1ffi5",
                drawerSection: "_1Ze8s",
                inputareaSizer: "_1cZ7Z"
            }
        },
        81315: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                photoPickerWrapper: "_3ABdz",
                scale: "IqBCc",
                nameWrapper: "_2uds3",
                "well-animation": "MxroG",
                wellAnimation: "MxroG",
                phoneIcon: "_32Ory",
                phoneField: "_394ZX",
                infoText: "_3ulTI"
            }
        },
        53200: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                more: "_2-RNR",
                hotKeyWraper: "_1gcuq"
            }
        },
        35912: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_1Do4k",
                popupPanel: "DCJBm",
                wrapper: "iEDES",
                emojiIcon: "_2iiHQ",
                sendIcon: "_1-llR",
                lineWrapper: "_3OcTj"
            }
        },
        98475: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                playerWrapper: "_2dY5u",
                mediaViewer: "_2M4qA",
                mediaStateControls: "YE6xI",
                playerBackground: "_1Zf5q",
                media: "_2QgqW",
                captionBackdrop: "_2EIWT",
                mediaCaption: "_1ffMZ",
                progressBackdrop: "_2cLT-",
                progressBarBackdropNarrow: "_2Ffvg",
                profile: "_1EeX0",
                nonClickProfile: "_3e5L4",
                profileNarrow: "_3b1f4",
                playerAvatar: "_3BoSP",
                measuringProfile: "FvPWY",
                profileMac: "_1Z225",
                msgInfo: "_1-4iF",
                msgInfoName: "_2_aAO",
                timestamp: "_2ztpj",
                playerContent: "_3IEC5",
                statusPanelPlayerContent: "_1BawO",
                statusThumbnailPlayerContent: "-n_AI",
                loading: "_2wRD3",
                v3Image: "_25YXn",
                v3Video: "_2yHik",
                text: "sAgdw",
                textLarge: "Rq1fv",
                textMedium: "_3oSbU",
                textSmall: "_1lOvh",
                font_1: "S89QA",
                font1: "S89QA",
                font_2: "_1oVgK",
                font2: "_1oVgK",
                font_3: "C1Kh3",
                font3: "C1Kh3",
                font_5: "_1NhlM",
                font5: "_1NhlM",
                unknown: "_39ZMU",
                textThumbnailPlayerContent: "_125n7"
            }
        },
        27611: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                body: "_2WQUg",
                vcardWrapper: "_5aqUc",
                btnContainer: "_3ztsL",
                btnPosition: "_3YdIR"
            }
        },
        98370: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                wallpaperApplyDoodle: "oo1EB",
                checkboxLabel: "_2k8zU",
                wallpaperColorGrid: "_10jcL",
                wallpaperColorCanvas: "_3sW34",
                wallpaperDefaultTitle: "rppEK",
                wallpaperColorEmpty: "_13AW3",
                canvasHover: "ekZ0H",
                canvasActive: "_2RSZp",
                canvasDefault: "_2brEy"
            }
        },
        58670: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                date: "rIQkf",
                info: "_2hSio"
            }
        },
        98524: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                price: "_31nEQ",
                separator: "Os1Zf",
                quantity: "_3d4eP"
            }
        },
        72227: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                productWrapper: "_2uogF",
                drawerHeader: "_1GToa",
                drawerHeaderButtonContainer: "_1lvg0",
                deleteButtonContainer: "dKJ3S",
                isSending: "_3RNZn",
                spinner: "ihGXI",
                hiddenLabel: "_3u6HC",
                hiddenDescr: "_1T7Ca"
            }
        },
        70168: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                addItemPlaceholder: "_2hNH0",
                placeholderIcon: "_1gkqm",
                placeholderContainer: "_1JcNK",
                divider: "yIA2U",
                isLoading: "_3LjT5",
                spinner: "hTNKQ"
            }
        },
        7109: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                drawerHeader: "_3_-Qp",
                productName: "_3MyYf",
                buttonSeparator: "_1TrI_",
                drawerHeaderButtonContainer: "UK7LY",
                productWrapper: "_1XolL",
                businessInfoTitle: "_2B1vD"
            }
        },
        56300: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                statusAlert: "i2Gpi",
                appealText: "_2tedq",
                appealLink: "_2NO1s",
                hiddenProductInfoContainer: "EOTwK",
                hiddenProductInfoIcon: "_1kTCc",
                hiddenProductInfoText: "_2qaDR"
            }
        },
        81001: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                panel: "_2QaL3",
                tileContainer: "fzUHY",
                imageTile: "_32YMy",
                imageThumb: "_1XE56",
                btnDelete: "_19moj",
                deleteIcon: "_3xLeM",
                btnAdd: "_5boY5",
                btnAddContainer: "_3swA4",
                btnAddText: "_16e26",
                errorMessage: "_1rWFc"
            }
        },
        70919: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                disabled: "_1agfk",
                title: "_1TDGA"
            }
        },
        40392: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                dimmed: "RJsro"
            }
        },
        47861: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                ring: "YrjAt",
                read: "_1TWqf",
                unread: "_3fnYk"
            }
        },
        8177: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_3w6fI",
                wrapper: "_1l9G0",
                mask: "_1voNw",
                bg: "AoYZ6",
                foreground: "_1Y0xy",
                filled: "_2q60l",
                empty: "_3649V",
                active: "_1oIDK"
            }
        },
        29340: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                textThumb: "_1iiZH",
                statusImage: "CYQuD",
                statusImageFallbackBackground: "_3-nnR",
                container: "_16lEZ",
                thumbContainer: "_3duy3"
            }
        }
    }
]);