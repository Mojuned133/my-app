/*! Copyright (c) 2021 WhatsApp Inc. All Rights Reserved. */
(self.webpackChunkbuild = self.webpackChunkbuild || []).push([
    [7205], {
        79728: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setGroupDesc = function(e, t = "") {
                return g((0, f.unproxy)(e), t)
            };
            var s = i(a(19976)),
                r = n(a(2784)),
                l = a(12073),
                o = i(a(79711)),
                d = a(19741),
                c = n(a(96452)),
                u = i(a(17957)),
                h = a(88011),
                p = i(a(49213)),
                f = a(64658);

            function m() {
                var e = (0, s.default)(["models:chat:setGroupDesc dropped"]);
                return m = function() {
                    return e
                }, e
            }

            function g(e, t = "", a = (0, l.genId)()) {
                var n = t && t.trim();
                if (n === e.groupMetadata.desc) return Promise.reject(new c.ActionError);
                "" === n && (n = null);
                var i = (0, h.sendSetGroupDescription)(e.id, n, (0, p.default)(), e.groupMetadata.descId),
                    s = e.groupMetadata.desc,
                    f = new l.ActionType(u.default.t(97)),
                    v = i.then((() => new l.ActionType(u.default.t(99), {
                        actionText: u.default.t(197),
                        actionHandler: () => g(e, s, a)
                    }))).catchType(d.ServerStatusCodeError, (e => {
                        if (e.status >= 400) return new l.ActionType(u.default.t(98))
                    })).catch((() => (__LOG__(3)(m()), new l.ActionType(u.default.t(98), {
                        actionText: u.default.t(193),
                        actionHandler: () => g(e, n, a)
                    }))));
                return o.default.openToast(r.createElement(l.ActionToast, {
                    id: a,
                    initialAction: f,
                    pendingAction: v
                })), i.then((t => {
                    t._duplicate || e.groupMetadata.set({
                        desc: n || ""
                    })
                })).catchType(d.ServerStatusCodeError, (() => {}))
            }
        },
        19947: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setGroupSubject = function(e, t = "") {
                return g((0, p.unproxy)(e), t)
            };
            var s = i(a(19976)),
                r = n(a(2784)),
                l = a(12073),
                o = i(a(79711)),
                d = a(19741),
                c = n(a(96452)),
                u = i(a(17957)),
                h = a(88011),
                p = a(64658),
                f = a(51803);

            function m() {
                var e = (0, s.default)(["models:chat:setSubject dropped"]);
                return m = function() {
                    return e
                }, e
            }

            function g(e, t, a = (0, l.genId)()) {
                var n = t.trim();
                if (!n) return Promise.reject(new c.ActionError);
                if (n === e.contact.name) return Promise.reject(new c.ActionError);
                var i = (0, h.sendSetGroupSubject)(e.id, n),
                    s = e.contact.name,
                    p = new l.ActionType(u.default.t(117)),
                    v = i.then((() => new l.ActionType(u.default.t(116, {
                        subject: n
                    }), {
                        actionText: u.default.t(197),
                        actionHandler: () => g(e, s, a)
                    }))).catchType(d.ServerStatusCodeError, (e => {
                        if (e.status >= 400) return new l.ActionType(u.default.t(115))
                    })).catch((() => (__LOG__(3)(m()), new l.ActionType(u.default.t(115), {
                        actionText: u.default.t(193),
                        actionHandler: () => g(e, n, a)
                    }))));
                return o.default.openToast(r.createElement(l.ActionToast, {
                    id: a,
                    initialAction: p,
                    pendingAction: v
                })), i.then((t => {
                    if (!t._duplicate) {
                        var a = {
                            name: n
                        };
                        return (0, f.updateLocal)(e.contact.id, a).then((() => {
                            e.contact.set(a)
                        }))
                    }
                })).catchType(d.ServerStatusCodeError, (() => {}))
            }
        },
        92816: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setArchiveSetting = function(e) {
                return m(e)
            };
            var s = i(a(19976)),
                r = n(a(2784)),
                l = a(12073),
                o = i(a(79711)),
                d = a(19741),
                c = i(a(17957)),
                u = i(a(2734)),
                h = i(a(37513));

            function p() {
                var e = (0, s.default)(["models:settings:setArchiveSetting dropped"]);
                return p = function() {
                    return e
                }, e
            }

            function f() {
                var e = (0, s.default)(["models:settings:setArchiveSetting failed with server error"]);
                return f = function() {
                    return e
                }, e
            }

            function m(e, t = (0, l.genId)()) {
                var a, n = (0, h.default)(e),
                    i = new l.ActionType(c.default.t(37)),
                    s = Boolean(null === (a = u.default.archive) || void 0 === a ? void 0 : a.classic),
                    g = n.then((() => {
                        var a = e ? c.default.t(35) : c.default.t(38);
                        return new l.ActionType(a, {
                            actionText: c.default.t(197),
                            actionHandler: () => m(s, t)
                        })
                    })).catchType(d.ServerStatusCodeError, (e => {
                        if (__LOG__(3)(f()), e.status >= 400) return new l.ActionType(c.default.t(36))
                    })).catch((() => {
                        throw __LOG__(3)(p()), new l.ActionType(c.default.t(36), {
                            actionText: c.default.t(193),
                            actionHandler: () => m(e, t)
                        })
                    }));
                return o.default.openToast(r.createElement(l.ActionToast, {
                    id: t,
                    initialAction: i,
                    pendingAction: g
                })), n.then((() => {
                    u.default.archive && u.default.archive.classic !== e && (u.default.archive = {
                        classic: e
                    })
                }))
            }
        },
        37513: (e, t, a) => {
            "use strict";
            var n = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                s.default.supportsFeature(s.default.F.MD_BACKEND);
                return r.default.setArchiveSetting(e).then((e => {
                    if (e.status && 200 !== e.status) throw new i.ServerStatusCodeError(e.status)
                }))
            };
            var i = a(19741),
                s = n(a(18120)),
                r = n(a(76022))
        },
        74816: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(65219)),
                l = n(a(40207));
            class o extends s.Component {
                constructor(...e) {
                    super(...e), this.contextEnabled = () => {
                        var {
                            contextEnabled: e,
                            contact: t
                        } = this.props;
                        return null != e && e(t)
                    }, this.onContext = e => {
                        var {
                            onContext: t,
                            contact: a
                        } = this.props;
                        return t && t(e, a)
                    }
                }
                render() {
                    var {
                        contact: e,
                        participant: t,
                        onClick: a,
                        contextMenu: n,
                        isPendingParticipant: i
                    } = this.props;
                    return s.createElement(r.default, {
                        contact: e,
                        admin: t.isAdmin,
                        onClick: a,
                        theme: "drawer-list",
                        contextEnabled: this.contextEnabled,
                        contextMenu: n,
                        onContext: this.onContext,
                        isPendingParticipant: i,
                        showNotifyName: !0,
                        waitIdle: !0
                    })
                }
            }
            o.CONCERNS = {
                participant: ["isAdmin"]
            };
            var d = (0, l.default)(o, o.CONCERNS);
            t.default = d
        },
        36938: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(58527)),
                r = i(a(22220)),
                l = n(a(2784)),
                o = i(a(17957)),
                d = i(a(20642)),
                c = i(a(80645));
            class u extends l.Component {
                constructor(...e) {
                    super(...e), this._setGallery = e => {
                        this._gallery = e
                    }, this._queryCollection = (e, t) => {
                        var {
                            docMsgs: a,
                            chat: n
                        } = this.props;
                        this.props.listeners.uiIdle((() => {
                            a.queryDocs(n, t)
                        }))
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(this.props.docMsgs, "add remove reset", (() => {
                        var e;
                        null === (e = this._gallery) || void 0 === e || e.forceUpdate()
                    })), this.props.listeners.add(this.props.docMsgs, "query_doc_before", (() => {
                        var e;
                        null === (e = this._gallery) || void 0 === e || e.forceUpdate()
                    }))
                }
                render() {
                    var e = this.props,
                        {
                            docMsgs: t,
                            listeners: a
                        } = e,
                        n = (0, r.default)(e, ["docMsgs", "listeners"]);
                    return l.createElement(c.default, (0, s.default)({
                        ref: this._setGallery,
                        msgsCollection: t,
                        queryCollection: this._queryCollection,
                        hasBefore: t.hasDocBefore,
                        queryBefore: t.queryDocBefore,
                        emptyText: o.default.t(1060)
                    }, n))
                }
            }
            var h = (0, d.default)(u);
            t.default = h
        },
        67059: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = null != e.side ? s.createElement("div", {
                        className: o.default.side
                    }, e.side) : null,
                    a = (0, r.default)(o.default.container, {
                        [o.default.multiline]: e.multiline
                    });
                return s.createElement("div", {
                    "data-a8n": l.default.key(e.a8nText),
                    className: a,
                    role: e.onClick ? "button" : null,
                    onClick: e.onClick
                }, s.createElement("div", {
                    className: o.default.block
                }, s.createElement("div", {
                    className: o.default.main
                }, e.children), t))
            };
            var s = i(a(2784)),
                r = n(a(72779)),
                l = n(a(32960)),
                o = n(a(35101))
        },
        28049: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    chat: t,
                    groupMetadata: a,
                    onClick: n
                } = e;
                return a ? s.createElement(_, {
                    groupMetadata: a,
                    onClick: n
                }) : s.createElement(v, {
                    chat: t,
                    onClick: n
                })
            }, t.BaseEphemeralSettingRow = C;
            var s = i(a(2784)),
                r = a(43322),
                l = n(a(79711)),
                o = n(a(9386)),
                d = n(a(67059)),
                c = n(a(64485)),
                u = a(13735),
                h = n(a(17957)),
                p = n(a(40207)),
                f = n(a(82631)),
                m = a(40263);
            class g extends s.PureComponent {
                constructor(...e) {
                    super(...e), this._getEphemeralDuration = () => {
                        var e;
                        return null !== (e = this.props.chat.ephemeralDuration) && void 0 !== e ? e : 0
                    }, this._unblockContact = () => {
                        var {
                            chat: e,
                            onClick: t
                        } = this.props;
                        e.contact.addPendingAction((0, r.unblockContact)(e.contact)).then((() => {
                            t(), l.default.closeModal()
                        })).catch((() => {}))
                    }, this._closeModal = () => {
                        l.default.closeModal()
                    }, this._openUnblockContactModal = () => {
                        l.default.openModal(s.createElement(o.default, {
                            onOK: this._unblockContact,
                            okText: h.default.t(1336),
                            onCancel: this._closeModal,
                            cancelText: h.default.t(1518)
                        }, this._getEphemeralDuration() ? h.default.t(637) : h.default.t(638)))
                    }, this._handleClick = () => {
                        var {
                            chat: e,
                            onClick: t
                        } = this.props;
                        e.contact.isContactBlocked ? this._openUnblockContactModal() : t()
                    }
                }
                render() {
                    return s.createElement(C, {
                        ephemeralDuration: this._getEphemeralDuration(),
                        canChange: !0,
                        onClick: this._handleClick
                    })
                }
            }
            g.CONCERNS = {
                chat: ["contact", "ephemeralDuration"]
            };
            var v = (0, p.default)(g, g.CONCERNS);
            class E extends s.PureComponent {
                constructor(...e) {
                    super(...e), this._closeModal = () => {
                        l.default.closeModal()
                    }, this._openNonAdminModal = () => {
                        l.default.openModal(s.createElement(o.default, {
                            onOK: this._closeModal,
                            okText: h.default.t(1680)
                        }, h.default.t(580)))
                    }, this._handleClick = () => {
                        var {
                            onClick: e,
                            groupMetadata: t
                        } = this.props;
                        t.canSetEphemeralSetting() ? e() : this._openNonAdminModal()
                    }
                }
                render() {
                    var e, {
                        groupMetadata: t
                    } = this.props;
                    return s.createElement(C, {
                        ephemeralDuration: null !== (e = t.ephemeralDuration) && void 0 !== e ? e : 0,
                        canChange: t.canSetEphemeralSetting(),
                        onClick: this._handleClick
                    })
                }
            }
            E.CONCERNS = {
                groupMetadata: ["ephemeralDuration", "participants"]
            };
            var _ = (0, p.default)(E, E.CONCERNS);

            function C(e) {
                var t, {
                    ephemeralDuration: a,
                    canChange: n,
                    onClick: i
                } = e;
                t = a > 0 ? n ? h.default.t(632) : (0, u.getEphemeralExplanationString)(a) : h.default.t(631);
                var r = s.createElement(f.default, {
                    className: n ? c.default.chevronIcon : c.default.ephemeralIcon,
                    name: n ? "chevron-right-alt" : "disappearing",
                    directional: !0
                });
                return s.createElement(d.default, {
                    onClick: i,
                    side: r,
                    multiline: !0
                }, s.createElement("div", {
                    className: c.default.header
                }, s.createElement(m.TextSpan, {
                    theme: "title"
                }, h.default.t(737))), s.createElement(m.TextDiv, {
                    theme: "muted"
                }, t))
            }
        },
        43620: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(58527)),
                r = i(a(22220)),
                l = n(a(2784)),
                o = i(a(50935)),
                d = i(a(17957)),
                c = i(a(5710)),
                u = i(a(20642)),
                h = i(a(80645)),
                p = i(a(85454));
            class f extends l.Component {
                constructor(...e) {
                    super(...e), this._setGallery = e => {
                        this._gallery = e
                    }, this._onNewMsgs = e => {
                        if (e) {
                            var t = [],
                                a = Array.isArray(e) ? e : [e];
                            Promise.all(a.map((e => (e.getLinks().length && t.push(e), Promise.resolve())))).then((() => {
                                t.length && this.props.linkMsgs.add(t)
                            }))
                        }
                    }, this._queryCollection = (e, t) => {
                        var {
                            linkMsgs: a,
                            chat: n
                        } = this.props;
                        this.props.listeners.uiIdle((() => {
                            a.queryLinks(n, t)
                        }))
                    }, this._renderLinks = e => {
                        var {
                            linkMsgs: t,
                            selectedMessages: a
                        } = this.props, n = [];
                        return t.forEach((t => {
                            var i = !t.isSentByMe && t.isGroupMsg;
                            t.getGalleryLinks().forEach(((s, r) => {
                                s.href !== t.matchedText && n.push(l.createElement(c.default, {
                                    key: "".concat(t.id.toString(), "-").concat(r),
                                    msg: t.safe(),
                                    link: s,
                                    displayAuthor: i,
                                    selectable: this.props.selectable,
                                    selectedMessages: a,
                                    onMessageSelect: this.props.onMessageSelect,
                                    onClickMsg: e
                                }))
                            })), t.linkPreview && n.push(l.createElement(p.default, {
                                key: t.id.toString(),
                                msg: t,
                                selectable: this.props.selectable,
                                selectedMessages: a,
                                onMessageSelect: this.props.onMessageSelect,
                                displayType: o.default.DISP_TYPE.GALLERY,
                                onClickMsg: e
                            }))
                        })), n.reverse(), n
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(this.props.linkMsgs, "add remove reset", (() => {
                        var e;
                        null === (e = this._gallery) || void 0 === e || e.forceUpdate()
                    })), this.props.listeners.add(this.props.linkMsgs, "query_link_before", (() => {
                        var e;
                        null === (e = this._gallery) || void 0 === e || e.forceUpdate()
                    })), this.props.listeners.add(this.props.chat.msgs, "add bulk_add", this._onNewMsgs)
                }
                render() {
                    var e = this.props,
                        {
                            linkMsgs: t,
                            listeners: a
                        } = e,
                        n = (0, r.default)(e, ["linkMsgs", "listeners"]);
                    return l.createElement(h.default, (0, s.default)({
                        ref: this._setGallery,
                        msgsCollection: t,
                        queryCollection: this._queryCollection,
                        hasBefore: t.hasLinkBefore,
                        queryBefore: t.queryLinkBefore,
                        renderElements: this._renderLinks,
                        emptyText: d.default.t(1062)
                    }, n))
                }
            }
            var m = (0, u.default)(f);
            t.default = m
        },
        5710: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(72779)),
                r = n(a(2784)),
                l = i(a(71874)),
                o = a(18164),
                d = i(a(50935)),
                c = i(a(91581)),
                u = i(a(41117)),
                h = i(a(17957)),
                p = i(a(87793)),
                f = i(a(20227)),
                m = i(a(20642)),
                g = i(a(20564)),
                v = i(a(40207)),
                E = i(a(65411)),
                _ = i(a(74824)),
                C = a(58355);
            class M extends r.Component {
                constructor(e) {
                    super(e), this.mouseOver = () => {
                        this.state.hover || this.setState({
                            hover: !0
                        })
                    }, this.mouseEnter = () => {
                        this.state.hover || this.setState({
                            hover: !0
                        })
                    }, this.mouseLeave = () => {
                        this.state.hover && this.setState({
                            hover: !1
                        })
                    }, this.onSelectChange = e => {
                        this.state.selected !== e && this.setState({
                            selected: e
                        })
                    }, this.onSelectClick = e => {
                        e && e.stopPropagation(), this.props.onMessageSelect(this.props.msg.unsafe(), !this.state.selected)
                    }, this.onClick = () => {
                        this.props.onClickMsg(this.props.msg.unsafe(), !this.state.selected)
                    };
                    var {
                        msg: t,
                        selectedMessages: a
                    } = e;
                    this.state = {
                        hover: !1,
                        selected: a.isSelected(t.unsafe())
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(this.props.selectedMessages, this.props.msg.id.toString(), this.onSelectChange)
                }
                render() {
                    var {
                        msg: e,
                        link: t,
                        displayAuthor: a
                    } = this.props, n = this.props.selectable || this.state.hover ? r.createElement(g.default, {
                        checked: this.state.selected,
                        onClick: this.onSelectClick,
                        msgTheme: "gallery"
                    }) : null, i = (0, o.Conversation)({
                        mentions: e.mentionMap(),
                        links: e.getLinks(),
                        selectable: true,
                        trusted: e.isTrusted()
                    }), m = e.body && e.body.includes(t.url) ? e.body : e.caption, v = a ? r.createElement("div", {
                        className: p.default.author
                    }, r.createElement(l.default, {
                        msg: e,
                        contact: e.senderObj
                    })) : null, M = e.getSuspiciousLinks().length > 0;
                    return r.createElement(u.default, {
                        hover: this.state.hover,
                        onClick: this.onClick,
                        onMouseEnter: this.state.hover ? null : this.mouseEnter,
                        onMouseOver: this.state.hover ? null : this.mouseOver,
                        onMouseLeave: this.state.hover ? this.mouseLeave : null
                    }, r.createElement("div", {
                        className: p.default.msg
                    }, r.createElement(_.default, {
                        transitionName: "delay-leave"
                    }, n), r.createElement(C.MessageContainer, {
                        isSentByMe: e.isSentByMe
                    }, r.createElement("div", {
                        className: (0, s.default)(p.default.bubble, {
                            [p.default.hasAuthor]: a,
                            [p.default.hasSuspiciousLinks]: M
                        })
                    }, v, r.createElement(E.default, {
                        link: t,
                        displayType: d.default.DISP_TYPE.GALLERY
                    }), r.createElement(f.default, {
                        title: t.url,
                        isSentByMe: e.isSentByMe,
                        canonicalUrl: t.domain,
                        displayType: d.default.DISP_TYPE.GALLERY,
                        star: e.star
                    }), r.createElement(c.default, {
                        text: m,
                        selectable: true,
                        className: p.default.text,
                        dirMismatch: e.rtl !== h.default.isRTL(),
                        direction: e.dir,
                        formatters: i
                    })))))
                }
            }
            M.CONCERNS = {
                msg: ["body", "caption", "dir", "id", "isSentByMe", "mediaData", "type", "rtl", "senderObj", "star", "mediaData", "asRevoked"]
            };
            var S = (0, m.default)((0, v.default)(M, M.CONCERNS));
            t.default = S
        },
        80645: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(12436)),
                r = n(a(2784)),
                l = i(a(79711)),
                o = i(a(50935)),
                d = a(20485),
                c = i(a(89286)),
                u = i(a(51581)),
                h = i(a(85454)),
                p = a(64658);
            class f extends r.Component {
                constructor(...e) {
                    super(...e), this._setScrollContainer = e => {
                        this._scrollContainer = e
                    }, this._onScroll = e => {
                        this._handleScroll(e.target)
                    }, this._handleScroll = (0, s.default)((e => {
                        var {
                            hasBefore: t,
                            msgsCollection: a,
                            setScrollOffset: n
                        } = this.props, i = e.scrollHeight - e.clientHeight - e.scrollTop < o.default.SCROLL_FUDGE;
                        t && i && this._queryCollection(a.head()), n && n(e.scrollTop)
                    }), 100), this._handleClickMsg = (e, t) => {
                        var a = (0, p.unproxy)(e);
                        this.props.selectable && void 0 !== t ? this.props.onMessageSelect(a, t) : l.default.openChatAt(a.chat, a.chat.getSearchContext(a))
                    }
                }
                componentDidMount() {
                    var {
                        hasBefore: e,
                        scrollOffset: t
                    } = this.props;
                    e && this._queryCollection(), this._scrollContainer && (this._scrollContainer.scrollTop = t)
                }
                componentWillUnmount() {
                    this._handleScroll.cancel()
                }
                _queryCollection(e) {
                    var {
                        hasBefore: t,
                        queryCollection: a
                    } = this.props;
                    t && a(e)
                }
                _renderElements() {
                    var {
                        msgsCollection: e,
                        selectedMessages: t,
                        renderElements: a
                    } = this.props;
                    return a ? a(this._handleClickMsg) : e.map(((e, a) => r.createElement(h.default, {
                        key: "".concat(e.id.toString(), "_").concat(a),
                        msg: e,
                        selectable: this.props.selectable,
                        selectedMessages: t,
                        onMessageSelect: this.props.onMessageSelect,
                        displayType: o.default.DISP_TYPE.GALLERY,
                        onClickMsg: this._handleClickMsg,
                        onProductClick: this.props.onProductDetail
                    }))).reverse()
                }
                render() {
                    var {
                        queryBefore: e,
                        hasBefore: t,
                        msgsCollection: a,
                        emptyText: n
                    } = this.props, i = this._renderElements();
                    if (e) {
                        if (0 === i.length) return r.createElement(d.Loading, null);
                        i.push(r.createElement(c.default, null))
                    }
                    return 0 !== a.length || e || t ? r.createElement("div", {
                        ref: this._setScrollContainer,
                        onScroll: this._onScroll,
                        className: u.default.wrapper
                    }, i) : r.createElement(d.Empty, {
                        text: n,
                        a8nText: "no-elements"
                    })
                }
            }
            t.default = f, f.defaultProps = {
                scrollOffset: 0
            }
        },
        59514: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(32960)),
                l = n(a(21403)),
                o = n(a(19899)),
                d = n(a(79711)),
                c = n(a(9386)),
                u = n(a(67059)),
                h = n(a(17957)),
                p = n(a(72424)),
                f = n(a(40207)),
                m = a(64658),
                g = a(40263);
            class v extends s.PureComponent {
                constructor(...e) {
                    super(...e), this.onMute = e => {
                        d.default.muteChat((0, m.unproxy)(this.props.chat), e)
                    }, this.onUnmute = () => {
                        var e = this.props.chat.isGroup ? h.default.t(506) : h.default.t(504);
                        d.default.openModal(s.createElement(c.default, {
                            onOK: this.unmute,
                            okText: h.default.t(77),
                            onCancel: () => d.default.closeModal(),
                            cancelText: h.default.t(1518)
                        }, e))
                    }, this.unmute = () => {
                        this.onMute(!1), d.default.closeModal()
                    }
                }
                render() {
                    var {
                        mute: e,
                        settings: t,
                        chat: a
                    } = this.props, n = e.isMuted, i = a.muteExpiration;
                    if (p.default.enhancedArchive && a.archive && t.archiveV2Enabled) return s.createElement(u.default, null, s.createElement(g.TextSpan, {
                        theme: "muted",
                        size: "16"
                    }, h.default.t(230)));
                    var d, c = n ? this.onUnmute : () => {
                            this.onMute(!0)
                        },
                        f = s.createElement(l.default, {
                            checked: n,
                            onChange: c
                        }),
                        m = n ? h.default.t(1527) : h.default.t(1661);
                    if (n && i) {
                        var v = o.default.untilStr(i);
                        d = s.createElement(g.TextDiv, {
                            theme: "muted"
                        }, v)
                    }
                    return s.createElement(u.default, {
                        a8nText: r.default.key("block-mute"),
                        side: f,
                        onClick: c,
                        multiline: !(!n || !i)
                    }, s.createElement(g.TextSpan, {
                        theme: "title"
                    }, m), d)
                }
            }
            v.CONCERNS = {
                chat: ["isGroup", "muteExpiration", "archive"],
                mute: ["isMuted"],
                settings: ["archiveV2Enabled"]
            };
            var E = (0, f.default)(v, v.CONCERNS);
            t.default = E
        },
        61048: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(58527)),
                r = i(a(22220)),
                l = n(a(2784)),
                o = i(a(17957)),
                d = i(a(20642)),
                c = i(a(80645));
            class u extends l.Component {
                constructor(...e) {
                    super(...e), this._setGallery = e => {
                        this._gallery = e
                    }, this._queryCollection = (e, t) => {
                        var {
                            productMsgs: a,
                            chat: n
                        } = this.props;
                        this.props.listeners.uiIdle((() => {
                            a.queryProducts(n, t)
                        }))
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(this.props.productMsgs, "add remove reset", (() => {
                        var e;
                        null === (e = this._gallery) || void 0 === e || e.forceUpdate()
                    }))
                }
                render() {
                    var e = this.props,
                        {
                            productMsgs: t,
                            listeners: a
                        } = e,
                        n = (0, r.default)(e, ["productMsgs", "listeners"]);
                    return l.createElement(c.default, (0, s.default)({
                        ref: this._setGallery,
                        msgsCollection: t,
                        queryCollection: this._queryCollection,
                        hasBefore: t.hasProductBefore,
                        queryBefore: t.hasProductBefore ? Promise.resolve() : null,
                        emptyText: o.default.t(1066)
                    }, n))
                }
            }
            var h = (0, d.default)(u);
            t.default = h
        },
        37576: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(79711)),
                l = n(a(9386)),
                o = n(a(7470)),
                d = n(a(77977)),
                c = n(a(91581)),
                u = n(a(29505)),
                h = n(a(17957)),
                p = a(45515);
            class f extends u.default {
                constructor(...e) {
                    super(...e), this.contactFilter = e => {
                        var t = this.props.chat.groupMetadata;
                        return !!o.default.isFilteredContact(e) && (!t.participants.get(e.id) || h.default.t(218))
                    }, this.confirmAddParticipant = e => {
                        var t = this.onAddParticipant.bind(this, e),
                            a = h.default.t(488, {
                                participant: e.formattedName,
                                subject: this.props.chat.contact.name
                            });
                        this.push(s.createElement(l.default, {
                            onOK: t,
                            okText: h.default.t(207),
                            onCancel: this._pop,
                            cancelText: h.default.t(1518)
                        }, s.createElement(c.default, {
                            text: a
                        })))
                    }, this.onAddParticipant = e => {
                        (0, p.addParticipants)(this.props.chat, [e]).catch((() => {})), r.default.closeModal()
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(s.createElement(d.default, {
                        title: h.default.t(207),
                        filter: this.contactFilter,
                        onCancel: this._pop,
                        onSelect: this.confirmAddParticipant
                    }))
                }
            }
            t.default = f
        },
        18213: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = a(60846),
                l = n(a(79711)),
                o = n(a(9386)),
                d = n(a(7470)),
                c = n(a(91581)),
                u = n(a(29505)),
                h = n(a(17957)),
                p = a(45515),
                f = i(a(51079));
            class m extends u.default {
                constructor(...e) {
                    super(...e), this._isGroupParticipant = e => {
                        var {
                            chat: t
                        } = this.props;
                        return !!t.groupMetadata.participants.get(e)
                    }, this.customSecondaryText = e => {
                        var {
                            chat: t
                        } = this.props;
                        return t.groupMetadata.participants.get(e) ? h.default.t(218) : null
                    }, this.contactFilter = e => {
                        var t = this.props.chat.groupMetadata;
                        return !!d.default.isFilteredContact(e) && (!t.participants.get(e.id) || h.default.t(218))
                    }, this.confirmAddParticipant = e => {
                        var {
                            chat: t
                        } = this.props;
                        this.push(s.createElement(o.default, {
                            onOK: this.onAddParticipant.bind(this, e),
                            okText: h.default.t(207, {
                                _plural: e.length
                            }),
                            onCancel: this._pop,
                            cancelText: h.default.t(1518)
                        }, s.createElement(c.default, {
                            text: this._makeNameEnumeration(e, t.contact.name)
                        })))
                    }, this._makeNameEnumeration = (e, t) => {
                        var a = e.map((e => e.formattedShortName || e.shortName)).reduce(((t, a, n) => [...t, a, n !== e.length - 1 && h.default.t(579) || ""]), []);
                        return h.default.t(489, {
                            participants: a.join(""),
                            subject: t
                        })
                    }, this.onAddParticipant = e => {
                        (0, p.addParticipants)(this.props.chat, e).catch((() => {})), l.default.closeModal()
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(s.createElement(f.default, {
                        onConfirm: this.confirmAddParticipant,
                        filter: this.contactFilter,
                        title: h.default.t(207),
                        isDisabled: this._isGroupParticipant,
                        isSelected: this._isGroupParticipant,
                        customSecondaryText: this.customSecondaryText,
                        listType: f.ListType.PARTICIPANT_MANAGE_MODAL,
                        singleSelectionFooterType: r.FooterType.CONFIRM,
                        multipleSelectionFooterType: r.FooterType.CONFIRM
                    }))
                }
            }
            t.default = m
        },
        71194: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(21081)),
                l = n(a(42034)),
                o = n(a(29505)),
                d = n(a(2734));
            class c extends o.default {
                constructor(...e) {
                    super(...e), this._showArchiveSettingsDrawer = () => {
                        this.push(s.createElement(r.default, {
                            settings: d.default,
                            onClose: this._pop
                        }))
                    }, this._pop = () => {
                        this.pop()
                    }
                }
                componentDidMount() {
                    this.push(s.createElement(l.default, {
                        showSettings: this._showArchiveSettingsDrawer,
                        onClose: this._pop,
                        settings: d.default
                    }))
                }
            }
            t.default = c
        },
        41780: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(48186)),
                l = a(93774),
                o = n(a(16285)),
                d = n(a(92229)),
                c = n(a(43222)),
                u = n(a(44537)),
                h = n(a(29505)),
                p = n(a(47377)),
                f = n(a(93171)),
                m = n(a(19426)),
                g = a(94469),
                v = a(83974),
                E = i(a(47040)),
                _ = n(a(96082)),
                C = n(a(83330)),
                M = n(a(32719)),
                S = n(a(63163)),
                T = n(a(11405));
            class b extends h.default {
                constructor(...e) {
                    super(...e), this._scrollOffset = 0, this._setScrollOffset = e => {
                        this._scrollOffset = e
                    }, this.onProductDetail = (e, t) => {
                        var {
                            chat: a
                        } = this.props, n = s.createElement(_.default, {
                            chat: a,
                            product: e,
                            onEnd: this._end,
                            onBack: this._popAndUpdate,
                            refreshCarousel: !1,
                            sessionId: t,
                            onProductLinkClick: this._onProductLinkClick,
                            onCartClick: this._onCartClick
                        });
                        this.push(n)
                    }, this.onProductDetailFromInfo = (e, t) => {
                        var a = s.createElement(C.default, {
                            chat: this.props.chat,
                            productInfo: e,
                            onEnd: this._end,
                            onBack: this._pop,
                            onProductDetail: this.onProductDetail,
                            onProductCatalog: this.onProductCatalogHeaderClick,
                            sessionId: t,
                            onProductLinkClick: this._onProductLinkClick,
                            onCartClick: this._onCartClick
                        });
                        this.push(a)
                    }, this._onProductLinkClick = (e, t) => {
                        this.push(s.createElement(M.default, {
                            product: e,
                            onBack: this._pop,
                            sessionId: t
                        }))
                    }, this._onCatalogLinkClick = (e, t, a) => {
                        this.push(s.createElement(o.default, {
                            catalog: e,
                            contact: t,
                            sessionId: a,
                            onBack: this._pop
                        }))
                    }, this._onCartClick = (e, t) => {
                        var a = (0, l.showCart)(e, t, this.props.chat);
                        a && this.push(a)
                    }, this.pushProductCatalog = e => {
                        var {
                            chat: t
                        } = this.props, a = s.createElement(S.default, {
                            contact: t.contact,
                            onProductDetail: this.onProductDetail,
                            catalogId: t.id,
                            onBack: this._pop,
                            sessionId: e,
                            businessProfile: t.contact.businessProfile,
                            onCatalogLinkClick: this._onCatalogLinkClick,
                            onCartClick: this._onCartClick
                        });
                        this.push(a)
                    }, this.onProductCatalog = e => {
                        var t = this.props.chat.id;
                        (0, v.logCarouselViewMoreClick)({
                            catalogOwnerWid: t,
                            catalogSessionId: e
                        }), this.pushProductCatalog(e, t)
                    }, this.onProductCatalogHeaderClick = (e, t) => {
                        (0, v.logCarouselViewMoreClick)({
                            catalogOwnerWid: e,
                            catalogSessionId: t
                        }), this.onProductCatalog(t)
                    }, this.onStarred = () => {
                        var e = s.createElement(T.default, {
                            chat: this.props.chat,
                            starredMsgs: this.props.chat.getStarredMsgs(),
                            onClose: this._pop
                        });
                        this.push(e)
                    }, this.onAdminSetting = () => {
                        var {
                            chat: e
                        } = this.props, t = s.createElement(m.default, {
                            chat: e,
                            groupMetadata: e.groupMetadata,
                            onClose: this._pop
                        });
                        this.push(t)
                    }, this.onContactCard = () => {
                        this.push(s.createElement(d.default, {
                            chat: this.props.chat,
                            onClose: this._pop
                        }))
                    }, this.onMediaGallery = () => {
                        var e = s.createElement(E.default, {
                            chat: this.props.chat,
                            onBack: this._pop,
                            onProductDetail: this.onProductDetail,
                            setProductsScrollOffset: this._setScrollOffset
                        });
                        this.push(e)
                    }, this.onGroupInviteLink = () => {
                        var {
                            chat: e
                        } = this.props, t = s.createElement(f.default, {
                            chat: this.props.chat,
                            groupMetadata: e.groupMetadata,
                            onBack: this._pop
                        });
                        this.push(t)
                    }, this._pop = () => {
                        this.pop()
                    }, this._popAndUpdate = () => {
                        this.popAndUpdate({
                            initialTab: E.TABS.PRODUCTS,
                            productsScrollOffset: this._scrollOffset
                        })
                    }, this._end = () => {
                        this.end(!0)
                    }, this.onLiveLocation = () => {
                        var e = s.createElement(g.LiveLocationDrawerLoadable, {
                            chat: this.props.chat,
                            onClose: this._pop
                        });
                        this.push(e)
                    }, this.onEphemeral = () => {
                        var {
                            chat: e
                        } = this.props, t = s.createElement(u.default, {
                            chat: e,
                            fromInfoFlow: !0,
                            onClose: this._pop
                        });
                        this.push(t)
                    }
                }
                componentDidMount() {
                    var e = this.onStarred,
                        t = this.onMediaGallery,
                        a = this.props.chat;
                    this.props.chat.isGroup ? this.push(s.createElement(p.default, {
                        chat: a,
                        showFullGroupDescription: this.props.showFullGroupDescription,
                        groupMetadata: a.groupMetadata,
                        contact: a.contact,
                        profilePicThumb: a.contact.getProfilePicThumb(),
                        onStarred: e,
                        onMediaGallery: t,
                        onAdminSetting: this.onAdminSetting,
                        onGroupInviteLink: this.onGroupInviteLink,
                        onLiveLocation: this.onLiveLocation,
                        onEphemeral: this.onEphemeral,
                        onClose: this._pop
                    })) : a.isBroadcast ? this.push(s.createElement(r.default, {
                        chat: a,
                        contact: a.contact,
                        onStarred: e,
                        onMediaGallery: t,
                        onClose: this._pop
                    })) : a.isUser && this.push(s.createElement(c.default, {
                        contact: a.contact,
                        onStarred: e,
                        onContactCard: this.onContactCard,
                        onMediaGallery: t,
                        onProductCatalog: this.onProductCatalog,
                        onProductDetail: this.onProductDetail,
                        onLiveLocation: this.onLiveLocation,
                        onEphemeral: this.onEphemeral,
                        onClose: this._pop
                    }))
                }
            }
            t.default = b
        },
        84425: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(19976)),
                r = i(a(12436)),
                l = n(a(2784)),
                o = i(a(79711)),
                d = i(a(50935)),
                c = n(a(96452)),
                u = i(a(17957)),
                h = i(a(20642)),
                p = i(a(8603)),
                f = i(a(22807)),
                m = i(a(85352)),
                g = i(a(40210)),
                v = i(a(61941)),
                E = i(a(72259)),
                _ = i(a(91378));

            function C() {
                var e = (0, s.default)(["query media msgs error: "]);
                return C = function() {
                    return e
                }, e
            }

            function M() {
                var e = (0, s.default)(["query media msgs error: "]);
                return M = function() {
                    return e
                }, e
            }
            class S extends l.Component {
                constructor(e) {
                    super(e), this._unmounted = !1, this.onKeyDown = e => {
                        var t = u.default.isRTL();
                        37 === e.keyCode ? t ? this.onNext() : this.onPrev() : 39 === e.keyCode && (t ? this.onPrev() : this.onNext())
                    }, this.onImageLoad = () => {
                        var {
                            uiActionEvent: e
                        } = this;
                        e && (e.markUiActionT(), e.commit(), delete this.uiActionEvent)
                    }, this.onScroll = e => {
                        this.handleScroll(e.currentTarget, this.mediaMsgs, e.currentTarget.scrollLeft, this.props.listeners)
                    }, this.onNext = e => {
                        if (e && e.stopPropagation(), !this.state.imgZoomed) {
                            var t = this.state.activeMsg;
                            if (t) {
                                var a = this.mediaMsgs.getAfter(t);
                                a ? this.onSelectThumb(a) : this.mediaMsgs.hasMediaAfter && (this._queryMediaAfter || (this._queryMediaAfter = this.mediaMsgs.queryMedia({
                                    chat: t.chat,
                                    msg: t,
                                    direction: "after"
                                }).checkpoint(this.props.rejectOnUnmount()).then((e => {
                                    "number" == typeof e.length && e.length > 0 && this.state.activeMsg === t && this.onNext()
                                })).catchType(c.Unmount, (() => {})).catch((() => {
                                    __LOG__(3)(M())
                                })).finally((() => {
                                    this._queryMediaAfter = null
                                }))))
                            }
                        }
                    }, this.onPrev = e => {
                        if (e && e.stopPropagation(), !this.state.imgZoomed) {
                            var t = this.state.activeMsg;
                            if (t) {
                                var a = this.mediaMsgs.getBefore(t);
                                a ? this.onSelectThumb(a) : this.mediaMsgs.hasMediaBefore && (this._queryMediaBefore || (this._queryMediaBefore = this.mediaMsgs.queryMedia({
                                    chat: t.chat,
                                    msg: t,
                                    direction: "before"
                                }).checkpoint(this.props.rejectOnUnmount()).then((e => {
                                    "number" == typeof e.length && e.length > 0 && this.state.activeMsg === t && this.onPrev()
                                })).catchType(c.Unmount, (() => {})).catch((() => {
                                    __LOG__(3)(C())
                                })).finally((() => {
                                    this._queryMediaBefore = null
                                }))))
                            }
                        }
                    }, this.onImgZoomIn = e => {
                        this.setState({
                            imgZoomed: e
                        })
                    }, this.endFlow = () => {
                        o.default.closeModalMedia()
                    }, this.willEndFlow = () => {
                        var e;
                        (e = this._refThumbsContainer) && (0, _.default)(e, {
                            opacity: [0, 1],
                            translateY: ["100%", "0%"]
                        }, {
                            duration: 300,
                            easing: [.1, .82, .25, 1]
                        })
                    }, this.onSelectThumb = e => {
                        this.props.listeners.uiIdle((() => {
                            this.mediaMsgs.loadMoreAroundIfNeeded(e)
                        })), this.setState({
                            activeMsg: e
                        })
                    }, this.scrollToActive = (e = !1) => {
                        var t = this._refThumbsContainer,
                            a = this._refThumbs,
                            n = this._refActiveThumb;
                        if (t && a && n) {
                            var i = 0;
                            n instanceof HTMLElement && (i = n.clientWidth / 2 - t.clientWidth / 2), (0, _.default)(a, "stop");
                            var s = 0;
                            e && (s = 300), (0, _.default)(n, "scroll", {
                                duration: s,
                                container: a,
                                offset: i,
                                axis: "x",
                                easing: [.1, .82, .25, 1]
                            })
                        }
                    }, this._setRefActiveThumb = e => {
                        this._refActiveThumb = e
                    }, this.setRefThumbsContainer = e => {
                        this._refThumbsContainer = e
                    }, this.setRefThumbs = e => {
                        this._refThumbs = e
                    }, this._getActiveMsgIndexInAlbum = () => {
                        var e = -1,
                            {
                                highlightedMsgIds: t
                            } = this.props;
                        if (!t || !this.state.activeMsg) return e;
                        var a = this.state.activeMsg.id.toString();
                        if (!t.has(a)) return e;
                        var n = 0;
                        return t.forEach((t => {
                            t === a && (e = n), n++
                        })), e
                    }, this._prevScrollWidth = null;
                    var t = this.props.msg;
                    this.mediaMsgs = t.chat.constructMediaMsgs(t), this.handleScroll = (0, r.default)(this._handleScroll.bind(this), 100), t.type === d.default.MSG_TYPE.IMAGE && (this.uiActionEvent = new g.default.UiAction({
                        uiActionType: g.default.UI_ACTION_TYPE.IMAGE_OPEN,
                        uiActionPreloaded: t.mediaData.mediaStage === p.default.STAGE.RESOLVED
                    })), this.state = {
                        activeMsg: t,
                        imgZoomed: !1,
                        animatingThumbs: this._hasThumbList(t)
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(window, "keydown", this.onKeyDown), this.addListeners.bind(this)(this.props.listeners, this.mediaMsgs, (() => this.state.activeMsg), this.onSelectThumb, this.endFlow), this.props.listeners.add(this.mediaMsgs, "query_media_before", (() => {
                        var e = this._refThumbs;
                        e && (this._prevScrollWidth = e.scrollWidth, e instanceof HTMLElement && this.forceUpdate())
                    })), this.scrollToActive(), (e => {
                        e && (0, _.default)(e, {
                            opacity: [1, 0],
                            translateY: ["0%", "100%"]
                        }, {
                            duration: 300,
                            delay: 100,
                            easing: [.1, .82, .25, 1]
                        }).then((() => {
                            this._unmounted || this.setState({
                                animatingThumbs: !1
                            })
                        }))
                    })(this._refThumbsContainer)
                }
                addListeners(e, t, a, n, i) {
                    e.uiIdle((() => {
                        var e = a();
                        e && t.loadMoreAroundIfNeeded(e)
                    })), e.add(t, "remove", ((e, s, r) => {
                        var l = a();
                        if (t.includes(e) || null != l && null != l.id && l.id.toString() !== e.id.toString()) this.forceUpdate();
                        else {
                            var o = r.index;
                            0 === t.length ? i() : t.length === o ? n(t.at(o - 1)) : n(t.at(o))
                        }
                    })), e.add(t, "reset", (() => {
                        i()
                    })), e.add(t, "query_media_after", (() => {
                        this.forceUpdate()
                    }))
                }
                componentWillUnmount() {
                    this.handleScroll.cancel(), this._unmounted = !0
                }
                componentDidUpdate(e, t) {
                    if (t.activeMsg !== this.state.activeMsg) this.scrollToActive(!0);
                    else {
                        var a = this._refThumbs;
                        if (!a || null == this._prevScrollWidth || 0 === this._prevScrollWidth) return;
                        a instanceof HTMLElement && (a.scrollLeft += a.scrollWidth - this._prevScrollWidth), this._prevScrollWidth = null
                    }
                }
                _hasThumbList(e) {
                    return !(null == e ? void 0 : e.isViewOnce)
                }
                _handleScroll(e, t, a, n) {
                    if (0 !== t.length && null != a) {
                        if (t.hasMediaBefore && a < e.clientWidth) {
                            var i = (0, v.default)(t.head(), "mediaMsgs.head()");
                            n.uiIdle((() => {
                                t.queryMedia({
                                    chat: i.chat,
                                    msg: i
                                }), this.forceUpdate()
                            }))
                        }
                        if (t.hasMediaAfter && a + d.default.SCROLL_FUDGE > e.scrollWidth - 2 * e.clientWidth) {
                            var s = (0, v.default)(t.last(), "mediaMsgs.last()");
                            n.uiIdle((() => {
                                t.queryMedia({
                                    chat: s.chat,
                                    msg: s,
                                    direction: "after"
                                }), this.forceUpdate()
                            }))
                        }
                    }
                }
                render() {
                    var e, t = this.state.activeMsg;
                    if (!t) return null;
                    var a = this.mediaMsgs.last(),
                        n = this.mediaMsgs.hasMediaAfter || this.state.activeMsg !== a ? this.onNext : null,
                        i = this.mediaMsgs.head(),
                        s = this.mediaMsgs.hasMediaBefore || this.state.activeMsg !== i ? this.onPrev : null;
                    return l.createElement("div", {
                        className: this.state.imgZoomed ? "img-zoomed-in" : null
                    }, this._hasThumbList(t) && l.createElement(m.default, {
                        activeMsg: t,
                        mediaMsgs: this.mediaMsgs,
                        highlightedMsgIds: this.props.highlightedMsgIds,
                        onSelectThumb: this.onSelectThumb,
                        onSetActiveThumb: this._setRefActiveThumb,
                        onScroll: this.onScroll,
                        setRefThumbsContainer: this.setRefThumbsContainer,
                        setRefThumbs: this.setRefThumbs
                    }), l.createElement(f.default, {
                        msg: t,
                        mediaData: t.mediaData,
                        onBack: this.endFlow,
                        onExitAnimation: this.willEndFlow,
                        onNext: n,
                        onPrev: s,
                        onImgZoomIn: this.onImgZoomIn,
                        getZoomNode: this.props.getZoomNode,
                        startTime: this.props.startTime,
                        isAnimatingIn: this.state.animatingThumbs,
                        onImageLoad: this.uiActionEvent ? this.onImageLoad : null,
                        msgIndexInAlbum: this._getActiveMsgIndexInAlbum(),
                        albumSize: (null === (e = this.props.highlightedMsgIds) || void 0 === e ? void 0 : e.size) || 0
                    }))
                }
            }
            var T = (0, E.default)((0, h.default)(S));
            t.default = T
        },
        21081: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(32960)),
                l = n(a(8444)),
                o = n(a(21403)),
                d = n(a(58701)),
                c = n(a(73023)),
                u = i(a(71311)),
                h = n(a(17957)),
                p = a(92816),
                f = n(a(40207)),
                m = a(40263);
            class g extends s.Component {
                constructor(...e) {
                    super(...e), this._onUnarchiveSettingChange = () => {
                        var e, t = !(null === (e = this.props.settings.archive) || void 0 === e ? void 0 : e.classic);
                        (0, p.setArchiveSetting)(t)
                    }
                }
                render() {
                    var e, t = Boolean(null === (e = this.props.settings.archive) || void 0 === e ? void 0 : e.classic);
                    return s.createElement(d.default, null, s.createElement(u.default, {
                        title: h.default.t(226),
                        type: u.DRAWER_HEADER_TYPE.LARGE,
                        onBack: this.props.onClose
                    }), s.createElement(c.default, null, s.createElement("div", {
                        className: l.default.section
                    }, s.createElement("div", {
                        "data-a8n": r.default.key("auto-unarchive-setting"),
                        className: l.default.control
                    }, s.createElement(o.default, {
                        onChange: this._onUnarchiveSettingChange,
                        checked: t
                    })), s.createElement("div", {
                        "data-a8n": r.default.key("auto-unarchive-setting-text")
                    }, h.default.t(245), s.createElement(m.TextDiv, {
                        theme: "muted"
                    }, h.default.t(244))))))
                }
            }
            g.CONCERNS = {
                settings: ["archive"]
            };
            var v = (0, f.default)(g, g.CONCERNS);
            t.default = v
        },
        42034: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(92963)),
                l = i(a(13886)),
                o = n(a(43334)),
                d = n(a(79711)),
                c = n(a(50935)),
                u = n(a(58701)),
                h = n(a(73023)),
                p = i(a(71311)),
                f = n(a(14457)),
                m = n(a(71201)),
                g = a(20485),
                v = n(a(35598)),
                E = n(a(22004)),
                _ = a(90973),
                C = n(a(6660)),
                M = a(95595),
                S = n(a(44343)),
                T = n(a(17957)),
                b = n(a(20642)),
                N = a(80898),
                P = n(a(72424)),
                y = n(a(73664)),
                I = n(a(40207)),
                k = n(a(82631)),
                A = i(a(40263)),
                R = n(a(74824));
            class O extends s.Component {
                constructor(...e) {
                    super(...e), this.flatListController = new E.default, this.selection = new y.default([], (e => e.id.toString())), this.state = {
                        forceHideNux: !1,
                        chats: this._getArchivedChats()
                    }, this.onClick = (e, t) => {
                        d.default.openChatFromUnread(t).then((e => {
                            e && d.default.focusChatTextInput(t)
                        })), P.default.enhancedArchive || this.onClose()
                    }, this.onClose = () => {
                        this.props.onClose()
                    }, this.onNextChat = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.setNext(!0)
                    }, this.onPrevChat = e => {
                        e.preventDefault(), e.stopPropagation(), this.selection.setPrev(!0)
                    }, this.renderItem = e => s.createElement(l.default, {
                        chat: e.chat,
                        mode: l.Mode.LAST,
                        active: this.selection,
                        onClick: this.onClick,
                        hideArchivedIcon: P.default.enhancedArchive,
                        hideMuteIcon: P.default.enhancedArchive && this.props.settings.archiveV2Enabled,
                        hideMuteOption: P.default.enhancedArchive && this.props.settings.archiveV2Enabled,
                        showEphemeralIcon: !0
                    }), this.setRefHotKeys = e => {
                        this.refList = e
                    }, this._onCloseNux = () => {
                        (0, M.setNUX)(c.default.NUX.ARCHIVE, {
                            views: c.default.ARCHIVE_NUX_MAX_VIEWS,
                            maxViews: c.default.ARCHIVE_NUX_MAX_VIEWS
                        }), this.setState({
                            forceHideNux: !0
                        })
                    }, this._showNux = () => {
                        var e = o.default.some((e => e.archive));
                        return P.default.enhancedArchive && this.props.settings.archiveV2Enabled && e && (0, M.shouldShowNUX)(c.default.NUX.ARCHIVE) && !this.state.forceHideNux
                    }
                }
                componentDidMount() {
                    P.default.enhancedArchive && this.props.settings.archiveV2Enabled && !(0, M.getNUX)(c.default.NUX.ARCHIVE) && (0, M.setNUX)(c.default.NUX.ARCHIVE, {
                        views: 0,
                        maxViews: c.default.ARCHIVE_NUX_MAX_VIEWS
                    }), this._showNux() && (0, M.viewNUX)(c.default.NUX.ARCHIVE), P.default.enhancedArchive ? this.props.listeners.add(o.default, "sort change:archive add remove", (() => {
                        this.setState({
                            chats: this._getArchivedChats()
                        })
                    })) : this.props.listeners.add(o.default, "change:archive add remove", (() => {
                        this.setState({
                            chats: this._getArchivedChats()
                        })
                    })), this.refList && C.default.focus(this.refList)
                }
                _getArchivedChats() {
                    return o.default.filter((e => e.archive))
                }
                getData() {
                    return this.state.chats.map((e => ({
                        itemKey: e.id.toString(),
                        chat: e
                    })))
                }
                render() {
                    var e, t;
                    if (this.selection.init(this.state.chats, !0), this._showNux() && (t = s.createElement("div", {
                            className: r.default.nuxContainer
                        }, s.createElement(_.FlexColumn, {
                            align: "center"
                        }, s.createElement("span", {
                            className: r.default.nuxIcon
                        }, s.createElement(k.default, {
                            name: "archive-nux"
                        })), s.createElement("div", {
                            className: r.default.nuxHeader
                        }, s.createElement(A.default, {
                            theme: "large",
                            as: "h1"
                        }, T.default.t(225))), s.createElement("div", {
                            className: r.default.nuxContent
                        }, s.createElement("div", {
                            className: r.default.nuxText
                        }, s.createElement(A.default, {
                            theme: "plain",
                            as: "p"
                        }, T.default.t(224))))), s.createElement("button", {
                            onClick: this._onCloseNux,
                            className: r.default.btnClose
                        }, s.createElement(k.default, {
                            name: "x-alt"
                        })))), this.state.chats.length > 0) {
                        var a = {
                            down: this.onNextChat,
                            up: this.onPrevChat
                        };
                        e = s.createElement(S.default, {
                            onRef: this.setRefHotKeys,
                            handlers: a
                        }, s.createElement(R.default, {
                            transitionName: "slide"
                        }, t), P.default.enhancedArchive && this.props.settings.archiveV2Enabled && !t && s.createElement("div", {
                            className: r.default.muteTextContainer
                        }, s.createElement(_.FlexColumn, {
                            align: "center"
                        }, s.createElement(A.TextSpan, {
                            theme: "muted",
                            size: "13"
                        }, T.default.t(229)))), s.createElement(v.default, {
                            className: r.default.flatListContainer,
                            data: this.getData(),
                            flatListController: this.flatListController,
                            direction: "vertical",
                            renderItem: this.renderItem
                        }))
                    } else e = s.createElement(g.Archived, null);
                    var n = P.default.enhancedArchive ? s.createElement(N.MenuBarItem, {
                        a8nText: "archived-menu",
                        icon: s.createElement(k.default, {
                            name: "menu"
                        }),
                        title: T.default.t(915)
                    }, s.createElement(f.default, {
                        type: "dropdown_menu",
                        flipOnRTL: !0,
                        key: "ArchivedDrawerHeader",
                        dirX: "LEFT"
                    }, s.createElement(m.default, {
                        a8n: "open-archive-settings menu-item",
                        action: this.props.showSettings
                    }, T.default.t(226)))) : null;
                    return s.createElement(u.default, {
                        theme: "archived"
                    }, s.createElement(p.default, {
                        title: T.default.t(228),
                        onBack: this.onClose,
                        type: p.DRAWER_HEADER_TYPE.LARGE,
                        menu: n
                    }), s.createElement(h.default, {
                        flatListControllers: [this.flatListController]
                    }, e))
                }
            }
            O.CONCERNS = {
                settings: ["archiveV2Enabled"]
            };
            var D = (0, b.default)((0, I.default)(O, O.CONCERNS));
            t.default = D
        },
        48186: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(68214)),
                l = n(a(43334)),
                o = n(a(19899)),
                d = n(a(79711)),
                c = n(a(65219)),
                u = n(a(7470)),
                h = i(a(46478)),
                p = n(a(58701)),
                f = n(a(73023)),
                m = n(a(6162)),
                g = i(a(71311)),
                v = n(a(77875)),
                E = n(a(35598)),
                _ = n(a(22004)),
                C = a(95595),
                M = n(a(98294)),
                S = n(a(17957)),
                T = n(a(20642)),
                b = n(a(65824)),
                N = n(a(40207)),
                P = a(64658),
                y = n(a(82631)),
                I = a(40263),
                k = n(a(68384));
            class A extends s.Component {
                constructor(...e) {
                    super(...e), this.flatListController = new _.default, this.onParticipantClick = (e, t) => {
                        k.default.equals((0, C.getMaybeMeUser)(), t.id) || l.default.find(t.id).then((function(e) {
                            d.default.openChatFromUnread(e).then((t => {
                                t && d.default.focusChatTextInput(e)
                            }))
                        }))
                    }, this.onClose = () => {
                        this.props.onClose ? this.props.onClose() : this.props.uim.uie.requestDismiss()
                    }, this.onDelete = () => {
                        d.default.deleteOrExitChat((0, P.unproxy)(this.props.chat))
                    }, this.renderItem = e => {
                        var {
                            participant: t
                        } = e, a = u.default.gadd(t.id);
                        return s.createElement(c.default, {
                            contact: a,
                            theme: "drawer-list",
                            admin: !!t.isAdmin,
                            onClick: this.onParticipantClick,
                            key: t.id.toString(),
                            waitIdle: !0
                        })
                    }
                }
                componentDidMount() {
                    var e = this.props.chat.groupMetadata;
                    this.props.listeners.add(e.participants, "add remove sort reset", (() => {
                        this.forceUpdate()
                    }))
                }
                getData() {
                    return this.props.chat.groupMetadata.participants.map((e => ({
                        itemKey: e.id.toString(),
                        participant: e
                    })))
                }
                render() {
                    var e = this.props.chat,
                        t = null;
                    if (this.props.onMediaGallery) {
                        var a = s.createElement(y.default, {
                                className: r.default.chevron,
                                name: "chevron-right-alt",
                                directional: !0
                            }),
                            n = S.default.t(896);
                        t = s.createElement(v.default, {
                            title: n,
                            titleOnClick: this.props.onMediaGallery || (() => {}),
                            subtitle: a,
                            theme: "padding"
                        }, s.createElement(b.default, {
                            chat: (0, P.unproxy)(e),
                            mediaMsgs: e.getMediaMsgs()
                        }))
                    }
                    var i, l = this.props.chat.groupMetadata.participants,
                        d = s.createElement(I.TextSpan, {
                            theme: "section-title"
                        }, S.default.n(l.length)),
                        c = l.length ? s.createElement(v.default, {
                            title: S.default.t(1733),
                            subtitle: d
                        }, s.createElement(E.default, {
                            flatListController: this.flatListController,
                            direction: "vertical",
                            forceConsistentRenderCount: !1,
                            data: this.getData(),
                            renderItem: this.renderItem
                        })) : null,
                        u = s.createElement(v.default, null, s.createElement(m.default, {
                            a8nText: "li-delete-broadcast",
                            icon: s.createElement(y.default, {
                                name: "delete"
                            }),
                            color: "danger",
                            theme: "list-aligned",
                            onClick: this.onDelete
                        }, S.default.t(1559)));
                    return e.groupMetadata.creation ? (i = o.default.createdStr(e.groupMetadata.creation), i = s.createElement(I.TextDiv, {
                        theme: "small"
                    }, i)) : i = null, s.createElement(p.default, {
                        key: "contact-info-modal",
                        theme: "striped"
                    }, s.createElement(g.default, {
                        type: g.DRAWER_HEADER_TYPE.SMALL,
                        onCancel: this.onClose
                    }, s.createElement(I.TextDiv, {
                        theme: "title"
                    }, S.default.t(340)), i), s.createElement(f.default, {
                        flatListControllers: [this.flatListController]
                    }, s.createElement("div", {
                        className: r.default.body
                    }, s.createElement("div", {
                        className: r.default.photo
                    }, s.createElement(h.default, {
                        id: e.id,
                        size: h.DETAIL_IMAGE_SIZE.LARGE
                    })), t, null, c, u)))
                }
            }
            A.CONCERNS = {
                chat: ["id", "groupMetadata"]
            };
            var R = (0, M.default)((0, T.default)((0, N.default)(A, A.CONCERNS)));
            t.default = R
        },
        7465: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(41353)),
                l = n(a(79711)),
                o = n(a(9386)),
                d = n(a(50935)),
                c = n(a(91581)),
                u = a(35387),
                h = a(95585),
                p = n(a(18120)),
                f = n(a(17957)),
                m = n(a(40207));
            class g extends s.PureComponent {
                constructor(...e) {
                    super(...e), this.onConfirm = () => {
                        l.default.closeModal()
                    }, this._onLearnMore = e => {
                        e.preventDefault(), l.default.closeModal("none"), setTimeout((() => (0, u.openExternalLink)((0, h.getBusinessFaqUrl)())), 10)
                    }, this._getMessage = () => {
                        var e = this.props.contact;
                        switch (e.verifiedLevel) {
                            case d.default.VERIFIED_LEVEL.HIGH:
                                return f.default.t(1761);
                            case d.default.VERIFIED_LEVEL.LOW:
                                return f.default.t(1763);
                            case d.default.VERIFIED_LEVEL.UNKNOWN:
                                return f.default.t(1765, {
                                    businessName: e.formattedName
                                })
                        }
                    }, this._getMessageV2 = () => {
                        var e = this.props.contact;
                        switch (e.verifiedLevel) {
                            case d.default.VERIFIED_LEVEL.HIGH:
                                return e.name === e.verifiedName ? f.default.t(1511, {
                                    businessName: e.verifiedName
                                }) : f.default.t(1512, {
                                    businessName: e.verifiedName
                                });
                            case d.default.VERIFIED_LEVEL.LOW:
                            case d.default.VERIFIED_LEVEL.UNKNOWN:
                                return f.default.t(1513)
                        }
                    }
                }
                render() {
                    var e;
                    e = p.default.supportsFeature(p.default.F.VNAME_V_2) ? this._getMessageV2() : this._getMessage();
                    var t = s.createElement(r.default, {
                        href: (0, h.getBusinessFaqUrl)(),
                        onClick: this._onLearnMore
                    }, f.default.t(825));
                    return s.createElement(o.default, {
                        onOK: this.onConfirm,
                        okText: f.default.t(1080)
                    }, s.createElement(c.default, {
                        text: e
                    }), " ", t)
                }
            }
            g.CONCERNS = {
                contact: ["name", "verifiedLevel", "verifiedName", "formattedName"]
            };
            var v = (0, m.default)(g, g.CONCERNS);
            t.default = v
        },
        43567: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.BusinessProfile = void 0;
            var s = i(a(72779)),
                r = n(a(2784)),
                l = i(a(7465)),
                o = i(a(684)),
                d = i(a(23279)),
                c = i(a(79711)),
                u = i(a(50935)),
                h = i(a(67059)),
                p = i(a(6162)),
                f = i(a(77875)),
                m = i(a(91581)),
                g = i(a(35387)),
                v = i(a(18120)),
                E = a(75459),
                _ = i(a(17957)),
                C = i(a(81524)),
                M = i(a(43562)),
                S = a(65935),
                T = i(a(40210)),
                b = a(87322),
                N = i(a(2825)),
                P = i(a(40207)),
                y = i(a(82631)),
                {
                    VERIFIED_LEVEL: I
                } = u.default;
            class k extends r.PureComponent {
                constructor(...e) {
                    super(...e), this.state = {
                        collapsedHours: !0
                    }, this._onBusinessHoursClick = () => {
                        this.setState({
                            collapsedHours: !this.state.collapsedHours
                        })
                    }, this._onBusinessInfoClick = () => {
                        c.default.openModal(r.createElement(l.default, {
                            contact: this.props.contact
                        }))
                    }, this._onBusinessInfoWithUpsellClick = () => {
                        c.default.openModal(r.createElement(o.default, {
                            contact: this.props.contact
                        }))
                    }
                }
                componentDidMount() {
                    new T.default.ViewBusinessProfile({
                        viewBusinessProfileAction: T.default.VIEW_BUSINESS_PROFILE_ACTION.ACTION_IMPRESSION
                    }).commit()
                }
                _getBusinessInfoTitle() {
                    var e, t = this.props.contact,
                        a = !t.name || t.name === t.verifiedName,
                        n = "psa-unverified";
                    switch (t.verifiedLevel) {
                        case I.HIGH:
                            n = "psa-verified", a ? e = r.createElement(m.default, {
                                className: d.default.verifiedLabel,
                                text: _.default.t(384)
                            }) : (e = r.createElement(m.default, {
                                className: d.default.verifiedLabel,
                                text: _.default.t(382)
                            }), e = r.createElement(C.default, {
                                id: 383,
                                params: {
                                    verified: e,
                                    businessName: t.verifiedName
                                }
                            }));
                            break;
                        case I.LOW:
                            e = a ? r.createElement(m.default, {
                                text: _.default.t(362)
                            }) : _.default.t(361, {
                                businessName: t.verifiedName
                            });
                            break;
                        case I.UNKNOWN:
                            e = _.default.t(357)
                    }
                    return r.createElement(R, {
                        icon: n,
                        className: d.default.businessMarker,
                        onClick: this._onBusinessInfoClick
                    }, e)
                }
                _getBusinessInfoTitleV2() {
                    var e;
                    switch (this.props.contact.verifiedLevel) {
                        case I.HIGH:
                            e = _.default.t(380);
                            break;
                        case I.LOW:
                        case I.UNKNOWN:
                            e = _.default.t(357)
                    }
                    return r.createElement(p.default, {
                        a8nText: "business-title",
                        className: d.default.businessTitleText,
                        onClick: this._onBusinessInfoClick
                    }, e)
                }
                _getBusinessInfoTitleWithSMBUpsell() {
                    var e;
                    switch (this.props.contact.verifiedLevel) {
                        case I.HIGH:
                            e = _.default.t(380);
                            break;
                        case I.LOW:
                        case I.UNKNOWN:
                            e = _.default.t(357)
                    }
                    return r.createElement(h.default, {
                        a8nText: "business-title",
                        onClick: this._onBusinessInfoWithUpsellClick,
                        side: r.createElement(y.default, {
                            className: d.default.infoIcon,
                            display: "inline",
                            name: "info"
                        })
                    }, e)
                }
                _getBusinessHours(e) {
                    var t = (0, b.getBusinessHours)(e).map((e => {
                        var {
                            day: t,
                            hours: a,
                            first: n
                        } = e;
                        return !n && this.state.collapsedHours ? null : r.createElement(A, {
                            day: t,
                            key: t,
                            hours: a,
                            first: n,
                            collapsed: this.state.collapsedHours
                        })
                    }));
                    return r.createElement(R, {
                        icon: "business-hours",
                        onClick: this._onBusinessHoursClick
                    }, t)
                }
                getAddressString(e) {
                    var {
                        streetAddress: t,
                        localizedCityName: a,
                        zipCode: n
                    } = e;
                    return t && a && n ? _.default.t(356, {
                        streetAddress: t,
                        city: a,
                        zipCode: n
                    }) : t && a ? _.default.t(355, {
                        streetAddress: t,
                        city: a
                    }) : t
                }
                _getAddress(e, t, a, n) {
                    var i, s, l, o = n ? this.getAddressString(n) : null;
                    (null != t && null != a && (i = r.createElement("div", {
                        style: {
                            height: 150
                        },
                        className: d.default.businessMap
                    }, r.createElement(M.default, {
                        lat: t,
                        lng: a,
                        name: o || e,
                        width: 565,
                        height: 150
                    }))), o) && (l = null != t && null != a ? (0, S.getMapUrl)(t, a, o) : (0, S.getSearchUrl)(o), s = r.createElement("div", {
                        className: d.default.address
                    }, r.createElement(g.default, {
                        href: l
                    }, r.createElement(m.default, {
                        selectable: !0,
                        direction: "auto",
                        text: o
                    }))));
                    return s || i ? r.createElement(R, {
                        icon: "business-address"
                    }, s, i) : null
                }
                render() {
                    var e, t, a, n, i, s, l, o;
                    e = (0, E.canSeeSMBUpsell)() ? this._getBusinessInfoTitleWithSMBUpsell() : v.default.supportsFeature(v.default.F.VNAME_V_2) ? this._getBusinessInfoTitleV2() : this._getBusinessInfoTitle();
                    var c, u = this.props.businessProfile;
                    if (u.stale) t = r.createElement("div", {
                        className: d.default.contactBusinessInfoSpinner
                    }, r.createElement(N.default, {
                        size: 20,
                        stroke: 5
                    }));
                    else if (a = u.categories && u.categories.length ? r.createElement(R, {
                            icon: "business-category"
                        }, r.createElement(m.default, {
                            selectable: !0,
                            direction: "auto",
                            text: u.categories.map((e => e.localized_display_name)).join(_.default.t(579))
                        })) : null, n = u.description ? r.createElement(R, {
                            icon: "business-description"
                        }, r.createElement(m.default, {
                            selectable: !0,
                            direction: "auto",
                            text: u.description
                        })) : null, i = this._getAddress(this.props.contact.name, u.latitude, u.longitude, u.structuredAddress), u.website && Array.isArray(u.website) && u.website.length && (s = u.website.map(((e, t) => {
                            var a = (0, b.getWebsiteLink)(e),
                                n = r.createElement(m.default, {
                                    selectable: !0,
                                    direction: "auto",
                                    text: e
                                }),
                                i = r.createElement(g.default, {
                                    className: d.default.link,
                                    href: a
                                }, n);
                            return r.createElement(R, {
                                icon: "business-website",
                                key: t
                            }, i)
                        }))), u.businessHours && (l = this._getBusinessHours(u.businessHours)), u.email) {
                        var h = r.createElement(m.default, {
                                selectable: !0,
                                direction: "auto",
                                text: u.email
                            }),
                            p = r.createElement(g.default, {
                                className: d.default.link,
                                href: "mailto:".concat(u.email)
                            }, h);
                        o = r.createElement(R, {
                            icon: "business-email",
                            dir: "auto"
                        }, p)
                    }
                    return (t || null != i || a || n || null != l || o || s) && (c = r.createElement(f.default, {
                        theme: "padding"
                    }, r.createElement("div", {
                        className: d.default.contactBusinessInfo
                    }, t, i, a, n, l, o, s))), r.createElement(r.Fragment, null, r.createElement(f.default, null, e), c)
                }
            }
            t.BusinessProfile = k, k.CONCERNS = {
                contact: ["id", "verifiedLevel", "name", "verifiedName"],
                businessProfile: ["description", "categories", "website", "email", "stale", "latitude", "longitude", "businessHours", "structuredAddress"]
            };
            var A = e => {
                    var t = e.first ? r.createElement("div", {
                        className: d.default.businessHoursChevron,
                        role: "button"
                    }, r.createElement(y.default, {
                        className: e.collapsed ? "" : d.default.flipSvg,
                        display: "inline",
                        name: "chevron-down-alt"
                    })) : null;
                    return r.createElement("div", {
                        className: d.default.businessHoursRow
                    }, r.createElement("div", {
                        className: d.default.businessHoursDay
                    }, r.createElement(m.default, {
                        direction: "auto",
                        text: e.day
                    })), r.createElement("div", {
                        className: d.default.businessHoursHours
                    }, r.createElement(m.default, {
                        direction: "auto",
                        text: e.hours
                    })), t)
                },
                R = e => r.createElement("div", {
                    className: (0, s.default)(d.default.dataRow, e.className),
                    onClick: e.onClick
                }, r.createElement("div", {
                    className: d.default.dataRowIcon
                }, r.createElement(y.default, {
                    name: e.icon
                })), r.createElement("div", {
                    className: d.default.dataRowText
                }, e.children)),
                O = (0, P.default)(k, k.CONCERNS);
            t.default = O
        },
        38949: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(19976)),
                r = n(a(2784)),
                l = i(a(96066)),
                o = n(a(13886)),
                d = i(a(79711)),
                c = i(a(50935)),
                u = i(a(77875)),
                h = a(87819),
                p = i(a(35598)),
                f = i(a(17957)),
                m = i(a(20642)),
                g = i(a(11498)),
                v = i(a(40207)),
                E = i(a(82631)),
                _ = a(40263);

            function C() {
                var e = (0, s.default)(["get from participants table failed"]);
                return C = function() {
                    return e
                }, e
            }
            class M extends r.Component {
                constructor(...e) {
                    super(...e), this._commonGroupInitialized = !1, this.state = {
                        collapsed: !1,
                        numGroups: 0
                    }, this.rerender = () => {
                        this.forceUpdate()
                    }, this.onClick = (e, t) => {
                        d.default.openChatFromUnread(t).then((e => {
                            e && d.default.focusChatTextInput(t)
                        })), this.props.onClose()
                    }, this.onShowMore = () => {
                        this.setState({
                            collapsed: !1
                        })
                    }, this.renderItem = e => {
                        var {
                            chat: t
                        } = e;
                        return r.createElement(o.default, {
                            chat: t,
                            theme: "drawer-list",
                            contact: t.contact,
                            mode: o.Mode.INFO,
                            onClick: this.onClick,
                            key: t.id.toString()
                        })
                    }
                }
                static getDerivedStateFromProps(e, t) {
                    var {
                        commonGroups: a
                    } = e.contact, n = a ? a.length : 0;
                    return t.numGroups <= c.default.INFO_DRAWER_MAX_ROWS && n > c.default.INFO_DRAWER_MAX_ROWS ? {
                        numGroups: n,
                        collapsed: !0
                    } : {
                        numGroups: n
                    }
                }
                componentDidMount() {
                    var {
                        commonGroups: e
                    } = this.props.contact;
                    e && (this.props.listeners.add(e, "add remove", this.rerender), this._commonGroupInitialized = !0), (0, h.findCommonGroups)(this.props.contact).catch((() => {
                        throw __LOG__(4, !0, new Error, !0)(C()), SEND_LOGS("get from participants table failed when finding common groups"), new Error("get from participants table failed")
                    }))
                }
                componentDidUpdate(e) {
                    if (e.contact !== this.props.contact) {
                        var t = e.contact.commonGroups;
                        t && e.listeners.remove(t, "add remove", this.rerender), this._commonGroupInitialized = !1
                    }
                    var {
                        commonGroups: a
                    } = this.props.contact;
                    a && (this._commonGroupInitialized || (this.props.listeners.add(a, "add remove", this.rerender), this._commonGroupInitialized = !0))
                }
                componentWillUnmount() {
                    var {
                        commonGroups: e
                    } = this.props.contact;
                    e && this._commonGroupInitialized && (this.props.listeners.remove(e, "add remove", this.rerender), this._commonGroupInitialized = !1)
                }
                getData() {
                    var e = this.props.contact.commonGroups;
                    return e.length > c.default.INFO_DRAWER_MAX_ROWS && this.state.collapsed && (e = e.slice(0, c.default.INFO_DRAWER_MAX_ROWS)), e.map((e => ({
                        itemKey: e.id.toString(),
                        chat: e
                    })))
                }
                render() {
                    var e = this.props.contact.commonGroups;
                    if (!e || !e.length) return null;
                    var t, a = r.createElement(_.TextSpan, {
                        theme: "section-title"
                    }, f.default.n(e.length));
                    if (e.length > c.default.INFO_DRAWER_MAX_ROWS && this.state.collapsed) {
                        var n = e.length - c.default.INFO_DRAWER_MAX_ROWS,
                            i = r.createElement(g.default, {
                                theme: "transparent"
                            }, r.createElement(E.default, {
                                name: "down"
                            }));
                        t = r.createElement(l.default, {
                            image: i,
                            theme: "drawer-list",
                            primary: f.default.t(746, {
                                count: n,
                                _plural: n
                            }),
                            onClick: this.onShowMore
                        })
                    }
                    return r.createElement(u.default, {
                        a8nText: "section-common-groups",
                        title: f.default.t(1640),
                        subtitle: a
                    }, r.createElement(p.default, {
                        flatListController: this.props.flatListController,
                        direction: "vertical",
                        forceConsistentRenderCount: !1,
                        data: this.getData(),
                        renderItem: this.renderItem
                    }), t)
                }
            }
            M.CONCERNS = {
                contact: ["commonGroups"]
            };
            var S = (0, m.default)((0, v.default)(M, M.CONCERNS));
            t.default = S
        },
        74549: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = a(43322),
                l = n(a(79148)),
                o = n(a(43567)),
                d = n(a(65468)),
                c = n(a(66585)),
                u = n(a(43334)),
                h = n(a(79711)),
                p = n(a(38949)),
                f = n(a(9386)),
                m = n(a(87335)),
                g = i(a(46478)),
                v = n(a(58701)),
                E = n(a(67059)),
                _ = n(a(73023)),
                C = n(a(6162)),
                M = i(a(71311)),
                S = n(a(77875)),
                T = n(a(91581)),
                b = n(a(28049)),
                N = n(a(22004)),
                P = n(a(18120)),
                y = n(a(98294)),
                I = a(33526),
                k = n(a(19712)),
                A = n(a(17957)),
                R = n(a(81524)),
                O = n(a(20642)),
                D = n(a(43282)),
                x = n(a(65824)),
                w = n(a(40210)),
                L = n(a(59514)),
                G = n(a(60949)),
                F = n(a(53865)),
                B = n(a(55043)),
                U = n(a(72259)),
                V = n(a(50540)),
                W = a(66615),
                H = a(89590),
                j = n(a(2734)),
                q = n(a(40207)),
                Y = n(a(58914)),
                K = n(a(82631)),
                Z = a(40263),
                z = n(a(37698)),
                X = n(a(3111));
            class Q extends s.Component {
                constructor(e) {
                    super(e), this.flatListController = new N.default, this.ProductCatalogSession = new B.default, this._init = () => {
                        P.default.supportsFeature(P.default.F.QUERY_IDENTITY) && !P.default.supportsFeature(P.default.F.MD_BACKEND) && (0, I.queryIdentity)(this.props.contact)
                    }, this._onBlocklistChange = () => {
                        this.state.contactIsBlocked !== !!l.default.get(this.props.contact.id) && this.setState({
                            contactIsBlocked: !!l.default.get(this.props.contact.id)
                        })
                    }, this._onDeleteChat = () => {
                        var e = u.default.assertGet(this.props.contact.id);
                        h.default.deleteOrExitChat(e)
                    }, this.onBlockContact = () => {
                        var e = s.createElement(G.default, {
                            contact: this.props.contact
                        });
                        h.default.openModal(s.createElement(f.default, {
                            onOK: this.blockContact,
                            okText: A.default.t(270),
                            onCancel: () => h.default.closeModal(),
                            cancelText: A.default.t(1518)
                        }, s.createElement(R.default, {
                            id: 271,
                            params: {
                                contact: e
                            }
                        })))
                    }, this.onReportSpam = () => {
                        h.default.openModal(s.createElement(V.default, {
                            isBusiness: this.props.contact.isBusiness,
                            isGroupChat: !1,
                            onReport: this.reportSpam,
                            onReportBlockClear: this.reportSpamBlockClear,
                            onCancel: () => h.default.closeModal()
                        }))
                    }, this.reportSpam = () => {
                        var e = u.default.get(this.props.contact.id);
                        e && (0, H.sendSpamReport)(e), h.default.closeModal()
                    }, this.reportSpamBlockClear = () => {
                        var e = u.default.get(this.props.contact.id);
                        e && (0, H.sendSpamBlockClear)(e), h.default.closeModal()
                    }, this.onUnblockContact = () => {
                        var e = s.createElement(G.default, {
                            contact: this.props.contact
                        });
                        h.default.openModal(s.createElement(f.default, {
                            okText: A.default.t(1336),
                            onOK: this.unblockContact,
                            cancelText: A.default.t(1518),
                            onCancel: () => h.default.closeModal()
                        }, s.createElement(R.default, {
                            id: 1337,
                            params: {
                                contact: e
                            }
                        })))
                    }, this.blockContact = () => {
                        (0, r.blockContact)(this.props.contact), h.default.closeModal()
                    }, this.unblockContact = () => {
                        (0, r.unblockContact)(this.props.contact), h.default.closeModal()
                    }, this.onClose = () => {
                        this.props.onClose ? this.props.onClose() : this.props.uim.uie.requestDismiss()
                    }, this._onViewPicture = e => {
                        if (this._canViewPicture) {
                            var t = e.target;
                            h.default.openModalMedia(s.createElement(F.default, {
                                contact: this.props.contact,
                                profilePicThumb: this.props.contact.getProfilePicThumb(),
                                animateBorderRadius: !0,
                                getZoomNode: e => {
                                    e(t)
                                }
                            }), {
                                transition: "profile-viewer",
                                uim: this.props.uim
                            })
                        }
                    }, this._onDetailImageLoad = () => {
                        this._canViewPicture = !0
                    }, this._canViewPicture = !1, this.state = {
                        contactIsBlocked: !!l.default.get(e.contact.id)
                    }
                }
                componentDidMount() {
                    this.props.listeners.add(l.default, "add remove reset sync", this._onBlocklistChange), this.props.listeners.uiIdle(this._init);
                    var {
                        contact: e
                    } = this.props;
                    e.businessProfile && !e.businessProfile.stale && e.businessCatalog && d.default.findCarouselCatalog(e.id), P.default.supportsFeature(P.default.F.MD_BACKEND)
                }
                _shouldRenderCatalog() {
                    var {
                        contact: e
                    } = this.props;
                    return !!(e && e.isBusiness && e.businessProfile) && !!e.businessCatalog
                }
                renderProductCatalogSection() {
                    if (!this._shouldRenderCatalog()) return null;
                    var {
                        contact: e,
                        onProductCatalog: t,
                        onProductDetail: a
                    } = this.props, n = d.default.get(e.id);
                    return n ? s.createElement(c.default, {
                        onProductDetail: a,
                        onProductCatalog: t,
                        catalog: n,
                        sessionId: this.ProductCatalogSession.toString(),
                        entryPoint: w.default.CATALOG_ENTRY_POINT.CATALOG_ENTRY_POINT_PROFILE
                    }) : null
                }
                render() {
                    var e, t = this.props.contact,
                        a = s.createElement(p.default, {
                            contact: this.props.contact,
                            onClose: this.onClose,
                            flatListController: this.flatListController
                        }),
                        n = u.default.get(t.id);
                    n && (e = s.createElement(S.default, null, s.createElement(C.default, {
                        a8nText: "li-delete-chat",
                        icon: s.createElement(K.default, {
                            name: "delete"
                        }),
                        color: "danger",
                        onClick: this._onDeleteChat
                    }, A.default.t(525))));
                    var i = null;
                    i = this.state.contactIsBlocked ? s.createElement(S.default, null, s.createElement(C.default, {
                        a8nText: "li-unblock",
                        color: "success",
                        icon: s.createElement(K.default, {
                            name: "settings-blocked",
                            directional: !0
                        }),
                        onClick: this.onUnblockContact
                    }, A.default.t(1336))) : s.createElement(S.default, null, s.createElement(C.default, {
                        a8nText: "li-block",
                        color: "danger",
                        icon: s.createElement(K.default, {
                            name: "settings-blocked",
                            directional: !0
                        }),
                        onClick: this.onBlockContact
                    }, A.default.t(270)));
                    var r = s.createElement(S.default, null, s.createElement(C.default, {
                            a8nText: "li-report-spam",
                            color: "danger",
                            icon: s.createElement(K.default, {
                                name: "thumbs-down",
                                directional: !0
                            }),
                            onClick: this.onReportSpam
                        }, t.isBusiness ? A.default.t(1165) : A.default.t(1168))),
                        l = null;
                    if (this.props.onMediaGallery && n) {
                        var d = this.props.onMediaGallery,
                            c = s.createElement(K.default, {
                                className: m.default.chevron,
                                name: "chevron-right-alt",
                                directional: !0
                            }),
                            h = A.default.t(896);
                        l = s.createElement(S.default, {
                            a8nText: "section-media",
                            title: h,
                            titleOnClick: d,
                            subtitle: c,
                            theme: "padding"
                        }, s.createElement(x.default, {
                            chat: n,
                            mediaMsgs: n.getMediaMsgs()
                        }))
                    }
                    var f = null;
                    P.default.supportsFeature(P.default.F.LIVE_LOCATIONS) && n && (f = s.createElement(D.default, {
                        chat: n,
                        onClick: this.props.onLiveLocation
                    }));
                    var N = this.renderProductCatalogSection(),
                        y = n && n.mute.canMute() ? s.createElement(L.default, {
                            chat: n,
                            mute: n.mute,
                            settings: j.default
                        }) : null,
                        I = null;
                    if (this.props.onStarred) {
                        var R = s.createElement(K.default, {
                            className: m.default.chevron,
                            name: "chevron-right-alt",
                            directional: !0
                        });
                        I = s.createElement(E.default, {
                            a8nText: "block-starred-messages",
                            side: R,
                            onClick: this.props.onStarred
                        }, s.createElement(Z.TextSpan, {
                            theme: "title"
                        }, A.default.t(467)))
                    }
                    var O = n && n.shouldShowEphemeralSetting() ? s.createElement(b.default, {
                            onClick: this.props.onEphemeral,
                            chat: n
                        }) : null,
                        w = null,
                        F = n && n.getReceivedVcardMsgs();
                    if (P.default.supportsFeature(P.default.F.INDEX_RECEIVED_VCARD) && F && F.length) {
                        var B = s.createElement(K.default, {
                            className: m.default.chevron,
                            name: "chevron-right-alt",
                            directional: !0
                        });
                        w = s.createElement(E.default, {
                            a8nText: "block-contact-card",
                            side: B,
                            onClick: this.props.onContactCard
                        }, s.createElement(Z.TextSpan, {
                            theme: "title"
                        }, A.default.t(511, {
                            _plural: F.length
                        })))
                    }
                    var U = null;
                    (y || I || O || w) && (U = s.createElement(S.default, null, y, I, O, w, null));
                    var V = s.createElement(E.default, {
                            multiline: !0
                        }, s.createElement(Z.TextSpan, {
                            theme: "title"
                        }, s.createElement(Y.default, {
                            id: t.id
                        }))),
                        H = s.createElement(E.default, null, s.createElement(W.SelectableSpan, {
                            dir: "auto",
                            selectable: !0
                        }, s.createElement(Z.TextSpan, {
                            theme: "title"
                        }, (0, X.default)(t.id)))),
                        q = s.createElement(S.default, {
                            a8nText: "section-about-and-phone-number"
                        }, s.createElement("div", {
                            className: m.default.titleAbout
                        }, s.createElement(Z.TextSpan, {
                            theme: "section-title"
                        }, A.default.t(512))), V, H),
                        Q = n && n.presence ? s.createElement(z.default, {
                            contact: t,
                            presence: n.presence,
                            chatstate: n.presence.chatstate,
                            location: "info"
                        }) : null,
                        J = t.showBusinessCheckmarkAsSecondary && P.default.supportsFeature(P.default.F.VNAME_V_2) ? s.createElement("div", {
                            className: m.default.businessVname
                        }, s.createElement(T.default, {
                            text: t.verifiedName,
                            direction: "auto"
                        }), s.createElement("div", {
                            className: m.default.icon
                        }, s.createElement(K.default, {
                            name: "psa-verified"
                        }))) : null,
                        $ = t.isBusiness && t.businessProfile ? s.createElement(o.default, {
                            contact: t,
                            businessProfile: t.businessProfile
                        }) : null,
                        ee = !t.name && t.notifyName ? s.createElement("div", {
                            className: m.default.nameSecondary
                        }, s.createElement(Z.TextSpan, {
                            theme: "muted"
                        }, s.createElement(T.default, {
                            className: m.default.screenName,
                            direction: "auto",
                            text: t.notifyName,
                            selectable: !0
                        }))) : null;
                    return s.createElement(v.default, {
                        key: "contact-info-modal",
                        theme: "striped"
                    }, s.createElement(M.default, {
                        title: A.default.t(1530),
                        type: M.DRAWER_HEADER_TYPE.SMALL,
                        onCancel: this.onClose
                    }), s.createElement(_.default, {
                        flatListControllers: [this.flatListController]
                    }, s.createElement("section", {
                        className: m.default.body
                    }, s.createElement(S.default, {
                        theme: "padding-large"
                    }, s.createElement("div", {
                        className: m.default.avatar
                    }, s.createElement(g.default, {
                        id: t.id,
                        size: g.DETAIL_IMAGE_SIZE.LARGE,
                        loader: !0,
                        onLoad: this._onDetailImageLoad,
                        onClick: this._onViewPicture,
                        quality: g.DETAIL_IMAGE_QUALITY.HIGH
                    })), s.createElement(Z.TextHeader, {
                        level: "2",
                        theme: "large"
                    }, s.createElement(G.default, {
                        contact: t,
                        selectable: !0,
                        showBusinessCheckmark: t.showBusinessCheckmarkAsPrimary
                    })), ee, s.createElement("div", {
                        className: m.default.nameSecondary
                    }, s.createElement(Z.TextSpan, {
                        theme: "muted"
                    }, J), s.createElement(Z.TextSpan, {
                        theme: "muted"
                    }, Q)), s.createElement(k.default, {
                        labels: t.labels
                    })), $, f, N, l, U, q, null, a, i, r, e)))
                }
            }
            Q.CONCERNS = {
                contact: ["id", "formattedName", "formattedUser", "formattedShortName", "isBusiness", "commonGroups", "businessProfile", "showBusinessCheckmarkAsPrimary", "showBusinessCheckmarkAsSecondary", "verifiedName", "name", "notifyName", "labels", "businessCatalog"]
            };
            var J = (0, y.default)((0, U.default)((0, O.default)((0, q.default)(Q, Q.CONCERNS))));
            t.default = J
        },
        43222: (e, t, a) => {
            "use strict";
            var n = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return i.default
                }
            });
            var i = n(a(74549))
        },
        47377: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(58527)),
                r = i(a(52954)),
                l = i(a(19976)),
                o = n(a(2784)),
                d = i(a(32960)),
                c = i(a(37576)),
                u = i(a(18213)),
                h = i(a(96066)),
                p = i(a(43334)),
                f = i(a(19899)),
                m = i(a(79711)),
                g = i(a(9386)),
                v = i(a(50935)),
                E = i(a(58701)),
                _ = i(a(67059)),
                C = i(a(73023)),
                M = i(a(6162)),
                S = n(a(71311)),
                T = i(a(77875)),
                b = i(a(71201)),
                N = i(a(39292)),
                P = i(a(91581)),
                y = i(a(63430)),
                I = i(a(28049)),
                k = n(a(96452)),
                A = n(a(35598)),
                R = i(a(22004)),
                O = a(95595),
                D = i(a(18120)),
                x = i(a(83219)),
                w = i(a(77142)),
                L = i(a(98294)),
                G = a(62902),
                F = i(a(19712)),
                B = i(a(17957)),
                U = n(a(90088)),
                V = i(a(20642)),
                W = i(a(43282)),
                H = i(a(65824)),
                j = a(45515),
                q = i(a(59514)),
                Y = a(60949),
                K = i(a(74816)),
                Z = i(a(91853)),
                z = i(a(96183)),
                X = a(75613),
                Q = i(a(72259)),
                J = i(a(50540)),
                $ = i(a(11498)),
                ee = a(89590),
                te = i(a(72424)),
                ae = a(79728),
                ne = a(19947),
                ie = i(a(2734)),
                se = i(a(40207)),
                re = a(64658),
                le = i(a(17565)),
                oe = i(a(82631)),
                de = a(40263),
                ce = n(a(52100)),
                ue = n(a(75074)),
                he = i(a(17693)),
                pe = i(a(63498)),
                fe = i(a(68384));

            function me() {
                var e = (0, l.default)(["group_info_drawer:onSetDescription failed"]);
                return me = function() {
                    return e
                }, e
            }

            function ge() {
                var e = (0, l.default)(["group_info_drawer:onSetSubject failed"]);
                return ge = function() {
                    return e
                }, e
            }

            function ve() {
                var e = (0, l.default)(["GroupInfoDrawer: failed to set/delete group image"]);
                return ve = function() {
                    return e
                }, e
            }
            var Ee = (0, ue.genId)("max_participant_toast");
            class _e extends o.Component {
                constructor(e) {
                    var t;
                    super(e), t = this, this._participantFlatListController = new R.default, this._pendingParticipantFlatListController = new R.default, this._updateGroupDescOnModelChange = () => {
                        this.props.groupMetadata && this.setState({
                            groupDesc: this.props.groupMetadata.desc
                        })
                    }, this.onImageSet = (e, t) => {
                        var a = this.props.profilePicThumb;
                        this.setState({
                            pendingPhoto: !0
                        }), (e && t ? (0, X.setProfilePic)(a, e, t) : (0, X.deleteProfilePic)(a)).checkpoint(this.props.rejectOnUnmount()).catchType(k.Unmount, (() => {})).catchType(k.ActionError, (() => {
                            __LOG__(3)(ve()), this.setState({
                                resetPhotoPicker: !this.state.resetPhotoPicker
                            })
                        })).finally((() => {
                            this.setState({
                                pendingPhoto: !1
                            })
                        }))
                    }, this.onParticipantClick = (e, t) => {
                        fe.default.equals((0, O.getMaybeMeUser)(), t.id) || p.default.find(t.id).then((e => {
                            m.default.openChatFromUnread(e).then((t => {
                                t && m.default.focusChatTextInput(e)
                            }))
                        }))
                    }, this._menuEnabled = e => {
                        var t = this.props.groupMetadata.participants,
                            a = t.get(e.id);
                        return !!a && (t.canPromote(a) || t.canRemove(a) || t.canVerifyIdentity(a))
                    }, this.onDemoteAdmin = e => {
                        e.contact.pendingAction++, (0, j.demoteParticipants)(this.props.chat, [e]).then((() => {
                            e.contact.pendingAction--
                        })), this.setState({
                            contextMenu: null
                        })
                    }, this.onParticipantMenu = (e, t) => {
                        var a = this.props.groupMetadata.participants,
                            n = a.assertGet(t.id);
                        if (this._menuEnabled(t)) {
                            var i = [];
                            if (a.canPromote(n)) {
                                var s = this._confirmParticipantPromote.bind(this, n);
                                i.push(o.createElement(b.default, {
                                    a8n: "mi-grp-promote-admin",
                                    key: "promote",
                                    action: s
                                }, B.default.t(904)))
                            }
                            if (a.canRemove(n)) {
                                var r = this._confirmParticipantRemove.bind(this, n);
                                i.push(o.createElement(b.default, {
                                    a8n: "mi-grp-remove-participant",
                                    key: "remove",
                                    action: r
                                }, B.default.t(908)))
                            }
                            if (D.default.supportsFeature(D.default.F.GROUPS_V_3) && a.canDemote(n)) {
                                var l = this.onDemoteAdmin.bind(this, n);
                                i.push(o.createElement(b.default, {
                                    a8n: "mi-grp-verify-identify",
                                    key: "demote-admin",
                                    action: l
                                }, B.default.t(546)))
                            }
                            e.event && e.event.persist(), this.setState({
                                contextMenu: {
                                    contactId: t.id,
                                    menu: i,
                                    anchor: e.anchor,
                                    event: e.event
                                }
                            })
                        }
                    }, this.closeContextMenu = () => {
                        this.setState({
                            contextMenu: null
                        })
                    }, this._confirmParticipantRemove = e => {
                        var t = this.onParticipantRemove.bind(this, e, !0),
                            a = B.default.t(497, {
                                participant: e.contact.formattedName,
                                subject: this.props.contact.name
                            });
                        m.default.openModal(o.createElement(g.default, {
                            onOK: t,
                            okText: B.default.t(1157),
                            onCancel: () => m.default.closeModal(),
                            cancelText: B.default.t(1518)
                        }, o.createElement(P.default, {
                            text: a
                        })))
                    }, this.onParticipantRemove = (e, t) => {
                        e.contact.pendingAction++, (0, j.removeParticipants)(this.props.chat, [e]).then((() => {
                            e.contact.pendingAction--
                        })), t && m.default.closeModal()
                    }, this._confirmParticipantPromote = e => {
                        var t = this.onParticipantPromote.bind(this, e, !0),
                            a = B.default.t(496, {
                                participant: e.contact.formattedName,
                                subject: this.props.contact.name
                            });
                        m.default.openModal(o.createElement(g.default, {
                            onOK: t,
                            okText: B.default.t(904),
                            onCancel: () => m.default.closeModal(),
                            cancelText: B.default.t(1518)
                        }, o.createElement(P.default, {
                            text: a
                        })))
                    }, this.onParticipantPromote = (e, t) => {
                        e.contact.pendingAction++, (0, j.promoteParticipants)(this.props.chat, [e]).then((() => {
                            e.contact.pendingAction--
                        })), t && m.default.closeModal()
                    }, this._openAddGroupParticipantFlow = () => {
                        var {
                            chat: e
                        } = this.props;
                        if (this.props.groupMetadata.participants.length >= te.default.maxParticipants) {
                            var t = B.default.t(90, {
                                max: te.default.maxParticipants
                            });
                            m.default.openToast(o.createElement(ue.default, {
                                msg: t,
                                id: Ee
                            }))
                        } else {
                            var a = D.default.supportsFeature(D.default.F.GROUPS_V_3) ? o.createElement(u.default, {
                                chat: (0, re.unproxy)(e),
                                pushTransition: "none",
                                popTransition: "none"
                            }) : o.createElement(c.default, {
                                chat: (0, re.unproxy)(e),
                                pushTransition: "none",
                                popTransition: "none"
                            });
                            m.default.openModal(a, {
                                transition: "modal-flow"
                            })
                        }
                    }, this._openParticpantSearch = () => {
                        m.default.openModal(o.createElement(w.default, {
                            chat: (0, re.unproxy)(this.props.chat),
                            onParticipantPromote: this.onParticipantPromote,
                            onParticipantRemove: this.onParticipantRemove,
                            onDemoteAdmin: this.onDemoteAdmin
                        }), {
                            transition: "modal-flow"
                        })
                    }, this.onClose = () => {
                        this.props.onClose ? this.props.onClose() : this.props.uim.uie.requestDismiss()
                    }, this._onExitOrDeleteGroup = () => {
                        m.default.deleteOrExitChat(this.props.chat)
                    }, this._onGroupDescChange = e => {
                        this.setState({
                            groupDesc: e
                        })
                    }, this._onSetSubject = function() {
                        var e = (0, r.default)((function*(e) {
                            var a = (0, y.default)(e);
                            a !== t.props.contact.name && (yield(0, ne.setGroupSubject)(t.props.chat, a).catchType(k.Unmount, (() => {})).catch((() => {
                                __LOG__(3)(ge())
                            })))
                        }));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }(), this._onSetDescription = () => {
                        var {
                            chat: e,
                            groupMetadata: t
                        } = this.props;
                        if (t.canSetDescription()) {
                            var a = this.state.groupDesc || "",
                                n = a.match(/\r\n/gm) ? "\r\n" : "\n",
                                i = new RegExp("^(".concat(n, "{2,})([^\n])"), "gm");
                            a = a.replace(i, "".concat(n, "$2"));
                            var s = (0, y.default)(a || "");
                            if (s === t.desc) return this.setState({
                                groupDesc: s
                            });
                            this.setState({
                                pendingDesc: !0
                            }), (0, ae.setGroupDesc)(e, s).then((() => {
                                this.setState({
                                    groupDesc: t.desc,
                                    pendingDesc: !1
                                })
                            })).catchType(k.Unmount, (() => {})).catch((() => {
                                __LOG__(3)(me()), this.setState({
                                    groupDesc: this.props.groupMetadata.desc,
                                    pendingDesc: !1
                                })
                            }))
                        }
                    }, this._onCancelDesc = () => {
                        this.setState({
                            groupDesc: this.props.groupMetadata.desc
                        })
                    }, this._showSecurityInfoPopup = () => {
                        m.default.openModal(o.createElement(N.default, {
                            chat: this.props.chat,
                            chatId: this.props.chat.id,
                            e2eSubtype: "info_encrypted"
                        }))
                    }, this.onShowMore = () => {
                        this.setState({
                            participantListCollapsed: !1
                        })
                    }, this._onShowMorePendingParticipants = () => {
                        this.setState({
                            pendingParticipantListCollapsed: !1
                        })
                    }, this.renderItem = e => {
                        var {
                            id: t
                        } = e, a = this.props.groupMetadata.participants.get(t);
                        if (!a) throw new A.UnknownDataError(e);
                        var n = a.contact,
                            i = !!this.state.contextMenu && fe.default.equals(n.id, this.state.contextMenu.contactId);
                        return o.createElement(K.default, {
                            contact: n,
                            participant: a,
                            key: a.id.toString(),
                            onClick: this.onParticipantClick,
                            contextEnabled: this._menuEnabled.bind(this, n),
                            contextMenu: i,
                            onContext: e => this.onParticipantMenu(e, n),
                            showNotifyName: !0,
                            waitIdle: !0
                        })
                    }, this.onReportSpam = () => {
                        m.default.openModal(o.createElement(J.default, {
                            isGroupChat: !0,
                            onReport: this.reportSpam,
                            onReportExitClear: this.reportSpamExitClear,
                            onCancel: () => m.default.closeModal()
                        }))
                    }, this.reportSpam = () => {
                        (0, ee.sendSpamReport)(this.props.chat), m.default.closeModal()
                    }, this.reportSpamExitClear = () => {
                        (0, ee.sendSpamExitClear)(this.props.chat), m.default.closeModal()
                    }, this._onDescriptionReadMore = () => {
                        this.setState({
                            descTruncated: !1
                        })
                    }, this._showEditRestrictionInfo = () => {
                        m.default.openModal(o.createElement(g.default, {
                            onOK: () => m.default.closeModal(),
                            okText: B.default.t(1680)
                        }, B.default.t(1081)))
                    }, this.revokeGrpV4Invite = e => {
                        m.default.openModal(o.createElement(g.default, {
                            onOK: () => {
                                m.default.closeModal(), this.props.groupMetadata.revokeGroupV4AddInvite([e.id.toString()]).then((() => {
                                    m.default.openToast(o.createElement(ue.default, {
                                        msg: B.default.t(1638),
                                        id: (0, ue.genId)()
                                    }))
                                }))
                            },
                            okText: B.default.t(1738),
                            onCancel: () => m.default.closeModal(),
                            cancelText: B.default.t(1518)
                        }, o.createElement(P.default, {
                            text: B.default.t(758, {
                                participant: e.contact.formattedName
                            })
                        })))
                    }, this._renderPendingParticipantItem = e => {
                        var {
                            id: t
                        } = e, a = this.props.groupMetadata.pendingParticipants.get(t);
                        if (!a) throw new A.UnknownDataError(e);
                        var n = a.contact;
                        return o.createElement(K.default, {
                            contact: n,
                            participant: a,
                            key: a.id.toString(),
                            contextEnabled: () => !0,
                            contextMenu: !0,
                            onContext: e => this._onPendingParticipantMenu(e, n),
                            showNotifyName: !0,
                            isPendingParticipant: !0,
                            waitIdle: !0
                        })
                    }, this._onPendingParticipantMenu = (e, t) => {
                        var a = this.props.groupMetadata.pendingParticipants.assertGet(t.id),
                            n = [o.createElement(b.default, {
                                a8n: "mi-grp-promote-admin",
                                key: "promote",
                                action: this.revokeGrpV4Invite.bind(this, a)
                            }, B.default.t(1194))];
                        e.event && e.event.persist(), this.setState({
                            contextMenu: {
                                contactId: t.id,
                                menu: n,
                                anchor: e.anchor,
                                event: e.event
                            }
                        })
                    };
                    var {
                        groupMetadata: {
                            desc: a,
                            participants: n,
                            pendingParticipants: i
                        },
                        showFullGroupDescription: s
                    } = this.props;
                    this.state = {
                        pendingDesc: !1,
                        pendingPhoto: !1,
                        contextMenu: null,
                        groupDraftSubject: null,
                        groupDesc: a,
                        descTruncated: !s && !!(a && a.length > 30),
                        participantListCollapsed: n.length > v.default.INFO_DRAWER_MAX_ROWS,
                        pendingParticipantListCollapsed: i.length > v.default.INFO_DRAWER_MAX_ROWS,
                        resetPhotoPicker: !1
                    }
                }
                componentDidMount() {
                    var e = this.props.groupMetadata;
                    D.default.supportsFeature(D.default.F.GROUPS_V_4_JOIN_PERMISSION) && e.queryGroupV4PendingInvite(), this.props.listeners.add(e.participants, "add remove reset sort change:isAdmin change:isSuperAdmin", (() => {
                        this.forceUpdate()
                    })), this.props.listeners.add(e.pendingParticipants, "add remove reset", (() => {
                        this.forceUpdate()
                    })), this.props.listeners.add(e, "change:desc", (() => {
                        this._updateGroupDescOnModelChange()
                    })), this.ensureParticipantsSorted()
                }
                componentDidUpdate() {
                    this.ensureParticipantsSorted()
                }
                ensureParticipantsSorted() {
                    this.props.groupMetadata.participants.ensureSorted(), this.props.groupMetadata.pendingParticipants.ensureSorted()
                }
                getData() {
                    var e, t = [],
                        a = [],
                        n = this.props.groupMetadata.participants;
                    n.forEach((n => {
                        n.contact.isMe ? e = n : n.isAdmin ? t.push(n) : a.push(n)
                    }));
                    var i = [];
                    return e && i.push(e), i = i.concat(t, a), n.length > v.default.INFO_DRAWER_MAX_ROWS && this.state.participantListCollapsed && (i = i.slice(0, v.default.INFO_DRAWER_MAX_ROWS)), i.map((e => ({
                        itemKey: e.id.toString(),
                        id: e.id
                    })))
                }
                _getPendingParticipantListData() {
                    var e = this.props.groupMetadata.pendingParticipants.toArray(),
                        t = [...e];
                    return e.length > v.default.INFO_DRAWER_MAX_ROWS && this.state.pendingParticipantListCollapsed && (t = t.slice(0, v.default.INFO_DRAWER_MAX_ROWS)), t.map((e => ({
                        itemKey: e.id.toString(),
                        id: e.id
                    })))
                }
                _getTitle() {
                    return te.default.productMediaAttachments ? B.default.t(897) : B.default.t(896)
                }
                render() {
                    var e, t, a, n, i, s, r, {
                            chat: l,
                            groupMetadata: c
                        } = this.props,
                        u = o.createElement(T.default, null, o.createElement(M.default, {
                            a8nText: "li-delete-group",
                            icon: o.createElement(oe.default, {
                                name: "exit",
                                directional: !0
                            }),
                            theme: "list-aligned",
                            color: "danger",
                            onClick: this._onExitOrDeleteGroup
                        }, l.isReadOnly ? B.default.t(1557) : B.default.t(1563)));
                    if (l.isReadOnly || (e = o.createElement(T.default, null, o.createElement(M.default, {
                            a8nText: "li-report-spam",
                            theme: "list-aligned",
                            color: "danger",
                            icon: o.createElement(oe.default, {
                                name: "thumbs-down",
                                directional: !0
                            }),
                            onClick: this.onReportSpam
                        }, B.default.t(1171)))), c.participants.canAdd() && !c.support) {
                        var p = o.createElement($.default, null, o.createElement(oe.default, {
                            name: "add-user",
                            directional: !0
                        }));
                        t = o.createElement(h.default, {
                            image: p,
                            theme: "drawer-list",
                            primary: B.default.t(207),
                            onClick: this._openAddGroupParticipantFlow
                        })
                    }
                    if (c.participants.iAmAdmin() && this.props.onGroupInviteLink && !c.support) {
                        var m = o.createElement($.default, null, o.createElement(oe.default, {
                            name: "link"
                        }));
                        a = o.createElement(h.default, {
                            image: m,
                            theme: "drawer-list",
                            primary: B.default.t(720),
                            onClick: this.props.onGroupInviteLink
                        })
                    }
                    if (c.participants.length > v.default.INFO_DRAWER_MAX_ROWS && this.state.participantListCollapsed) {
                        var g = c.participants.length - v.default.INFO_DRAWER_MAX_ROWS,
                            b = o.createElement($.default, {
                                theme: "transparent"
                            }, o.createElement(oe.default, {
                                name: "down"
                            }));
                        n = o.createElement(h.default, {
                            image: b,
                            theme: "drawer-list",
                            primary: B.default.t(746, {
                                count: g,
                                _plural: g
                            }),
                            onClick: this.onShowMore
                        })
                    }
                    if (c.pendingParticipants.length > v.default.INFO_DRAWER_MAX_ROWS && this.state.pendingParticipantListCollapsed) {
                        var N = c.pendingParticipants.length - v.default.INFO_DRAWER_MAX_ROWS,
                            P = o.createElement($.default, {
                                theme: "transparent"
                            }, o.createElement(oe.default, {
                                name: "down"
                            }));
                        i = o.createElement(h.default, {
                            image: P,
                            theme: "drawer-list",
                            primary: B.default.t(746, {
                                count: N,
                                _plural: N
                            }),
                            onClick: this._onShowMorePendingParticipants
                        })
                    }
                    if (c.pendingParticipants.length > 0 && (s = o.createElement(A.default, {
                            flatListController: this._pendingParticipantFlatListController,
                            direction: "vertical",
                            forceConsistentRenderCount: !1,
                            data: this._getPendingParticipantListData(),
                            renderItem: this._renderPendingParticipantItem
                        })), c.participants.iAmAdmin() && D.default.supportsFeature(D.default.F.GROUPS_V_3) && !c.support) {
                        var y = o.createElement(oe.default, {
                            className: x.default.chevron,
                            name: "chevron-right-alt",
                            directional: !0
                        });
                        r = o.createElement(_.default, {
                            onClick: this.props.onAdminSetting,
                            side: y
                        }, o.createElement(de.TextSpan, {
                            theme: "title"
                        }, B.default.t(744)))
                    }
                    var k, R = o.createElement(oe.default, {
                            name: "search",
                            className: x.default.iconSearch
                        }),
                        O = c.participants.length ? o.createElement(T.default, {
                            a8nText: "section-participants",
                            title: B.default.t(1682, {
                                count: c.participants.length,
                                _plural: c.participants.length
                            }),
                            titleOnClick: D.default.supportsFeature(D.default.F.GROUPS_V_3) ? this._openParticpantSearch : void 0,
                            subtitle: D.default.supportsFeature(D.default.F.GROUPS_V_3) ? R : void 0
                        }, t, a, o.createElement(A.default, {
                            flatListController: this._participantFlatListController,
                            direction: "vertical",
                            forceConsistentRenderCount: !1,
                            data: this.getData(),
                            renderItem: this.renderItem
                        }), n) : null;
                    c.participants.iAmAdmin() && c.pendingParticipants.length > 0 && (k = o.createElement(T.default, {
                        a8nText: "section-participants",
                        title: B.default.t(750, {
                            number: c.pendingParticipants.length
                        })
                    }, s, i));
                    var w = null;
                    if (this.props.onMediaGallery) {
                        var L = this.props.onMediaGallery,
                            V = o.createElement(oe.default, {
                                className: x.default.chevron,
                                name: "chevron-right-alt",
                                directional: !0
                            }),
                            j = this._getTitle();
                        w = o.createElement(T.default, {
                            a8nText: "section-media",
                            title: j,
                            titleOnClick: L,
                            subtitle: V,
                            theme: "padding"
                        }, o.createElement(H.default, {
                            chat: (0, re.unproxy)(l),
                            mediaMsgs: l.getMediaMsgs()
                        }))
                    }
                    var K = this.props.contact.profilePicThumb,
                        X = z.default.GROUP,
                        Q = l.isReadOnly || !K.canDelete() && !K.canSet() || l.isSupportGroup(),
                        J = o.createElement("div", {
                            className: x.default.avatar
                        }, o.createElement(Z.default, {
                            key: String(this.state.resetPhotoPicker),
                            type: X,
                            id: this.props.contact.id,
                            attachToChat: !0,
                            pending: this.state.pendingPhoto,
                            startImage: this.props.profilePicThumb.imgFull,
                            readOnly: Q,
                            onImageSet: this.onImageSet
                        })),
                        ee = null;
                    this.props.groupMetadata.creation && (ee = o.createElement("div", {
                        "data-a8n": d.default.key("group-created-time"),
                        className: x.default.nameSecondary
                    }, o.createElement(de.TextSpan, {
                        theme: "muted"
                    }, f.default.createdStr(this.props.groupMetadata.creation))));
                    var ae = null;
                    D.default.supportsFeature(D.default.F.LIVE_LOCATIONS) && (ae = o.createElement(W.default, {
                        chat: l,
                        onClick: this.props.onLiveLocation
                    }));
                    var ne = l && l.shouldShowEphemeralSetting() ? o.createElement(I.default, {
                            onClick: this.props.onEphemeral,
                            chat: l,
                            groupMetadata: c
                        }) : null,
                        se = null;
                    this.props.chat.isSupportGroup() && (se = o.createElement(le.default, {
                        onClick: this._showSecurityInfoPopup
                    }));
                    var ue, fe = l.mute.canMute() ? o.createElement(q.default, {
                            chat: l,
                            mute: l.mute,
                            settings: ie.default
                        }) : null,
                        me = null;
                    if (this.props.onStarred) {
                        var ge = o.createElement(oe.default, {
                            className: x.default.chevron,
                            name: "chevron-right-alt",
                            directional: !0
                        });
                        me = o.createElement(_.default, {
                            side: ge,
                            onClick: this.props.onStarred
                        }, o.createElement(de.TextSpan, {
                            theme: "title"
                        }, B.default.t(467)))
                    }
                    this.state.contextMenu && (ue = o.createElement(he.default, {
                        displayName: "ChatContextMenu",
                        escapable: !0,
                        popable: !0,
                        requestDismiss: this.closeContextMenu
                    }, o.createElement(pe.default, {
                        contextMenu: this.state.contextMenu
                    })));
                    var ve, Ee = null;
                    if ((fe || me || se || ne) && (Ee = o.createElement(T.default, null, fe, me, ne, se, r)), D.default.supportsFeature(D.default.F.GROUPS_V_3) && te.default.groupDescLength > 0) {
                        var _e = this.state.groupDesc || "",
                            Me = {
                                textLimit: this.state.descTruncated ? v.default.GROUP_DESCRIPTION_INFO_PANEL_TRUNC_LENGTH : 1 / 0,
                                readMoreText: B.default.t(1155),
                                onReadMore: this._onDescriptionReadMore,
                                formatters: this.props.chat.isTrusted() ? G.Configuration.TrustedGroupDesc({
                                    links: U.findLinks(_e)
                                }) : G.Configuration.UntrustedGroupDesc()
                            };
                        ve = o.createElement(T.default, {
                            theme: "group-desc-padding",
                            title: B.default.t(709)
                        }, o.createElement("div", {
                            className: x.default.description
                        }, o.createElement(ce.default, {
                            a8n: "group-info-drawer-description-title-input",
                            value: _e,
                            emptyValuePlaceholder: B.default.t(205),
                            renderEmojiTextInLockMode: Me,
                            editable: c.canSetDescription(),
                            pending: this.state.pendingDesc,
                            showRemaining: !0,
                            maxLength: te.default.groupDescLength,
                            onChange: this._onGroupDescChange,
                            onSave: this._onSetDescription,
                            onCancel: this._onCancelDesc,
                            multiline: !0,
                            editRestrictionInfo: c.restrict ? this._showEditRestrictionInfo : void 0,
                            supportsEmoji: !0,
                            lockable: !0,
                            lowProfile: !0,
                            customStyleThemes: [ce.TextInputCustomStyleThemes.groupInfoName],
                            theme: "small"
                        })))
                    }
                    return o.createElement(E.default, {
                        key: "contact-info-modal",
                        theme: "striped"
                    }, o.createElement(S.default, {
                        title: B.default.t(1591),
                        type: S.DRAWER_HEADER_TYPE.SMALL,
                        onCancel: this.onClose
                    }), o.createElement(C.default, {
                        flatListControllers: [this._pendingParticipantFlatListController, this._participantFlatListController]
                    }, o.createElement("section", {
                        className: x.default.body
                    }, null, o.createElement(T.default, {
                        theme: "padding-large"
                    }, J, c.support ? o.createElement(de.TextHeader, {
                        className: x.default.title,
                        level: "2",
                        theme: "large"
                    }, o.createElement(Y.GroupNameClass, {
                        chat: l,
                        groupMetadata: c
                    })) : o.createElement(Ce, {
                        subject: this.props.contact.name,
                        onSave: this._onSetSubject,
                        textInputProps: {
                            editable: c.canSetSubject(),
                            editRestrictionInfo: c.restrict ? this._showEditRestrictionInfo : void 0
                        }
                    }), ee, o.createElement(F.default, {
                        labels: l.labels
                    })), ve, ae, w, Ee, null, O, k, u, e)), ue)
                }
            }

            function Ce(e) {
                var [t, a] = o.useState(null), [n, i] = o.useState(!1), l = o.useRef(!1), d = function() {
                    var n = (0, r.default)((function*() {
                        if (!t || t === e.subject) return l.current = !1, void a(null);
                        i(!0);
                        try {
                            yield e.onSave(t)
                        } finally {
                            l.current = !1, a(null), i(!1)
                        }
                    }));
                    return function() {
                        return n.apply(this, arguments)
                    }
                }();
                return o.createElement(ce.default, (0, s.default)({
                    a8n: "group-info-drawer-subject-input",
                    value: null != t ? t : e.subject,
                    pending: n,
                    showRemaining: !0,
                    validate: e => !(!e || !e.trim()),
                    maxLength: te.default.maxSubject,
                    onBeginEdit: () => {
                        l.current = !0
                    },
                    onChange: e => {
                        l.current && a(e)
                    },
                    onSave: d,
                    onError: () => {
                        m.default.openModal(o.createElement(g.default, {
                            onOK: () => m.default.closeModal(),
                            okText: B.default.t(1680)
                        }, B.default.t(118)))
                    },
                    onCancel: () => {
                        l.current = !1, a(null)
                    },
                    supportsEmoji: !0,
                    lockable: !0,
                    lowProfile: !0,
                    theme: "large",
                    customStyleThemes: [ce.TextInputCustomStyleThemes.groupInfoName]
                }, e.textInputProps))
            }
            _e.CONCERNS = {
                chat: ["isReadOnly", "mute", "id", "pendingAction", "liveLocation", "labels"],
                groupMetadata: ["desc", "participants", "pendingParticipants", "creation", "restrict", "announce", "support"],
                contact: ["name", "id", "profilePicThumb", "pendingAction"],
                profilePicThumb: ["imgFull"]
            };
            var Me = (0, L.default)((0, Q.default)((0, V.default)((0, se.default)(_e, _e.CONCERNS))));
            t.default = Me
        },
        77142: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(43334)),
                l = n(a(79711)),
                o = n(a(77977)),
                d = n(a(71201)),
                c = a(95595),
                u = n(a(18120)),
                h = n(a(17957)),
                p = n(a(20642)),
                f = n(a(17693)),
                m = n(a(63498)),
                g = n(a(68384));
            class v extends s.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        contextMenu: null
                    }, this.openChat = e => {
                        r.default.find(e).then((e => {
                            l.default.closeModal(), l.default.openChatFromUnread(e)
                        }))
                    }, this.contextMenu = e => !g.default.equals((0, c.getMaybeMeUser)(), e), this.onParticipantMenu = (e, t) => {
                        var a = this.props.chat.groupMetadata.participants,
                            n = a.assertGet(t.id),
                            i = [];
                        if (a.canPromote(n)) {
                            var r = this.props.onParticipantPromote.bind(null, n, !1);
                            i.push(s.createElement(d.default, {
                                a8n: "mi-grp-promote-admin",
                                key: "promote",
                                action: r
                            }, h.default.t(904)))
                        }
                        if (a.canRemove(n)) {
                            var l = this.props.onParticipantRemove.bind(null, n, !1);
                            i.push(s.createElement(d.default, {
                                a8n: "mi-grp-remove-participant",
                                key: "remove",
                                action: l
                            }, h.default.t(908)))
                        }
                        if (u.default.supportsFeature(u.default.F.GROUPS_V_3) && a.canDemote(n)) {
                            var o = this.props.onDemoteAdmin.bind(this, n);
                            i.push(s.createElement(d.default, {
                                a8n: "mi-grp-verify-identify",
                                key: "demote-admin",
                                action: o
                            }, h.default.t(546)))
                        }
                        g.default.equals((0, c.getMaybeMeUser)(), n.id) || i.push(s.createElement(d.default, {
                            key: "message author",
                            action: this.openChat.bind(null, n.contact.id)
                        }, h.default.t(919, {
                            author: n.contact.formattedName
                        }))), e.anchor || e.event || e.persist(), this.setState({
                            contextMenu: {
                                contactId: t.id,
                                menu: i,
                                anchor: e.anchor,
                                event: e.anchor ? void 0 : e
                            }
                        })
                    }, this.closeContextMenu = () => {
                        this.setState({
                            contextMenu: null
                        })
                    }, this.contextEnabled = () => !1, this.cancel = () => {
                        l.default.closeModal()
                    }, this.isAdmin = e => this.props.chat.groupMetadata.participants.assertGet(e).isAdmin, this.contactFilter = e => !!this.props.chat.groupMetadata.participants.get(e.id)
                }
                componentDidMount() {
                    var e = this.props.chat.groupMetadata.participants;
                    this.props.listeners.add(e, "add remove reset", (() => {
                        this.forceUpdate()
                    }))
                }
                render() {
                    var e;
                    return this.state.contextMenu && (e = s.createElement(f.default, {
                        displayName: "ChatContextMenu",
                        escapable: !0,
                        popable: !0,
                        requestDismiss: this.closeContextMenu
                    }, s.createElement(m.default, {
                        contextMenu: this.state.contextMenu
                    }))), s.createElement(s.Fragment, null, s.createElement(o.default, {
                        title: h.default.t(1211),
                        filter: this.contactFilter,
                        onCancel: this.cancel,
                        openContextOnClick: !0,
                        contextEnabled: this.contextEnabled,
                        contextMenu: this.contextMenu,
                        onContext: this.onParticipantMenu,
                        showNotifyName: !0,
                        listenForAdminChange: !0,
                        participantCollection: this.props.chat.groupMetadata.participants
                    }), e)
                }
            }
            var E = (0, p.default)(v);
            t.default = E
        },
        19426: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(29036)),
                r = n(a(2784)),
                l = a(60846),
                o = i(a(79711)),
                d = i(a(50935)),
                c = i(a(58701)),
                u = i(a(67059)),
                h = i(a(73023)),
                p = n(a(71311)),
                f = i(a(77875)),
                m = a(95595),
                g = i(a(18120)),
                v = i(a(50739)),
                E = i(a(11780)),
                _ = i(a(98294)),
                C = i(a(17957)),
                M = i(a(20642)),
                S = a(45515),
                T = n(a(51079)),
                b = i(a(72424)),
                N = i(a(40207)),
                P = a(40263),
                y = i(a(68384)),
                I = ({
                    isRestricted: e,
                    onClick: t
                }) => r.createElement(u.default, {
                    onClick: t,
                    multiline: !0
                }, r.createElement("div", {
                    className: v.default.header
                }, r.createElement(P.TextSpan, {
                    theme: "title"
                }, C.default.t(736))), r.createElement(P.TextDiv, {
                    theme: "muted"
                }, e ? C.default.t(742) : C.default.t(735))),
                k = ({
                    isAnnouncement: e,
                    onClick: t
                }) => r.createElement(u.default, {
                    onClick: t,
                    multiline: !0
                }, r.createElement("div", {
                    className: v.default.header
                }, r.createElement(P.TextSpan, {
                    theme: "title"
                }, C.default.t(743))), r.createElement(P.TextDiv, {
                    theme: "muted"
                }, e ? C.default.t(742) : C.default.t(735))),
                A = ({
                    isNoFrequentlyForwarded: e,
                    onClick: t
                }) => {
                    var a = b.default.hfmStringChanges ? C.default.t(740) : C.default.t(739);
                    return r.createElement(u.default, {
                        onClick: t,
                        multiline: !0
                    }, r.createElement("div", {
                        className: v.default.header
                    }, r.createElement(P.TextSpan, {
                        theme: "title"
                    }, a)), r.createElement(P.TextDiv, {
                        theme: "muted"
                    }, e ? C.default.t(741) : C.default.t(738)))
                };
            class R extends r.Component {
                constructor(...e) {
                    super(...e), this._openSettingModal = e => {
                        var {
                            chat: t,
                            groupMetadata: a
                        } = this.props;
                        o.default.openModal(r.createElement(E.default, {
                            settingType: e,
                            chat: t,
                            groupMetadata: a
                        }), {
                            transition: "modal",
                            uim: this.props.uim
                        })
                    }, this._openAnnouncementSettingModal = () => {
                        this._openSettingModal(d.default.GROUP_SETTING_TYPE.ANNOUNCEMENT)
                    }, this._openRestrictedSettingModal = () => {
                        this._openSettingModal(d.default.GROUP_SETTING_TYPE.RESTRICT)
                    }, this._openNoFrequentlyForwardedSettingModal = () => {
                        this._openSettingModal(d.default.GROUP_SETTING_TYPE.NO_FREQUENTLY_FORWARDED)
                    }, this._getCurrentAdmins = () => {
                        var {
                            groupMetadata: e
                        } = this.props;
                        return e.participants.filter((e => e.isAdmin)).map((e => e.contact))
                    }, this._filterParticipants = e => {
                        var {
                            groupMetadata: t
                        } = this.props;
                        return !!t.participants.get(e.id)
                    }, this.isDisabled = e => {
                        var {
                            groupMetadata: t
                        } = this.props;
                        return y.default.equals(e, t.owner) || (0, m.getMaybeMeUser)().equals(e)
                    }, this._openManageAdminModal = () => {
                        o.default.openModal(r.createElement(T.default, {
                            onConfirm: this._updateAdmins,
                            getInitialItems: this._getCurrentAdmins,
                            isDisabled: this.isDisabled,
                            isSelected: this.isDisabled,
                            filter: this._filterParticipants,
                            title: C.default.t(882),
                            useShortName: !0,
                            useAllContacts: !0,
                            listType: T.ListType.PARTICIPANT_MANAGE_MODAL,
                            singleSelectionFooterType: l.FooterType.CONFIRM,
                            multipleSelectionFooterType: l.FooterType.CONFIRM
                        }))
                    }, this._updateAdmins = e => {
                        var {
                            chat: t,
                            groupMetadata: a
                        } = this.props, n = a.participants, i = n.filter((e => e.isAdmin)), r = (0, s.default)(e, i, ((e, t) => e.id.equals(t.id))).map((e => n.assertGet(e.id))), l = (0, s.default)(i, e, ((e, t) => e.id.equals(t.id)));
                        r.length > 0 && (r.forEach((e => {
                            e.contact.pendingAction++
                        })), (0, S.promoteParticipants)(t, r).finally((() => {
                            r.forEach((e => {
                                e.contact.pendingAction--
                            }))
                        }))), l.length > 0 && (l.forEach((e => {
                            e.contact.pendingAction++
                        })), (0, S.demoteParticipants)(t, l).finally((() => {
                            l.forEach((e => {
                                e.contact.pendingAction--
                            }))
                        }))), o.default.closeModal()
                    }
                }
                render() {
                    var {
                        groupMetadata: e
                    } = this.props;
                    return r.createElement(c.default, {
                        theme: "striped"
                    }, r.createElement(p.default, {
                        title: C.default.t(744),
                        type: p.DRAWER_HEADER_TYPE.SMALL,
                        onBack: this.props.onClose
                    }), r.createElement(h.default, null, r.createElement(f.default, {
                        animation: !1
                    }, r.createElement(I, {
                        onClick: this._openRestrictedSettingModal,
                        isRestricted: e.restrict
                    })), g.default.supportsFeature(g.default.F.EPHEMERAL_ALLOW_GROUP_MEMBERS) ? r.createElement("div", {
                        className: v.default.restrictText
                    }, r.createElement(P.TextSpan, {
                        theme: "muted"
                    }, C.default.t(564))) : null, r.createElement(f.default, {
                        animation: !1
                    }, r.createElement(k, {
                        onClick: this._openAnnouncementSettingModal,
                        isAnnouncement: e.announce
                    }), b.default.frequentlyForwardedGroupSetting && g.default.supportsFeature(g.default.F.FREQUENTLY_FORWARDED_SETTING) ? r.createElement(A, {
                        onClick: this._openNoFrequentlyForwardedSettingModal,
                        isNoFrequentlyForwarded: e.noFrequentlyForwarded
                    }) : null), r.createElement(f.default, {
                        animation: !1
                    }, r.createElement(u.default, {
                        onClick: this._openManageAdminModal,
                        multiline: !0
                    }, r.createElement("div", {
                        className: v.default.header
                    }, r.createElement(P.TextSpan, {
                        theme: "title"
                    }, C.default.t(882)))))))
                }
            }
            R.CONCERNS = {
                chat: ["id"],
                groupMetadata: ["restrict", "announce", "noFrequentlyForwarded", "participants", "owner"]
            };
            var O = (0, _.default)((0, M.default)((0, N.default)(R, R.CONCERNS)));
            t.default = O
        },
        11780: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(50935)),
                l = n(a(18120)),
                o = n(a(17957)),
                d = n(a(72424)),
                c = a(63590),
                u = n(a(60703)),
                h = n(a(40207));
            class p extends s.PureComponent {
                constructor(...e) {
                    super(...e), this._handleSelect = e => {
                        var {
                            chat: t,
                            settingType: a
                        } = this.props;
                        e !== this._getInitialValue() && (0, c.setGroupProperty)(t, a, e).catch((() => () => {}))
                    }
                }
                _getOptions() {
                    var {
                        settingType: e
                    } = this.props;
                    switch (e) {
                        case r.default.GROUP_SETTING_TYPE.ANNOUNCEMENT:
                        case r.default.GROUP_SETTING_TYPE.RESTRICT:
                            return [{
                                label: o.default.t(735),
                                value: 0
                            }, {
                                label: o.default.t(742),
                                value: 1
                            }];
                        case r.default.GROUP_SETTING_TYPE.NO_FREQUENTLY_FORWARDED:
                            return [{
                                label: o.default.t(738),
                                value: 0
                            }, {
                                label: o.default.t(741),
                                value: 1
                            }];
                        default:
                            return []
                    }
                }
                _getInitialValue() {
                    var {
                        settingType: e,
                        groupMetadata: t
                    } = this.props, {
                        restrict: a,
                        announce: n,
                        noFrequentlyForwarded: i
                    } = t;
                    switch (e) {
                        case r.default.GROUP_SETTING_TYPE.ANNOUNCEMENT:
                            return n ? 1 : 0;
                        case r.default.GROUP_SETTING_TYPE.RESTRICT:
                            return a ? 1 : 0;
                        case r.default.GROUP_SETTING_TYPE.NO_FREQUENTLY_FORWARDED:
                            return i ? 1 : 0;
                        default:
                            return 0
                    }
                }
                _getPopupTitle() {
                    var {
                        settingType: e
                    } = this.props;
                    switch (e) {
                        case r.default.GROUP_SETTING_TYPE.ANNOUNCEMENT:
                            return o.default.t(743);
                        case r.default.GROUP_SETTING_TYPE.RESTRICT:
                            return o.default.t(736);
                        case r.default.GROUP_SETTING_TYPE.NO_FREQUENTLY_FORWARDED:
                            return d.default.hfmStringChanges ? o.default.t(740) : o.default.t(739);
                        default:
                            return ""
                    }
                }
                _getExplanation() {
                    return this.props.settingType === r.default.GROUP_SETTING_TYPE.RESTRICT && l.default.supportsFeature(l.default.F.EPHEMERAL_ALLOW_GROUP_MEMBERS) ? o.default.t(564) : null
                }
                render() {
                    return s.createElement(u.default, {
                        options: this._getOptions(),
                        initialValue: this._getInitialValue(),
                        title: this._getPopupTitle(),
                        onSelect: this._handleSelect,
                        explanation: this._getExplanation()
                    })
                }
            }
            p.CONCERNS = {
                chat: ["id"],
                groupMetadata: ["restrict", "announce", "noFrequentlyForwarded"]
            };
            var f = (0, h.default)(p, p.CONCERNS);
            t.default = f
        },
        43282: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(77875)),
                l = n(a(17957)),
                o = n(a(20642)),
                d = n(a(84383)),
                c = a(57052),
                u = n(a(51908)),
                h = n(a(40207)),
                p = a(64658),
                f = n(a(82631)),
                m = a(40263);
            class g extends s.Component {
                constructor(e) {
                    super(e), this._updateParticipants = () => {
                        this.setState({
                            participants: this.getParticipants(this.props.chat)
                        })
                    }, this.state = {
                        participants: this.getParticipants(e.chat)
                    }
                }
                componentDidMount() {
                    var {
                        chat: e
                    } = this.props;
                    e.liveLocationQueried || d.default.getActive(e.id.toString()).then((() => {
                        e.liveLocationQueried = !0
                    })).catch((() => {})), this.props.listeners.add((0, p.unproxy)(e), "change:liveLocation", (() => {
                        var {
                            liveLocation: t
                        } = e;
                        t && (this._removeParticipantListener(t), this._addParticipantListener(t), this._updateParticipants())
                    }));
                    var {
                        liveLocation: t
                    } = e;
                    t && this._addParticipantListener(t)
                }
                _addParticipantListener(e) {
                    this.props.listeners.add(e.participants, "add remove", this._updateParticipants)
                }
                _removeParticipantListener(e) {
                    this.props.listeners.remove(e.participants, "add remove", this._updateParticipants)
                }
                getParticipants(e) {
                    var {
                        liveLocation: t
                    } = e;
                    return t ? t.participants.toArray() : []
                }
                getText() {
                    var e, t, {
                            chat: a
                        } = this.props,
                        {
                            participants: n
                        } = this.state,
                        i = 0;
                    if (n.forEach((a => {
                            a.isMe ? e = !0 : (t || (t = a.contact), i++)
                        })), a.isGroup) return e ? 1 === n.length ? l.default.t(855) : l.default.t(854, {
                        count: i,
                        _plural: i
                    }) : l.default.t(851, {
                        count: i,
                        _plural: i
                    });
                    if (e) {
                        if (1 === n.length) return l.default.t(855);
                        if (t) return l.default.t(853, {
                            name: t.formattedShortNameWithNonBreakingSpaces
                        })
                    } else if (t) return l.default.t(850, {
                        name: t.formattedShortNameWithNonBreakingSpaces
                    });
                    return ""
                }
                render() {
                    var {
                        onClick: e
                    } = this.props;
                    if (!this.state.participants.length) return null;
                    var t = s.createElement(f.default, {
                        name: (0, c.liveLocationIcon)(!0)
                    });
                    return s.createElement(r.default, {
                        a8nText: "section-live-location",
                        theme: "padding",
                        title: l.default.t(858),
                        titleOnClick: e
                    }, s.createElement(u.default, {
                        side: t,
                        onClick: e
                    }, s.createElement(m.TextSpan, {
                        theme: "title"
                    }, this.getText())))
                }
            }
            g.CONCERNS = {
                chat: ["id", "isGroup", "liveLocation", "liveLocationQueried"]
            };
            var v = (0, o.default)((0, h.default)(g, g.CONCERNS));
            t.default = v
        },
        47040: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.TABS = void 0;
            var s = i(a(98346)),
                r = i(a(72779)),
                l = n(a(2784)),
                o = a(12073),
                d = i(a(36938)),
                c = i(a(58701)),
                u = i(a(73023)),
                h = n(a(71311)),
                p = i(a(17957)),
                f = i(a(43620)),
                m = i(a(65824)),
                g = i(a(66558)),
                v = i(a(51465)),
                E = i(a(42913)),
                _ = i(a(61048)),
                C = i(a(72424)),
                M = i(a(17693)),
                S = i(a(74824)),
                T = {
                    MEDIA: "media",
                    DOCS: "docs",
                    LINKS: "links",
                    PRODUCTS: "products"
                };
            t.TABS = T;
            class b extends l.Component {
                constructor() {
                    super(...arguments), this.state = {
                        selected: this.props.initialTab,
                        direction: null,
                        selectable: !1
                    }, this.onSelectMessages = () => {
                        this.state.selectable || this.setState({
                            selectable: !0
                        })
                    }, this.onCancelSelection = () => {
                        this.state.selectable && (this.selectedMessages.unsetAll(), this.setState({
                            selectable: !1
                        }))
                    }, this.onMessageSelect = (e, t) => {
                        this.onSelectMessages(), this.selectedMessages.setVal(e, t), 0 === this.selectedMessages.getSelected().length && this.onCancelSelection()
                    }, this.selectedMessages = new E.default([], (e => e.id.toString()))
                }
                _onSelectTab(e) {
                    var t = (0, s.default)(T).indexOf(this.state.selected),
                        a = (0, s.default)(T).indexOf(e);
                    t !== a && this.selectedMessages.unsetAll();
                    var n = a > t ? "right" : "left";
                    this.setState({
                        selected: e,
                        direction: n,
                        selectable: !1
                    })
                }
                _getTabs() {
                    var e = [{
                        tab: T.MEDIA,
                        title: p.default.t(888)
                    }, {
                        tab: T.DOCS,
                        title: p.default.t(547)
                    }, {
                        tab: T.LINKS,
                        title: p.default.t(829)
                    }];
                    C.default.productMediaAttachments && e.push({
                        tab: T.PRODUCTS,
                        title: p.default.t(1147)
                    });
                    var t = e.map((e => {
                            var t = (0, r.default)(g.default.menuItem, {
                                [g.default.active]: this.state.selected === e.tab
                            });
                            return l.createElement("button", {
                                className: t,
                                onClick: this._onSelectTab.bind(this, e.tab),
                                key: e.tab,
                                title: e.title
                            }, e.title)
                        })),
                        a = (0, r.default)(g.default.menuTabsLists, C.default.productMediaAttachments ? g.default.fourTabs : g.default.threeTabs);
                    return l.createElement("div", {
                        className: a,
                        "data-active-tab": this.state.selected
                    }, t)
                }
                _getContent() {
                    var e, t = this.props.chat;
                    switch (this.state.selected) {
                        case T.MEDIA:
                            e = l.createElement(m.default, {
                                chat: t,
                                mediaMsgs: t.getMediaMsgs(),
                                selectable: this.state.selectable,
                                onMessageSelect: this.onMessageSelect,
                                selectedMessages: this.selectedMessages,
                                fullCollection: !0
                            });
                            break;
                        case T.LINKS:
                            e = l.createElement(f.default, {
                                chat: t,
                                linkMsgs: t.getLinkMsgs(),
                                selectable: this.state.selectable,
                                onMessageSelect: this.onMessageSelect,
                                selectedMessages: this.selectedMessages
                            });
                            break;
                        case T.DOCS:
                            e = l.createElement(d.default, {
                                chat: t,
                                docMsgs: t.getDocMsgs(),
                                selectable: this.state.selectable,
                                onMessageSelect: this.onMessageSelect,
                                selectedMessages: this.selectedMessages
                            });
                            break;
                        case T.PRODUCTS:
                            e = l.createElement(_.default, {
                                chat: t,
                                productMsgs: t.getProductMsgs(),
                                selectable: this.state.selectable,
                                onMessageSelect: this.onMessageSelect,
                                selectedMessages: this.selectedMessages,
                                onProductDetail: this.props.onProductDetail,
                                setScrollOffset: this.props.setProductsScrollOffset,
                                scrollOffset: this.props.productsScrollOffset
                            })
                    }
                    return e
                }
                render() {
                    var e = this.props.chat,
                        t = this._getTabs(),
                        a = this._getContent(),
                        n = [T.MEDIA, T.DOCS].includes(this.state.selected),
                        i = this.state.selectable ? l.createElement(M.default, {
                            displayName: "MediaMultiSelect",
                            escapable: !0,
                            requestDismiss: this.onCancelSelection
                        }, l.createElement(v.default, {
                            chat: e,
                            noSortOnForward: !0,
                            theme: "mediaGallery",
                            toastPosition: o.ToastPosition.RIGHT,
                            downloadButton: n,
                            selectedMessages: this.selectedMessages,
                            onCancel: this.onCancelSelection
                        })) : null,
                        s = "right" === this.state.direction ? "slide-forward" : "slide-back";
                    return l.createElement(c.default, {
                        theme: "gallery"
                    }, l.createElement(h.default, {
                        title: " ",
                        onBack: this.props.onBack,
                        type: h.DRAWER_HEADER_TYPE.MULTI_MEDIA_GALLERY
                    }), i, t, l.createElement(u.default, {
                        "data-list-scroll-container": !0
                    }, l.createElement(S.default, {
                        transitionName: s,
                        className: g.default.column
                    }, l.createElement("div", {
                        className: g.default.multimediaGallery,
                        key: this.state.selected
                    }, l.createElement("div", {
                        className: g.default.column
                    }, a)))))
                }
            }
            t.default = b, b.defaultProps = {
                initialTab: T.MEDIA,
                productsScrollOffset: 0
            }
        },
        42844: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(72779)),
                r = n(a(2784)),
                l = i(a(18984)),
                o = i(a(17957)),
                d = i(a(47665)),
                c = i(a(19125)),
                u = i(a(40207));
            class h extends r.PureComponent {
                constructor(...e) {
                    super(...e), this.stopPropagation = e => {
                        e.stopPropagation()
                    }, this._renderAudioTag = e => r.createElement(l.default, {
                        url: e,
                        className: d.default.mediaViewerAudio,
                        onClick: this.stopPropagation,
                        autoPlay: !0,
                        controls: !0
                    }, o.default.t(239)), this._renderPlaceholder = () => r.createElement("div", {
                        className: (0, s.default)(d.default.imageAudio, d.default.mediaViewerPlaceholder),
                        onClick: this.stopPropagation
                    })
                }
                render() {
                    var {
                        mediaData: e
                    } = this.props;
                    return r.createElement(c.default, {
                        mediaData: e,
                        placeholderRenderer: this._renderPlaceholder
                    }, this._renderAudioTag)
                }
            }
            h.CONCERNS = {
                mediaData: ["mediaStage", "renderableUrl"]
            };
            var p = (0, u.default)(h, h.CONCERNS);
            t.default = p
        },
        35795: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(96066)),
                l = n(a(19899)),
                o = n(a(46478)),
                d = i(a(14457)),
                c = n(a(71201)),
                u = n(a(91581)),
                h = n(a(17957)),
                p = n(a(8603)),
                f = n(a(20434)),
                m = a(80898),
                g = n(a(40207)),
                v = n(a(82631));
            class E extends s.PureComponent {
                constructor(...e) {
                    super(...e), this._getMenuBtns = () => this.props.msgIndexInAlbum >= 0 ? this._getAlbumMediaMenuBtns() : this._getNonAlbumMediaMenuBtns(), this._getNonAlbumMediaMenuBtns = () => {
                        var {
                            msg: e
                        } = this.props;
                        return [e.isViewOnce ? null : s.createElement(m.MenuBarItem, {
                            key: "btnGoToMsg",
                            icon: s.createElement(v.default, {
                                name: "bubble"
                            }),
                            title: h.default.t(702),
                            onClick: this.props.onGoToMsgClick
                        }), e.canStar() ? this._getStarMenuBarItem() : null, e.canForward() ? this._getForwardMenuBarItem() : null, e.isViewOnce ? null : s.createElement(m.MenuBarItem, {
                            key: "btnDownload",
                            icon: s.createElement(v.default, {
                                name: "download"
                            }),
                            title: h.default.t(1514),
                            disabled: !this._isMediaDownloadable(),
                            onClick: this.props.onDownloadClick
                        })].filter(Boolean)
                    }, this._getAlbumMediaMenuBtns = () => {
                        var {
                            msg: e
                        } = this.props;
                        return [e.canReply() ? s.createElement(m.MenuBarItem, {
                            key: "btnReply",
                            icon: s.createElement(v.default, {
                                name: "reply"
                            }),
                            title: h.default.t(1162),
                            onClick: this.props.onReplyClick
                        }) : null, e.canStar() ? this._getStarMenuBarItem() : null, s.createElement(m.MenuBarItem, {
                            key: "btnDelete",
                            icon: s.createElement(v.default, {
                                name: "delete"
                            }),
                            title: h.default.t(1556),
                            onClick: this.props.onDeleteClick
                        }), e.canForward() ? this._getForwardMenuBarItem() : null, this._getDropdownMenuBarItem()].filter(Boolean)
                    }, this._getStarMenuBarItem = () => {
                        var e, t, a, {
                            msg: n
                        } = this.props;
                        return n.star ? (e = this.props.onUnstarClick, t = "unstar-btn", a = h.default.t(1347)) : (e = this.props.onStarClick, t = "star-btn", a = h.default.t(1269)), s.createElement(m.MenuBarItem, {
                            key: t,
                            icon: s.createElement(v.default, {
                                name: t
                            }),
                            title: a,
                            onClick: e
                        })
                    }, this._getForwardMenuBarItem = () => s.createElement(m.MenuBarItem, {
                        key: "btnForward",
                        icon: s.createElement(v.default, {
                            name: "forward"
                        }),
                        title: h.default.t(662),
                        onClick: this.props.openForwardFlow
                    }), this._getDropdownMenuBarItem = () => {
                        var {
                            msg: e
                        } = this.props, t = [];
                        return e.isSentByMe && t.push(s.createElement(c.default, {
                            key: "dropdownMsgInfo",
                            action: this.props.onMsgInfoClick
                        }, h.default.t(923))), t.push(s.createElement(c.default, {
                            key: "dropdownGoToMsg",
                            action: this.props.onGoToMsgClick
                        }, h.default.t(702)), s.createElement(c.default, {
                            key: "dropdownDownload",
                            action: this.props.onDownloadClick,
                            disabled: !this._isMediaDownloadable()
                        }, h.default.t(1514))), s.createElement(m.MenuBarItem, {
                            key: "btnMenu",
                            icon: s.createElement(v.default, {
                                name: "menu"
                            }),
                            title: h.default.t(915)
                        }, s.createElement(d.default, {
                            type: "dropdown_menu",
                            key: "MediaPanelHeaderDropdown",
                            flipOnRTL: !0,
                            dirX: d.DirX.LEFT
                        }, t))
                    }, this._isMediaDownloadable = () => {
                        var {
                            mediaData: e,
                            msg: t
                        } = this.props;
                        return !t.isViewOnce && (!!e.renderableUrl || e.mediaStage === p.default.STAGE.RESOLVED)
                    }
                }
                render() {
                    var e = this.props.msg,
                        t = e.displayName(!0, !0);
                    return e.isGroupMsg && (t += " @ " + e.chat.title()), s.createElement("div", {
                        className: f.default.mediaPanelHeader
                    }, s.createElement("div", {
                        className: f.default.info
                    }, s.createElement(r.default, {
                        idle: !0,
                        image: s.createElement(o.default, {
                            id: e.sender,
                            size: 40
                        }),
                        primary: s.createElement(u.default, {
                            ellipsify: !0,
                            text: t
                        }),
                        secondary: l.default.relativeDateAndTimeStr(e.t),
                        theme: "media"
                    })), s.createElement("div", {
                        className: f.default.mediaPanelTools
                    }, s.createElement(m.MenuBar, {
                        key: "media-panel-header",
                        theme: "strong"
                    }, this._getMenuBtns(), s.createElement(m.MenuBarItem, {
                        a8nText: "btn-close",
                        icon: s.createElement(v.default, {
                            name: "x-viewer"
                        }),
                        title: h.default.t(1529),
                        onClick: this.props.onClose
                    }))))
                }
            }
            E.CONCERNS = {
                msg: ["star", "isGroupMsg", "chat", "type", "isGif", "isViewOnce", "sender", "t", "isSentByMe"],
                mediaData: ["filehash", "mediaStage", "renderableUrl"]
            };
            var _ = (0, g.default)(E, E.CONCERNS);
            t.default = _
        },
        5751: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(43596)),
                l = n(a(34854)),
                o = a(72292),
                d = a(47025),
                c = n(a(17957)),
                u = n(a(8603)),
                h = n(a(79850)),
                p = n(a(40210)),
                f = n(a(41885)),
                m = n(a(88352)),
                g = n(a(40207)),
                v = n(a(15668));
            class E extends s.PureComponent {
                constructor(...e) {
                    super(...e), this.state = {
                        played: !1,
                        size: {
                            width: 0,
                            height: 0
                        },
                        isFullscreenMode: !1
                    }, this._setRefContainer = e => {
                        this.refContainer = e
                    }, this.stopPropagation = e => {
                        e.stopPropagation()
                    }, this._handleFullscreenToggle = e => {
                        this.setState({
                            isFullscreenMode: e
                        })
                    }
                }
                static getDerivedStateFromProps(e) {
                    var {
                        mediaData: t
                    } = e;
                    return (t.mediaStage === u.default.STAGE.RESOLVED || t.streamable && t.isStreamable()) && t.fullWidth && t.fullHeight ? {
                        size: E.getSize(t)
                    } : null
                }
                static getSize(e) {
                    if (e.isGif) {
                        return e.fullWidth >= 330 ? {
                            width: e.fullWidth,
                            height: e.fullHeight
                        } : {
                            width: 330,
                            height: 330 * e.fullHeight / e.fullWidth
                        }
                    }
                    return e.fullWidth >= d.MIN_WIDTH ? {
                        width: e.fullWidth,
                        height: e.fullHeight
                    } : {
                        width: d.MIN_WIDTH,
                        height: e.fullHeight
                    }
                }
                componentDidMount() {
                    this.props.mediaData.isStreamable() || this.props.msg.downloadMedia({
                        downloadEvenIfExpensive: !0,
                        rmrReason: p.default.WEBC_RMR_REASON_CODE.MEDIA_VIEWER,
                        isUserInitiated: !0
                    })
                }
                componentWillUnmount() {
                    this.props.msg.mediaObject && this.props.msg.cancelDownload()
                }
                render() {
                    var e, {
                            msg: t,
                            mediaData: a
                        } = this.props,
                        n = a.isGif,
                        i = a.mediaStage === u.default.STAGE.RESOLVED || a.streamable && a.isStreamable();
                    if (i = i || t.isForcingRMR()) {
                        var d, p, g = c.default.t(1392);
                        return !this.state.isFullscreenMode && t && t.interactiveAnnotations && t.interactiveAnnotations.length > 0 && (d = s.createElement(r.default, {
                            annotations: t.interactiveAnnotations
                        })), p = n ? s.createElement("div", {
                            className: h.default.mediaViewerImg,
                            ref: this._setRefContainer
                        }, s.createElement(v.default, {
                            src: a.renderableUrl,
                            onClick: this.stopPropagation,
                            autoPlay: !0,
                            loop: !0
                        }, g), d) : s.createElement("div", {
                            ref: this._setRefContainer,
                            className: h.default.mediaViewerImg,
                            onClick: this.stopPropagation
                        }, s.createElement(f.default, {
                            msg: t,
                            mediaData: a,
                            startTime: this.props.startTime,
                            onClose: this.props.onClose,
                            onError: () => {},
                            onFullscreenToggle: this._handleFullscreenToggle,
                            autoPlay: !0,
                            type: o.PLAYER_TYPE.MEDIA_VIEWER,
                            overlays: d,
                            noPip: t.isViewOnce
                        })), s.createElement(m.default, {
                            type: "scaleDown",
                            position: "relative",
                            objectPosition: "relative",
                            size: this.state.size,
                            onObjectLoad: this.props.onLoad
                        }, p)
                    }
                    return s.createElement(l.default, {
                        altText: null !== (e = t.caption) && void 0 !== e ? e : "",
                        mediaData: a
                    })
                }
            }
            E.CONCERNS = {
                mediaData: ["mediaStage", "fullWidth", "fullHeight", "isGif", "isViewOnce", "preview", "renderableUrl", "streamable"]
            }, E.defaultProps = {
                startTime: 0
            };
            var _ = (0, g.default)(E, E.CONCERNS);
            t.default = class extends _ {
                getContainerElement() {
                    return this.getComponent().refContainer
                }
            }
        },
        22807: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(19976)),
                r = i(a(12436)),
                l = i(a(72779)),
                o = a(91460),
                d = n(a(2784)),
                c = n(a(60519)),
                u = i(a(79711)),
                h = i(a(53388)),
                p = i(a(9386)),
                f = i(a(50935)),
                m = i(a(55236)),
                g = i(a(91581)),
                v = i(a(27352)),
                E = i(a(93329)),
                _ = a(13414),
                C = a(62902),
                M = i(a(17957)),
                S = a(55488),
                T = i(a(42844)),
                b = i(a(8603)),
                N = i(a(61195)),
                P = i(a(35795)),
                y = i(a(13934)),
                I = i(a(5751)),
                k = i(a(45864)),
                A = a(94461),
                R = i(a(40207)),
                O = a(64658),
                D = a(11419),
                x = i(a(17693)),
                w = i(a(91378));

            function L() {
                var e = (0, s.default)(["type: ", ""]);
                return L = function() {
                    return e
                }, e
            }

            function G(e) {
                null == e || e.stopPropagation()
            }

            function F(e) {
                var t = e.chat;
                t.composeQuotedMsg = e, u.default.focusChatTextInput(t)
            }
            class B extends d.PureComponent {
                constructor(e) {
                    super(e), this._setRefMediaImage = e => {
                        this._refMediaImage = e
                    }, this._setRefMediaVideo = e => {
                        this._refMediaVideo = e
                    }, this.onImageLoad = e => {
                        this.props.onImageLoad && this.props.onImageLoad();
                        var t = this.state.zoomElement;
                        t && e && this.props.isAnimatingIn && e instanceof HTMLElement && (this.zoomed || (this.zoomed = !0, this.animateZoom(t, e)))
                    }, this.animateZoom = (e, t) => {
                        var a, n = t.getBoundingClientRect(),
                            i = e.getBoundingClientRect(),
                            s = i.top - n.top,
                            r = i.left - n.left,
                            l = e.clientWidth / t.clientWidth;
                        s -= (t.clientHeight - e.clientHeight) / 2, r -= (t.clientWidth - e.clientWidth) / 2, (0, w.default)(t, {
                            opacity: [1, 0],
                            translateX: [0, r],
                            translateY: [0, s],
                            scale: [1, l]
                        }, {
                            duration: f.default.MEDIA_VIEWER.ANIMATION_DURATION,
                            easing: [.1, .82, .25, 1]
                        });
                        var o = null === (a = this._refCaption) || void 0 === a ? void 0 : a.getContainerElement();
                        o && (0, w.default)(o, {
                            opacity: [1, 0]
                        }, {
                            duration: f.default.MEDIA_VIEWER.ANIMATION_DURATION
                        })
                    }, this.openForwardFlow = e => {
                        e.stopPropagation();
                        var {
                            msg: t
                        } = this.props;
                        t.isUnsentMedia ? u.default.openModal(d.createElement(p.default, {
                            title: M.default.t(649),
                            onOK: () => u.default.closeModal(),
                            okText: M.default.t(1680)
                        }, M.default.t(646))) : u.default.openModal(d.createElement(E.default, {
                            msgs: [(0, O.unproxy)(t)]
                        }), {
                            transition: "modal-flow"
                        })
                    }, this.onReplyClick = () => {
                        this.onClose(), (0, o.delayMs)(f.default.MEDIA_VIEWER.CLOSE_ANIMATION_DURATION).then(F.bind(null, (0, O.unproxy)(this.props.msg)))
                    }, this.onDeleteClick = () => {
                        var {
                            msg: e
                        } = this.props;
                        u.default.openModal(d.createElement(m.default, {
                            chat: e.chat,
                            msgList: [(0, O.unproxy)(e)],
                            deletePrompt: !0,
                            revokePrompt: e.canRevoke()
                        }))
                    }, this.onMsgInfoClick = () => {
                        this.onClose(), (0, o.delayMs)(f.default.MEDIA_VIEWER.CLOSE_ANIMATION_DURATION + 250).then(u.default.msgInfoDrawer.bind(u.default, (0, O.unproxy)(this.props.msg)))
                    }, this.onScroll = e => {
                        Math.abs(e.deltaY) > 7 && this.onClose()
                    }, this.onImgZoomIn = e => {
                        var t = this._refMediaImage;
                        e && t && (this.listenToMouseMove = t.heightOverflow > 0 || t.widthOverflow > 0), this.setState({
                            imgZoomed: e
                        }), this.props.onImgZoomIn(e)
                    }, this.onZoomOut = e => {
                        this.handleMouseMove.cancel();
                        var t = this._refMediaImage;
                        t && this.state.imgZoomed && t.onImageClick(e)
                    }, this.onMouseMove = e => {
                        this.handleMouseMove(e.pageX, e.pageY)
                    }, this._handleMouseMove = (e, t) => {
                        if (!this.state.annotationTooltipDisplayed) {
                            var a = this._refMediaImage;
                            if (a) {
                                var n = a.getInsideContainer();
                                if (n && n instanceof HTMLElement) {
                                    var i = a.getOutsideContainer();
                                    if (i && i instanceof HTMLElement) {
                                        var {
                                            translateX: s,
                                            translateY: r
                                        } = a.getTranslatePosition(i, e, t);
                                        (0, w.default)(n, "stop"), (0, w.default)(n, {
                                            translateX: s,
                                            translateY: r,
                                            scale: f.default.MEDIA_VIEWER.ZOOM_IN_FACTOR
                                        }, {
                                            duration: 0
                                        })
                                    }
                                }
                            }
                        }
                    }, this.onDownloadClick = e => {
                        e.stopPropagation(), v.default.initDownload((0, O.unproxy)(this.props.msg))
                    }, this.onStarClick = e => {
                        e.stopPropagation();
                        var {
                            msg: t
                        } = this.props;
                        u.default.sendStarMsgs(t.chat, [(0, O.unproxy)(t)])
                    }, this.onUnstarClick = e => {
                        e.stopPropagation();
                        var {
                            msg: t
                        } = this.props;
                        u.default.sendUnstarMsgs(t.chat, [(0, O.unproxy)(t)])
                    }, this.onGoToMsgClick = e => {
                        e.stopPropagation(), this.onClose(), u.default.existsDrawerRight((e => {
                            e && 2 === h.default.column && u.default.closeDrawerRight()
                        }));
                        var {
                            msg: t
                        } = this.props, a = t.chat.getSearchContext((0, O.unproxy)(t));
                        u.default.openChatAt(t.chat, a).then((e => {
                            e && u.default.focusChatTextInput(t.chat)
                        }))
                    }, this.onClose = () => {
                        if (!this.closing) {
                            this.closing = !0, (0, D.isFunction)(this.props.onExitAnimation) && this.props.onExitAnimation();
                            var e, t = this.props.getZoomNode && this.props.getZoomNode(this.props.msg.id);
                            if (!t) return this.props.onBack();
                            if (this.props.mediaData.type === b.default.TYPE.IMAGE && this._refMediaImage ? e = this._refMediaImage.getInsideContainer() : this.props.mediaData.isGif && this._refMediaVideo && (e = this._refMediaVideo.getContainerElement()), !e) return this.props.onBack();
                            var a, n = e,
                                i = e.getBoundingClientRect(),
                                s = t.getBoundingClientRect(),
                                r = s.top - i.top,
                                l = s.left - i.left,
                                o = t.clientWidth / n.clientWidth;
                            r -= (n.clientHeight - t.clientHeight) / 2, l -= (n.clientWidth - t.clientWidth) / 2, (0, w.default)(e, {
                                translateX: [l, 0],
                                translateY: [r, 0],
                                scale: [o, 1]
                            }, {
                                duration: f.default.MEDIA_VIEWER.CLOSE_ANIMATION_DURATION,
                                easing: [.1, .82, .25, 1]
                            }).then((() => {
                                this.props.onBack()
                            }));
                            var d = null === (a = this._refCaption) || void 0 === a ? void 0 : a.getContainerElement();
                            d && (0, w.default)(d, {
                                opacity: [0, 1]
                            }, {
                                duration: f.default.MEDIA_VIEWER.CLOSE_ANIMATION_DURATION,
                                easing: [.1, .82, .25, 1]
                            })
                        }
                    }, this.onAnnotationTooltipDisplay = () => this.setState({
                        annotationTooltipDisplayed: !0
                    }), this.onAnnotationTooltipDismiss = () => this.setState({
                        annotationTooltipDisplayed: !1
                    }), this.zoomed = !1, this.closing = !1, this.listenToMouseMove = !1;
                    var t = e.mediaData.mediaStage === b.default.STAGE.RESOLVED && e.isAnimatingIn && e.getZoomNode ? e.getZoomNode(e.msg.id) : null;
                    this.state = {
                        zoomElement: t,
                        imgZoomed: !1,
                        annotationTooltipDisplayed: !1,
                        isCaptionVisible: !e.isAnimatingIn
                    }, this.handleMouseMove = (0, r.default)(this._handleMouseMove)
                }
                componentDidMount() {
                    var {
                        msg: e
                    } = this.props;
                    e.isViewOnce && (0, S.canMarkPlayed)(e) && (0, S.markPlayed)(e)
                }
                componentDidUpdate(e) {
                    var {
                        isCaptionVisible: t
                    } = this.state, {
                        isAnimatingIn: a
                    } = this.props;
                    a || t || !e.isAnimatingIn || this.setState({
                        isCaptionVisible: !0
                    })
                }
                componentWillUnmount() {
                    this.handleMouseMove.cancel()
                }
                render() {
                    var e, t, a, n, i, s, {
                        msg: r,
                        mediaData: o
                    } = this.props;
                    switch (o.type) {
                        case b.default.TYPE.IMAGE:
                            i = d.createElement(N.default, {
                                key: r.id.toString(),
                                msg: r,
                                mediaData: o,
                                onLoad: this.onImageLoad,
                                onImgZoomIn: this.onImgZoomIn,
                                onAnnotationTooltipDisplay: this.onAnnotationTooltipDisplay,
                                onAnnotationTooltipDismiss: this.onAnnotationTooltipDismiss,
                                preventDownload: r.isViewOnce,
                                ref: this._setRefMediaImage
                            });
                            break;
                        case b.default.TYPE.VIDEO:
                            i = d.createElement(I.default, {
                                key: r.id.toString(),
                                msg: r,
                                mediaData: o,
                                onLoad: o.isGif ? this.onImageLoad : null,
                                startTime: this.props.startTime,
                                onClose: this.onClose,
                                ref: this._setRefMediaVideo
                            });
                            break;
                        case b.default.TYPE.AUDIO:
                            i = d.createElement(T.default, {
                                mediaData: o,
                                key: r.id.toString()
                            });
                            break;
                        default:
                            __LOG__(4, void 0, new Error, !0)(L(), o.type), SEND_LOGS("MediaViewerModal: unexpected media type")
                    }
                    var u = this.props.msgIndexInAlbum >= 0 && this.props.albumSize >= 0;
                    if (r.caption || u) {
                        var h;
                        if (u) {
                            var p = {
                                number: this.props.msgIndexInAlbum + 1,
                                totalNumber: this.props.albumSize
                            };
                            h = M.default.t(1074, p)
                        }
                        var f = C.Configuration.Conversation({
                                mentions: r.mentionMap(),
                                links: r.getLinks(),
                                trusted: !0
                            }),
                            m = !this.state.isCaptionVisible && (o.isGif || o.type === b.default.TYPE.IMAGE),
                            v = (0, l.default)(k.default.mediaCaption, {
                                [k.default.captionHidden]: m
                            });
                        s = d.createElement(g.default, {
                            className: v,
                            formatters: f,
                            ref: (0, _.GetRef)((e => {
                                this._refCaption = e
                            })),
                            text: r.caption || h
                        })
                    }
                    var E = (0, l.default)(k.default.media, {
                            [k.default.mediaWithCaption]: !!s
                        }),
                        S = (0, l.default)("overlay", k.default.mediaViewer, {
                            [k.default.viewOnce]: r.isViewOnce,
                            [k.default.mediaViewerAnimate]: this.props.isAnimatingIn,
                            [k.default.cursorZoomOut]: this.state.imgZoomed
                        }),
                        R = this.state.imgZoomed && this.listenToMouseMove ? this.onMouseMove : null,
                        O = this.state.imgZoomed ? this.onZoomOut : null,
                        D = r.isViewOnce || this.state.imgZoomed ? null : this.onScroll;
                    return d.createElement(x.default, {
                        displayName: "MediaViewer",
                        escapable: !0,
                        requestDismiss: this.onClose
                    }, d.createElement("div", {
                        className: S,
                        "data-animate-media-viewer": !0,
                        onClick: O,
                        onMouseMove: R,
                        onWheel: D
                    }, d.createElement(P.default, {
                        msg: r,
                        mediaData: o,
                        onGoToMsgClick: this.onGoToMsgClick,
                        onReplyClick: this.onReplyClick,
                        onUnstarClick: this.onUnstarClick,
                        onStarClick: this.onStarClick,
                        onDeleteClick: this.onDeleteClick,
                        openForwardFlow: this.openForwardFlow,
                        onDownloadClick: this.onDownloadClick,
                        onMsgInfoClick: this.onMsgInfoClick,
                        onClose: this.onClose,
                        msgIndexInAlbum: this.props.msgIndexInAlbum
                    }), d.createElement("div", {
                        className: k.default.mediaContent,
                        onClick: this.state.imgZoomed ? null : this.onClose
                    }, !r.isViewOnce && d.createElement("div", {
                        className: (0, l.default)(k.default.btnMediaPrev)
                    }, d.createElement(c.default, {
                        type: c.ButtonType.Prev,
                        onClick: null !== (e = this.props.onPrev) && void 0 !== e ? e : G,
                        onKeyDown: null !== (t = this.props.onPrev) && void 0 !== t ? t : G,
                        disabled: !this.props.onPrev || this.state.imgZoomed,
                        theme: A.RoundTheme.Default
                    })), d.createElement("div", {
                        className: E
                    }, d.createElement(y.default, {
                        msg: r,
                        mediaData: o
                    }), i, s), !r.isViewOnce && d.createElement("div", {
                        className: (0, l.default)(k.default.btnMediaNext)
                    }, d.createElement(c.default, {
                        type: c.ButtonType.Next,
                        onClick: null !== (a = this.props.onNext) && void 0 !== a ? a : G,
                        onKeyDown: null !== (n = this.props.onNext) && void 0 !== n ? n : G,
                        disabled: !this.props.onNext || this.state.imgZoomed,
                        theme: A.RoundTheme.Default
                    })))))
                }
            }
            B.CONCERNS = {
                msg: ["id", "star", "isUnsentMedia", "isViewOnce", "chat", "caption", "interactiveAnnotations"],
                mediaData: ["mediaStage", "type", "isGif"]
            };
            var U = (0, R.default)(B, B.CONCERNS);
            t.default = U
        },
        85352: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(19976)),
                r = i(a(12436)),
                l = n(a(2784)),
                o = i(a(44661)),
                d = i(a(83541)),
                c = i(a(68421)),
                u = i(a(2825));

            function h() {
                var e = (0, s.default)(["MediaViewerFlow: attempted to render a msg without mediaData: ", ""]);
                return h = function() {
                    return e
                }, e
            }
            class p extends l.Component {
                constructor(e) {
                    super(e), this._setThumbRef = (e, t) => {
                        this._thumbRefs[t] = e
                    }, this._isPreviewPreferred = e => {
                        var t = this._thumbRefs[e];
                        if (!t) return !1;
                        var a = t.getBoundingClientRect(),
                            n = (a.left + a.right) / 2;
                        return !(n > -1 * window.innerWidth && n < 2 * window.innerWidth)
                    }, this._getMsgIdToPreferPreview = () => {
                        var e = new Map;
                        return this.props.mediaMsgs.forEach((t => {
                            var a = t.id.toString();
                            e.set(a, this._isPreviewPreferred(a))
                        })), e
                    }, this.onScroll = e => {
                        this.handleScroll(), this.props.onScroll(e)
                    }, this._handleScroll = () => {
                        var e = this._getMsgIdToPreferPreview();
                        (0, o.default)(this.state.msgIdToPreferPreview, e) || this.setState({
                            msgIdToPreferPreview: e
                        })
                    }, this.getThumbs = () => {
                        var {
                            highlightedMsgIds: e
                        } = this.props, t = e && e.size > 0 && e.has(this.props.activeMsg.id.toString()), a = [];
                        return this.props.mediaMsgs.forEach((n => {
                            if (null != n.mediaData) {
                                var i = t && e && !e.has(n.id.toString()) ? "viewerFlowTransparent" : "viewerFlow";
                                a.push(l.createElement(d.default, {
                                    theme: i,
                                    active: n === this.props.activeMsg,
                                    msg: n,
                                    containerRef: e => {
                                        this._setThumbRef(e, n.id.toString()), n === this.props.activeMsg && this.props.onSetActiveThumb(e)
                                    },
                                    key: "media-".concat(n.id.id),
                                    onClick: () => {
                                        this.props.onSelectThumb(n)
                                    },
                                    preferPreview: !!this.state.msgIdToPreferPreview.get(n.id.toString())
                                }))
                            } else {
                                var s = this.props.activeMsg;
                                __LOG__(3, !0)(h(), JSON.stringify({
                                    type: n.type,
                                    isMedia: n.isMedia,
                                    startMsgType: s.type,
                                    startMsgIsMedia: s.isMedia
                                }))
                            }
                        })), a.push(l.createElement("div", {
                            className: c.default.mediaThumb,
                            key: "spinner-right"
                        }, this.props.mediaMsgs.queryMediaAfter ? l.createElement(u.default, {
                            stroke: 6,
                            size: 24
                        }) : null)), a.unshift(l.createElement("div", {
                            className: c.default.mediaThumb,
                            key: "spinner-left"
                        }, this.props.mediaMsgs.queryMediaBefore ? l.createElement(u.default, {
                            stroke: 6,
                            size: 24
                        }) : null)), a.push(l.createElement("div", {
                            className: c.default.thumbPadding,
                            key: "padding-right"
                        })), a.unshift(l.createElement("div", {
                            className: c.default.thumbPadding,
                            key: "padding-left"
                        })), a
                    }, this._thumbRefs = {}, this.handleScroll = (0, r.default)(this._handleScroll, 100), this.state = {
                        msgIdToPreferPreview: this._getMsgIdToPreferPreview()
                    }
                }
                componentWillUnmount() {
                    this.handleScroll.cancel()
                }
                render() {
                    var e = this.getThumbs();
                    return l.createElement("div", {
                        className: c.default.thumbsContainer,
                        ref: this.props.setRefThumbsContainer
                    }, l.createElement("div", {
                        className: c.default.scrollContainer,
                        dir: "ltr"
                    }, l.createElement("div", {
                        onScroll: this.onScroll,
                        className: c.default.viewerThumbs,
                        ref: this.props.setRefThumbs
                    }, e)))
                }
            }
            t.default = p
        },
        60703: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(79711)),
                l = n(a(9386)),
                o = n(a(17957)),
                d = n(a(72836)),
                c = a(40263);
            class u extends s.PureComponent {
                constructor(e) {
                    super(e), this._handleOK = () => {
                        var {
                            selectedValue: e
                        } = this.state;
                        null != e && this.props.onSelect(e), this.closeModal()
                    }, this._handleChange = e => {
                        var {
                            target: t
                        } = e;
                        t instanceof HTMLInputElement && this.setState({
                            selectedValue: parseInt(t.value, 10)
                        })
                    }, this.closeModal = () => {
                        r.default.closeModal()
                    }, this.state = {
                        selectedValue: e.initialValue
                    }
                }
                render() {
                    var {
                        options: e,
                        explanation: t
                    } = this.props, a = e.map((({
                        value: e,
                        label: t
                    }) => s.createElement("li", {
                        key: "setting-".concat(e)
                    }, s.createElement("label", {
                        className: d.default.label
                    }, s.createElement("input", {
                        type: "radio",
                        className: d.default.input,
                        value: String(e),
                        checked: e === this.state.selectedValue,
                        onChange: this._handleChange
                    }), t))));
                    return s.createElement(l.default, {
                        title: this.props.title,
                        okText: o.default.t(490),
                        onOK: this._handleOK,
                        onCancel: this.closeModal
                    }, t ? s.createElement(c.TextDiv, {
                        theme: "muted",
                        className: d.default.explanation
                    }, t) : null, s.createElement("form", null, s.createElement("ol", null, a)))
                }
            }
            t.default = u
        },
        684: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(a(2784)),
                r = n(a(52668)),
                l = n(a(41353)),
                o = n(a(79711)),
                d = n(a(9386)),
                c = n(a(52737)),
                u = n(a(50935)),
                h = n(a(91581)),
                p = a(35387),
                f = a(95585),
                m = n(a(17957)),
                g = n(a(40210)),
                v = n(a(45679)),
                E = n(a(40207)),
                _ = a(40263);
            var C = (0, E.default)((function({
                contact: {
                    verifiedLevel: e,
                    verifiedName: t
                }
            }) {
                var a = (0, f.getBusinessFaqUrl)(),
                    n = !c.default.isSMB;
                (0, s.useEffect)((() => {
                    n && new g.default.BannerEvent({
                        bannerType: g.default.BANNER_TYPES.CROSS_SELL_PROFILE_INTERSTITIAL,
                        bannerOperation: g.default.BANNER_OPERATIONS.SHOWN
                    }).commit()
                }), [n]);
                var i = e === u.default.VERIFIED_LEVEL.HIGH ? m.default.t(1749, {
                    businessName: t
                }) : m.default.t(1748);
                return s.createElement(d.default, {
                    title: m.default.t(1751),
                    onOK: () => {
                        o.default.closeModal(), n && new g.default.BannerEvent({
                            bannerType: g.default.BANNER_TYPES.CROSS_SELL_PROFILE_INTERSTITIAL,
                            bannerOperation: g.default.BANNER_OPERATIONS.DISMISS
                        }).commit()
                    },
                    okText: m.default.t(1680)
                }, s.createElement(h.default, {
                    text: i
                }), " ", s.createElement(l.default, {
                    href: a,
                    onClick: e => {
                        e.preventDefault(), o.default.closeModal(), setTimeout((() => (0, p.openExternalLink)(a)), 10)
                    }
                }, m.default.t(825)), n && s.createElement("div", {
                    className: r.default.footerNote
                }, s.createElement(_.TextSpan, {
                    theme: "muted",
                    size: "13"
                }, m.default.t(1752), s.createElement("br", null), s.createElement(l.default, {
                    onClick: e => {
                        e.preventDefault(), o.default.closeModal(), new g.default.BannerEvent({
                            bannerType: g.default.BANNER_TYPES.CROSS_SELL_PROFILE_INTERSTITIAL,
                            bannerOperation: g.default.BANNER_OPERATIONS.CLICK
                        }).commit(), setTimeout((() => o.default.openModal(s.createElement(v.default, null))), 200)
                    },
                    className: r.default.getTheAppLink
                }, m.default.t(1750)))))
            }), {
                contact: ["verifiedLevel", "verifiedName"]
            }, {}, !0);
            t.default = C
        },
        45679: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                return s.createElement(o.default, {
                    title: u.default.t(1755),
                    onOK: () => {
                        new h.default.BannerEvent({
                            bannerType: h.default.BANNER_TYPES.CROSS_SELL_PROFILE_INTERSTITIAL,
                            bannerOperation: h.default.BANNER_OPERATIONS.DISMISS
                        }).commit(), l.default.closeModal()
                    },
                    okText: u.default.t(1529)
                }, s.createElement(p.default, null), s.createElement("p", null, s.createElement(d.default, {
                    text: u.default.t(1753)
                })), s.createElement("br", null), s.createElement("p", null, s.createElement(d.default, {
                    text: u.default.t(1754)
                }), " ", s.createElement(r.default, {
                    href: f,
                    onClick: e => {
                        e.preventDefault(), l.default.closeModal(), setTimeout((() => (0, c.openExternalLink)(f)), 10)
                    }
                }, u.default.t(825))))
            }, t.WHATSAPP_BUSINESS_URL = void 0;
            var s = i(a(2784)),
                r = n(a(41353)),
                l = n(a(79711)),
                o = n(a(9386)),
                d = n(a(91581)),
                c = a(35387),
                u = n(a(17957)),
                h = n(a(40210)),
                p = n(a(81823)),
                f = "https://www.whatsapp.com/business";
            t.WHATSAPP_BUSINESS_URL = f
        },
        81823: (e, t, a) => {
            "use strict";
            var n = a(93291),
                i = a(14859);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                var e = (0, r.useRef)(null),
                    t = (0, r.useRef)(null),
                    {
                        theme: a
                    } = (0, r.useContext)(c.default),
                    n = "dark" === a;
                return (0, r.useEffect)((() => (null != e.current && (t.current = new o.default(e.current, {
                    text: "https://www.whatsapp.com/business/download",
                    colorDark: "#122e31",
                    colorLight: "#ffffff",
                    width: l.default.QR_EDGE / 2,
                    height: l.default.QR_EDGE / 2,
                    typeNumber: 4,
                    correctLevel: o.default.CorrectLevel.H
                })), () => {
                    null != t.current && (t.current.clear(), t.current = null, e.current = null)
                })), [n]), r.createElement("div", {
                    className: d.default.wrapper
                }, r.createElement("div", {
                    ref: e,
                    className: (0, s.default)(d.default.code, {
                        [d.default.codeDarkMode]: n
                    })
                }, r.createElement(u, {
                    theme: a
                })))
            };
            var s = i(a(72779)),
                r = n(a(2784)),
                l = i(a(50935)),
                o = i(a(88120)),
                d = i(a(40772)),
                c = i(a(2220));

            function u() {
                return r.createElement("div", {
                    className: d.default.codeLogo
                }, r.createElement("svg", {
                    width: "100%",
                    viewBox: "0 0 50 50",
                    xmlns: "http://www.w3.org/2000/svg"
                }, r.createElement("path", {
                    d: "M42.6776 42.6779C37.9558 47.3997 31.6777 50.0001 24.9999 50.0001C21.0047 50.0001 17.0541 49.0389 13.5244 47.2141L0.601068 49.3339L2.72832 36.3645C0.941278 32.8647 0 28.9525 0 25.0001C0 18.3223 2.60042 12.0443 7.32229 7.32237C12.0442 2.6005 18.3221 0 24.9999 0C31.6777 0 37.9558 2.6005 42.6776 7.32237C47.3995 12.0443 50 18.3223 50 25.0001C50 31.678 47.3995 37.9558 42.6776 42.6779ZM24.9999 4.33778C13.6067 4.33778 4.33772 13.607 4.33772 25.0001C4.33772 28.4792 5.21935 31.9192 6.8868 34.9487L7.24853 35.6054L5.85915 44.0756L14.2959 42.6918L14.9565 43.0601C18.0107 44.7624 21.4837 45.6622 24.9999 45.6622C36.3932 45.6622 45.6622 36.3933 45.6622 25.0001C45.6622 13.607 36.3932 4.33778 24.9999 4.33778ZM31.1133 24.3614C32.4522 24.9804 34.1536 26.3725 34.1208 29.3117C34.0749 33.4266 31.2191 35.6542 27.2744 35.6542H19.4594H18.3042C17.5079 35.6542 16.8645 35.0053 16.8713 34.2092L17.0344 15.0573C17.041 14.2714 17.6794 13.6377 18.4652 13.6366L27.1493 13.6256C31.4651 13.6256 33.9598 16.039 33.9177 19.8134C33.8903 22.2579 32.2484 23.8355 31.1133 24.3614ZM26.766 17.4622H21.3643L21.3076 22.5361H26.7093C28.5347 22.5361 29.5672 21.5152 29.584 19.9992C29.6009 18.4831 28.5915 17.4622 26.766 17.4622ZM26.9444 26.4035H21.2643L21.2038 31.8178H26.884C28.8333 31.8178 29.7752 30.5802 29.792 29.0952C29.8085 27.6101 28.8939 26.4035 26.9444 26.4035Z",
                    fill: "currentColor"
                })))
            }
        },
        17565: (e, t, a) => {
            "use strict";
            var n = a(14859),
                i = a(93291);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var {
                    onClick: t
                } = e;
                return s.createElement(r.default, {
                    onClick: t,
                    side: s.createElement(d.default, {
                        name: "lock",
                        className: l.default.icon
                    }),
                    multiline: !0
                }, s.createElement("div", {
                    className: l.default.header
                }, s.createElement(c.TextSpan, {
                    theme: "title"
                }, o.default.t(1309))), s.createElement(c.TextDiv, {
                    theme: "muted"
                }, o.default.t(1308)))
            };
            var s = i(a(2784)),
                r = n(a(67059)),
                l = n(a(94354)),
                o = n(a(17957)),
                d = n(a(82631)),
                c = a(40263)
        },
        44661: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                if (e.size !== t.size) return !1;
                for (var [a, n] of e)
                    if (t.get(a) !== n) return !1;
                return !0
            }
        },
        35101: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                container: "_2kOFZ",
                block: "RYIWw",
                main: "_10szZ",
                side: "_3KoVD",
                multiline: "_3JrO0"
            }
        },
        64485: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                header: "pZ7LD",
                chevronIcon: "rRKDJ",
                ephemeralIcon: "_1WLw0"
            }
        },
        87793: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                msg: "_3rdbB",
                text: "_3U8HP",
                bubble: "_2wvOi",
                author: "_6dcVq",
                hasSuspiciousLinks: "_19kns",
                hasAuthor: "_1OGhb",
                suspiciousLabel: "gQUJI"
            }
        },
        51581: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                wrapper: "_29uOU"
            }
        },
        8444: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                section: "QNaXM",
                control: "_1HA3p"
            }
        },
        92963: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                muteTextContainer: "_11lVP",
                nuxContainer: "_2065p",
                flatListContainer: "l8-Rl",
                btnClose: "Yvbln",
                nuxHeader: "eoOdQ",
                nuxContent: "_1leJV",
                nuxIcon: "_1pV3Q",
                nuxText: "_29ak9"
            }
        },
        68214: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                body: "_33SrD",
                photo: "_2lCi8",
                chevron: "_2oBEb"
            }
        },
        23279: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                contactBusinessInfo: "_3kWnf",
                contactBusinessInfoSpinner: "_3cDIk",
                dataRow: "wGgmc",
                businessHoursRow: "_3QoFx",
                businessHoursDay: "_2ImEI",
                businessHoursHours: "_3ZHqN",
                businessHoursChevron: "_1oBhF",
                flipSvg: "NPymp",
                dataRowIcon: "_2gGSv",
                dataRowText: "rn_1d",
                businessTitleText: "_3kecW",
                businessMarker: "_38M3x",
                verifiedLabel: "_1rAnz",
                businessMap: "_3RNY_",
                address: "_3gChR",
                link: "_3d4tA",
                infoIcon: "_1P52c"
            }
        },
        87335: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                body: "_1kkcj",
                avatar: "_1Qz61",
                nameSecondary: "_1TFjN",
                screenName: "_3e1tx",
                businessVname: "_3oeAe",
                icon: "_2mfHr",
                titleAbout: "NKhhL",
                chevron: "_2KrN8"
            }
        },
        94354: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                header: "_26JZV",
                icon: "_1rtCQ"
            }
        },
        83219: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                body: "_2zCWg",
                avatar: "bnO5E",
                description: "_3NATg",
                nameSecondary: "_2VBEG",
                chevron: "pQbiR",
                iconSearch: "_32gq5",
                title: "lOB7J",
                dogfoodingGroupBannerInternalOnly: "_3o6i8"
            }
        },
        50739: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                header: "_1bhv2",
                restrictText: "_1iS3E"
            }
        },
        66558: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                multimediaGallery: "_2OJCz",
                column: "_3uBgi",
                menuItem: "_2-q8E",
                active: "_2Rdwt",
                menuTabsLists: "_1xOYT",
                threeTabs: "HDR8D",
                fourTabs: "_2Ov65"
            }
        },
        47665: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                mediaViewerPlaceholder: "viFjD",
                imageAudio: "_2PyNo",
                mediaViewerAudio: "_1cxdm"
            }
        },
        68421: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                thumbsContainer: "_1O9tq",
                scrollContainer: "_7fCtq",
                viewerThumbs: "_2gaFk",
                mediaThumb: "_2P46q",
                thumbPadding: "fAqrI"
            }
        },
        72836: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                label: "u20ZK",
                input: "_3dBIO",
                explanation: "osDhr"
            }
        },
        52668: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                footerNote: "aiKUN",
                getTheAppLink: "_1m5bt"
            }
        },
        40772: (e, t, a) => {
            "use strict";
            a.r(t), t.default = {
                wrapper: "_2c4cP",
                code: "_19Fja",
                codeDarkMode: "_1BVwF",
                codeLogo: "_1PBlf"
            }
        }
    }
]);